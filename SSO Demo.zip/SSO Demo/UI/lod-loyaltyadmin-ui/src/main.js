import './set-public-path';
import Vue from 'vue';
import singleSpaVue from 'single-spa-vue';
import vuetify from './plugins/vuetify';
import App from './App.vue';
import router from './router';
import { MiniCard } from '@brierley/SharedComponents';
import store from './store/index.js';
import filter from './feature-modules/Viewusers/filters/filters';

// Set Base URL
import { ApiClient } from '@brierley/SharedComponents';
import * as VeeValidate from 'vee-validate';
import { required, email } from 'vee-validate/dist/rules';
import * as rules from 'vee-validate/dist/rules';
import { ValidationProvider, ValidationObserver, extend } from 'vee-validate';
import { addTypeEntityOrganizationObject } from './i18n/language.js';
Vue.prototype.$http = new ApiClient(process.env.VUE_APP_LOYALTY_BASEURL).client;

Vue.config.productionTip = false;
// i18n config start
import VueI18n from 'vue-i18n';
Vue.use(VueI18n);
let lng = localStorage.getItem('language');
if (lng === null || lng === '') {
  localStorage.setItem('language', 'en');
}
const i18n = new VueI18n({
  locale: localStorage.getItem('language'),
  addTypeEntityOrganizationObject
});

Object.keys(rules).forEach(rule => {
  extend(rule, {
    ...rules[rule],
    message: ''
  });
});
extend('required', {
  ...required,
  message: 'This field is required'
});

extend('nameCheck', {
  params: ['programData', 'indexData'],
  validate: (value, { programData, indexData }) => {
    if (programData.length > 1) {
      if (value) {
        const CurrentList = [...programData];
        CurrentList.splice(indexData, 1);
        let testObject = CurrentList.find(x => x.programId === value);
        if (testObject) {
          return false;
        }
      }
    }
    return true;
  }
});

extend('uppercaseletter', {
  params: ['uppercase'],
  validate (uppercase) {
    if (uppercase.search(/[A-Z]/g) === -1) {
      return false;
    }
    return true;
  },
  message: 'Password must contain uppercase letters'
});

extend('orgNameCheck', {
  params: ['orgData', 'indexData'],
  validate: (value, { orgData, indexData }) => {
    if (orgData.length > 1) {
      if (value) {
        const CurrentList = [...orgData];
        CurrentList.splice(indexData, 1);
        let testObject = CurrentList.find(x => x.name === value);
        if (testObject) {
          return false;
        }
      }
    }
    return true;
  }
});

extend('passwordLength', {
  params: ['minimum'],
  validate (minimum) {
    if (minimum.length < 8) {
      return false;
    }
    return true;
  },

  message: 'Length must be greater than 8 characters'
});

extend('nameLength', {
  params: ['minimum'],
  validate (minimum) {
    if (minimum.length >= 51) {
      return false;
    }
    return true;
  },

  message: 'Name must be lesser than 50 characters'
});

extend('greaterThanOne', {
  params: ['minimum'],
  validate (minimum) {
    if (minimum < 1) {
      return false;
    }
    return true;
  },

  message: 'Fields must be greater than one'
});

extend('descLength', {
  params: ['minimum'],
  validate (minimum) {
    if (minimum.length >= 501) {
      return false;
    }
    return true;
  },

  message: 'Description must be lesser than 500 characters'
});

extend('atleastonenumber', {
  params: ['number'],
  validate (number) {
    if (number.search(/[0-9]/i) < 0) {
      return false;
    }
    return true;
  },
  message: 'Password must contain at least one number'
});
extend('specialchar', {
  params: ['character'],
  validate (character) {
    if (character.search(/[@#&]/g) === -1) {
      return false;
    }
    return true;
  },
  message: 'Password must contain at least 1 special character( @ # & )'
});

extend('email', {
  ...email
});
extend('length', {
  validate (val, len) {
    return val.length <= len.length
      ? true
      : `value must not be greater than${len.length}`;
  },
  params: ['length']
});

extend('alphaSpace', {
  params: ['alpha'],
  validate (alpha) {
    if (alpha.search(/^[A-Za-z ]+$/) === -1) {
      return false;
    }
    return true;
  },
  message: 'Alphabetic'
});

extend('alphaNumericOnly', value => {
  const pattern = /^[a-zA-Z0-9 ]*$/;
  return (
    pattern.test(value) || 'Please enter only letters A – Z and numbers 0-9'
  );
});
Vue.component('Validation-Observer', ValidationObserver);
Vue.component('ValidationProvider', ValidationProvider);
Vue.use(VeeValidate, { inject: false });
Vue.component('mini-card', MiniCard);

const vueLifecycles = singleSpaVue({
  Vue,
  appOptions: {
    render: h => h(App),
    el: '#loyaltyadmin',
    store,
    router,
    vuetify,
    i18n,
    filter
  }
});

export const validate = new Vue();
export const bootstrap = vueLifecycles.bootstrap;
export const mount = vueLifecycles.mount;
export const unmount = vueLifecycles.unmount;
