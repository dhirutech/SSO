import { setPublicPath } from 'systemjs-webpack-interop';

setPublicPath('loyaltyadmin');
