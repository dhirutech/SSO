<template>
  <v-row class="flex-column member-status-page" no-gutters>
    <v-col>
      <img
        class="member-status__diagram"
        src="@/assets/images/member-status-journey-diagram.png"
      />
    </v-col>
    <v-col
      class="member-status__panel"
      v-if="memberDefDataAttributes.memberStatus !== undefined"
    >
      <v-expansion-panels
        class="user-role-assignment-expansions"
        v-for="memberStatus in memberDefDataAttributes.memberStatus"
        :key="memberStatus.memberStatusId"
      >
        <v-expansion-panel v-if="memberStatus.memberStatusId === 4">
          <v-expansion-panel-header disable-icon-rotate>
            <div class="checkbox-block d-flex">
              <v-checkbox
                class="checkbox-custom"
                v-model="memberStatus.isSelected"
                :disabled="
                  memberStatus.isExists &&
                    memberDefDataAttributes.programStatus === 'Published'
                "
              ></v-checkbox>
            </div>
            <p class="font24 f600 bmb0">
              {{ memberStatus.memberStatusText }}
              <column-tooltip
                :header="$t('nonMemberTooltipHeader')"
                :content="$t('nonMemberTooltip')"
              />
            </p>
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <p class="label-text text-uppercase">
              {{ $t('configNonEnrollHeader') }}
            </p>
            <div class="member-status__panel-list">
              <ul>
                <li>{{ $t('optionallyConditionsForNonEnroll') }}</li>
                <li class="sub">{{ $t('memberStatusThroughApi') }}</li>
                <li class="sub">{{ $t('memberStatusThroughPortal') }}</li>
                <li>{{ $t('statusConditionsNonEnroll1') }}</li>
                <li>{{ $t('statusConditionsNonEnroll2') }}</li>
                <li>{{ $t('statusConditionsNonEnroll3') }}</li>
              </ul>
              <v-row
                no-gutters
                class="flex-column"
                v-for="(memberStatusDetail,
                index) in memberStatus.memberStatusLists"
                :key="index"
              >
                <v-col>
                  <v-checkbox
                    class="checkbox-custom checkbox-custom__light"
                    :label="memberStatusDetail.memberStatusFeatureDefText"
                    v-model="memberStatusDetail.isApplicable"
                    :disabled="
                      !memberStatusDetail.isConfigurable ||
                        (memberDefDataAttributes.programStatus ===
                          'Published' &&
                          memberStatusDetail.isExists)
                    "
                  ></v-checkbox>
                </v-col>
              </v-row>
            </div>
          </v-expansion-panel-content>
        </v-expansion-panel>
        <v-expansion-panel v-else-if="memberStatus.memberStatusId === 2">
          <v-expansion-panel-header disable-icon-rotate>
            <div class="checkbox-block d-flex">
              <v-checkbox
                class="checkbox-custom"
                v-model="memberStatus.isSelected"
                :disabled="
                  memberStatus.isExists &&
                    memberDefDataAttributes.programStatus === 'Published'
                "
              ></v-checkbox>
            </div>
            <p class="font24 f600 bmb0">
              {{ memberStatus.memberStatusText }}
              <column-tooltip
                :header="$t('preEnrollTooltipHeader')"
                :content="$t('preEnrollTooltip')"
              />
            </p>
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <p class="label-text text-uppercase">
              {{ $t('configPreEnrollHeader') }}
            </p>
            <div class="member-status__panel-list">
              <ul>
                <li>{{ $t('optionallyConditionsForPreEnroll') }}</li>
                <li class="sub">{{ $t('memberStatusThroughApiPreEnroll') }}</li>
                <li class="sub">
                  {{ $t('memberStatusThroughPortalPreEnroll') }}
                </li>
                <li>{{ $t('statusConditionsPreEnroll1') }}</li>
                <li>{{ $t('statusConditionsPreEnroll2') }}</li>
              </ul>
              <v-row
                no-gutters
                class="flex-column"
                v-for="(memberStatusDetail,
                index) in memberStatus.memberStatusLists"
                :key="index"
              >
                <v-col>
                  <v-checkbox
                    class="checkbox-custom checkbox-custom__light"
                    :label="memberStatusDetail.memberStatusFeatureDefText"
                    v-model="memberStatusDetail.isApplicable"
                    :disabled="
                      !memberStatusDetail.isConfigurable ||
                        (memberDefDataAttributes.programStatus ===
                          'Published' &&
                          memberStatusDetail.isExists)
                    "
                  ></v-checkbox>
                </v-col>
              </v-row>
            </div>
          </v-expansion-panel-content>
        </v-expansion-panel>
        <v-expansion-panel v-else-if="memberStatus.memberStatusId === 1">
          <v-expansion-panel-header disable-icon-rotate>
            <div class="checkbox-block d-flex">
              <v-checkbox
                class="checkbox-custom"
                v-model="memberStatus.isSelected"
                :disabled="true"
              ></v-checkbox>
            </div>
            <p class="font24 f600 bmb0">
              {{ memberStatus.memberStatusText }}
              <column-tooltip
                :header="$t('activeTooltipHeader')"
                :content="$t('activeTooltip')"
              />
            </p>
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <p class="label-text text-uppercase">
              {{ $t('configActiveHeader') }}
            </p>
            <div class="member-status__panel-list">
              <ul>
                <li>
                  {{ $t('optionallyConditionsForActive') }}
                </li>
                <li>
                  {{ $t('activeStatusCondition1') }}
                </li>
                <li>
                  {{ $t('activeStatusCondition2') }}
                </li>
                <li class="sub">
                  {{ $t('activeStatusCondition3') }}
                </li>
              </ul>
              <p class="label-text text-uppercase bml8 bmy4">
                {{ $t('activeStatusCondition4') }}
              </p>
              <ul>
                <li>
                  {{ $t('activeStatusCondition5') }}
                </li>
                <li>
                  {{ $t('activeStatusCondition6') }}
                </li>
                <li class="sub">{{ $t('firstName') }}</li>
                <li class="sub">{{ $t('lastName') }}</li>
                <li class="sub">{{ $t('pryEmail') }}</li>
                <li class="sub">{{ $t('pryPhone') }}</li>
                <li>
                  {{ $t('activeStatusCondition7') }}
                </li>
              </ul>
              <v-row
                no-gutters
                class="flex-column"
                v-for="(memberStatusDetail,
                index) in memberStatus.memberStatusLists"
                :key="index"
              >
                <v-col>
                  <v-checkbox
                    class="checkbox-custom checkbox-custom__light"
                    :label="memberStatusDetail.memberStatusFeatureDefText"
                    v-model="memberStatusDetail.isApplicable"
                    :disabled="
                      !memberStatusDetail.isConfigurable ||
                        (memberDefDataAttributes.programStatus ===
                          'Published' &&
                          memberStatusDetail.isExists)
                    "
                  ></v-checkbox>
                </v-col>
              </v-row>
            </div>
          </v-expansion-panel-content>
        </v-expansion-panel>
        <v-expansion-panel v-else-if="memberStatus.memberStatusId === 5">
          <v-expansion-panel-header disable-icon-rotate>
            <div class="checkbox-block d-flex">
              <v-checkbox
                class="checkbox-custom"
                v-model="memberStatus.isSelected"
                :disabled="
                  memberStatus.isExists &&
                    memberDefDataAttributes.programStatus === 'Published'
                "
              ></v-checkbox>
            </div>
            <p class="font24 f600 bmb0">
              {{ memberStatus.memberStatusText }}
              <column-tooltip
                :header="$t('lockedTooltipHeader')"
                :content="$t('lockedTooltip')"
              />
            </p>
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <p class="label-text text-uppercase">
              {{ $t('configLockedHeader') }}
            </p>
            <div class="member-status__panel-list">
              <ul>
                <li>
                  {{ $t('optionallyConditionsForLocked') }}
                </li>
                <li>
                  {{ $t('lockedStatusCondition1') }}
                </li>
                <li>{{ $t('lockedStatusCondition2') }}</li>
                <li>{{ $t('lockedStatusCondition3') }}</li>
                <li class="sub">
                  {{ $t('lockedStatusCondition4') }}
                </li>
                <li class="sub">{{ $t('lockedStatusCondition5') }}</li>
                <li>
                  {{ $t('lockedStatusCondition6') }}
                </li>
              </ul>
              <v-row
                no-gutters
                class="flex-column"
                v-for="(memberStatusDetail,
                index) in memberStatus.memberStatusLists"
                :key="index"
              >
                <v-col>
                  <v-checkbox
                    class="checkbox-custom checkbox-custom__light"
                    :label="memberStatusDetail.memberStatusFeatureDefText"
                    v-model="memberStatusDetail.isApplicable"
                    :disabled="
                      !memberStatusDetail.isConfigurable ||
                        (memberDefDataAttributes.programStatus ===
                          'Published' &&
                          memberStatusDetail.isExists)
                    "
                  ></v-checkbox>
                </v-col>
              </v-row>
            </div>
          </v-expansion-panel-content>
        </v-expansion-panel>
        <v-expansion-panel v-else-if="memberStatus.memberStatusId === 3">
          <v-expansion-panel-header disable-icon-rotate>
            <div class="checkbox-block d-flex">
              <v-checkbox
                class="checkbox-custom"
                v-model="memberStatus.isSelected"
                :disabled="true"
              ></v-checkbox>
            </div>
            <p class="font24 f600 bmb0">
              {{ memberStatus.memberStatusText }}
              <column-tooltip
                :header="$t('deactiveTooltipHeader')"
                :content="$t('deactiveTooltip')"
              />
            </p>
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <p class="label-text text-uppercase">
              {{ $t('configDeactiveHeader') }}
            </p>
            <div class="member-status__panel-list">
              <ul>
                <li>
                  {{ $t('optionallyConditionsForDeactive') }}
                </li>
                <li>
                  {{ $t('deactiveStatusCondition1') }}
                </li>
                <li>
                  {{ $t('deactiveStatusCondition2') }}
                </li>
                <li class="sub">
                  {{ $t('deactiveStatusCondition3') }}
                </li>
                <li>
                  {{ $t('deactiveStatusCondition4') }}
                </li>
              </ul>
              <v-row
                no-gutters
                class="flex-column"
                v-for="(memberStatusDetail,
                index) in memberStatus.memberStatusLists"
                :key="index"
              >
                <v-col>
                  <v-checkbox
                    class="checkbox-custom checkbox-custom__light"
                    :label="memberStatusDetail.memberStatusFeatureDefText"
                    v-model="memberStatusDetail.isApplicable"
                    :disabled="
                      !memberStatusDetail.isConfigurable ||
                        (memberDefDataAttributes.programStatus ===
                          'Published' &&
                          memberStatusDetail.isExists)
                    "
                  ></v-checkbox>
                </v-col>
              </v-row>
            </div>
          </v-expansion-panel-content>
        </v-expansion-panel>
        <v-expansion-panel v-else-if="memberStatus.memberStatusId === 6">
          <v-expansion-panel-header disable-icon-rotate>
            <div class="checkbox-block d-flex">
              <v-checkbox
                class="checkbox-custom"
                v-model="memberStatus.isSelected"
                :disabled="
                  memberStatus.isExists &&
                    memberDefDataAttributes.programStatus === 'Published'
                "
              ></v-checkbox>
            </div>
            <p class="font24 f600 bmb0">
              {{ memberStatus.memberStatusText }} (Future Program Enhancements)
              <column-tooltip
                :header="$t('forgottenTooltipHeader')"
                :content="$t('forgottenTooltip')"
              />
            </p>
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <p class="label-text text-uppercase">
              {{ $t('configForgottenHeader') }}
            </p>
            <div class="member-status__panel-list">
              <ul>
                <li>
                  {{ $t('optionallyConditionsForForgotten') }}
                </li>
                <!-- <li>
                  {{ $t('forgottenStatusCondition1') }}
                </li> -->
              </ul>
              <v-row
                no-gutters
                class="flex-column"
                v-for="(memberStatusDetail,
                index) in memberStatus.memberStatusLists"
                :key="index"
              >
                <v-col>
                  <v-checkbox
                    class="checkbox-custom checkbox-custom__light"
                    :label="memberStatusDetail.memberStatusFeatureDefText"
                    v-model="memberStatusDetail.isApplicable"
                    :disabled="
                      !memberStatusDetail.isConfigurable ||
                        (memberDefDataAttributes.programStatus ===
                          'Published' &&
                          memberStatusDetail.isExists)
                    "
                  ></v-checkbox>
                </v-col>
              </v-row>
            </div>
          </v-expansion-panel-content>
        </v-expansion-panel>
        <v-expansion-panel v-else-if="memberStatus.memberStatusId === 7">
          <v-expansion-panel-header disable-icon-rotate>
            <div class="checkbox-block d-flex">
              <v-checkbox
                class="checkbox-custom"
                v-model="memberStatus.isSelected"
                :disabled="
                  memberStatus.isExists &&
                    memberDefDataAttributes.programStatus === 'Published'
                "
              ></v-checkbox>
            </div>
            <p class="font24 f600 bmb0">
              {{ memberStatus.memberStatusText }}
              <column-tooltip
                :header="$t('terminatedTooltipHeader')"
                :content="$t('terminatedTooltip')"
              />
            </p>
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <p class="label-text text-uppercase">
              {{ $t('configTerminatedHeader') }}
            </p>
            <div class="member-status__panel-list">
              <ul>
                <li>
                  {{ $t('optionallyConditionsForTerminated') }}
                </li>
                <!-- <li>
                  {{ $t('terminatedStatusCondition1') }}
                </li> -->
              </ul>
              <v-row
                no-gutters
                class="flex-column"
                v-for="(memberStatusDetail,
                index) in memberStatus.memberStatusLists"
                :key="index"
              >
                <v-col>
                  <v-checkbox
                    class="checkbox-custom checkbox-custom__light"
                    :label="memberStatusDetail.memberStatusFeatureDefText"
                    v-model="memberStatusDetail.isApplicable"
                    :disabled="
                      !memberStatusDetail.isConfigurable ||
                        (memberDefDataAttributes.programStatus ===
                          'Published' &&
                          memberStatusDetail.isExists)
                    "
                  ></v-checkbox>
                </v-col>
              </v-row>
            </div>
          </v-expansion-panel-content>
        </v-expansion-panel>
        <v-expansion-panel v-else-if="memberStatus.memberStatusId === 8">
          <v-expansion-panel-header disable-icon-rotate>
            <div class="checkbox-block d-flex">
              <v-checkbox
                class="checkbox-custom"
                v-model="memberStatus.isSelected"
                :disabled="
                  memberStatus.isExists &&
                    memberDefDataAttributes.programStatus === 'Published'
                "
              ></v-checkbox>
            </div>
            <p class="font24 f600 bmb0">
              {{ memberStatus.memberStatusText }} (Future Program Enhancements)
              <column-tooltip
                :header="$t('mergedTooltipHeader')"
                :content="$t('mergedTooltip')"
              />
            </p>
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <p class="label-text text-uppercase">
              {{ $t('configMergedHeader') }}
            </p>
            <div class="member-status__panel-list">
              <ul>
                <li>
                  {{ $t('optionallyConditionsForMerged') }}
                </li>
                <li>
                  {{ $t('mergedStatusCondition1') }}
                </li>
              </ul>

              <v-row
                no-gutters
                class="flex-column"
                v-for="(memberStatusDetail,
                index) in memberStatus.memberStatusLists"
                :key="index"
              >
                <v-col>
                  <v-checkbox
                    class="checkbox-custom checkbox-custom__light"
                    :label="memberStatusDetail.memberStatusFeatureDefText"
                    v-model="memberStatusDetail.isApplicable"
                    :disabled="
                      !memberStatusDetail.isConfigurable ||
                        (memberDefDataAttributes.programStatus ===
                          'Published' &&
                          memberStatusDetail.isExists)
                    "
                  ></v-checkbox>
                </v-col>
              </v-row>
            </div>
          </v-expansion-panel-content>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-col>
  </v-row>
</template>

<script>
import { mapState } from 'vuex';
import ColumnTooltip from './ColumnTooltip';
import { memberStatusDefObj } from '../../../../i18n/language';

export default {
  i18n: memberStatusDefObj,
  components: {
    ColumnTooltip
  },
  data () {
    return {};
  },
  computed: {
    ...mapState('memberDefinitionModule', ['memberDefDataAttributes'])
  }
};
</script>
<style lang="scss">
.member-status {
  &__diagram {
    max-width: 100%;
  }
  &__panel {
    margin-top: 24px;
    .v-expansion-panels {
      .v-expansion-panel {
        background-color: white !important;
        &-content {
          &__wrap {
            padding: 0 24px !important;
          }
        }
        .mdi-information-outline {
          color: #0628b1;
        }
        .mdi-chevron-down {
          &:before {
            font-family: 'Material Icons';
            content: 'add';
          }
        }
        &--active {
          .mdi-chevron-down {
            &:before {
              font-family: 'Material Icons';
              content: 'remove';
            }
          }
        }
      }
    }
    &-list {
      background: whitesmoke;
      padding: 40px 24px;
      border: solid 1px #e9e9e9;
      ul {
        list-style: none;
        margin: 0;
        padding: 0;
        li {
          position: relative;
          padding-left: 54px;
          margin-bottom: 24px;
          &:before {
            content: '';
            width: 9px;
            height: 9px;
            background: #4d4d4d;
            position: absolute;
            left: 8px;
            top: 8px;
          }
          &.sub {
            margin-left: 54px;
            margin-bottom: 24px;
            &:before {
              width: 7px;
              height: 7px;
              z-index: 1;
              box-shadow: -2px 1px 0px #9a9a9a;
            }
          }
        }
      }
      .checkbox-custom {
        display: inline-flex;
        margin-bottom: 8px !important;
        .v-label {
          padding-left: 54px;
        }
      }
    }
  }
}
</style>
