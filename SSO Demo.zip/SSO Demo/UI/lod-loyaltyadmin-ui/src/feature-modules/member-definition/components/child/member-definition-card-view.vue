<template>
  <v-row class="mem-def__card-view">
    <v-col md="6" v-for="(item,index) in memberDefData" :key="index">
      <brierley-card >
        <template v-slot:header>
          <h2 class="elipsis-fullwidth" :title="item.definitionName">{{item.definitionName}}</h2>
        </template>
        <template v-slot:body>
          <p class="bmt3">
            <strong>{{ $t("description") }}:</strong>
          </p>
          <p class="elipsis-twoline" :title="item.description">
            {{item.description}}
          </p>
          <p class="bmt3 bmb0">
            <strong>{{ $t("mappedProgram") }}:</strong>
            <span> {{item.mappedProgram}}</span>
          </p>
        </template>
        <template v-slot:footer>
          <v-col class="mt-n8">
            <v-row no-gutters>
              <v-col sm="8">
                <brierley-card-icons class="bmt5 bpa0">
                  <template v-slot:action-icons>
                    <span data-qe-id="mem_def_btn_card_view_details" @click="editMemDef(item)" class="active">
                      <v-icon>fe fe-eye</v-icon>
                      <span class="viewdetails-icon">{{ $t("viewDetails") }}</span>
                    </span>
                    <span data-qe-id="mem_def_btn_card_view_edit" @click="editMemDef(item)">
                      <v-icon>fe fe-edit</v-icon>
                      <span class="edit-icon">{{ $t("edit") }}</span>
                    </span>
                  </template>
                </brierley-card-icons>
              </v-col>
              <v-col sm="4">
                <p>
                  <strong>{{ $t("reviewStatus") }}</strong>
                </p>
                <brierleyStatus v-if="item.isReviewed" status="Verified"></brierleyStatus>
                <brierleyStatus v-else status="Not Verified"></brierleyStatus>
              </v-col>
            </v-row>
          </v-col>
        </template>
      </brierley-card>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyCard, BrierleyCardIcons, BrierleyStatus } from '@brierley/SharedComponents';
import { memberDefinitionGridViewObj } from '../../../../i18n/language';

export default {
  i18n: memberDefinitionGridViewObj,
  components: {
    BrierleyCard,
    BrierleyCardIcons,
    BrierleyStatus,
  },
  data () {
    return {};
  },
  props: {
    memberDefData: {
      type: Array
    }
  },
  methods: {
    editMemDef (item) {
      this.$emit('edit-member-definition', item);
      window.scrollTo(0, 0);
    }
  },
};
</script>
