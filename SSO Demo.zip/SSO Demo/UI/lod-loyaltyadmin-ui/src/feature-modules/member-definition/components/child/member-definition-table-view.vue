<template>
  <brierley-table-module class="md-card-view">
    <template v-slot:tablehead>
      <tr>
        <th v-for="item in header" :key="item.value" :width="item.width">
          {{ item.text }}
        </th>
      </tr>
    </template>
    <template v-slot:tablebody>
      <tr v-for="(memberItem, index) in memberDefData" :key="index">
        <td>
          <h4
            class="primary-text font15 text-uppercase fbold elipsis-fullwidth"
            :title="memberItem.definitionName"
          >
            {{ memberItem.definitionName }}
          </h4>
        </td>
        <td>{{ memberItem.mappedProgram }}</td>
        <td>
          <p class="elipsis-twoline bmb0" :title="memberItem.description">
            {{ memberItem.description }}
          </p>
        </td>
        <td>
          <brierleyStatus
            v-if="memberItem.isReviewed"
            status="Verified"
          ></brierleyStatus>
          <brierleyStatus v-else status="Not Verified"></brierleyStatus>
          <v-row
            class="d-flex d-inline-flex hover-actions width-auto"
            no-gutters
          >
            <v-col>
              <brierleyCardIcons>
                <template v-slot:action-icons>
                  <span data-qe-id="mem_def_btn_view_details" class="active" @click="editMemDef(memberItem)">
                    <v-icon>fe fe-eye</v-icon>
                    <span class="viewdetails-icon">{{ $t("viewDetails") }}</span>
                  </span>
                  <span data-qe-id="mem_def_btn_edit" @click="editMemDef(memberItem)">
                    <v-icon>fe fe-edit</v-icon>
                    <span class="edit-icon">{{ $t("edit") }}</span>
                  </span>
                </template>
              </brierleyCardIcons>
            </v-col>
          </v-row>
        </td>
      </tr>
    </template>
  </brierley-table-module>
</template>
<script>
import {
  BrierleyTableModule,
  BrierleyCardIcons,
  BrierleyStatus
} from '@brierley/SharedComponents';
import { memberDefinitionTableViewObj } from '../../../../i18n/language';

export default {
  i18n: memberDefinitionTableViewObj,
  components: {
    BrierleyTableModule,
    BrierleyCardIcons,
    BrierleyStatus
  },
  data () {
    return {
      header: [
        {
          text: this.$t('definitionName'),
          width: '28%',
        },
        {
          text: this.$t('mappedProgram'),
          width: '20%'
        },
        {
          text: this.$t('description'),
          width: '35%'
        },
        {
          text: this.$t('reviewStatus'),
          width: '17%',
        },
      ],
    };
  },
  props: {
    memberDefData: {
      type: Array
    }
  },
  methods: {
    editMemDef (memberItem) {
      this.$emit('edit-member-definition', memberItem);
      window.scrollTo(0, 0);
    }
  }
};
</script>
<style lang="scss">
.hover-actions {
  &.width-auto {
    width: 100% !important;
  }
}
.md-card-view table td {
  vertical-align: middle !important;
}
</style>
