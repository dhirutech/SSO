<template>
  <brierley-inner-view>
    <template v-slot:header>
      <span class="inner-head text-uppercase">
        {{ $t("memberDefinitionTitle") }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        data-qe-id="mem_def_btn_close_header"
        class="no-ripple"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>{{ $t("close") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <brierley-form-title class="bmt3" :formTitle="$t('memberDefinitionFormTitle')" :showSteps="false"></brierley-form-title>
      <v-row no-gutters class="bmt4 bmb1 align-center">
        <v-col>
          <h4 class="font15 text-uppercase fbold">{{ $t("memberDefinitionList") }}</h4>
        </v-col>
        <v-col class="text-right">
          <brierley-view-option :viewList="viewList" @viewChanged="viewType = $event" />
        </v-col>
      </v-row>
      <div v-if="viewType == 'grid_view'">
        <member-definition-grid-view @edit-member-definition="editMemberDefinition" :memberDefData="memberDefData"></member-definition-grid-view>
      </div>
      <div v-if="viewType == 'table_view'">
        <member-definition-table-view @edit-member-definition="editMemberDefinition" :memberDefData="memberDefData"></member-definition-table-view>
      </div>
      <div v-if="viewType == 'card_view'">
        <member-definition-card-view @edit-member-definition="editMemberDefinition" :memberDefData="memberDefData"></member-definition-card-view>
      </div>
    </template>

    <template v-slot:footer>
      <v-btn
        text
        class="primaryctabtn no-ripple"
        data-qe-id="mem_def_btn_close"
        @click.native="$router.push('/gettingstarted')"
        >{{ $t("close") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>

<script>
import { BrierleyInnerView, BrierleyFormTitle, BrierleyViewOption } from '@brierley/SharedComponents';
import MemberDefinitionGridView from './child/member-definition-grid-view';
import MemberDefinitionCardView from './child/member-definition-card-view';
import MemberDefinitionTableView from './child/member-definition-table-view';
import { mapState } from 'vuex';
import { memberDefinitionLanguageObj } from '../../../i18n/language';

export default {
  i18n: memberDefinitionLanguageObj,
  components: {
    BrierleyInnerView,
    BrierleyFormTitle,
    BrierleyViewOption,
    MemberDefinitionGridView,
    MemberDefinitionCardView,
    MemberDefinitionTableView,
  },
  data () {
    return {
      viewType: 'grid_view',
      viewList: [
        { key: 'grid_view', icon: 'calendar_view_day', label: 'Grid view' },
        { key: 'table_view', icon: 'table_chart', label: 'Table view' },
        { key: 'card_view', icon: 'view_module', label: 'Card view' },
      ],
    };
  },
  created () {
    this.$store.dispatch(
      'memberDefinitionModule/getMemberDefData',
    );
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  },
  computed: {
    ...mapState({
      memberDefData: (state) => state.memberDefinitionModule.memberDefData
    }),
  },
  methods: {
    editMemberDefinition (value) {
      this.$store.commit('memberDefinitionModule/setPresentMemberDefinition', value);
      this.$router.push('/loyaltyadmin/editMemberDefinition');
    }
  }
};
</script>
