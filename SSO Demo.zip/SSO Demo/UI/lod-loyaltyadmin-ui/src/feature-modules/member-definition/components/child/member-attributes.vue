<template>
  <v-row class="gen2-scroll-table mb-0" no-gutters>
    <v-col>
      <v-row class="table_container d-flex" no-gutters>
        <v-col class="table-center sticky-data-table gen2-forms form-light-bg">
          <v-flex class="sticky-data-table__scroll">
            <v-simple-table class="sticky-data-table__table">
              <thead>
                <tr>
                  <th class="sticky-first">
                    {{ $t("dataName") }}
                  </th>
                  <th class="largecol">
                    {{ $t("dataType") }}
                  </th>
                  <th>
                    {{ $t("maxLength") }}
                    <column-tooltip
                      :header="$t('maxLength')"
                      :content="$t('maxLengthContent')"
                    />
                  </th>
                  <th>
                    {{ $t("required") }}
                  </th>
                  <th>
                    {{ $t("unique") }}
                  </th>
                  <th class="largecol">
                    {{ $t("encryption") }}
                    <column-tooltip
                      :header="$t('encryption')"
                      :content="$t('encryptionContent')"
                    />
                  </th>
                  <th class="largecol">
                    {{ $t("defaultField") }}
                    <column-tooltip
                      :header="$t('defaultField')"
                      :content="$t('defaultFieldContent')"
                    />
                  </th>
                  <th class="largecol">
                    {{ $t("isDSARFlag") }}
                    <column-tooltip
                      :header="$t('isDSARFlag')"
                      :content="$t('isDSARFlagContent')"
                    />
                  </th>
                  <th class="largecol">
                    {{ $t("isRTBFFlag") }}
                    <column-tooltip
                      :header="$t('isRTBFFlag')"
                      :content="$t('isRTBFFlagContent')"
                    />
                  </th>
                  <th class="largecol">
                    {{ $t("description") }}
                  </th>
                  <th class="sticky-last">
                    {{ $t("actions") }}
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(attribute, i) in memberAttributes" :key="i">
                  <td class="sticky-first">
                    <v-row class="content-info" no-gutters>
                      <v-col
                        v-if="
                          attribute.isSelected &&
                            memberDefDataAttributes.programStatus !==
                              'Published' &&
                            attribute.isPII === undefined
                        "
                      >
                        <v-text-field
                          :label="$t('dataName')"
                          class="mini-field"
                          v-model="attribute.dataName"
                          :error="dataNameRequired"
                          maxlength="50"
                          required
                          filled
                        ></v-text-field>
                      </v-col>
                      <v-col
                        v-else-if="attribute.extensionPropertyId === undefined"
                      >
                        {{ attribute.displayText }}
                      </v-col>
                      <v-col v-else>
                        {{ attribute.dataName }}
                      </v-col>
                      <v-col
                        md="auto"
                        class="align-self-center bml1"
                        v-if="
                          attribute.extensionPropertyId === undefined &&
                            attribute.isPII !== undefined
                        "
                      >
                        <v-icon v-if="attribute.isPII === 'Lock Icon'"
                          >lock</v-icon
                        >
                        <i
                          v-else-if="attribute.isPII === 'PII icon'"
                          class="v-icon pause-icon"
                        ></i>
                      </v-col>
                    </v-row>
                  </td>
                  <td>
                    <span
                      v-if="
                        attribute.isSelected &&
                          memberDefDataAttributes.programStatus !==
                            'Published' &&
                          attribute.isPII === undefined
                      "
                    >
                      <v-select
                        data-qe-id="data_type_field_selector"
                        :label="$t('dataType')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="attribute.dataType"
                        :error="datatypeRequired"
                        :items="dataTypes"
                        @change="changeDefault(attribute)"
                        filled
                      ></v-select>
                    </span>
                    <span v-else>
                      {{ attribute.dataType }}
                    </span>
                  </td>
                  <td>
                    <span
                      v-if="
                        attribute.isSelected &&
                          attribute.dataType === 'String' &&
                          attribute.isPII === undefined
                      "
                    >
                      <v-text-field
                        v-model="attribute.maxLength"
                        :label="$t('maxLength')"
                        class="mini-field"
                        :error="maxLengthRequired"
                        type="number"
                        min="1"
                        filled
                      ></v-text-field>
                    </span>
                    <span v-else>{{ attribute.maxLength }}</span>
                  </td>
                  <td>
                    <span>
                      {{ attribute.isRequired }}
                    </span>
                  </td>
                  <td>
                    <span>
                      {{ attribute.unique }}
                    </span>
                  </td>
                  <td>
                    <span
                      v-if="
                        attribute.isSelected &&
                          memberDefDataAttributes.programStatus !== 'Published'
                      "
                    >
                      <v-select
                        :label="$t('encryption')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="attribute.encryption"
                        :items="encryptions"
                        filled
                      ></v-select>
                    </span>
                    <span v-else>
                      {{ attribute.encryption }}
                    </span>
                  </td>
                  <td>
                    <span
                      v-if="
                        attribute.isSelected && attribute.isPII === undefined
                      "
                    >
                      <v-text-field
                        v-if="attribute.dataType === 'String'"
                        :label="$t('defaultField')"
                        :error="defaultValueRequired"
                        class="mini-field bmt-2"
                        ref="item.defaultValue"
                        v-model="attribute.defaultField"
                        maxlength="100"
                        filled
                      ></v-text-field>
                      <v-text-field
                        v-else-if="attribute.dataType === 'Number'"
                        :label="$t('defaultField')"
                        class="mini-field bmt-2"
                        :error="defaultValueRequired"
                        ref="item.defaultValue"
                        v-model="attribute.defaultField"
                        type="number"
                        min="1"
                        filled
                      ></v-text-field>
                      <v-text-field
                        v-else-if="attribute.dataType === 'Date'"
                        label="Default Field"
                        placeholder="mm/dd/yyyy"
                        class="mini-field bmt-2"
                        :error="defaultValueRequired"
                        ref="item.defaultValue"
                        v-model="attribute.defaultField"
                        filled
                      ></v-text-field>
                      <!-- <v-menu
                        ref="defaultFieldDateMenu"
                        v-else-if="attribute.dataType === 'Date'"
                        v-model="defaultFieldDateMenu"
                        :close-on-content-click="false"
                        :return-value.sync="defaultFieldDate"
                        transition="scale-transition"
                        offset-y
                        min-width="290px"
                      >
                        <template v-slot:activator="{ on }">
                          <v-text-field
                            :label="$t('defaultField')"
                            v-model="defaultFieldDateFormat"
                            v-on="on"
                            :error="defaultValueRequired"
                            class="mini-field bmt-2"
                            readonly
                            filled
                          ></v-text-field>
                        </template>
                        <v-date-picker
                          v-model="defaultFieldDate"
                          no-title
                          scrollable
                        >
                          <v-spacer></v-spacer>
                          <v-btn
                            text
                            color="primary"
                            @click="defaultFieldDateMenu = false"
                            >{{ $t("cancel") }}</v-btn
                          >
                          <v-btn
                            text
                            color="primary"
                            @click="
                              $refs.defaultFieldDateMenu[0].save(
                                defaultFieldDate
                              )
                            "
                            >{{ $t("ok") }}</v-btn
                          >
                        </v-date-picker>
                      </v-menu> -->
                      <v-select
                        data-qe-id="default_field_selector"
                        v-else-if="attribute.dataType === 'Boolean'"
                        :label="$t('defaultField')"
                        v-model="attribute.defaultField"
                        :items="booleans"
                        :error="defaultValueRequired"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        filled
                      ></v-select>
                    </span>
                    <span v-else>
                      {{ attribute.defaultField }}
                    </span>
                  </td>
                  <td>
                    <span v-if="attribute.isSelected">
                      <v-select
                        data-qe-id="is_dsar_flag_field_selector"
                        :label="$t('isDSARFlag')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="attribute.isDSARFlag"
                        :items="booleans"
                        filled
                      ></v-select>
                    </span>
                    <span v-else>
                      {{ attribute.isDSARFlag }}
                    </span>
                  </td>
                  <td>
                    <span v-if="attribute.isSelected">
                      <v-select
                        data-qe-id="is_rtbf_flag_field_selector"
                        :label="$t('isRTBFFlag')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="attribute.isRTBFFlag"
                        :items="booleans"
                        filled
                      ></v-select>
                    </span>
                    <span v-else>
                      {{ attribute.isRTBFFlag }}
                    </span>
                  </td>
                  <td>
                    <span
                      v-if="
                        attribute.isSelected && attribute.isPII === undefined
                      "
                    >
                      <v-text-field
                        :label="$t('description')"
                        class="mini-field"
                        v-model="attribute.description"
                        maxlength="50"
                        required
                        filled
                      ></v-text-field>
                    </span>
                    <span v-else>
                      {{ attribute.description }}
                    </span>
                  </td>
                  <td class="sticky-last">
                    <template v-if="attribute.isSelected">
                      <v-icon
                        color="#0628b1"
                        data-qe-id="mem_attr_btn_save"
                        @click="saveAttribute(attribute)"
                      >
                        {{ $t("save") }}
                      </v-icon>
                      <v-icon
                        color="#212121"
                        @click="cancelEditedAttribute(attribute)"
                        data-qe-id="mem_attr_btn_cancel"
                      >
                        {{ $t("cancel") }}
                      </v-icon>
                    </template>
                    <template v-else>
                      <v-icon
                        color="#0628b1"
                        @click="editAttribute(attribute)"
                        data-qe-id="mem_attr_btn_edit"
                      >
                        {{ $t("edit") }}
                      </v-icon>
                      <v-icon
                        color="#212121"
                        :disabled="
                          attribute.extensionPropertyId === undefined ||
                            (memberDefDataAttributes.programStatus ===
                              'Published' &&
                              attribute.extensionPropertyId !== 0)
                        "
                        @click="deleteAttribute(attribute, i)"
                        data-qe-id="mem_attr_btn_delete"
                      >
                        {{ $t("delete") }}
                      </v-icon>
                    </template>
                  </td>
                </tr>
                <tr v-for="tempAttr in tempAttributes" :key="tempAttr.id">
                  <td class="sticky-first">
                    <v-row class="content-info" no-gutters>
                      <v-col v-if="tempAttr.isSelected">
                        <v-text-field
                          :label="$t('dataName')"
                          class="mini-field"
                          v-model="tempAttr.dataName"
                          :error="dataNameRequired"
                          maxlength="50"
                          required
                          filled
                        ></v-text-field>
                      </v-col>
                    </v-row>
                  </td>
                  <td>
                    <span v-if="tempAttr.isSelected">
                      <v-select
                        data-qe-id="temp_data_type_field_selector"
                        :label="$t('dataType')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="tempAttr.dataType"
                        @change="changeDefault(tempAttr)"
                        :error="datatypeRequired"
                        :items="dataTypes"
                        filled
                      ></v-select>
                    </span>
                  </td>
                  <td>
                    <span
                      v-if="
                        tempAttr.isSelected && tempAttr.dataType === 'String'
                      "
                    >
                      <v-text-field
                        v-model="tempAttr.maxLength"
                        :label="$t('maxLength')"
                        class="mini-field"
                        :error="maxLengthRequired"
                        type="number"
                        min="1"
                        filled
                      ></v-text-field>
                    </span>
                  </td>
                  <td>
                    <span>
                      {{ tempAttr.required }}
                    </span>
                  </td>
                  <td>
                    <span>
                      {{ tempAttr.unique }}
                    </span>
                  </td>
                  <td>
                    <span v-if="tempAttr.isSelected">
                      <v-select
                        data-qe-id="encryption_field_selector"
                        :label="$t('encryption')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="tempAttr.encryption"
                        :items="encryptions"
                        filled
                      ></v-select>
                    </span>
                  </td>
                  <td>
                    <span v-if="tempAttr.isSelected">
                      <v-text-field
                        v-if="tempAttr.dataType === 'String'"
                        :label="$t('defaultField')"
                        :error="defaultValueRequired"
                        class="mini-field bmt-2"
                        ref="item.defaultValue"
                        v-model="tempAttr.defaultField"
                        maxlength="100"
                        filled
                      ></v-text-field>
                      <v-text-field
                        v-else-if="tempAttr.dataType === 'Number'"
                        :label="$t('defaultField')"
                        class="mini-field bmt-2"
                        :error="defaultValueRequired"
                        ref="item.defaultValue"
                        v-model="tempAttr.defaultField"
                        type="number"
                        min="1"
                        filled
                      ></v-text-field>
                      <v-text-field
                        v-else-if="tempAttr.dataType === 'Date'"
                        label="Default Field"
                        placeholder="mm/dd/yyyy"
                        class="mini-field bmt-2"
                        :error="defaultValueRequired"
                        ref="item.defaultValue"
                        v-model="tempAttr.defaultField"
                        filled
                      ></v-text-field>
                      <!-- <v-menu
                        ref="defaultFieldDateMenu"
                        v-else-if="tempAttr.dataType === 'Date'"
                        v-model="defaultFieldDateMenu"
                        :close-on-content-click="false"
                        :return-value.sync="defaultFieldDate"
                        transition="scale-transition"
                        offset-y
                        min-width="290px"
                      >
                        <template v-slot:activator="{ on }">
                          <v-text-field
                            :label="$t('defaultField')"
                            v-model="defaultFieldDateFormat"
                            v-on="on"
                            :error="defaultValueRequired"
                            class="mini-field bmt-2"
                            readonly
                            filled
                          ></v-text-field>
                        </template>
                        <v-date-picker
                          v-model="defaultFieldDate"
                          no-title
                          scrollable
                        >
                          <v-spacer></v-spacer>
                          <v-btn
                            text
                            color="primary"
                            @click="defaultFieldDateMenu = false"
                            >{{ $t("cancel") }}</v-btn
                          >
                          <v-btn
                            text
                            color="primary"
                            @click="
                              $refs.defaultFieldDateMenu[0].save(
                                defaultFieldDate
                              )
                            "
                            >{{ $t("ok") }}</v-btn
                          >
                        </v-date-picker>
                      </v-menu> -->
                      <v-select
                        v-else-if="tempAttr.dataType === 'Boolean'"
                        :label="$t('defaultField')"
                        v-model="tempAttr.defaultField"
                        :items="booleans"
                        :error="defaultValueRequired"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        filled
                      ></v-select>
                    </span>
                  </td>
                  <td>
                    <span v-if="tempAttr.isSelected">
                      <v-select
                        :label="$t('isDSARFlag')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="tempAttr.isDSARFlag"
                        :items="booleans"
                        filled
                      ></v-select>
                    </span>
                  </td>
                  <td>
                    <span v-if="tempAttr.isSelected">
                      <v-select
                        :label="$t('isRTBFFlag')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="tempAttr.isRTBFFlag"
                        :items="booleans"
                        filled
                      ></v-select>
                    </span>
                  </td>
                  <td>
                    <span v-if="tempAttr.isSelected">
                      <v-text-field
                        :label="$t('Description')"
                        class="mini-field"
                        v-model="tempAttr.description"
                        maxlength="50"
                        required
                        filled
                      ></v-text-field>
                    </span>
                  </td>
                  <td class="sticky-last">
                    <template v-if="tempAttr.isSelected">
                      <v-icon
                        color="#0628b1"
                        data-qe-id="mem_attr_btn_save"
                        @click="saveAttribute(tempAttr)"
                      >
                        {{ $t("save") }}
                      </v-icon>
                      <v-icon
                        color="#212121"
                        @click="cancelAttribute()"
                        data-qe-id="mem_attr_btn_cancel"
                      >
                        {{ $t("cancel") }}
                      </v-icon>
                    </template>
                  </td>
                </tr>
              </tbody>
            </v-simple-table>
          </v-flex>
        </v-col>
      </v-row>
    </v-col>
    <v-col sm="12" class="bmt1" v-if="validationMessages.length > 0">
      <v-alert
        class="b-alert-error"
        type="error"
        :dismissible="false"
        style="min-width:100%"
      >
        <v-row class="alert-block align-center" no-gutters>
          <v-col class="alert-block__body">
            <h3>{{ $t("error") }}</h3>
            <p v-for="error in validationMessages" :key="error">{{ error }}</p>
          </v-col>
        </v-row>
      </v-alert>
    </v-col>
    <v-col>
      <v-btn
        text
        class="no-ripple btn-hover-none bpx0"
        @click="addNewAttribute()"
        data-qe-id="mem_attr_btn_add-new"
      >
        <span class="fbold text-uppercase assign primary-text">
          <v-icon class="pr-3 primary-text">add_circle_outline</v-icon>
          {{ $t("addNewAttribute") }}
        </span>
      </v-btn>
    </v-col>
  </v-row>
</template>

<script>
import ColumnTooltip from './ColumnTooltip';
import _ from 'lodash';
import { mapState } from 'vuex';
import { memberAttributesObj } from '../../../../i18n/language';
export default {
  i18n: memberAttributesObj,
  components: {
    ColumnTooltip
  },
  data () {
    return {
      dataTypes: ['String', 'Number', 'Boolean', 'Date'],
      encryptions: ['None', 'Symmetric', 'Asymmetric', 'Encoded'],
      booleans: [true, false],
      tempAttributes: [],
      dataNameRequired: false,
      datatypeRequired: false,
      maxLengthRequired: false,
      defaultValueRequired: false,
      defaultFieldDateMenu: false,
      defaultFieldDateFormat: null,
      defaultFieldDate: null,
      validationMessages: [],
      initialLength: null,
      editedAttribute: {}
    };
  },
  computed: {
    ...mapState({
      coreAttributes: state =>
        state.memberDefinitionModule.memberDefDataAttributes.coreAttributes
          .memberCoreAttributes,
      extendedAttributes: state =>
        state.memberDefinitionModule.memberDefDataAttributes
          .memberExtendedAttribute
    }),
    ...mapState('memberDefinitionModule', ['memberDefDataAttributes']),
    memberAttributes () {
      return this.coreAttributes.concat(this.extendedAttributes);
    }
  },
  watch: {
    defaultFieldDate (value) {
      if (value !== null) {
        this.defaultFieldDateFormat = this.formatDate(this.defaultFieldDate);
      }
    }
  },
  methods: {
    addNewAttribute () {
      let addAttribute = {
        extensionPropertyId: this.memberAttributes.length + 1,
        dataName: '',
        dataType: '',
        maxLength: '',
        isRequired: '',
        unique: '',
        encryption: 'None',
        defaultField: '',
        isDSARFlag: false,
        isRTBFFlag: false,
        description: '',
        isSelected: true,
        isEditable: true,
        isEdited: false,
        attributeMetaDataId: 1000
      };
      if (this.tempAttributes.length === 0) {
        this.tempAttributes.push(addAttribute);
      }
    },
    saveAttribute (attribute) {
      this.validationMessages = [];
      if (attribute.dataName === '') {
        this.validationMessages.push('Data Name is Mandatory');
        this.dataNameRequired = true;
      } else {
        let duplicateDataNames = _.filter(this.memberAttributes, function (
          element
        ) {
          if (
            element.dataName.toLowerCase() ===
              attribute.dataName.toLowerCase() &&
            element.extensionPropertyId !== attribute.extensionPropertyId
          )
            return element;
        });
        if (duplicateDataNames.length > 0) {
          this.validationMessages.push('Data Name must be unique');
        } else {
          this.dataNameRequired = false;
        }
      }
      if (attribute.dataType === '') {
        this.validationMessages.push('Data Type is Mandatory');
        this.datatypeRequired = true;
      } else {
        this.datatypeRequired = false;
      }
      if (attribute.dataType === 'String' && attribute.maxLength === '') {
        this.validationMessages.push(
          'Max length value is required for String data type'
        );
        this.maxLengthRequired = true;
      } else if (
        attribute.dataType === 'String' &&
        attribute.maxLength &&
        attribute.isEdited &&
        this.memberDefDataAttributes.programStatus === 'Published'
      ) {
        if (this.initialLength > attribute.maxLength) {
          this.validationMessages.push('Max length value can not be decreased');
          this.maxLengthRequired = true;
        } else {
          this.maxLengthRequired = false;
        }
      } else {
        this.maxLengthRequired = false;
      }
      if (attribute.defaultField === '' || attribute.defaultField === null) {
        this.defaultValueRequired = true;
        this.validationMessages.push('Default Field values cannot be empty');
      } else if (
        attribute.maxLength !== null &&
        attribute.maxLength !== '' &&
        attribute.defaultField !== ''
      ) {
        let defaultFieldLength = attribute.defaultField.length;
        if (defaultFieldLength > attribute.maxLength) {
          this.defaultValueRequired = true;
          this.validationMessages.push(
            'Default Field value length should not be more than maxlength'
          );
        } else {
          this.defaultValueRequired = false;
        }
      } else {
        this.defaultValueRequired = false;
      }
      if (this.validationMessages.length === 0) {
        attribute.isSelected = false;
        this.tempAttributes = [];
        if (!attribute.isEdited) {
          this.memberDefDataAttributes.memberExtendedAttribute.push(attribute);
          attribute.extensionPropertyId = 0;
        }
      }
    },
    editAttribute (attribute) {
      this.editedAttribute = Object.assign({}, attribute);
      attribute.isSelected = true;
      attribute.isEdited = true;
      if (attribute.dataType === 'String')
        this.initialLength = attribute.maxLength;
    },
    cancelEditedAttribute (attribute) {
      this.clearErrors();
      for (let key in this.editedAttribute) {
        attribute[key] = this.editedAttribute[key];
      }
    },
    cancelAttribute () {
      this.clearErrors();
      this.tempAttributes.splice(-1, 1);
    },
    clearErrors () {
      if (this.validationMessages.length > 0) {
        this.validationMessages = [];
        this.dataNameRequired = false;
        this.datatypeRequired = false;
        this.maxLengthRequired = false;
        this.defaultValueRequired = false;
      }
    },
    changeDefault (attribute) {
      attribute.defaultField = '';
      if (attribute.dataType !== 'String') {
        attribute.maxLength = '';
      }
    },
    formatDate (date) {
      if (!date) return null;
      const [year, month, day] = date.split('-');
      return `${month}/${day}/${year}`;
    },
    deleteAttribute (attribute, index) {
      if (attribute.extensionPropertyId !== undefined) {
        this.memberDefDataAttributes.memberExtendedAttribute.splice(
          index - this.coreAttributes.length,
          1
        );
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.pause-icon {
  &:before {
    content: "PII";
    font-style: normal;
    font-size: 8px;
    background: #bdbdbd;
    color: #fff;
    padding: 1px 3px;
    border-radius: 2px;
    text-align: center;
  }
}
</style>
