<template>
  <brierley-inner-view class="edit-mem-def">
    <template v-slot:header>
      <span class="inner-head text-uppercase">
        {{ presentMemberDefinition.definitionName }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        data-qe-id="mem_def_btn_edit_view_close"
        class="no-ripple"
        text
        @click.native="$router.push('/loyaltyadmin/memberDefinition')"
      >
        <v-icon>mdi-close</v-icon>{{ $t('close') }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <brierley-form-title
        class="bmt3"
        :formTitle="presentMemberDefinition.definitionName"
        :showSteps="false"
      ></brierley-form-title>
      <div class="bmt5">
        <v-row no-gutters>
          <v-col cols="12" sm="5" class="gen2-forms form-light-bg">
            <p>
              <strong class="text-uppercase">{{ $t('basicDetails') }}</strong>
            </p>
            <v-text-field
              autocomplete="off"
              data-qe-id="definition_name_input_field"
              :label="$t('definitionName')"
              filled
              v-model="presentMemberDefinition.definitionName"
            />
            <v-textarea
              data-qe-id="definition_description_input_field"
              :label="$t('definitionDescription')"
              filled
              auto-grow
              v-model="presentMemberDefinition.description"
            >
            </v-textarea>
          </v-col>
          <v-col offset-sm="3" cols="12" sm="4" class="">
            <brierley-alert
              alertType="info"
              :alertBody="$t('infoAlertMessage')"
              :alertHeader="$t('info')"
              icon
            ></brierley-alert>
          </v-col>
        </v-row>
        <v-expansion-panels
          class="role-assignment-expansions member-data-expansions bmt5"
          accordion
        >
          <v-expansion-panel>
            <v-expansion-panel-header data-qe-id="member_attributes_panel">{{
              $t('memberAttributes')
            }}</v-expansion-panel-header>
            <v-expansion-panel-content>
              <member-attributes></member-attributes>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
        <v-expansion-panels
          class="role-assignment-expansions member-data-expansions bmt3"
          accordion
        >
          <v-expansion-panel>
            <v-expansion-panel-header
              data-qe-id="loyalty_card_attributes_panel"
              >{{ $t('loyaltyCardAttributes') }}</v-expansion-panel-header
            >
            <v-expansion-panel-content>
              <loyalty-card-attributes></loyalty-card-attributes>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
        <v-expansion-panels
          class="role-assignment-expansions member-data-expansions bmt3"
          accordion
        >
          <v-expansion-panel>
            <v-expansion-panel-header data-qe-id="member_identifiers_panel">{{
              $t('memberIdentifiers')
            }}</v-expansion-panel-header>
            <v-expansion-panel-content>
              <div class="bmt4">
                <p>
                  {{ $t('memberIdentifiersInfoText') }}
                </p>
                <p>{{ $t('memberIdentifiersInfoHeader') }}:</p>
                <ul class="bpl6">
                  <li>
                    {{ $t('memberIdentifierSubInfo1') }}
                  </li>
                  <li>
                    {{ $t('memberIdentifierSubInfo2') }}
                  </li>
                </ul>
                <v-row
                  no-gutters
                  class="mem-identifiers"
                  v-if="
                    memberDefDataAttributes.memberIdentifierViewModel !==
                      undefined
                  "
                >
                  <v-col cols="12" class="mem-identifiers__list">
                    <v-checkbox
                      v-model="
                        memberDefDataAttributes.memberIdentifierViewModel
                          .isLoyaltyIdNumber
                      "
                      :disabled="true"
                      class="checkbox-custom"
                      :label="$t('loyaltyIdNumber')"
                      id="loyaltyID"
                    ></v-checkbox>
                  </v-col>
                  <v-col cols="12" class="mem-identifiers__list">
                    <v-checkbox
                      v-model="
                        memberDefDataAttributes.memberIdentifierViewModel
                          .isAlternateId
                      "
                      :disabled="
                        memberDefDataAttributes.programStatus === 'Published'
                      "
                      class="checkbox-custom"
                      :label="$t('alternateID')"
                      id="alternateID"
                    ></v-checkbox>
                  </v-col>
                  <v-col cols="12" class="mem-identifiers__list">
                    <v-checkbox
                      v-model="
                        memberDefDataAttributes.memberIdentifierViewModel
                          .isPrimaryEmailAddress
                      "
                      :disabled="
                        memberDefDataAttributes.programStatus === 'Published'
                      "
                      class="checkbox-custom"
                      :label="$t('primaryEmailAddress')"
                      id="emailAddress"
                    ></v-checkbox>
                  </v-col>
                  <v-col cols="12" class="mem-identifiers__list">
                    <v-checkbox
                      v-model="
                        memberDefDataAttributes.memberIdentifierViewModel
                          .isPrimaryPhoneNumber
                      "
                      :disabled="
                        memberDefDataAttributes.programStatus === 'Published'
                      "
                      class="checkbox-custom"
                      :label="$t('primaryPhoneNumber')"
                      id="phoneNumber"
                    ></v-checkbox>
                  </v-col>
                </v-row>
              </div>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
        <v-expansion-panels
          class="role-assignment-expansions member-data-expansions bmt3"
          accordion
        >
          <v-expansion-panel>
            <v-expansion-panel-header data-qe-id="loyalty_id_panel">{{
              $t('loyaltyID')
            }}</v-expansion-panel-header>
            <v-expansion-panel-content>
              <loyalty-id></loyalty-id>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
        <v-expansion-panels
          class="role-assignment-expansions member-data-expansions bmt3"
          accordion
        >
          <v-expansion-panel>
            <v-expansion-panel-header>
              {{ $t('memberStatus') }}
            </v-expansion-panel-header>
            <v-expansion-panel-content>
              <member-status></member-status>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
      </div>
      <brierley-dialogbox
        :dialog="showEncryptionReviewWindow"
        @closeMe="showEncryptionReviewWindow = $event"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ $t('encryptionReview') }}</v-card-title
          >
        </template>

        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col cols="12">
                <brierley-alert
                  alertType="warning"
                  :alertHeader="$t('alert')"
                  icon="notifications_active"
                >
                  <template v-slot:bodyslot>
                    <p>
                      {{ $t('alertMessage') }}
                    </p>
                  </template>
                </brierley-alert>
              </v-col>
              <v-col cols="12" class="text-right bmt6">
                <v-btn
                  text
                  data-qe-id="mem_def_btn_modal_close"
                  class="no-ripple btn-hover-none bmx4"
                  @click="showEncryptionReviewWindow = false"
                >
                  <span class="fbold primary-text">{{ $t('cancel') }}</span>
                </v-btn>
                <v-btn
                  text
                  class="primaryctabtn no-ripple"
                  data-qe-id="mem_def_btn_modal_confirm"
                  @click="encryptionReviwed"
                >
                  {{ $t('confirm') }}
                </v-btn>
              </v-col>
            </v-row>
          </v-col>
        </template>
      </brierley-dialogbox>
      <brierley-dialogbox
        :dialog="showChangesRevertAlert"
        @closeMe="showChangesRevertAlert = $event"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ $t('alert') }}</v-card-title
          >
        </template>

        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col cols="12">
                <brierley-alert
                  alertType="warning"
                  :alertBody="$t('memberDefRevertChanges')"
                  :alertHeader="$t('alert')"
                  icon="notifications_active"
                ></brierley-alert>
              </v-col>
              <v-col cols="12" class="text-right bmt6">
                <v-btn
                  text
                  class="primaryctabtn no-ripple"
                  data-qe-id="mem_def_btn_modal_cancel"
                  @click.native="$router.push('/loyaltyadmin/memberDefinition')"
                >
                  {{ $t('continue') }}
                </v-btn>
              </v-col>
            </v-row>
          </v-col>
        </template>
      </brierley-dialogbox>
    </template>

    <template v-slot:footer>
      <v-btn
        text
        class="cancel no-ripple bmr6"
        @click="showChangesRevertAlert = true"
        >{{ $t('cancelclose') }}</v-btn
      >
      <v-btn
        text
        data-qe-id="mem_def_btn_edit_view_close"
        class="primaryctabtn no-ripple"
        @click="saveMemberDefinitionData"
        >{{
          presentMemberDefinition.isProgramActive
            ? $t('saveClose')
            : $t('saveClose')
        }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyInnerView,
  BrierleyFormTitle,
  BrierleyDialogbox,
  brierleyAlert
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import memberAttributes from './member-attributes';
import loyaltyCardAttributes from './loyalty-card-attributes';
import { editMemberDefinitionLanguageObj } from '../../../../i18n/language';
import loyaltyId from './loyalty-id';
import memberStatus from './member-status';

export default {
  i18n: editMemberDefinitionLanguageObj,
  components: {
    BrierleyInnerView,
    BrierleyFormTitle,
    BrierleyDialogbox,
    brierleyAlert,
    memberAttributes,
    loyaltyCardAttributes,
    loyaltyId,
    memberStatus
  },
  data () {
    return {
      dialog: false,
      isMemberIdentifiersExpanded: false,
      memberDefinitionName: '',
      memberDefinitionDesc: '',
      isDraft: false,
      showEncryptionReviewWindow: false,
      reviewedStatus: false,
      showChangesRevertAlert: false
    };
  },
  methods: {
    getMemberDefinitionAttributes () {
      if (!this.isMemberIdentifiersExpanded) {
        this.isMemberIdentifiersExpanded = false;
        this.$store.dispatch(
          'memberDefinitionModule/getDefinitionAttribute',
          this.presentMemberDefinition.memberProgramDefId
        );
      }
    },

    saveEditedMemberDefinition () {
      this.memberDefDataAttributes.memberDefinitionName = this.presentMemberDefinition.definitionName;
      this.memberDefDataAttributes.memberDefinitionDescription = this.presentMemberDefinition.description;
      this.memberDefDataAttributes.memberStatusFeatureDef = this.memberDefDataAttributes.memberStatus;
      delete this.memberDefDataAttributes.memberStatus;
      this.$store
        .dispatch(
          'memberDefinitionModule/updateMemberDefinitionData',
          this.memberDefDataAttributes
        )
        .then((res) => {
          if (res.status) {
            this.$router.push('/loyaltyadmin/memberDefinition');
          }
        })
        .catch((err) => {
          this.memberDefDataAttributes.isReviewed = this.presentMemberDefinition.isReviewed;
          console.error(err);
        });
    },
    saveMemberDefinitionData () {
      if (this.memberDefDataAttributes.isReviewed) {
        this.saveEditedMemberDefinition();
      } else {
        this.showEncryptionReviewWindow = true;
      }
    },
    encryptionReviwed () {
      this.memberDefDataAttributes.isReviewed = true;
      this.saveEditedMemberDefinition();
    }
  },
  computed: {
    ...mapState('memberDefinitionModule', [
      'memberIdentifierData',
      'presentMemberDefinition',
      'memberDefDataAttributes'
    ])
  },
  created () {
    this.getMemberDefinitionAttributes();
  }
};
</script>
<style lang="scss">
.mem-identifiers {
  border: 1px solid #e9e9e9;
  margin-top: 16px;
  &__list {
    background: white;
    border-bottom: 1px solid #e9e9e9;
    padding: 12px 32px !important;
    .v-input {
      display: inline-block;
      &__control {
        .v-input__slot {
          margin: 0 !important;
        }
      }
    }
    .v-label {
      font-weight: bold;
      color: #0628b1 !important;
      padding-left: 40px !important;
    }
    &:last-child {
      border: none;
    }
  }
}
.edit-mem-def {
  .v-expansion-panel {
    .v-expansion-panel-content__wrap {
      padding-bottom: 48px !important;
    }
  }
}
</style>
