<template>
  <v-row no-gutters class="loyalty-identifier-page">
    <v-col
      cols="12"
      class="gen2-forms form-dark-bg"
      :class="toggleLodPlatform ? 'col-sm-5' : 'col-sm-5'"
    >
      <p>
        <strong class="text-uppercase">{{
          $t("chooseGenerationSource")
        }}</strong>
      </p>
      <v-select
        :items="items"
        filled
        :label="$t('generationSource')"
        :disabled="
          memberDefDataAttributes.programStatus == 'Published' ? true : false
        "
        attach
        offset-y
        class="gen2select loyalty-identifier-page__select"
        v-model="selectedSource"
        append-icon="expand_more"
        @change="changeSource"
        data-qe-id="loyalty_identifier_select"
      ></v-select>
      <v-row no-gutters v-if="toggleLodPlatform">
        <v-col cols="12">
          <p class="bmt1">
            <strong class="text-uppercase">{{ $t("example") }}:</strong>
          </p>
          <p>{{ $t("codePattern") }}: {{ codePattern }}</p>
        </v-col>
      </v-row>
      <v-row no-gutters v-if="!toggleLodPlatform">
        <v-col cols="12">
          <p class="bmt1">
            <strong class="text-uppercase">{{
              $t("loyaltyIdentifierPattern")
            }}</strong
            ><column-tooltip
              :header="$t('prefixValues')"
              :content="$t('allowedValues')"
            />
          </p>
          <v-row no-gutters>
            <v-col cols="12" sm="6">
              <validation-provider
                :rules="{ alpha_num: true }"
                v-slot="{ errors }"
              >
                <v-text-field
                  autocomplete="off"
                  @input="updatePrefix($event)"
                  maxlength="4"
                  data-qe-id="code_prefix_input_field"
                  :disabled="
                    memberDefDataAttributes.programStatus == 'Published'
                      ? true
                      : false
                  "
                  v-model="codePrefix"
                  :label="$t('codePrefix')"
                  filled
                />
                <p
                  v-if="errors[0] === '{field} is not valid.'"
                  class="custom-error-msg"
                >
                  {{ $t("allowedValuesErrorMsg") }}
                </p>
              </validation-provider>
            </v-col>
            <v-col cols="12" sm="12">
              <p>
                {{ $t("codePattern") }} {{ `: ${codePrefix}${codePattern}` }}
              </p>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </v-col>
    <v-col cols="12" sm="4" offset-sm="3">
      <brierley-alert
        v-if="toggleLodPlatform"
        alertType="info"
        :alertBody="$t('toggleAlertBodyText')"
        :alertHeader="$t('alertType')"
      ></brierley-alert>
      <brierley-alert
        v-if="!toggleLodPlatform"
        alertType="info"
        :alertBody="$t('alertBodyText')"
        :alertHeader="$t('alertType')"
      ></brierley-alert>
    </v-col>
  </v-row>
</template>

<script>
import ColumnTooltip from './ColumnTooltip';
import { brierleyAlert } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { loyaltyIdObject } from '../../../../i18n/language';
export default {
  i18n: loyaltyIdObject,
  components: {
    ColumnTooltip,
    brierleyAlert
  },
  data () {
    return {
      items: ['LoyaltyOnDemand Platform Generated', 'Client Generated'],
      selectedSource: 'LoyaltyOnDemand Platform Generated',
      toggleLodPlatform: false,
      codePattern: '1111222233334444',
      codePrefix: '',
      programStatus: 'Draft'
    };
  },
  computed: {
    ...mapState('memberDefinitionModule', ['memberDefDataAttributes'])
  },
  methods: {
    changeSource () {
      if (this.selectedSource === 'LoyaltyOnDemand Platform Generated') {
        this.toggleLodPlatform = false;
      } else {
        this.toggleLodPlatform = true;
      }
      this.memberDefDataAttributes.loyaltyIdAttribute.generationSourceSelected = this.selectedSource;
    },
    updatePrefix () {
      this.memberDefDataAttributes.loyaltyIdAttribute.prefix = this.codePrefix;
    }
  },
  mounted () {
    this.changeSource();
    this.programStatus =
      this.memberDefDataAttributes.programStatus !== null
        ? this.memberDefDataAttributes.programStatus
        : 'Draft';
    this.codePrefix =
      this.memberDefDataAttributes.loyaltyIdAttribute.prefix !== null
        ? this.memberDefDataAttributes.loyaltyIdAttribute.prefix
        : '';
  }
};
</script>
<style lang="scss">
.loyalty-identifier-page {
  &__select {
    max-width: 400px;
  }
  .mdi-information-outline {
    font-size: 18px !important;
    color: #0628b1;
    margin: -4px 0 0 8px;
  }
}
</style>
