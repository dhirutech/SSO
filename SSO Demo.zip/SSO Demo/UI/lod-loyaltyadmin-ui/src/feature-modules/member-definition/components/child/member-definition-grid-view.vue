<template>
  <v-row no-gutters class="mem-def__grid-view">
    <v-col cols="12">
      <brierley-grid-card v-for="(item,index) in memberDefData" :key="index">
        <template v-slot:grid-card-body>
          <v-col cols="12" sm="12" md="4">
            <v-card-title title="Default member Definition" class="elipsis-fullwidth"
              >{{item.definitionName}}</v-card-title
            >
            <p>
              <strong> {{ $t("mappedProgram") }} </strong>
            </p>
            <p>
             {{item.mappedProgram}}
            </p>
          </v-col>
          <v-col cols="12" sm="12" md="5" class="bpr6">
            <p class="bmt0">
              <strong>{{ $t("description") }}:</strong>
            </p>
            <p class="elipsis-twoline" :title="item.description">
              {{ item.description }}
            </p>
          </v-col>
          <v-col cols="12" sm="12" md="3">
            <p class="bmt0">
              <strong>{{ $t("reviewStatus") }}</strong>
            </p>
            <brierleyStatus v-if="item.isReviewed" status="Verified"></brierleyStatus>
            <brierleyStatus v-else status="Not Verified"></brierleyStatus>
          </v-col>
          <v-col cols="12">
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span data-qe-id="mem_def_btn_view_details" class="active" @click="editMemDef(item)">
                  <v-icon>fe fe-eye</v-icon>
                  <span class="viewdetails-icon">{{ $t("viewDetails") }}</span>
                </span>
                <span data-qe-id="mem_def_btn_edit_view" @click="editMemDef(item)">
                  <v-icon>fe fe-edit</v-icon>
                  <span class="edit-icon">{{ $t("edit") }}</span>
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
        </template>
      </brierley-grid-card>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyGridCard, BrierleyCardIcons, BrierleyStatus } from '@brierley/SharedComponents';
import { memberDefinitionGridViewObj } from '../../../../i18n/language';

export default {
  i18n: memberDefinitionGridViewObj,
  components: {
    BrierleyGridCard,
    BrierleyCardIcons,
    BrierleyStatus,
  },
  data () {
    return {};
  },
  props: {
    memberDefData: {
      type: Array
    }
  },
  methods: {
    editMemDef (item) {
      this.$emit('edit-member-definition', item);
      window.scrollTo(0, 0);
    }
  },
};
</script>
<style lang="scss">
  .mem-def__grid-view {
    .gen2-card-btm-icons{
      display: inline-block;
    }
  }
</style>
