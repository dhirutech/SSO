import Vue from 'vue';

const getMemberIdentifiersDataAPI = params => {
  return Vue.prototype.$http.get(`member/api/v2/members/GetByMemberProgramDefId?memberProgramDefId=${params}`);
};

const updateMemberDefinitionAPI = params => {
  return Vue.prototype.$http.put('member/api/v2/members/addOrEditExtendedAttributes', params);
};

const getMemberDefAsync =  () => {
  return  Vue.prototype.$http.get('member/api/v2/members/memberDefinition');
};

const getDefinitionAttributesAPI = params => {
  return Vue.prototype.$http.get(`member/api/v2/members/GetMemberProgramDefinition?memberProgramDefId=${params}`);
};
export {
  getMemberIdentifiersDataAPI,
  updateMemberDefinitionAPI,
  getMemberDefAsync,
  getDefinitionAttributesAPI
};
