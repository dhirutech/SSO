import memberDefinition from './components/member-definition.vue';
import editMemberDefinition from './components/child/edit-member-definition.vue';

const memberDefinitionRoutes = [
  {
    path: '/loyaltyadmin/memberDefinition',
    name: 'memberDefinition',
    component: memberDefinition,
    meta: {
      showNavigation: false,
    },
  },
  {
    path: '/loyaltyadmin/editMemberDefinition',
    name: 'memberDefinition',
    component: editMemberDefinition,
    meta: {
      showNavigation: false,
    },
  },
];

export default memberDefinitionRoutes;
