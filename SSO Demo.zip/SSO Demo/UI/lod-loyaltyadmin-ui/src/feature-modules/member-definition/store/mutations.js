const saveMemberIdentifierData = (state, payload) => {
  state.memberIdentifierData = payload;
};

const setPresentMemberDefinition = (state, payload) => {
  state.presentMemberDefinition = payload;
};

const setMemberDef = (state, payload) => {
  state.memberDefData = payload;
};

const setMemberDefinitionAttributes = (state, payload) => {
  state.memberDefDataAttributes = payload;
};
export default {
  saveMemberIdentifierData,
  setPresentMemberDefinition,
  setMemberDef,
  setMemberDefinitionAttributes
};
