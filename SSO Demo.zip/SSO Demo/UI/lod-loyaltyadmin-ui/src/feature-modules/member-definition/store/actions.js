import { getMemberIdentifiersDataAPI, updateMemberDefinitionAPI, getMemberDefAsync, getDefinitionAttributesAPI } from '../api/member-definition-api';

const getMemberIdentifiersData = (context, params) => {
  getMemberIdentifiersDataAPI(params).then(res => {
    context.commit('saveMemberIdentifierData', res.data);
  }).catch(err => {
    console.error(err);
  });
};

const updateMemberDefinitionData = (context, queryParams) => {
  return new Promise((resolve, reject) => {
    updateMemberDefinitionAPI(queryParams)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getMemberDefData = async ({ commit }) => {
  getMemberDefAsync().then(res => {
    commit('setMemberDef', res.data);
  });
};

const getDefinitionAttribute = (context, params) => {
  getDefinitionAttributesAPI(params)
    .then(res => {
      context.commit('setMemberDefinitionAttributes', res.data);
    })
    .catch(err => {
      console.error(err);
    });
};
export default {
  getMemberIdentifiersData,
  updateMemberDefinitionData,
  getMemberDefData,
  getDefinitionAttribute
};
