export default {
  memberIdentifierData: {},
  presentMemberDefinition: {},
  memberDefData: [],
  memberDefDataAttributes: {}
};
