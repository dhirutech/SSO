<template>
  <brierley-inner-view>
    <template v-slot:header>
      <v-flex class="toggle-menu-custom">
        <v-btn class="no-ripple iconbtn" text @click="menutoggle = !menutoggle">
          <v-icon>
            fe-menu
          </v-icon>
        </v-btn>
        <brierley-toggle-menu v-if="menutoggle"></brierley-toggle-menu>
      </v-flex>
      <span class="inner-head text-uppercase">
        {{ title }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        text
        data-qe-id="edit_trans_details_close_header"
        @click.native="$router.push('/loyaltyadmin/transactionDefinition')"
      >
        <v-icon>mdi-close</v-icon>{{ $t("close") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <brierley-form-title
        class="bmt3"
        :formTitle="$t('newTransactionDef')"
        infoText=""
        :showSteps="false"
      ></brierley-form-title>
      <div class="bmt5">
        <v-row no-gutters>
          <v-col cols="12" sm="5" class="gen2-forms form-light-bg">
            <p>
              <strong class="text-uppercase">{{ $t("basicDetails") }}</strong>
            </p>
            <v-form v-model="form.valid" ref="form">
              <v-row no-gutters>
                <v-col cols="12" md="8">
                  <v-text-field
                    :label="$t('txndeflable')"
                    filled
                    v-model="txndefname"
                    ref="userNameRules"
                    :rules="userNameRules"
                    required
                    @focus="Txnnameunique = false"
                  />
                </v-col>
                <span class="custom-error-msg" v-if="Txnnameunique">
                  {{ $t("txndefnameunique") }}
                </span>
              </v-row>
            </v-form>
            <v-textarea
              :label="$t('txndefdesclable')"
              filled
              auto-grow
              v-model="txndefdesc"
            >
            </v-textarea>
          </v-col>
          <v-col offset-sm="3" cols="12" sm="4" class="">
            <brierley-info-side>
              <template v-slot:info-side-header>
                <div class="info_title">
                  <v-icon>info</v-icon>{{ $t("infoText") }}
                </div>
              </template>
              <template v-slot:info-side-body>
                <p class="bpl5">
                  {{ $t("transactionInfocontent") }}
                </p>
              </template>
            </brierley-info-side>
          </v-col>
        </v-row>
        <v-expansion-panels
          class="role-assignment-expansions member-data-expansions bmt5"
          accordion
        >
          <v-expansion-panel>
            <v-expansion-panel-header>{{
              $t("headerAttributes")
            }}</v-expansion-panel-header>
            <v-expansion-panel-content>
              <header-attributes ref="headerAttributes"></header-attributes>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
        <v-expansion-panels
          class="role-assignment-expansions member-data-expansions bmt3"
          accordion
        >
          <v-expansion-panel>
            <v-expansion-panel-header>{{
              $t("detailsAttributes")
            }}</v-expansion-panel-header>
            <v-expansion-panel-content>
              <details-attributes ref="detailAttributes"></details-attributes>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
        <v-expansion-panels
          class="role-assignment-expansions member-data-expansions bmt3"
          accordion
        >
          <v-expansion-panel>
            <v-expansion-panel-header>{{
              $t("tenderAttributes")
            }}</v-expansion-panel-header>
            <v-expansion-panel-content>
              <tender-attributes ref="tenderAttributes"></tender-attributes>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
        <v-expansion-panels
          class="role-assignment-expansions member-data-expansions bmt3"
          accordion
        >
          <v-expansion-panel>
            <v-expansion-panel-header>{{
              $t("transactionIdentifiers")
            }}</v-expansion-panel-header>
            <v-expansion-panel-content>
              <p class="bmb3">{{ $t("trasactionIdentifierHeading") }}</p>
              {{ $t("transactionIdentifierTitle") }}
              <ul class="bpl6">
                <li>{{ $t("transactionIdentifierPoint1") }}</li>
                <li>{{ $t("transactionIdentifierPoint2") }}</li>
                <li>{{ $t("transactionIdentifierPoint3") }}</li>
                <li>{{ $t("transactionIdentifierPoint4") }}</li>
              </ul>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
        <v-expansion-panels
          class="role-assignment-expansions member-data-expansions bmt3"
          accordion
        >
          <v-expansion-panel>
            <v-expansion-panel-header>{{
              $t("rewardRedemption")
            }}</v-expansion-panel-header>
            <v-expansion-panel-content>
              <reward-redemption ref="rewardAttributes"></reward-redemption>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
        <v-expansion-panels
          class="role-assignment-expansions member-data-expansions bmt3"
          accordion
        >
          <v-expansion-panel>
            <v-expansion-panel-header>{{
              $t("programEntityMapping")
            }}</v-expansion-panel-header>
            <v-expansion-panel-content>
              <v-row no-gutters>
                <v-col class="transaction-program-entity">
                  <v-row no-gutters class="d-flex ">
                    <v-col
                      class="col-padding form-light-bg"
                      xs="12"
                      sm="12"
                      md="12"
                    >
                      <p>{{ $t("selectProgramEntity") }}</p>
                    </v-col>
                  </v-row>
                  <v-row no-gutters class="d-flex ">
                    <v-col
                      class="col-padding gen2-forms form-light-bg"
                      xs="12"
                      sm="6"
                      md="6"
                    >
                      <p class="label-text mt-3 mb-1">
                        {{ $t("programEntity") }}
                      </p>
                      <v-row>
                        <v-col sm="8" class="pb-0">
                          <v-text-field
                            :label="$t('noProgramEntity')"
                            id="product_basic_name"
                            filled
                            required
                            :disabled="TransactionDefobj.businessEntityId === 0"
                            v-if="TransactionDefobj.businessEntityId === 0"
                          ></v-text-field>
                        </v-col>
                      </v-row>
                      <brierley-block-with-chips
                        v-model="TransactionDefobj.businessEntityId"
                        v-if="TransactionDefobj.businessEntityId !== 0"
                      >
                        <template v-slot:block-with-chips-title>
                          <span class="chips-req-label">{{
                            $t("selectedProgramEntity")
                          }}</span>
                        </template>
                        <template v-slot:block-with-chips-body>
                          <p
                            class="font12 body-text fbold"
                            v-if="TransactionDefobj.businessEntityId === 0"
                          >
                            {{ $t("noProgramEntity") }}
                          </p>
                          <v-chip
                            v-if="TransactionDefobj.businessEntityId !== 0"
                            @click:close="deleteEntity"
                            close
                            close-icon="close"
                            :disabled="
                              cloning ? false : TransactionDefobj.inUse
                            "
                            >{{ TransactionDefobj.businessEntityName }}</v-chip
                          >
                        </template>
                      </brierley-block-with-chips>
                      <p class="pb5">
                        <span
                          v-if="cloning ? true : !TransactionDefobj.inUse"
                          @click="openDialog"
                          class="primary-text fbold text-uppercase click-here-select"
                          :class="{
                            'cursor-p': true,
                            'gray-text': TransactionDefobj.inUse
                          }"
                          >{{ $t("clickHereSelectText") }}</span
                        >
                      </p>
                    </v-col>
                    <v-col
                      class="gen2-forms form-light-bg"
                      xs="12"
                      sm="6"
                      md="6"
                    >
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
      </div>
      <brierley-dialogbox
        class="custom-dialog__large custom-large"
        :dialog="businessEntityDialog"
        @closeMe="doneBusinessEntityDialog"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ $t("progHierarchyText") }}
          </v-card-title>
        </template>

        <template v-slot:dialog-body-description>
          <v-col>
            <template>
              <div class="chart-container loyalty-org">
                <div class="entity-chart-container">
                  <div class="entity-chart">
                    <brierley-program-entity-chart
                      :entity="businessEntityNode"
                      :infoMessage="$t('alreadyAssignedProgramEntityMessage')"
                      :bus="bus"
                    >
                    </brierley-program-entity-chart>
                  </div>
                </div>
              </div>
            </template>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            text
            class="cancel no-ripple"
            @click="cancelBusinessEntityDialog"
          >
            {{ $t("cancel") }}
          </v-btn>
          <v-btn
            class="primaryctabtn btn-close"
            title="Default"
            @click="doneBusinessEntityDialog"
          >
            {{ $t("done") }}
          </v-btn>
        </template>
      </brierley-dialogbox>
      <brierley-dialogbox :dialog="dialog" @closeMe="dialog = $event">
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ $t("alert") }}</v-card-title
          >
        </template>

        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col cols="12">
                <brierley-alert
                  alertType="warning"
                  :alertBody="$t('noSavingAlert')"
                  :alertHeader="$t('alert')"
                  icon="notifications_active"
                ></brierley-alert>
              </v-col>
              <v-col cols="12" class="text-right bmt6">
                <v-btn
                  text
                  class="primaryctabtn no-ripple"
                  data-qe-id="mem_def_btn_modal_confirm"
                  @click.native="
                    $router.push('/loyaltyadmin/transactionDefinition')
                  "
                >
                  {{ $t("continue") }}
                </v-btn>
              </v-col>
            </v-row>
          </v-col>
        </template>
      </brierley-dialogbox>
      <brierley-dialogbox
        :dialog="showProgramSelectionAlert"
        @closeMe="showProgramSelectionAlert = false"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ $t("alert") }}</v-card-title
          >
        </template>

        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col cols="12">
                <brierley-alert
                  alertType="warning"
                  :alertBody="$t('mapProgramAlert')"
                  :alertHeader="$t('alert')"
                  icon="notifications_active"
                ></brierley-alert>
              </v-col>
              <v-col cols="12" class="text-right bmt6">
                <v-btn
                  text
                  class="primaryctabtn no-ripple"
                  data-qe-id="mem_def_btn_modal_confirm"
                  @click.native="showProgramSelectionAlert = false"
                >
                  {{ $t("continue") }}
                </v-btn>
              </v-col>
            </v-row>
          </v-col>
        </template>
      </brierley-dialogbox>
    </template>

    <template v-slot:footer>
      <v-btn text class="cancel no-ripple bmr6" @click="dialog = true">{{
        $t("cancel")
      }}</v-btn>
      <v-btn
        text
        class="primaryctabtn no-ripple"
        @click.native="createTxnDefination()"
        >{{ $t("saveAndClose") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyInnerView,
  BrierleyFormTitle,
  brierleyAlert,
  BrierleyDialogbox,
  BrierleyToggleMenu,
  BrierleyInfoSide,
  BrierleyBlockWithChips,
  BrierleyProgramEntityChart
} from '@brierley/SharedComponents';
import HeaderAttributes from './header-attributes';
import DetailsAttributes from './details-attributes';
import TenderAttributes from './tender-attributes';
import RewardRedemption from './reward-redemption';
import { transactionDefinitonObj } from '../../../../i18n/language.js';
import { mapState } from 'vuex';
import Vue from 'vue';

export default {
  components: {
    BrierleyInnerView,
    BrierleyFormTitle,
    brierleyAlert,
    BrierleyDialogbox,
    BrierleyInfoSide,
    HeaderAttributes,
    DetailsAttributes,
    TenderAttributes,
    RewardRedemption,
    BrierleyToggleMenu,
    BrierleyBlockWithChips,
    BrierleyProgramEntityChart
  },
  data () {
    return {
      dialog: false,
      menutoggle: false,
      title: '',
      txndefname: '',
      txndefdesc: '',
      Txnnameunique: false,
      editing: false,
      cloning: false,
      viewing: false,
      creating: false,
      showProgramSelectionAlert: false,
      businessEntityDialog: false,
      tempBusinessEntityId: 0,
      bus: new Vue(),
      userNameRules: [
        v => !!v || this.$t('txndefnamerequired'),
        v =>
          !v ||
          /^[^\s]+[-a-zA-Z0-9\s]+([-a-zA-Z0-9]+)*$/.test(v) ||
          this.$t('txndefnamerequired')
      ],
      form: {
        valid: false
      },
      errorMessage:
        'Attribute is not saved. Please save the attribute before you continue.',
      emptyTransactionDefobj: {
        transactionDefinitionId: 0,
        businessEntityId: 0,
        transactionDefName: '',
        txnEntityDefName: '',
        transactionDefDescription: '',
        isReviewed: false,
        defStatus: null,
        inUse: false
      }
    };
  },
  computed: {
    ...mapState('transactionDefinitionModule', {
      TransactionDefobj: state => {
        return state.TransactionDefobj;
      },
      attributes: state => state.attributes,
      headerhasErrors: state => state.headerhasErrors,
      detialhasErrors: state => state.detialhasErrors,
      tenderhasErrors: state => state.tenderhasErrors,
      rewardhasErrors: state => state.rewardhasErrors,
      businessEntityNode: state => state.businessEntityNode,
      businessEntitiesAlreadyAssigned: state =>
        state.businessEntitiesAlreadyAssigned
    })
  },
  watch: {
    TransactionDefobj (value) {
      this.$store.commit(
        'transactionDefinitionModule/setTransactionDefinition',
        value
      );
      this.txndefdesc = value.transactionDefDescription;
      if (this.cloning) {
        this.TransactionDefobj.transactionDefinitionId = 0;
        this.txndefname = 'Clone - ' + value.transactionDefName;
        this.TransactionDefobj.businessEntityName = '';
        this.TransactionDefobj.businessEntityId = 0;
      } else if (this.editing) {
        this.txndefname = value.transactionDefName;
      } else if (this.creating) {
        this.TransactionDefobj = this.emptyTransactionDefobj;
      }
    }
  },
  created () {
    let self = this;
    self.initialize();
    self.attachBusEvents();
  },
  methods: {
    createTxnDefination () {
      if (this.$refs.form.validate()) {
        this.validate();
        if (
          this.headerhasErrors === false &&
          this.detialhasErrors === false &&
          this.tenderhasErrors === false &&
          this.rewardhasErrors === false
        ) {
          if (
            !this.showProgramSelectionAlert &&
            this.txndefname.trim().length !== 0
          ) {
            this.TransactionDefobj.transactionDefName = this.txndefname.trim();
            this.TransactionDefobj.transactionDefDescription = this.txndefdesc;
            this.assignBusinessEnitity();

            const coreHeader = this.attributes.headerAttributes.filter(function (
              e
            ) {
              return e.isCoreAttr === true;
            });
            const extendedHeader = this.attributes.headerAttributes.filter(
              function (e) {
                return e.isCoreAttr === false;
              }
            );
            this.TransactionDefobj.headerAttributes = Object.assign(
              {},
              {
                transactionCoreAttributes: coreHeader,
                transactionExtendedAttributes: extendedHeader
              }
            );

            const coreDetail = this.attributes.detailAttributes.filter(function (
              e
            ) {
              return e.isCoreAttr === true;
            });
            const extendedDetail = this.attributes.detailAttributes.filter(
              function (e) {
                return e.isCoreAttr === false;
              }
            );
            this.TransactionDefobj.detailAttributes = Object.assign(
              {},
              {
                transactionCoreAttributes: coreDetail,
                transactionExtendedAttributes: extendedDetail
              }
            );

            const coreTender = this.attributes.tenderAttributes.filter(function (
              e
            ) {
              return e.isCoreAttr === true;
            });
            const extendedTender = this.attributes.tenderAttributes.filter(
              function (e) {
                return e.isCoreAttr === false;
              }
            );
            this.TransactionDefobj.tenderAttributes = Object.assign(
              {},
              {
                transactionCoreAttributes: coreTender,
                transactionExtendedAttributes: extendedTender
              }
            );

            const coreReward = this.attributes.redemptionAttributes.filter(
              function (e) {
                return e.isCoreAttr === true;
              }
            );
            const extendedReward = this.attributes.redemptionAttributes.filter(
              function (e) {
                return e.isCoreAttr === false;
              }
            );
            this.TransactionDefobj.redemptionAttributes = Object.assign(
              {},
              {
                transactionCoreAttributes: coreReward,
                transactionExtendedAttributes: extendedReward
              }
            );
            this.$store
              .dispatch(
                'transactionDefinitionModule/createTxnDefAction',
                this.TransactionDefobj
              )
              .then(res => {
                if (res.status === 200) {
                  this.$router.push({ name: 'transactionDefinition' });
                }
              })
              .catch(err => {
                if (err.response.data.httpStatusCode === 409)
                  this.Txnnameunique = true;
              });
          }
        }
      }
    },
    assignBusinessEnitity () {
      for (const property in this.attributes) {
        for (let i = 0; i < this.attributes[property].length; i++) {
          if ('businessEntityId' in this.attributes[property][i]) {
            this.attributes[property][
              i
            ].businessEntityId = this.TransactionDefobj.businessEntityId;
          } else {
            Vue.set(
              this.attributes[property][i],
              'businessEntityId',
              this.TransactionDefobj.businessEntityId
            );
          }
        }
      }
    },
    validate () {
      if (
        this.TransactionDefobj.businessEntityId === 0 ||
        this.txndefname.trim().length === 0
      ) {
        this.showProgramSelectionAlert = true;
      }
      const selectedHeaderAttributes = this.attributes.headerAttributes.filter(function (e) {
        return e.isSelected === true;
      });
      if (selectedHeaderAttributes.length > 0 || this.$refs.headerAttributes && this.$refs.headerAttributes.tempAttributes.length > 0) {
        this.$refs.headerAttributes.validationMessages =[this.errorMessage];
        this.$store.commit(
          'transactionDefinitionModule/headerhasErrorsmutation',
          true
        );
      }
      const selectedDetailAttributes = this.attributes.detailAttributes.filter(function (e) {
        return e.isSelected === true;
      });
      if (selectedDetailAttributes.length > 0 ||  this.$refs.detailAttributes && this.$refs.detailAttributes.tempAttributes.length > 0) {
        this.$refs.detailAttributes.validationMessages =[this.errorMessage];
        this.$store.commit(
          'transactionDefinitionModule/headerhasErrorsmutation',
          true
        );
      }
      const selectedtenderAttributes = this.attributes.tenderAttributes.filter(function (e) {
        return e.isSelected === true;
      });
      if (selectedtenderAttributes.length > 0 || this.$refs.tenderAttributes && this.$refs.tenderAttributes.tempAttributes.length > 0) {
        this.$refs.tenderAttributes.validationMessages =[this.errorMessage];
        this.$store.commit(
          'transactionDefinitionModule/headerhasErrorsmutation',
          true
        );
      }
      const selectedRewardAttributes = this.attributes.redemptionAttributes.filter(function (e) {
        return e.isSelected === true;
      });
      if (selectedRewardAttributes.length > 0 || this.$refs.redemptionAttributes &&this.$refs.redemptionAttributes.tempAttributes.length > 0) {
        this.$refs.redemptionAttributes.validationMessages =[this.errorMessage];
        this.$store.commit(
          'transactionDefinitionModule/headerhasErrorsmutation',
          true
        );
      }
    },
    initialize () {
      this.TransactionDefobj.businessEntityId = 0;
      this.TransactionDefobj.businessEntityName = '';
    },
    selectEntity (entity) {
      let self = this;
      this.TransactionDefobj.businessEntityId = entity.id;
      this.TransactionDefobj.businessEntityName = entity.name;
      self.$store.commit(
        'transactionDefinitionModule/setTransactionDefinition',
        self.TransactionDefobj
      );
      self.$store.commit(
        'transactionDefinitionModule/setBusinessEntityNode',
        self.businessEntityNode
      );
    },
    attachBusEvents () {
      let self = this;
      self.bus.$on('entity-selected', entity => {
        self.selectEntity(entity);
      });
    },
    deleteEntity () {
      this.TransactionDefobj.businessEntityId = 0;
      this.TransactionDefobj.businessEntityName = '';
    },
    openDialog () {
      this.businessEntityDialog = true;
      this.tempBusinessEntityId = this.TransactionDefobj.businessEntityId;
      this.getBusinessEntityNode();
    },
    getBusinessEntityNode () {
      let self = this;
      this.$store
        .dispatch('transactionDefinitionModule/viewTxnDefAction')
        .then(res => {
          if (res.status === 200) {
            this.$store.commit(
              'transactionDefinitionModule/setBusinessEntitiesAlreadyAssigned',
              res.data
            );
            self.$store.dispatch(
              'transactionDefinitionModule/getBusinessEntityNode'
            );
          } else {
            this.$store.commit(
              'transactionDefinitionModule/setBusinessEntitiesAlreadyAssigned',
              []
            );
            self.$store.dispatch(
              'transactionDefinitionModule/getBusinessEntityNode'
            );
          }
        })
        .catch(err => {
          if (err)
            this.$store.commit(
              'transactionDefinitionModule/setBusinessEntitiesAlreadyAssigned',
              []
            );
          self.$store.dispatch(
            'transactionDefinitionModule/getBusinessEntityNode'
          );
        });
    },
    doneBusinessEntityDialog () {
      this.businessEntityDialog = false;
    },
    cancelBusinessEntityDialog () {
      this.TransactionDefobj.businessEntityId = this.tempBusinessEntityId;
      this.businessEntityDialog = false;
    },
    fetchallattributes () {
      this.$store
        .dispatch('transactionDefinitionModule/fetchcoreattibutesAction')
        .then(res => {
          if (res.status === 200) {
            this.$store.commit(
              'transactionDefinitionModule/fetchcoreattributeMutation',
              res.data
            );
          }
        })
        .catch();
    }
  },
  i18n: transactionDefinitonObj,
  mounted () {
    if (this.$route.name.includes('edit')) {
      this.title = this.$t('edittxndefname');
      this.editing = true;
    } else if (this.$route.name.includes('create')) {
      this.title = this.$t('creatxndefname');
      this.creating = true;
      this.fetchallattributes();
      this.$store.commit(
        'transactionDefinitionModule/setTransactionDefinition',
        this.emptyTransactionDefobj
      );
    } else if (this.$route.name.includes('clone')) {
      this.title = this.$t('clonetxndefname');
      this.cloning = true;
    }
  },
  beforeDestroy () {
    let emptyAttributes = {
      headerAttributes: {},
      tenderAttributes: {},
      detailAttributes: {},
      redemptionAttributes: {}
    };
    this.$store.commit(
      'transactionDefinitionModule/fetchcoreattributeMutation',
      emptyAttributes
    );
  }
};
</script>

<style lang="scss" scoped>
.iconbtn {
  position: absolute;
  left: -22px;
}
.transaction-program-entity {
  background-color: #ffffff;
  padding: 32px 0 60px 32px;
  .chips-req-label {
    font-size: 12px !important;
  }
  .block-with-chips {
    margin-bottom: 10px;
  }
}
</style>
