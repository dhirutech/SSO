<template>
  <brierley-inner-view>
    <template v-slot:header>
      <span class="inner-head text-uppercase">
        {{ $t('Txndef') }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        data-qe-id="trans_details_btn_close_header"
        class="no-ripple"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon> {{ $t('close') }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <brierley-form-title
        class="bmt3"
        :formTitle="$t('Txndefs')"
        :showSteps="false"
      ></brierley-form-title>
      <v-row no-gutters class="bmt4 bmb1 align-center">
        <v-col>
          <h4 class="font15 text-uppercase fbold">{{ $t('TxndefList') }}</h4>
        </v-col>
        <v-col class="text-right">
          <brierley-view-option
            :viewList="viewList"
            @viewChanged="viewType = $event"
          />
          <v-btn
            text
            class="no-ripple btn-hover-none bpx0 bml1"
            @click="$router.push('/loyaltyadmin/TransactionDefinition/create')"
          >
            <span class="f600 primary-text text-uppercase"
              ><v-icon>add_circle</v-icon> {{ $t('createTxndef') }}
            </span>
          </v-btn>
        </v-col>
      </v-row>
      <div v-if="viewType == 'grid_view'">
        <transaction-definition-grid-view
          :transactionDefinitions="transactionDefinitionData"
        ></transaction-definition-grid-view>
      </div>
      <div v-if="viewType == 'table_view'">
        <transaction-definition-table-view
          :transactionDefinitions="transactionDefinitionData"
        ></transaction-definition-table-view>
      </div>
      <div v-if="viewType == 'card_view'">
        <transaction-definition-card-view
          :transactionDefinitions="transactionDefinitionData"
        ></transaction-definition-card-view>
      </div>
      <div v-if="transactionDefinitionData.length === 0 && isLoading===false">
        <brierley-no-result
          noResultMessage="this.$t('noRecordsMessage')"
           id="viewuser_img_no_data"
       ></brierley-no-result>
      </div>
    </template>

    <template v-slot:footer>
      <v-btn
        text
        class="primaryctabtn no-ripple"
        data-qe-id="trans_details_btn_close_footer"
        @click.native="$router.push('/gettingstarted')"
      >
        {{ $t('close') }}
      </v-btn>
    </template>
  </brierley-inner-view>
</template>

<script>
import {
  BrierleyInnerView,
  BrierleyFormTitle,
  BrierleyNoResult,
  BrierleyViewOption
} from '@brierley/SharedComponents';
import TransactionDefinitionGridView from './child/transaction-definition-grid-view';
import TransactionDefinitionCardView from './child/transaction-definition-card-view';
import TransactionDefinitionTableView from './child/transaction-definition-table-view';
import { transactionDefinitonObj } from '../../../i18n/language';
import { mapState } from 'vuex';

export default {
  i18n: transactionDefinitonObj,
  components: {
    BrierleyInnerView,
    BrierleyFormTitle,
    BrierleyViewOption,
    BrierleyNoResult,
    TransactionDefinitionGridView,
    TransactionDefinitionTableView,
    TransactionDefinitionCardView
  },
  data () {
    return {
      isLoading: false,
      viewType: 'grid_view',
      viewList: [
        { key: 'grid_view', icon: 'calendar_view_day', label: localStorage.getItem('language') === 'en' ? 'Grid view' : 'グリッドビュー' },
        { key: 'table_view', icon: 'table_chart', label: localStorage.getItem('language') === 'en' ? 'Table view' : 'テーブルビュー' },
        { key: 'card_view', icon: 'view_module', label: localStorage.getItem('language') === 'en' ? 'Card view' : 'カードビュー' }
      ]
    };
  },
  computed: {
    ...mapState('transactionDefinitionModule', {
      transactionDefinitionData: (state) => {
        return state.transactionDefinitionData;
      }
    })
  },
  mounted () {
    this.isLoading = true;
    this.$store
      .dispatch('transactionDefinitionModule/viewTxnDefAction')
      .then((res) => {
        this.isLoading = false;
        if (res.status === 200) {
          this.$store.commit(
            'transactionDefinitionModule/setBusinessEntitiesAlreadyAssigned',
            res.data
          );
          this.$store.commit(
            'transactionDefinitionModule/viewTxndataMutation',
            res.data
          );
        }
      })
      .catch((err) => {
        this.isLoading = false;
        if (err)
          this.$store.commit(
            'transactionDefinitionModule/viewTxndataMutation',
            []
          );
      });
  }
};
</script>
