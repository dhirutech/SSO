<template>
  <v-row class="gen2-scroll-table mb-0" no-gutters>
    <v-col>
      <v-row class="table_container d-flex" no-gutters>
        <v-col class="table-center sticky-data-table gen2-forms form-light-bg">
          <v-flex class="sticky-data-table__scroll">
            <v-simple-table class="sticky-data-table__table">
              <thead>
                <tr>
                  <th class="sticky-first">
                    {{ $t('attibutename') }}
                  </th>
                  <th class="largecol">
                    {{ $t('datatype') }}
                  </th>
                  <th>
                    {{ $t('maxlength') }}
                    <column-tooltip
                      :header="$t('maxlength')"
                      :content="$t('maxlengthcontent')"
                    />
                  </th>
                  <th>
                    {{ $t('required') }}
                  </th>
                  <th>
                    {{ $t('unique') }}
                  </th>
                  <th class="largecol">
                    {{ $t('defaultfield') }}
                    <column-tooltip
                      :header="$t('defaultfield')"
                      :content="$t('defaultfieldcontent')"
                    />
                  </th>
                  <th class="largecol">
                    {{ $t('isdsarflag') }}
                    <column-tooltip
                      :header="$t('isdsarflag')"
                      :content="$t('isdsarflagcontent')"
                    />
                  </th>
                  <th class="largecol">
                    {{ $t('isrtbfflag') }}
                    <column-tooltip
                      :header="$t('isrtbfflag')"
                      :content="$t('isrtbfflagcontent')"
                    />
                  </th>
                  <th class="largecol">
                    {{ $t('description') }}
                  </th>
                  <th class="sticky-last">
                    {{ $t('action') }}
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(attribute, i) in allAttributes" :key="i">
                  <td class="sticky-first">
                    <v-row class="content-info" no-gutters>
                      <v-col v-if="attribute.isSelected && isInUse">
                        <v-text-field
                          label="Attribute Name"
                          class="mini-field"
                          v-model="attribute.attributeName"
                          maxlength="50"
                          required
                          filled
                        ></v-text-field>
                      </v-col>
                      <v-col v-else>
                        {{ attribute.attributeName }}
                      </v-col>
                      <v-col
                        md="auto"
                        class="align-self-center bml1"
                        v-if="attribute.isCoreAttr"
                      >
                        <v-icon>lock</v-icon>
                      </v-col>
                    </v-row>
                  </td>
                  <td>
                    <span
                      v-if="
                        attribute.isSelected &&
                          (isCloned || (!attribute.isCoreAttr && !editInUse))
                      "
                    >
                      <v-select
                        label="Data Type"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="attribute.dataType"
                        :error="datatypeRequired"
                        :items="dataTypes"
                        @change="clearFields(attribute)"
                        filled
                      ></v-select>
                    </span>
                    <span v-else>
                      {{ attribute.dataType }}
                    </span>
                  </td>
                  <td>
                    <span
                      v-if="
                        attribute.isSelected &&
                          !attribute.isCoreAttr &&
                          attribute.dataType === 'String'
                      "
                    >
                      <v-text-field
                        v-model="attribute.maxLength"
                        label="Max Length"
                        class="mini-field"
                        type="number"
                        min="1"
                        filled
                      >
                      </v-text-field>
                    </span>
                    <span v-else>{{ attribute.maxLength }}</span>
                  </td>
                   <td>
                    <span> {{ attribute.required ? "Yes" : "No" }} </span>
                  </td>
                  <td>
                    <span> {{ attribute.unique ? "Yes" : "No" }} </span>
                  </td>
                  <td>
                    <span v-if="attribute.isSelected">
                      <v-text-field
                        v-if="attribute.dataType === 'String'"
                        :label="$t('defaultField')"
                        :error="defaultValueRequired"
                        class="mini-field bmt-2"
                        ref="item.defaultValue"
                        v-model="attribute.defaultValue"
                        maxlength="100"
                        filled
                      ></v-text-field>
                      <v-text-field
                        v-else-if="attribute.dataType === 'Number'"
                        :label="$t('defaultField')"
                        class="mini-field bmt-2"
                        :error="defaultValueRequired"
                        ref="item.defaultValue"
                        v-model="attribute.defaultValue"
                        v-on:keypress="isNumeric($event)"
                        type="number"
                        min="1"
                        filled
                      ></v-text-field>
                      <v-text-field
                        v-else-if="attribute.dataType === 'Date'"
                        label="Default Field"
                        placeholder="mm/dd/yyyy"
                        class="mini-field bmt-2"
                        :error="defaultValueRequired || validDateRequired"
                        ref="item.defaultValue"
                        v-model="attribute.defaultValue"
                        v-on:keypress="isDate($event)"
                        filled
                      ></v-text-field>
                      <v-select
                        v-else-if="attribute.dataType === 'Boolean'"
                        :label="$t('defaultField')"
                        v-model="attribute.defaultValue"
                        :items="booleanStrings"
                        :error="defaultValueRequired"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        filled
                      ></v-select>
                    </span>
                    <span v-else>
                      {{ attribute.defaultValue }}
                    </span>
                  </td>
                  <td>
                    <span v-if="attribute.isSelected">
                      <v-select
                        :label="$t('isdsarflag')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="attribute.isDSARFlag"
                        :items="booleans"
                        filled
                      ></v-select>
                    </span>
                    <span v-else>
                      {{ attribute.isDSARFlag }}
                    </span>
                  </td>
                  <td>
                    <span v-if="attribute.isSelected">
                      <v-select
                        :label="$t('isrtbfflag')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="attribute.isRTBFFlag"
                        :items="booleans"
                        filled
                      ></v-select>
                    </span>
                    <span v-else>
                      {{ attribute.isRTBFFlag }}
                    </span>
                  </td>
                  <td>
                    <span v-if="attribute.isSelected && !attribute.isCoreAttr">
                      <v-text-field
                        label="Description"
                        class="mini-field"
                        v-model="attribute.description"
                        maxlength="50"
                        filled
                      ></v-text-field>
                    </span>
                    <span v-else>
                      {{ attribute.description }}
                    </span>
                  </td>
                  <td class="sticky-last">
                    <template v-if="attribute.isSelected">
                      <v-icon
                        color="#0628b1"
                        @click="saveCoreAttribute(attribute, i)"
                        data-qe-id="header_attr_btn_save"
                      >
                        save
                      </v-icon>
                      <v-icon
                        color="#212121"
                        @click="cancelEditedAttribute(attribute, i)"
                        data-qe-id="header_attr_btn_cancel"
                      >
                        cancel
                      </v-icon>
                    </template>
                    <template v-else>
                      <v-icon
                        color="#0628b1"
                        :disabled="
                          !attribute.isEditable && !attribute.isSelected
                        "
                        @click="editAttribute(attribute, i)"
                        data-qe-id="header_attr_btn_edit"
                      >
                        edit
                      </v-icon>
                      <v-icon
                        color="#0628b1"
                        :disabled="
                          (isCloned || isCreate)
                            ? attribute.isCoreAttr
                              ? true
                              : false
                            : true
                        "
                        @click="deleteAttribute(attribute, i)"
                        data-qe-id="header_attr_btn_delete"
                      >
                        delete
                      </v-icon>
                    </template>
                  </td>
                </tr>
                <tr v-for="(tempAttr, i) in tempAttributes" :key="tempAttr.id">
                  <td class="sticky-first">
                    <v-row class="content-info" no-gutters>
                      <v-col v-if="tempAttr.isSelected">
                        <v-text-field
                          :label="$t('dataName')"
                          class="mini-field"
                          v-model="tempAttr.attributeName"
                          :error="dataNameRequired"
                          maxlength="50"
                          required
                          filled
                        ></v-text-field>
                      </v-col>
                    </v-row>
                  </td>
                  <td>
                    <span v-if="tempAttr.isSelected">
                      <v-select
                        data-qe-id="temp_data_type_field_selector"
                        :label="$t('dataType')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="tempAttr.dataType"
                        @change="clearDefaultFields(tempAttr)"
                        :error="dataTypeRequired"
                        :items="dataTypes"
                        filled
                      ></v-select>
                    </span>
                  </td>
                  <td>
                    <span
                      v-if="
                        tempAttr.isSelected && tempAttr.dataType === 'String'
                      "
                    >
                      <v-text-field
                        v-model="tempAttr.maxLength"
                        :label="$t('maxLength')"
                        class="mini-field"
                        :error="maxLengthRequired"
                        type="number"
                        min="1"
                        filled
                      ></v-text-field>
                    </span>
                  </td>
                  <td>
                    <span> </span>
                  </td>
                  <td>
                    <span> </span>
                  </td>
                  <td>
                    <span v-if="tempAttr.isSelected">
                      <v-text-field
                        v-if="tempAttr.dataType === 'String'"
                        :label="$t('defaultField')"
                        :error="defaultValueRequired"
                        class="mini-field bmt-2"
                        ref="item.defaultValue"
                        v-model="tempAttr.defaultValue"
                        maxlength="100"
                        filled
                        v-on:keypress="isLetter($event)"
                      ></v-text-field>
                      <v-text-field
                        v-else-if="tempAttr.dataType === 'Number'"
                        :label="$t('defaultField')"
                        class="mini-field bmt-2"
                        :error="defaultValueRequired"
                        ref="item.defaultValue"
                        v-model="tempAttr.defaultValue"
                        v-on:keypress="isNumeric($event)"
                        type="number"
                        min="1"
                        filled
                      ></v-text-field>
                      <v-text-field
                        v-else-if="tempAttr.dataType === 'Date'"
                        label="Default Field"
                        placeholder="mm/dd/yyyy"
                        class="mini-field bmt-2"
                        :error="defaultValueRequired"
                        ref="item.defaultValue"
                        v-model="tempAttr.defaultValue"
                        v-on:keypress="isDate($event)"
                        filled
                      ></v-text-field>
                      <v-select
                        v-else-if="tempAttr.dataType === 'Boolean'"
                        :label="$t('defaultField')"
                        v-model="tempAttr.defaultValue"
                        :items="booleanStrings"
                        :error="defaultValueRequired"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        filled
                      ></v-select>
                    </span>
                  </td>
                  <td>
                    <span v-if="tempAttr.isSelected">
                      <v-select
                        :label="$t('isdsarflag')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="tempAttr.isDSARFlag"
                        :items="booleans"
                        filled
                      ></v-select>
                    </span>
                  </td>
                  <td>
                    <span v-if="tempAttr.isSelected">
                      <v-select
                        :label="$t('isrtbfflag')"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        v-model="tempAttr.isRTBFFlag"
                        :items="booleans"
                        filled
                      ></v-select>
                    </span>
                  </td>
                  <td>
                    <span v-if="tempAttr.isSelected">
                      <v-text-field
                        :label="$t('description')"
                        class="mini-field"
                        v-model="tempAttr.description"
                        maxlength="50"
                        required
                        filled
                      ></v-text-field>
                    </span>
                  </td>
                  <td class="sticky-last">
                    <template v-if="tempAttr.isSelected">
                      <v-icon
                        color="#0628b1"
                        data-qe-id="mem_attr_btn_save"
                        @click="saveAttribute(tempAttr, i)"
                      >
                        {{ $t('save') }}
                      </v-icon>
                      <v-icon
                        color="#212121"
                        @click="cancelAttribute()"
                        data-qe-id="mem_attr_btn_cancel"
                      >
                        cancel
                      </v-icon>
                    </template>
                  </td>
                </tr>
              </tbody>
            </v-simple-table>
          </v-flex>
        </v-col>
      </v-row>
    </v-col>
    <v-col sm="12" class="bmt1" v-if="validationMessages.length > 0">
      <v-alert
        class="b-alert-error"
        type="error"
        :dismissible="false"
        style="min-width:100%"
      >
        <v-row class="alert-block align-center" no-gutters>
          <v-col class="alert-block__body">
            <h3>{{ $t('error') }}</h3>
            <p v-for="error in validationMessages" :key="error">{{ error }}</p>
          </v-col>
        </v-row>
      </v-alert>
    </v-col>
    <v-col>
      <v-btn
        text
        class="no-ripple btn-hover-none bpx0"
        @click="addNewAttribute()"
        data-qe-id="header_attr_btn_add-new"
      >
        <span class="fbold text-uppercase assign primary-text">
          <v-icon class="pr-3 primary-text">add_circle_outline</v-icon>
          {{ $t('addNewAttribute') }}
        </span>
      </v-btn>
    </v-col>
  </v-row>
</template>

<script>
import { mapState } from 'vuex';
import ColumnTooltip from './ColumnTooltip';
import { transactionDefinitonObj } from '../../../../i18n/language';
export default {
  components: {
    ColumnTooltip
  },
  computed: {
    ...mapState('transactionDefinitionModule', {
      allAttributes: (state) => {
        return state.attributes.tenderAttributes;
      },
      TransactionDefobj: (state) => {
        return state.TransactionDefobj;
      },
      tenderhasErrors: (state) => {
        return state.tenderhasErrors;
      }
    })
  },
  i18n: transactionDefinitonObj,
  data () {
    return {
      // attributeSelected: false,
      dataTypes: ['String', 'Number', 'Boolean', 'Date'],
      booleans: [true, false],
      booleanStrings: ['true', 'false'],
      validationMessages: [],
      dataNameRequired: false,
      datatypeRequired: false,
      maxLengthRequired: false,
      initialLength: null,
      tempAttributes: [],
      editedAttribute: {},
      isInUse: false,
      isCloned: false,
      isCreate: false,
      defaultValueRequired: false,
      validDateRequired: false,
      editInUse: false
    };
  },
  mounted () {
    if (this.$route.name.includes('clone')) {
      this.isCloned = true;
    } else if (this.$route.name.includes('edit')) {
      this.editInUse = this.TransactionDefobj.inUse;
    } else if (this.$route.name.includes('create')) {
      this.isCreate = true;
    }
  },
  methods: {
    addNewAttribute () {
      let addAttribute = {
        attributeName: '',
        dataType: '',
        maxLength: '',
        required: true,
        unique: true,
        defaultValue: '',
        isDSARFlag: false,
        isRTBFFlag: false,
        description: '',
        isSelected: true,
        isEditable: true,
        isCoreAttr: false,
        extensionPropertyId: 0,
        attributeMetadataId: 1000
      };
      this.tempAttributes.push(addAttribute);
    },
    clearFields (attribute) {
      attribute.maxLength = '';
      attribute.defaultValue = '';
      attribute.isDSARFlag = false;
      attribute.isRTBFFlag = false;
      attribute.description = '';
    },
    clearDefaultFields (attribute) {
      attribute.maxLength = '';
      attribute.defaultValue = '';
    },
    saveCoreAttribute (attribute, index) {
      this.validationMessages = [];
      if (attribute.isCoreAttr === true) {
        this.allAttributes[index] = attribute;
        attribute.isSelected = false;
      } else {
        this.saveAttribute(attribute, index);
      }
    },
    saveAttribute (attribute, index) {
      this.validationMessages = [];
      if (attribute.attributeName === '') {
        this.validationMessages.push('Data Name is Mandatory');
        this.dataNameRequired = true;
      } else {
        let duplicateNames = false;
        let counter = 0;
        this.allAttributes.forEach((element) => {
          let inputName = attribute.attributeName.toLowerCase();
          let name = element.attributeName.toLowerCase();
          if (name === inputName && counter !== index) {
            duplicateNames = true;
          }
          counter += 1;
        });
        if (duplicateNames) {
          this.validationMessages.push('Name must be unique');
        } else {
          this.dataNameRequired = false;
        }
      }
      if (attribute.dataType === '') {
        this.validationMessages.push('Data Type is Mandatory');
        this.datatypeRequired = true;
      } else {
        this.datatypeRequired = false;
      }
      if (attribute.dataType === 'String' && attribute.maxLength === '') {
        this.validationMessages.push(
          'Max length value is required for String data type'
        );
        this.maxLengthRequired = true;
      } else if (
        attribute.dataType === 'String' &&
        attribute.maxLength &&
        attribute.isEdited
      ) {
        if (attribute.extensionPropertyId === 0) {
          this.maxLengthRequired = false;
        } else if (this.initialLength > attribute.maxLength) {
          this.validationMessages.push('Max length value can not be decreased');
          this.maxLengthRequired = true;
        } else {
          this.maxLengthRequired = false;
        }
      } else {
        this.maxLengthRequired = false;
      }
      if (
        attribute.defaultValue === '' ||
        attribute.defaultValue === null ||
        attribute.dataType !== 'Boolean' &&
          attribute.defaultValue.trim() === ''
      ) {
        this.defaultValueRequired = true;
        this.validationMessages.push('Default Field values cannot be empty');
      } else if (
        attribute.maxLength !== null &&
        attribute.maxLength !== '' &&
        attribute.defaultValue !== ''
      ) {
        let defaultFieldLength = attribute.defaultValue.length;
        if (defaultFieldLength > attribute.maxLength) {
          this.defaultValueRequired = true;
          this.validationMessages.push(
            'Default Field value length should not be more than maxlength'
          );
        } else {
          this.defaultValueRequired = false;
        }
      } else if (
        attribute.dataType === 'Date' &&
        attribute.defaultValue !== ''
      ) {
        const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/;
        this.validDateRequired = !dateRegex.test(attribute.defaultValue);
        if (this.validDateRequired) {
          this.validationMessages.push('Entered date must be valid');
        }
      } else {
        this.defaultValueRequired = false;
        this.validDateRequired = false;
      }
      if (this.validationMessages.length === 0) {
        attribute.isSelected = false;
        this.tempAttributes.splice(index, 1);
        if (!attribute.isEdited) {
          const coreAttributeMetaDataID = this.allAttributes[0]
            .attributeMetadataId;
          attribute.attributeMetadataId =
            coreAttributeMetaDataID !== null &&
            coreAttributeMetaDataID !== undefined
              ? coreAttributeMetaDataID
              : 0;
          this.allAttributes.push(attribute);
        } else {
          this.allAttributes[index] = attribute;
        }
      }
    },
    editAttribute (attribute, index) {
      this.editAttribute[index] = Object.assign({}, attribute);
      attribute.isSelected = true;
      attribute.isEdited = true;
      if (attribute.dataType === 'String')
        this.initialLength = parseInt(attribute.maxLength);
    },
    cancelEditedAttribute (attribute, index) {
      this.clearErrors();
      for (let outerKey in this.editAttribute) {
        if (outerKey === `${index}`) {
          const editedAttribute = this.editAttribute[index];
          for (let key in editedAttribute) {
            attribute[key] = editedAttribute[key];
          }
        }
      }
    },
    cancelAttribute () {
      this.clearErrors();
      this.tempAttributes.splice(-1, 1);
    },
    deleteAttribute (attribute, index) {
      this.allAttributes.splice(index, 1);
    },
    clearErrors () {
      if (this.validationMessages.length > 0) {
        this.validationMessages = [];
        this.dataNameRequired = false;
        this.datatypeRequired = false;
        this.maxLengthRequired = false;
        this.defaultValueRequired = false;
        this.validDateRequired = false;
      }
    },
    isNumeric (e) {
      let char = String.fromCharCode(e.keyCode);
      if (/^\d+$/.test(char)) return true;
      else e.preventDefault();
    },
    isDate (e) {
      let char = String.fromCharCode(e.keyCode);
      if (/^\d+$/.test(char) || char === '/') return true;
      else e.preventDefault();
    }
  },
  watch: {
    validationMessages (value) {
      const haserrors = value.length > 0;
      this.$store.commit(
        'transactionDefinitionModule/tenderhasErrorsmutation',
        haserrors
      );
    }
  }
};
</script>
