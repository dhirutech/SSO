<template>
  <v-col>
    <brierley-table-module v-if="transactionDefinitions.length !== 0">
      <template v-slot:tablehead>
        <tr>
          <th v-for="item in header" :key="item.value" :width="item.width">
            {{ item.text }}
          </th>
        </tr>
      </template>
      <template v-slot:tablebody>
        <tr
          v-for="transactionDefinition in transactionDefinitions"
          :key="transactionDefinition.id"
        >
          <td>
            <h4 class="primary-text font15 text-uppercase fbold">
              {{ transactionDefinition.txnEntityDefName }}
            </h4>
          </td>
          <td>
            {{ transactionDefinition.txnEntityDefDescription }}
          </td>
          <td>
            {{ transactionDefinition.businessEntityName }}
            <v-row
              class="d-flex d-inline-flex hover-actions width-auto"
              no-gutters
            >
              <v-col>
                <brierleyCardIcons>
                  <template v-slot:action-icons>
                    <span
                      class="active"
                      @click="editTransactionDefinition(transactionDefinition)"
                    >
                      <v-icon>fe fe-eye</v-icon>
                      <span class="viewdetails-icon">
                        {{ $t('viewdetails') }}
                      </span>
                    </span>
                    <span
                      @click="clonetransactiondefinition(transactionDefinition)"
                    >
                      <v-icon>fe fe-copy</v-icon>
                      <span class="copy-icon">{{ $t('copy') }}</span>
                    </span>
                    <span
                      data-qe-id="table_trans_details_edit"
                      @click="editTransactionDefinition(transactionDefinition)"
                    >
                      <v-icon>fe fe-edit</v-icon>
                      <span class="edit-icon">{{ $t('edit') }}</span>
                    </span>
                    <span
                      :class="{
                        'disable-item': transactionDefinition.inUse === true
                      }"
                      @click="showDeletePopup(transactionDefinition)"
                    >
                      <v-icon
                        :title="$t('delete')"
                        :class="{
                          blackicon: transactionDefinition.inUse === false
                        }"
                        >fe-trash-2</v-icon
                      >
                      <span class="delete-icon">{{ $t('delete') }}</span>
                    </span>
                  </template>
                </brierleyCardIcons>
              </v-col>
            </v-row>
          </td>
        </tr>
        <brierley-dialogbox :dialog="dialog" @closeMe="dialog = false">
          <template v-slot:dialog-header>
            <v-card-title class="gen2-dialog-title text-uppercase">{{
              $t('deleteAlertName') + ` ${toBeDeletedTransactionName}`
            }}</v-card-title>
          </template>
          <template v-slot:dialog-body-alert>
            <brierley-alert
              alertType="error"
              :alertBody="$t('delete')"
            ></brierley-alert>
          </template>
          <template v-slot:dialog-body-description>
            <v-col>
              <p>
                {{ $t('deleteAlertBody') }}
              </p>
            </v-col>
          </template>
          <template v-slot:dialog-footer>
            <v-btn text class="cancel no-ripple" @click="dialog = false">{{
              $t('no')
            }}</v-btn>
            <v-btn class="primaryctabtn btn-close" @click="deleteProgram()">{{
              $t('yes')
            }}</v-btn>
          </template>
        </brierley-dialogbox>
      </template>
    </brierley-table-module>
  </v-col>
</template>
<script>
import {
  BrierleyTableModule,
  BrierleyCardIcons,
  BrierleyDialogbox,
  brierleyAlert
} from '@brierley/SharedComponents';
import { transactionDefinitonObj } from '../../../../i18n/language';
import { mapState } from 'vuex';
import Vue from 'vue';

export default {
  components: {
    BrierleyTableModule,
    BrierleyCardIcons,
    BrierleyDialogbox,
    brierleyAlert
  },
  props: {
    transactionDefinitions: {
      type: Array,
      default: null
    }
  },
  i18n: transactionDefinitonObj,
  data () {
    return {
      dialog: false,
      toBeDeletedTransactionId: 0,
      toBeDeletedTransactionName: '',
      header: [
        {
          text: this.$t('defname'),
          width: '30%'
        },
        {
          text: this.$t('desc'),
          width: '40%'
        },
        {
          text: this.$t('pgmentity'),
          width: '30%'
        }
      ]
    };
  },
  computed: {
    ...mapState('transactionDefinitionModule', {
      TransactionDefobj: (state) => {
        return state.TransactionDefobj;
      },
      attributes: (state) => state.attributes
    })
  },
  methods: {
    editTransactionDefinition (data) {
      this.fetchTransactionData(data, true, false);
      this.$router.push('/loyaltyadmin/TransactionDefinition/edit');
    },
    clonetransactiondefinition (data) {
      this.fetchTransactionData(data, false, true);
      this.$router.push('/loyaltyadmin/TransactionDefinition/clone');
    },
    fetchTransactionData (data, isEditable, isCloned) {
      this.$store
        .dispatch('transactionDefinitionModule/getTxnDefAction', data)
        .then((res) => {
          if (res.status === 200) {
            this.$store.commit(
              'transactionDefinitionModule/setTransactionDefinition',
              res.data
            );
            this.setAttributes(isEditable, isCloned);
          }
        })
        .catch();
    },
    setAttributes (isEditable, isCloned) {
      let modifiedAttributes = {};
      for (const property in this.TransactionDefobj) {
        if (
          property === 'headerAttributes' ||
          property === 'detailAttributes' ||
          property === 'tenderAttributes' ||
          property === 'redemptionAttributes'
        ) {
          const core = this.TransactionDefobj[property]
            .transactionCoreAttributes;
          const extended = this.TransactionDefobj[property]
            .transactionExtendedAttributes;

          this.setDefaultValues(core, isEditable, true, isCloned);
          this.setDefaultValues(extended, true, false, isCloned);
          const allAttributes = core.concat(extended);

          if (property === 'headerAttributes') {
            modifiedAttributes['headerAttributes'] = allAttributes;
          } else if (property === 'detailAttributes') {
            modifiedAttributes['detailAttributes'] = allAttributes;
          } else if (property === 'tenderAttributes') {
            modifiedAttributes['tenderAttributes'] = allAttributes;
          } else if (property === 'redemptionAttributes') {
            modifiedAttributes['redemptionAttributes'] = allAttributes;
          }
        }
      }
      this.$store.commit(
        'transactionDefinitionModule/setCoreattributes',
        modifiedAttributes
      );
    },
    setDefaultValues (item, isEditable, isCoreAttribute, isCloned) {
      for (let i = 0; i < item.length; i++) {
        if (isCloned && isCoreAttribute) {
          item[i].attributeMetaProgramPropertyId = 0;
        } else if (isCloned && !isCoreAttribute) {
          item[i].extensionPropertyId = 0;
        }
        item[i].isEditable = isEditable;
        if ('isCoreAttr' in item[i]) {
          item[i].isCoreAttribute = isCoreAttribute;
        } else {
          Vue.set(item[i], 'isCoreAttr', isCoreAttribute);
        }
      }
    },
    showDeletePopup (transactionDefintion) {
      this.dialog = true;
      this.toBeDeletedTransactionId = transactionDefintion.txnEntityDefId;
      this.toBeDeletedTransactionName = transactionDefintion.txnEntityDefName;
    },
    deleteProgram () {
      this.dialog = false;
      this.$store
        .dispatch(
          'transactionDefinitionModule/deleteTxnDefAction',
          this.toBeDeletedTransactionId
        )
        .then((res) => {
          if (res.status === 200) {
            this.fetchAllTransactions();
          }
        })
        .catch();
    },
    fetchAllTransactions () {
      this.$store
        .dispatch('transactionDefinitionModule/viewTxnDefAction')
        .then((res) => {
          if (res.status === 200) {
            this.$store.commit(
              'transactionDefinitionModule/viewTxndataMutation',
              res.data
            );
          } else if (res.status === 204) {
            this.$store.commit(
              'transactionDefinitionModule/viewTxndataMutation',
              []
            );
          }
        })
        .catch();
    }
  }
};
</script>
<style lang="scss">
.hover-actions {
  &.width-auto {
    width: 100% !important;
  }
}
</style>
