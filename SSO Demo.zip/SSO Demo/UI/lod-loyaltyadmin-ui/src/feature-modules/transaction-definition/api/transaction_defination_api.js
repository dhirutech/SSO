import Vue from 'vue';
import constants from '../../store-definition/config/constants';
import utilities from '../../store-definition/utilities/store-definition-helper';

const createTxnDefApi = (params) => {
  return Vue.prototype.$http.post(
    'transactions/api/v2/TransactionDefinition/EditTransactionDefinition',
    params
  );
};

const viewTxnDefApi = () => {
  return Vue.prototype.$http.get(
    'transactions/api/v2/TransactionDefinition/GetAll'
  );
};

const getTxnDefById = (params) => {
  return Vue.prototype.$http.get(
    `transactions/api/v2/TransactionDefinition/GetTransactionDefinitionById?TransactionDefinitionId=${params.txnEntityDefId}`
  );
};

const deleteTxnDef = (params) => {
  return Vue.prototype.$http.get(
    `transactions/api/v2/TransactionDefinition/DeleteTransactionDefinition?txnDefId=${params}`
  );
};

const getBusinessEntityNodeAsyncAPI = async () => {
  return await Vue.prototype.$http
    .get(constants.LOYALTY_CONFIGURATION_V1 + '/businessEntities/structure')
    .then((res) => {
      return utilities.getJsonData(res.data);
    });
};

const fetchcoreattibutesApi = () => {
  return Vue.prototype.$http.get(
    'transactions/api/v2/TransactionDefinition/coreAttributes'
  );
};

export {
  createTxnDefApi,
  viewTxnDefApi,
  fetchcoreattibutesApi,
  getBusinessEntityNodeAsyncAPI,
  getTxnDefById,
  deleteTxnDef
};
