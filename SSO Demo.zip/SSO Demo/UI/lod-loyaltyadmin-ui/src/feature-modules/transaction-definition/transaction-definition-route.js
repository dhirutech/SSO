import transactionDefinition from './components/transaction-definition.vue';
import editTransactionDefinition from './components/child/edit-transaction-definition.vue';


const transactionDefinitionRoutes = [
  {
    path: '/loyaltyadmin/transactionDefinition',
    name: 'transactionDefinition',
    component: transactionDefinition,
    meta: {
      showNavigation: false,
    },
  },
  {
    path: '/loyaltyadmin/TransactionDefinition/edit',
    name: 'editTransactionDefinition',
    component: editTransactionDefinition,
    meta: {
      showNavigation: false,
    },
  },
  {
    path: '/loyaltyadmin/TransactionDefinition/create',
    name: 'createTransactionDefinition',
    component: editTransactionDefinition,
    meta: {
      showNavigation: false,
    },
  },
  {
    path: '/loyaltyadmin/TransactionDefinition/clone',
    name: 'cloneTransactionDefinition',
    component: editTransactionDefinition,
    meta: {
      showNavigation: false,
    },
  },
];

export default transactionDefinitionRoutes;
