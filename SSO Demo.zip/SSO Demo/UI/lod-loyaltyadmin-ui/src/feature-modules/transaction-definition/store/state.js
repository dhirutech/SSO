export default {
  TransactionDefobj: {
    transactionDefinitionId: 0,
    txnEntityDefId: 0,
    businessEntityId: 0,
    transactionDefName: '',
    txnEntityDefName: '',
    transactionDefDescription: '',
    isReviewed: false,
    defStatus: null,
    inUse: false,
    headerAttributes: {
      transactionCoreAttributes: [],
      transactionExtendedAttributes: []
    },
    detailAttributes: {
      transactionCoreAttributes: [],
      transactionExtendedAttributes: []
    },
    tenderAttributes: {
      transactionCoreAttributes: [],
      transactionExtendedAttributes: []
    },
    redemptionAttributes: {
      transactionCoreAttributes: [],
      transactionExtendedAttributes: []
    }
  },
  attributes: {
    headerAttributes: [],
    tenderAttributes: [],
    detailAttributes: [],
    redemptionAttributes: []
  },
  businessEntityNode: {},
  businessEntitiesAlreadyAssigned: [],
  transactionDefinitionData: [],
  headerhasErrors: false,
  detialhasErrors: false,
  tenderhasErrors: false,
  rewardhasErrors: false
};
