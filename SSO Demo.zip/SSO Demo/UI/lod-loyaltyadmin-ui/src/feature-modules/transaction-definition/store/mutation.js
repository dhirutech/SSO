import Vue from 'vue';


const setCoreattributes = (state, payload) => {
  let modifiedAttributes = {};
  modifiedAttributes['headerAttributes'] = payload.headerAttributes;
  modifiedAttributes['detailAttributes'] = payload.detailAttributes;
  modifiedAttributes['tenderAttributes'] = payload.tenderAttributes;
  modifiedAttributes['redemptionAttributes'] = payload.redemptionAttributes;
  state.attributes = Object.assign({}, modifiedAttributes);
};

const viewTxndataMutation = (state, payload) => {
  state.transactionDefinitionData = payload;
};

const setTransactionDefinition = (state, payload) => {
  state.TransactionDefobj = payload;
};

const setDisabled = (bEntity, disabledEntities, TransactionDefobj) => {
  if (disabledEntities.includes(bEntity.id)) {
    bEntity.isDisabled = true;
    bEntity.color = 'gray';
  } else {
    bEntity.isDisabled = false;
    bEntity.color = 'black';
  }
  bEntity.programs = [];

  if (bEntity.id === TransactionDefobj.businessEntityId) {
    bEntity.selected = !bEntity.selected;
  } else {
    bEntity.selected = false;
  }

  if (bEntity.children && bEntity.children.length > 0) {
    for (let i = 0; i < bEntity.children.length; i++) {
      setDisabled(bEntity.children[i], disabledEntities, TransactionDefobj);
    }
  }
  return bEntity;
};

function setDefaultValues (item) {
  for (let i=0; i < item.length; i++) {
    Vue.set(item[i], 'isSelected', false);
    Vue.set(item[i], 'isEditable', true);
    Vue.set(item[i], 'isCoreAttr', true);
    Vue.set(item[i], 'isDSARFlag', false);
    Vue.set(item[i], 'isRTBFFlag', false);
    Vue.set(item[i], 'attributeMetaProgramPropertyId', 0);
    Vue.set(item[i], 'attributeName', item[i].displayText);
  }
  return item;
}

const fetchcoreattributeMutation = (state, payload) => {
  let modifiedAttributes = {};
  modifiedAttributes['headerAttributes'] = setDefaultValues(payload.headerAttributes);
  modifiedAttributes['detailAttributes'] = setDefaultValues(payload.detailAttributes);
  modifiedAttributes['tenderAttributes'] = setDefaultValues(payload.tenderAttributes);
  modifiedAttributes['redemptionAttributes'] = setDefaultValues(payload.redemptionAttributes);
  state.attributes = Object.assign({}, modifiedAttributes);
};

const setBusinessEntityNode = (state, payload) => {
  state.businessEntityNode = setDisabled(
    payload,
    state.businessEntitiesAlreadyAssigned,
    state.TransactionDefobj
  );
};

const setBusinessEntitiesAlreadyAssigned = (state, payload) => {
  state.businessEntitiesAlreadyAssigned = [];
  for (let i = 0; i < payload.length; i++) {
    state.businessEntitiesAlreadyAssigned.push(payload[i].businessEntityId);
  }
};

const headerhasErrorsmutation = (state, payload) => {
  state.headerhasErrors = payload;
};

const detailhasErrorsmutation = (state, payload) => {
  state.detialhasErrors = payload;
};

const tenderhasErrorsmutation = (state, payload) => {
  state.tenderhasErrors = payload;
};

const rewardhasErrorsmutation = (state, payload) => {
  state.rewardhasErrors = payload;
};

export default {
  viewTxndataMutation,
  setBusinessEntityNode,
  setBusinessEntitiesAlreadyAssigned,
  setTransactionDefinition,
  fetchcoreattributeMutation,
  setCoreattributes,
  headerhasErrorsmutation,
  detailhasErrorsmutation,
  tenderhasErrorsmutation,
  rewardhasErrorsmutation
};
