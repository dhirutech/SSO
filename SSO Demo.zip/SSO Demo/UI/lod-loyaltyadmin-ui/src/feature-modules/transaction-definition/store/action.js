import {
  createTxnDefApi,
  viewTxnDefApi,
  getBusinessEntityNodeAsyncAPI,
  fetchcoreattibutesApi,
  getTxnDefById,
  deleteTxnDef
} from '../api/transaction_defination_api.js';

const createTxnDefAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    createTxnDefApi(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const viewTxnDefAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    viewTxnDefApi(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getTxnDefAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getTxnDefById(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const deleteTxnDefAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    deleteTxnDef(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getBusinessEntityNode = async ({ commit }) => {
  let response = await getBusinessEntityNodeAsyncAPI();
  commit('setBusinessEntityNode', response);
};

const fetchcoreattibutesAction = () => {
  return new Promise((resolve, reject) => {
    fetchcoreattibutesApi()
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export default {
  createTxnDefAction,
  viewTxnDefAction,
  fetchcoreattibutesAction,
  getBusinessEntityNode,
  getTxnDefAction,
  deleteTxnDefAction
};
