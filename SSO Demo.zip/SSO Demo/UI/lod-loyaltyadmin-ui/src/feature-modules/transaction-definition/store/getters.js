const businessEntityNode = (state) => state.businessEntityNode;
const businessEntitiesAlreadyAssigned = (state) =>
  state.businessEntitiesAlreadyAssigned;
const transactionDefinition = (state) => state.TransactionDefobj;

export default {
  businessEntityNode,
  businessEntitiesAlreadyAssigned,
  transactionDefinition
};
