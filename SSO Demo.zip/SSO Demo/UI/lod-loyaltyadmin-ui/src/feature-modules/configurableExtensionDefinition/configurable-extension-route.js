import configurableExtensionDashboard from './components/configurableExtensionDashboard.vue';

const configurableExtensionRoutes = [
  {
    path: '/loyaltyadmin/configurableExtension',
    name: 'configurableExtension',
    component: configurableExtensionDashboard,
    meta: {
      showNavigation: false
    }
  }
];

export default configurableExtensionRoutes;
