<template>
  <v-row no-gutters>
    <v-col
      cols="12"
      v-for="configExtension in configExtensionDefinitions"
      :key="configExtension.id"
    >
      <brierley-grid-card>
        <template v-slot:grid-card-body>
          <v-col cols="12" sm="12" md="4">
            <v-card-title
              title="Default member Definition"
              class="elipsis-fullwidth"
              >{{ configExtension.configEntityDefName }}</v-card-title
            >
            <p class="bmt3">
              <strong>{{ $t("extensionType") }}: </strong>
              <span>{{ configExtension.configExtensionType }}</span>
            </p>
          </v-col>
          <v-col cols="12" sm="12" md="4">
            <p class="bmt0">
              <strong>{{ $t("extensionDescription") }}: </strong>
            </p>
            <p>
              {{ configExtension.configEntityDefDescription }}
            </p>
          </v-col>
          <v-col cols="12" sm="12" md="3" offset-md="1">
            <p class="bmt0">
              <strong>{{ $t("programEntity") }}: </strong>
            </p>
            <p>
              {{ configExtension.programEntityName }}
            </p>
          </v-col>
          <v-col cols="12">
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span class="active">
                  <v-icon>fe fe-eye</v-icon>
                  <span class="viewdetails-icon">{{ $t("viewdetails") }}</span>
                </span>
                <span>
                  <v-icon>fe fe-copy</v-icon>
                  <span class="copy-icon">{{ $t("copy") }}</span>
                </span>
                <span data-qe-id="grid_trans_details_edit">
                  <v-icon>fe fe-edit</v-icon>
                  <span class="edit-icon">{{ $t("edit") }}</span>
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
        </template>
      </brierley-grid-card>
    </v-col>
    <v-col v-if="configExtensionDefinitions.length === 0">
      <brierley-no-result
        :noResultMessage="this.$t('noRecordsMessage')"
        id="viewuser_img_no_data"
      ></brierley-no-result>
    </v-col>
  </v-row>
</template>
<script>
import {
  BrierleyGridCard,
  BrierleyCardIcons,
  BrierleyNoResult
} from '@brierley/SharedComponents';
import { configurableExtensionObj } from '../../../../i18n/language';

export default {
  components: {
    BrierleyGridCard,
    BrierleyCardIcons,
    BrierleyNoResult
  },
  props: {
    configExtensionDefinitions: {
      type: Array,
      default: null
    }
  },
  data () {
    return {};
  },
  computed: {},
  methods: {},
  i18n: configurableExtensionObj
};
</script>
