<template>
  <brierley-inner-view>
    <template v-slot:header>
      <span class="inner-head text-uppercase">
        {{ $t("configurableExtension") }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        data-qe-id="trans_details_btn_close_header"
        class="no-ripple"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon> {{ $t("close") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <brierley-form-title
        class="bmt3"
        :formTitle="$t('configurableExtensions')"
        :showSteps="false"
      ></brierley-form-title>
      <v-row no-gutters class="bmt4 bmb1 align-center">
        <v-col>
          <h4 class="font15 text-uppercase fbold">
            {{ $t("configurableExtensionList") }}
          </h4>
        </v-col>
        <v-col class="text-right">
          <brierley-view-option
            :viewList="viewList"
            @viewChanged="viewType = $event"
          />
          <v-btn
            text
            class="no-ripple btn-hover-none bpx0 bml1"
          >
            <span class="f600 primary-text text-uppercase"
              ><v-icon>add_circle</v-icon> {{ $t("createNewconfigExtension") }}
            </span>
          </v-btn>
        </v-col>
      </v-row>
      <div v-if="viewType == 'grid_view'">
        <configurableExtensionGridView
          :configExtensionDefinitions="configExtensions"
        ></configurableExtensionGridView>
      </div>
      <div v-if="viewType == 'table_view'">
        <configurableExtensionTableView
          :configExtensionDefinitions="configExtensions"
        ></configurableExtensionTableView>
      </div>
      <div v-if="viewType == 'card_view'">
        <configurableExtensionCardView
          :configExtensionDefinitions="configExtensions"
        ></configurableExtensionCardView>
      </div>
    </template>
    <template v-slot:footer>
      <v-btn
        text
        class="primaryctabtn no-ripple"
        data-qe-id="trans_details_btn_close_footer"
        @click.native="$router.push('/gettingstarted')"
      >
        {{ $t("close") }}
      </v-btn>
    </template>
  </brierley-inner-view>
</template>

<script>
import {
  BrierleyInnerView,
  BrierleyFormTitle,
  BrierleyViewOption
} from '@brierley/SharedComponents';
import configurableExtensionGridView from './child/configurableExtensionGridView';
import configurableExtensionCardView from './child/configurableExtensionCardView';
import configurableExtensionTableView from './child/configurableExtensionTableView';
import { configurableExtensionObj } from '../../../i18n/language';

export default {
  i18n: configurableExtensionObj,
  components: {
    BrierleyInnerView,
    BrierleyFormTitle,
    BrierleyViewOption,
    configurableExtensionGridView,
    configurableExtensionTableView,
    configurableExtensionCardView
  },
  data () {
    return {
      viewType: 'grid_view',
      viewList: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label:
            localStorage.getItem('language') === 'en'
              ? 'Grid view'
              : 'グリッドビュー'
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label:
            localStorage.getItem('language') === 'en'
              ? 'Table view'
              : 'テーブルビュー'
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label:
            localStorage.getItem('language') === 'en'
              ? 'Card view'
              : 'カードビュー'
        }
      ],
      configExtensions: [
        {
          configEntityDefName: 'GAP CONFIG Ext',
          configEntityDefDescription: 'Loreum ipsum default description',
          programEntityName: 'GAP',
          configExtensionType: 'Core Extended Table'
        },
        {
          configEntityDefName: 'Ck CONFIG Ext',
          configEntityDefDescription: 'Loreum ipsum default description',
          programEntityName: 'Calvin Klien',
          configExtensionType: 'Core Extended Table'
        }
      ]
    };
  }
};
</script>
