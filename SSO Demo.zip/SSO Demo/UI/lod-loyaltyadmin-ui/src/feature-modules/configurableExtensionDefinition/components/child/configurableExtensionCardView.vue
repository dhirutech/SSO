<template>
  <v-row>
    <v-col
      md="6"
      v-for="configExtension in configExtensionDefinitions"
      :key="configExtension.id"
    >
      <brierley-card>
        <template v-slot:header>
          <h2
            class="bmb3 bmt2 elipsis-fullwidth"
            title="USA TRANSACTION Definition"
          >
            {{ configExtension.configEntityDefName }}
          </h2>
        </template>
        <template v-slot:body>
          <p>
            <strong> {{ $t("extensionDescription") }}: </strong>
          </p>
          <p>
            {{ configExtension.configEntityDefDescription }}
          </p>
          <p class="bmt2">
            <strong> {{ $t("extensionType") }}: </strong>
            <span>{{ configExtension.configExtensionType }}</span>
          </p>
          <p class="bmt2">
            <strong> {{ $t("programEntity") }}: </strong>
            <span>{{ configExtension.programEntityName }}</span>
          </p>
        </template>
        <template v-slot:footer>
          <v-col class="mt-n5">
            <brierley-card-icons class="bmt bpa0">
              <template v-slot:action-icons>
                <span class="active">
                  <v-icon>fe fe-eye</v-icon>
                  <span class="viewdetails-icon">{{ $t("viewdetails") }} </span>
                </span>
                <span>
                  <v-icon>fe fe-copy</v-icon>
                  <span class="copy-icon">{{ $t("copy") }}</span>
                </span>
                <span data-qe-id="card_trans_details_edit">
                  <v-icon>fe fe-edit</v-icon>
                  <span class="edit-icon">{{ $t("edit") }}</span>
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
        </template>
      </brierley-card>
    </v-col>
    <v-col v-if="configExtensionDefinitions.length === 0">
      <brierley-no-result
        :noResultMessage="this.$t('noRecordsMessage')"
        id="viewuser_img_no_data"
      ></brierley-no-result>
    </v-col>
  </v-row>
</template>
<script>
import {
  BrierleyCard,
  BrierleyCardIcons,
  BrierleyNoResult
} from '@brierley/SharedComponents';
import { configurableExtensionObj } from '../../../../i18n/language';

export default {
  components: {
    BrierleyCard,
    BrierleyCardIcons,
    BrierleyNoResult
  },
  data () {
    return {};
  },
  props: {
    configExtensionDefinitions: {
      type: Array,
      default: null
    }
  },
  i18n: configurableExtensionObj
};
</script>
