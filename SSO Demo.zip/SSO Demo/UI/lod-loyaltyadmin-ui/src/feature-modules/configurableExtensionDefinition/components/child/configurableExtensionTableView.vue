<template>
  <v-col>
    <v-col v-if="configExtensionDefinitions.length === 0">
      <brierley-no-result
        :noResultMessage="this.$t('noRecordsMessage')"
        id="viewuser_img_no_data"
      ></brierley-no-result>
    </v-col>
    <brierley-table-module v-if="configExtensionDefinitions.length !== 0">
      <template v-slot:tablehead>
        <tr>
          <th v-for="item in header" :key="item.value" :width="item.width">
            {{ item.text }}
          </th>
        </tr>
      </template>
      <template v-slot:tablebody>
        <tr
          v-for="configExtension in configExtensionDefinitions"
          :key="configExtension.id"
        >
          <td>
            <h4 class="primary-text font15 text-uppercase fbold">
              {{ configExtension.configEntityDefName }}
            </h4>
          </td>
          <td>
            {{ configExtension.configEntityDefDescription }}
          </td>
          <td>
            {{ configExtension.configExtensionType }}
          </td>
          <td>
            {{ configExtension.programEntityName }}
            <v-row
              class="d-flex d-inline-flex hover-actions width-auto"
              no-gutters
            >
              <v-col>
                <brierleyCardIcons>
                  <template v-slot:action-icons>
                    <span class="active">
                      <v-icon>fe fe-eye</v-icon>
                      <span class="viewdetails-icon">
                        {{ $t("viewdetails") }}
                      </span>
                    </span>
                    <span>
                      <v-icon>fe fe-copy</v-icon>
                      <span class="copy-icon">{{ $t("copy") }}</span>
                    </span>
                    <span data-qe-id="table_trans_details_edit">
                      <v-icon>fe fe-edit</v-icon>
                      <span class="edit-icon">{{ $t("edit") }}</span>
                    </span>
                  </template>
                </brierleyCardIcons>
              </v-col>
            </v-row>
          </td>
        </tr>
      </template>
    </brierley-table-module>
  </v-col>
</template>
<script>
import {
  BrierleyTableModule,
  BrierleyCardIcons,
  BrierleyNoResult
} from '@brierley/SharedComponents';
import { configurableExtensionObj } from '../../../../i18n/language';

export default {
  components: {
    BrierleyTableModule,
    BrierleyCardIcons,
    BrierleyNoResult
  },
  props: {
    configExtensionDefinitions: {
      type: Array,
      default: null
    }
  },
  i18n: configurableExtensionObj,
  data () {
    return {
      header: [
        {
          text: this.$t('extensionName'),
          width: '25%'
        },
        {
          text: this.$t('extensionDescription'),
          width: '30%'
        },
        {
          text: this.$t('extensionType'),
          width: '22.5%'
        },
        {
          text: this.$t('programEntity'),
          width: '22.5%'
        }
      ]
    };
  }
};
</script>
<style lang="scss">
.hover-actions {
  &.width-auto {
    width: 100% !important;
  }
}
</style>
