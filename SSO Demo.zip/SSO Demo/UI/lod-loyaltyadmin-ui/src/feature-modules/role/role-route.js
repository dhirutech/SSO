import RoleSteps from './components/creation/RoleSteps';
import RoleList from './components/listing/RoleList';

const roleRoutes = [
  {
    path: '/loyaltyadmin/role/create',
    name: 'createRole',
    component: RoleSteps,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/role/edit/:id',
    name: 'editRole',
    component: RoleSteps,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/role/clone/:id',
    name: 'cloneRole',
    component: RoleSteps,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/role/view/:id',
    name: 'viewRole',
    component: RoleSteps,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/role',
    name: 'roleList',
    component: RoleList,
    meta: {
      showNavigation: false
    }
  }
];

export default roleRoutes;
