const roles_v1 = '/rbac/api/v1/roles';
const services_v1 = '/rbac/api/v1/services';
const methods_v1 = '/rbac/api/v1/methods';
const permissions_v1 = '/rbac/api/v1/permissions';

export default {
  roles_v1,
  services_v1,
  methods_v1,
  permissions_v1
};
