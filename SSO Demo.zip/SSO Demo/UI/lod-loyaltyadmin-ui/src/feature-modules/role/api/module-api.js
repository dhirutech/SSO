import Vue from 'vue';
import constants from '../config/constants';

const roleExistsAsync = async (roleName) => {
  let params = {
    params: {
      roleName: roleName
    }
  };

  return await Vue.prototype.$http
    .get(constants.roles_v1 + '/exists', params)
    .then((res) => {
      return res.data.data;
    });
};

const deleteRoleAsync = async roleId => {
  return await Vue.prototype.$http
    .delete(constants.roles_v1 + '/' + roleId)
    .then((res) => {
      return res.data;
    });
};

const roleIsAssignedAsync = async roleId => {
  return await Vue.prototype.$http
    .get(constants.roles_v1 + '/isassigned/' + roleId)
    .then((res) => {
      return res.data.data;
    });
};

const getServicesAsync = async () => {
  return await Vue.prototype.$http.get(constants.services_v1).then(res => {
    return res.data.data;
  });
};

const getMethodsAsync = async () => {
  return await Vue.prototype.$http.get(constants.methods_v1).then(res => {
    return res.data.data;
  });
};

const getRolesAsync = async () => {
  return await Vue.prototype.$http.get(constants.roles_v1).then(res => {
    return res.data.data;
  });
};

const postRoleAsync = async role => {
  return await Vue.prototype.$http.post(constants.roles_v1, role).then(res => {
    return res.data;
  });
};

const getRoleAsync = async roleId => {
  return await Vue.prototype.$http
    .get(constants.roles_v1 + '/' + roleId)
    .then((res) => {
      return res.data.data;
    });
};

const putRoleAsync = async role => {
  return await Vue.prototype.$http
    .put(constants.roles_v1 + '/' + role.roleId, role)
    .then((res) => {
      return res.data;
    });
};

const postFilterRolesAsync = async searchRequest => {
  return await Vue.prototype.$http
    .post(constants.roles_v1 + '/filter', searchRequest)
    .then((res) => {
      return res.data.data;
    });
};

const getDisabledPermissionsAsync = async () => {
  return await Vue.prototype.$http
    .get(constants.permissions_v1 + '/disabled')
    .then((res) => {
      return res.data.data.disabledPermissions;
    });
};

export {
  roleExistsAsync,
  getServicesAsync,
  getMethodsAsync,
  getRolesAsync,
  postRoleAsync,
  roleIsAssignedAsync,
  deleteRoleAsync,
  getRoleAsync,
  putRoleAsync,
  postFilterRolesAsync,
  getDisabledPermissionsAsync
};
