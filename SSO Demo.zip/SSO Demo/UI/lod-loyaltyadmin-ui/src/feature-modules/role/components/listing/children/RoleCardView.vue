<template>
  <v-row>
    <v-col md="6" sm="12" xs="12" v-for="(role, index) in roles" :key="index">
      <brierley-card>
        <template v-slot:header>
          <h2 :title="role.roleName" class="bmb2">
            {{ role.roleName.length > 22 ? role.roleName.substr(0,22) + '...' : role.roleName }}
            <v-icon v-if="role.isOutOfTheBox">mdi-lock</v-icon>
          </h2>
        </template>
        <template v-slot:body>
          <p>
            <strong>{{ $t("message.descriptionText") }}</strong>
          </p>
          <p class="text-left" :title="role.description">
            <span>{{ role.description.length > 120 ? role.description.substr(0,120) + '...' : role.description }} </span>
          </p>
          <p class="bpt-roles2">
            <strong>{{ $t("message.applicationPermissionsText") }}</strong>
          </p>
          <p
            class="elipsis-twoline"
            :title="$t('message.applicationPermissionsText')"
          >
            {{ role.applicationPermissions.join(", ") }}
          </p>
        </template>
        <template v-slot:footer>
          <v-col>
            <brierley-controls
              :actions="getActions(role)"
              :language="language"
            >
            </brierley-controls>
          </v-col>
        </template>
      </brierley-card>
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyCard
} from '@brierley/SharedComponents';
import BrierleyControls from '../../../../SharedComponents/BrierleyControls';
import { mapState } from 'vuex';

export default {
  components: {
    BrierleyCard,
    BrierleyControls
  },
  props: {
    roles: {
      type: Array
    },
    actions: {
      type: Array
    },
    language: {
      type: String,
      default: () => 'en'
    },
  },
  data () {
    return {
      isHidden: false
    };
  },
  computed: {
    ...mapState({
      dialog: state => state.roleModule.deactivateDialogStatus
    })
  },
  methods: {
    getActions (role) {
      let self = this;
      if (role.isOutOfTheBox === true) {
        return self.actions.map(it =>{
          if (it.referenceId === 1001 || it.referenceId === 1003) {
            return { ...it, ...{ disable: true } };
          } else {
            if (role.roleName === 'Loyalty Administrator' && it.referenceId === 1002)
              return { ...it, ...{ disable: true } };
            else {
              switch (it.referenceId) {
              case 1000:
                return { ...it, ...{ click: { name: 'viewRole', params: { id: role.roleId } } } };
              case 1002:
                return { ...it, ...{ click: { name: 'cloneRole', params: { id: role.roleId } } } };
              }
            }
            return it;
          }
        });
      } else {
        return self.actions.map(it =>{
          switch (it.referenceId) {
          case 1000:
            return { ...it, ...{ click: { name: 'viewRole', params: { id: role.roleId } } } };
          case 1001:
            return { ...it, ...{ click: { name: 'editRole', params: { id: role.roleId } } } };
          case 1002:
            return { ...it, ...{ click: { name: 'cloneRole', params: { id: role.roleId } } } };
          case 1003:
            return { ...it, ...{ click: { id: role.roleId, name: role.roleName, dialog: self.dialog } } };
          }
          return it;
        });
      }
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          descriptionText: 'Role Description: ',
          applicationPermissionsText: 'Application Permissions: ',
          viewText: 'View',
          editText: 'Edit',
          cloneText: 'Clone',
          deleteText: 'Delete'
        }
      },
      ja: {
        message: {
          descriptionText: 'ロール概要：',
          applicationPermissionsText: '対象機能：',
          viewText: '詳細',
          editText: '編集',
          cloneText: 'コピー',
          deleteText: '削除'
        }
      }
    }
  }
};
</script>

<style scoped>
    .text-left {
      text-align: left !important;
    }
</style>
