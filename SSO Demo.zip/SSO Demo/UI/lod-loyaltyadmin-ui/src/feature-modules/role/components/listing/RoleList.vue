<template>
  <brierley-inner-view :footerOnly="false">
    <template v-slot:header>
      <span class="inner-head-role">{{
        $t("message.headerText")
      }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>{{ $t("message.headerCloseText") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row class="d-flex flex-column bpt-roles2" no-gutters>
        <v-col>
          <brierley-form-title
            :formTitle="
              seeMoreRoles === true
                ? $t('message.formTitleText') +
                  ' ' +
                  $t('message.searchResults') +
                  ' (' +
                  rolesCount +
                  ')'
                : $t('message.formTitleText')
            "
            :infoText="$t('message.rolesInfoText')"
          />
        </v-col>
      </v-row>
      <v-row class="d-flex gen2-search-filter bpt2" no-gutters>
        <v-col class="text-left" cols="6">
          <v-row class="d-flex grid-search" no-gutters>
            <v-col class="bpr2">
              <v-text-field
                autocomplete="off"
                class="search-field bmb0"
                :label="$t('message.searchText')"
                prepend-inner-icon="mdi-magnify"
                v-model="searchQuery"
                @input="isTyping = true"
              ></v-text-field>
            </v-col>
          </v-row>
        </v-col>
        <v-col cols="6" class="text-right">
          <brierley-filter
            v-on:click.native="
              isHidden = !isHidden;
              showSearchResults = false;
            "
          ></brierley-filter>
          <div class="bmr1 d-inline-block">
            <brierley-view-option
              :viewList="cardlist"
              @viewChanged="changeView($event)"
            ></brierley-view-option>
          </div>
          <brierley-icon-with-head
            @click.native="$router.push('/loyaltyadmin/role/create')"
            :iconTitle="$t('message.createNewIconText')"
            :iconName="'add_circle'"
          ></brierley-icon-with-head>
        </v-col>
        <v-col v-if="showSearchResults">
          <v-row class="rowbg">
            <v-col xs="12" sm="6" md="4">
              <h2 class="fbold bmb1">
                {{ $t("message.searchResults") }}
                <span class="gen2-title-inner-text"
                  >{{ "(" + rolesCount + " " + $t("message.results") + ")" }}
                </span>
              </h2>
            </v-col>
            <v-col xs="12" sm="6" md="4" />
            <v-col xs="12" sm="6" md="4">
              <button
                type="button"
                class="v-icon notranslate float-right v-icon--link material-icons theme--light"
                @click="showSearchResults = false"
              >
                close
              </button>
            </v-col>
          </v-row>
          <v-row class="rowbg-role">
            <brierley-search-result-card
              v-for="role in rolesSearched.slice(0, 6)"
              :key="role.roleName"
              :redirect="{ url: { name: 'viewRole', params: { id: role.roleId }}}"
            >
              <template v-slot:search-result-card-header>
                <h3 class="primary-text fbold elipsis-fullwidth">{{ role.roleName }}</h3>
              </template>
            </brierley-search-result-card>
            <v-row v-if="rolesSearched.length === 0" class="alert-p" no-gutters>
              <v-col>
                <brierley-alert
                  alertType="secondary"
                  :alertBody="$t('message.tryAgain')"
                  :alertHeader="$t('message.noResultsFound')"
                  icon="info"
                ></brierley-alert>
              </v-col>
            </v-row>
          </v-row>
          <v-row class="rowbg-a">
            <v-col xs="12" sm="6" md="4">
              <v-btn v-if="rolesSearched.length > 0" text @click="seeMore"
                ><strong class="primary-text">{{
                  $t("message.seeMore")
                }}</strong></v-btn
              >
            </v-col>
          </v-row>
        </v-col>
        <v-col cols="12" class="filter-dropdown bmt1">
          <brierley-filter-result v-if="isHidden">
            <template v-slot:body-content>
              <v-row no-gutters class="bmb6">
                <v-col cols="3" class="bmr6">
                  <h3>{{ $t("message.createDateText") }}</h3>
                  <v-row class="main-wrapper__header">
                    <v-col cols="12" class="todate">
                      <v-menu
                        ref="fromDateDialog"
                        v-model="fromDateDialog"
                        :close-on-content-click="false"
                        :return-value.sync="searchRequest.fromDate"
                        transition="scale-transition"
                        offset-y
                        min-width="290px"
                      >
                        <template v-slot:activator="{ on }">
                          <v-text-field
                            autocomplete="off"
                            readonly
                            v-model="fromDateFormated"
                            :label="$t('message.fromText')"
                            append-icon="mdi-calendar-range"
                            v-on="on"
                            class="darktxtfield__light"
                            filled
                            dense
                            @click:append="fromDateDialog = !fromDateDialog"
                          ></v-text-field>
                        </template>
                        <v-date-picker
                          v-model="searchRequest.fromDate"
                          no-title
                          scrollable
                          :max="searchRequest.toDate"
                        >
                          <v-spacer></v-spacer>
                          <v-btn
                            text
                            color="primary"
                            @click="fromDateDialog = false"
                            >{{ $t("message.cancel") }}</v-btn
                          >
                          <v-btn
                            text
                            color="primary"
                            @click="
                              $refs.fromDateDialog.save(searchRequest.fromDate)
                            "
                            >{{ $t("message.ok") }}</v-btn
                          >
                        </v-date-picker>
                      </v-menu>
                    </v-col>
                    <v-col cols="12" class="todate">
                      <v-menu
                        ref="toDateDialog"
                        v-model="toDateDialog"
                        :close-on-content-click="false"
                        :return-value.sync="searchRequest.toDate"
                        transition="scale-transition"
                        offset-y
                        min-width="290px"
                      >
                        <template v-slot:activator="{ on }">
                          <v-text-field
                            autocomplete="off"
                            readonly
                            v-model="toDateFormated"
                            :label="$t('message.toText')"
                            append-icon="mdi-calendar-range"
                            v-on="on"
                            class="darktxtfield__light"
                            filled
                            dense
                            @click:append="toDateDialog = !toDateDialog"
                          ></v-text-field>
                        </template>
                        <v-date-picker
                          v-model="searchRequest.toDate"
                          no-title
                          scrollable
                          :min="searchRequest.fromDate"
                        >
                          <v-spacer></v-spacer>
                          <v-btn
                            text
                            color="primary"
                            @click="toDateDialog = false"
                            >{{ $t("message.cancel") }}</v-btn
                          >
                          <v-btn
                            text
                            color="primary"
                            @click="
                              $refs.toDateDialog.save(searchRequest.toDate)
                            "
                            >{{ $t("message.ok") }}</v-btn
                          >
                        </v-date-picker>
                      </v-menu>
                    </v-col>
                  </v-row>
                </v-col>
                <v-col cols="2"></v-col>
                <v-col cols="4" class="bml6">
                  <h3>{{ $t("message.applicationPermissionsText") }}</h3>
                  <v-row
                    v-for="service in filteredServices"
                    :key="service.serviceId"
                    no-gutters
                  >
                    <v-col cols="12 pt-0">
                      <v-checkbox
                        class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                        :label="service.name"
                        :value="service.name"
                        v-model="searchRequest.applicationPermissions"
                      ></v-checkbox>
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>
            </template>
            <template v-slot:footer>
              <v-btn text class="cancel no-ripple bmt2 bmr6" @click="resetFilter">{{
                $t("message.resetText")
              }}</v-btn>
              <v-btn
                depressed
                class="next bmt3 primaryctabtn"
                @click="filterRoles"
                >{{ $t("message.applyFiltersText") }}</v-btn
              >
            </template>
          </brierley-filter-result>
        </v-col>
      </v-row>
      <v-row
        v-if="roles.length == 0"
        no-gutters
      >
        <brierley-no-result
          :noRecordFoundHeader = "$t('message.noRecordFoundHeader')"
          :noResultMessage = "$t('message.noResultMessage')"
        >
        </brierley-no-result>
      </v-row>
      <role-card-view v-if="viewType === 'card_view'" :roles="roles" :actions="actions[language]" :language="language" />
      <role-grid-view v-if="viewType === 'grid_view'" :roles="roles" :actions="actions[language]" :language="language" />
      <role-table-view v-if="viewType === 'table_view'" :roles="roles" :actions="actions[language]" :language="language" />
      <v-col v-if="scrollInProgress" align="center" justify="center" class="bpt6 bmb3">
        <v-row
          class="d-flex d-inline-flex flex-column load-more-listing text-center"
          no-gutters
        >
          <v-col class="bpa2">
            <v-progress-circular
              :width="3"
              indeterminate
              color="brown"
            ></v-progress-circular>
          </v-col>
          <v-col>{{ $t("message.loadingText") }}</v-col>
        </v-row>
      </v-col>
      <v-col class="additional-footer-margin-roles bpt0 bpb0 bpl0 bpr0">
      </v-col>
    </template>
    <template v-slot:footer>
      <v-btn
        text
        class="primaryctabtn no-ripple"
        @click.native="$router.push('/gettingstarted')"
        >{{ $t("message.closeText") }}</v-btn
      >
      <v-row class="bpx0 bmx0">
        <v-col class="bpb-grid-roles0">
        </v-col>
      </v-row>
      <brierley-dialogbox :dialog="error" @closeMe="error = $event">
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            $t("message.errorDialogTitle")
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-alert>
          <brierley-alert
            alertType="warning"
            :alertBody="$t('message.errorDialogAlertBody')"
            icon="notifications_active"
          ></brierley-alert>
        </template>
        <template v-slot:dialog-footer>
          <v-btn class="primaryctabtn" title="Default" @click="ok">{{
            $t("message.ok")
          }}</v-btn>
        </template>
      </brierley-dialogbox>
      <brierley-dialogbox :dialog="dialog" @closeMe="changeDialog">
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            $t("message.deactivateDialogTitle")
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-alert>
          <brierley-alert
            alertType="warning"
            :alertBody="alertMessage"
            icon="notifications_active"
          ></brierley-alert>
        </template>
        <template v-slot:dialog-footer>
          <v-btn text class="cancel no-ripple" @click="changeDialog(0, '')">{{
            $t("message.cancel")
          }}</v-btn>
          <v-btn class="primaryctabtn" title="Default" @click="deactivate">{{
            $t("message.deactivate")
          }}</v-btn>
        </template>
      </brierley-dialogbox>
      <brierley-dialogbox :dialog="errorDialog" @closeMe="errorDialog = $event">
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            $t("message.errorHandlingDialogTitle")
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-alert>
          <brierley-alert
            alertType="error"
            :alertBody="$t('message.errorHandlingDialogAlertBody')"
            icon="notifications_active"
          ></brierley-alert>
        </template>
        <template v-slot:dialog-footer>
          <v-btn class="primaryctabtn" title="Default" @click="ok">{{
            $t("message.ok")
          }}</v-btn>
        </template>
      </brierley-dialogbox>
    </template>
  </brierley-inner-view>
</template>

<script>
import {
  BrierleyFormTitle,
  BrierleyFilter,
  BrierleyFilterResult,
  BrierleyInnerView,
  BrierleyIconWithHead,
  BrierleyViewOption,
  BrierleyDialogbox,
  brierleyAlert,
  BrierleySearchResultCard,
  BrierleyNoResult
} from '@brierley/SharedComponents';
import RoleCardView from './children/RoleCardView';
import RoleGridView from './children/RoleGridView';
import RoleTableView from './children/RoleTableView';
import { mapState } from 'vuex';
import { formatDate } from './utilities.js';
import _ from 'lodash';
export default {
  components: {
    BrierleyFormTitle,
    BrierleyFilter,
    BrierleyFilterResult,
    RoleCardView,
    RoleGridView,
    RoleTableView,
    BrierleyInnerView,
    BrierleyIconWithHead,
    BrierleyViewOption,
    BrierleyDialogbox,
    brierleyAlert,
    BrierleySearchResultCard,
    BrierleyNoResult
  },
  data () {
    return {
      self: this,
      isHidden: false,
      scrollInProgress: false,
      error: false,
      totalPages: 0,
      errorDialog: false,
      alertMessage: '',
      cardlist: [
        { key: 'grid_view', icon: 'calendar_view_day', label: this.$t('message.gridView') },
        { key: 'table_view', icon: 'table_chart', label: this.$t('message.tableView') },
        { key: 'card_view', icon: 'view_module', label: this.$t('message.cardView') }
      ],
      fromDateDialog: false,
      toDateDialog: false,
      searchRequest: {
        searchText: '',
        fromDate: '',
        toDate: '',
        applicationPermissions: [],
        PageNumber: 1,
        PageSize: 10
      },
      disabledServices: [
        'b-Empowered',
        'b-Informed',
        'Analytics'
      ],
      language: {
        type: String,
        default: () => 'en'
      },
      actions: {
        'en': [
          {
            id: 1000,
            name: 'View',
            value: 'view details',
            referenceId: 1000,
            icon: 'fe-eye',
            disable: false
          },
          {
            id: 1001,
            name: 'Edit',
            value: 'edit',
            referenceId: 1001,
            icon: 'fe-edit',
            disable: false
          },
          {
            id: 1002,
            name: 'Clone',
            value: 'clone',
            referenceId: 1002,
            icon: 'fe-copy',
            disable: false
          },
          {
            id: 1003,
            name: 'Delete',
            value: 'delete',
            referenceId: 1003,
            icon: 'fe-trash-2',
            disable: false
          }],
        'ja': [
          {
            id: 1010,
            name: 'View',
            value: '詳細',
            referenceId: 1000,
            icon: 'fe-eye',
            disable: false
          },
          {
            id: 1011,
            name: 'Edit',
            value: '編集',
            referenceId: 1001,
            icon: 'fe-edit',
            disable: false
          },
          {
            id: 1012,
            name: 'Clone',
            value: 'コピー',
            referenceId: 1002,
            icon: 'fe-copy',
            disable: false
          },
          {
            id: 1013,
            name: 'Delete',
            value: '削除',
            referenceId: 1003,
            icon: 'fe-trash-2',
            disable: false
          }]
      },
      showSearchResults: false,
      seeMoreRoles: false,
      searchQuery: '',
      isTyping: false,
    };
  },
  computed: {
    ...mapState({
      roles: state => state.roleModule.roles,
      rolesSearched: state => state.roleModule.rolesSearched,
      services: state => state.roleModule.services,
      dialog: state => state.roleModule.deactivateDialogStatus,
      selectedRole: state => state.roleModule.selectedRole,
      roleIsAssigned: state => state.roleModule.roleIsAssigned,
      viewType: state => state.roleModule.currentView,
      rolesCount: state => state.roleModule.rolesCount,
      sortRequest: state => state.roleModule.sortRequest
    }),
    fromDateFormated () {
      if (!this.searchRequest.fromDate) return null;
      return formatDate(this.searchRequest.fromDate);
    },
    toDateFormated () {
      if (!this.searchRequest.toDate) return null;
      return formatDate(this.searchRequest.toDate);
    },
    filteredServices () {
      let self = this;
      return self.services.filter(function (service) {
        return self.disabledServices.indexOf(service.name) < 0;
      });
    }
  },
  created () {
    this.language = this.getLanguage();
  },
  mounted: function () {
    this.language = this.getLanguage();
    let requestForGrid = { ...this.searchRequest, ...this.sortRequest };
    this.$store.dispatch('roleModule/filterRoles', requestForGrid);
    this.$store.dispatch('roleModule/getServices');
    window.addEventListener('scroll', this.onScroll);
  },
  beforeDestroy () {
    window.removeEventListener('scroll', this.onScroll);
  },
  watch: {
    dialog () {
      const self = this;
      self.alertMessage = self.$t('message.deactivateDialogAlertBody').replace('#ROLENAME#', self.selectedRole.name);
    },
    sortRequest (newValue) {
      let searchPaginationData =  { PageNumber: 1 };
      let requestForGrid =  { ...this.searchRequest, ...searchPaginationData, ...newValue };
      this.$store.dispatch('roleModule/filterRoles', requestForGrid);
    },
    'roles' () {
      this.scrollInProgress=false;
    },
    searchQuery: _.debounce(function () {
      this.isTyping = false; // eslint-disable-line no-invalid-this
      this.searchRequest.PageNumber = 1; // eslint-disable-line no-invalid-this
    }, 1000),
    isTyping: function (value) {
      if (this.searchQuery === '') {
        this.searchRequest.searchText = '';
        this.showSearchResults = false;
        this.seeMoreRoles = false;
      }
      if (!value) {
        this.searchRoles(this.searchQuery);
      }
    }
  },
  methods: {
    getLanguage () {
      // TODO: this would be part of user Account Data, once it is there this should be updated to get it from
      // there.
      let lng = localStorage.getItem('language');
      if (lng === null || lng === '') {
        return 'en';
      }
      return lng;
    },
    changeView (view) {
      const self = this;
      let newSortObj = {
        SortColumn: 'CreatedDate',
        IsDescending: true
      };
      self.searchRequest.PageNumber = 1;
      self.searchRequest.PageSize = 10;
      self.$store.dispatch('roleModule/setSortRequest', newSortObj);
      self.$store.dispatch('roleModule/setCurrentView', view);
    },
    getRoles () {
      this.$store.dispatch('roleModule/getRoles');
    },
    changeDialog () {
      const self = this;
      self.$store.dispatch('roleModule/setDialogStatus', !self.dialog);
    },
    ok () {
      this.error = false;
      this.errorDialog = false, this.$router.push('/loyaltyadmin/role');
    },
    deactivate () {
      const self = this;
      self.$store.dispatch('roleModule/setDialogStatus', !self.dialog);
      self.$store
        .dispatch('roleModule/roleIsAssigned', self.selectedRole.id)
        .then(() => {
          if (self.roleIsAssigned) {
            self.error = true;
          } else {
            self.error = false;
            self.$store.dispatch('roleModule/deleteRole', self.selectedRole.id)
              .then(() => {
                let searchPaginationData =  { PageNumber: 1 };
                let requestForGrid =  { ...this.searchRequest, ...searchPaginationData, ...this.sortRequest };
                this.$store.dispatch('roleModule/filterRoles', requestForGrid);
              })
              .catch(() => {
                self.errorDialog = true;
              });
          }
        })
        .catch(() => {
          self.errorDialog = true;
        });
    },
    resetFilter () {
      this.searchRequest.fromDate = '';
      this.searchRequest.toDate = '';
      this.searchRequest.applicationPermissions = [];
      this.searchRequest.PageNumber = 1;
      this.searchRequest.PageSize = 10;
      this.$store.dispatch('roleModule/filterRoles', { ...this.searchRequest, ...this.sortRequest });
    },
    filterRoles () {
      this.searchRequest.PageNumber = 1;
      this.$store.dispatch('roleModule/filterRoles', { ...this.searchRequest, ...this.sortRequest });
      this.isHidden = false;
      if (this.searchRequest.searchText !== '')
        this.seeMoreRoles = true;
    },
    searchRoles (value) {
      this.isHidden = false;
      if (value !== '') {
        this.showSearchResults = true;
        let searchPaginationData =  { searchText: this.searchQuery, PageNumber: 1, PageSize: 6 };
        let requestForSerachBox =  { ...this.searchRequest, ...searchPaginationData };
        this.$store.dispatch('roleModule/searchRoles', requestForSerachBox);
      } else {
        this.showSearchResults = false;
        let searchPaginationData =  { PageNumber: 1 };
        let requestForGrid =  { ...this.searchRequest, ...searchPaginationData, ...this.sortRequest };
        this.$store.dispatch('roleModule/filterRoles', requestForGrid);
      }
    },
    getDocHeight () {
      let D = document;
      return Math.max(D.body.scrollHeight, D.documentElement.scrollHeight);
    },
    onScroll () {
      let winheight =
        window.innerHeight ||
        (document.documentElement || document.body).clientHeight;
      let docheight = this.getDocHeight();
      let scrollTop =
        window.pageYOffset ||
        (document.documentElement || document.body.parentNode || document.body)
          .scrollTop;
      let trackLength = docheight - winheight;
      let pctScrolled = Math.floor(scrollTop / trackLength * 100);
      this.totalPages = Math.ceil(this.rolesCount / 10);
      if (
        pctScrolled >= 75 &&
        this.searchRequest.PageNumber < this.totalPages &&
        !this.scrollInProgress
      ) {
        this.scrollInProgress=true;
        this.searchRequest.PageNumber = this.searchRequest.PageNumber + 1;
        this.searchRequest.PageSize = this.searchRequest.PageSize + 10;
        this.showSearchResults = false;
        let searchPaginationData =  { PageNumber: 1 };
        let requestForGrid =  { ...this.searchRequest, ...searchPaginationData, ...this.sortRequest };
        this.$store.dispatch('roleModule/filterRoles', requestForGrid);
      }
    },
    seeMore () {
      this.searchRequest.PageNumber = 1;
      this.searchRequest.searchText = this.searchQuery;
      this.$store.dispatch('roleModule/filterRoles', { ...this.searchRequest, ...this.sortRequest });
      this.showSearchResults = false;
      this.seeMoreRoles = true;
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          headerText: 'VIEW ROLES',
          headerCloseText: 'CLOSE',
          formTitleText: 'Roles',
          rolesInfoText: 'Roles, their descriptions, and application permissions are listed and can be managed on this screen.',
          createNewIconText: 'Create a new Role',
          searchText: 'Search Roles',
          closeText: 'Close',
          deactivateDialogTitle: 'Deactivate Role',
          deactivateDialogAlertBody: 'Do you wish to deactivate the role #ROLENAME#?',
          errorDialogTitle: 'Role Cannot Be Deactivated',
          errorDialogAlertBody: 'This role cannot be deactivated because it\'s already assigned to users.',
          cancel: 'Cancel',
          deactivate: 'Deactivate',
          ok: 'Ok',
          createDateText: 'Create Date',
          fromText: 'From',
          toText: 'To',
          applicationPermissionsText: 'Application Permissions',
          resetText: 'Reset',
          applyFiltersText: 'APPLY FILTERS',
          seeMore: 'SEE MORE',
          searchResults: 'SEARCH RESULTS',
          results: 'Results',
          noResultsFound: 'No search results found',
          tryAgain: 'Please try again by revising your search.',
          errorHandlingDialogTitle: 'Error Occurred',
          errorHandlingDialogAlertBody: 'An unexpected error occurred while trying to deactivate the role. Please try again.',
          loadingText: 'LOAD MORE',
          gridView: 'Grid view',
          tableView: 'Table view',
          cardView: 'Card view',
          noRecordFoundHeader: 'NO ROLES FOUND',
          noResultMessage: 'The filters you applied did not find any matching roles.',
        }
      },
      ja: {
        message: {
          headerText: 'ロール一覧',
          headerCloseText: '閉じる',
          formTitleText: 'ロール',
          rolesInfoText: 'ロールの参照・追加・編集・削除が行えます。',
          createNewIconText: '新規ロール登録',
          searchText: '検索',
          closeText: '閉じる',
          deactivateDialogTitle: 'ロールの非アクティブ化',
          deactivateDialogAlertBody: '#ROLENAME#を非アクティブステータスに設定します。よろしいですか？',
          cancel: 'キャンセル',
          deactivate: '非アクティブ化',
          errorDialogTitle: 'ロールを非アクティブに設定できません',
          errorDialogAlertBody: 'このロールはすでにユーザーに紐付けされているため、非アクティブステータスに設定できません。',
          ok: 'OK',
          createDateText: '日付範囲指定（登録日）',
          fromText: '開始日',
          toText: '終了日',
          applicationPermissionsText: '対象機能で絞り込む',
          resetText: 'リセット',
          applyFiltersText: 'フィルターを適用する',
          seeMore: 'もっと見る',
          searchResults: '検索結果',
          results: '件',
          noResultsFound: '検索結果がみつかりませんでした',
          tryAgain: '検索条件を修正して、もう一度お試しください。',
          errorHandlingDialogTitle: 'エラー',
          errorHandlingDialogAlertBody: 'エラーが発生したため、ロールを非アクティブステータスに設定できませんでした。もう一度お試しください。',
          loadingText: 'ロード中',
          gridView: 'グリッドビュー',
          tableView: 'テーブルビュー',
          cardView: 'カードビュー',
          noRecordFoundHeader: '検索結果がみつかりませんでした',
          noResultMessage: '検索結果がみつかりませんでした。検索条件を修正して、もう一度お試しください。',
        }
      }
    }
  }
};
</script>

<style scoped>
.rowbg{
  padding: 24px 24px 12px 24px !important;
}
.rowbg-role {
  background: #f4f4f4;
  margin: 0 !important;
  padding: 0px 26px 6px 26px !important;
}
.rowbg-a {
  background: #f4f4f4;
  margin: 0 !important;
  padding: 0px 24px 40px 8px !important;
}
.alert-p {
  padding: 55px 94px 72px 94px !important;
}
</style>

<style>
  .gen2-search-card.v-card {
    padding: 20px 16px 12px 16px !important;
  }
  .alert-block__body h3 {
    line-height: 24px !important;
  }
</style>
