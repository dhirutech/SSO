<template>
  <v-row no-gutters class="d-flex ">
    <v-col class="bmt4 gen2-forms form-light-bg" sm="6" xs="12" md="7">
      <h2 class="mb-3">
        <strong>{{ $t("message.roleDetails") }}</strong>
      </h2>
      <v-col sm="8" xs="12" class="bpa0">
        <v-text-field
          autocomplete="off"
          :label="$t('message.nameLabel')"
          :error-messages="nameErrorMsg"
          :disabled="readonly"
          :readonly="readonly"
          filled
          required
          v-model="role.roleName"
          :rules="nameRules"
          @keyup="updateName"
          @keydown.enter.prevent
        >
        </v-text-field>
      </v-col>
      <v-col sm="10" xs="12" class="bpa0">
        <v-textarea
          :label="$t('message.descriptionLabel')"
          filled
          :disabled="readonly"
          :readonly="readonly"
          auto-grow
          :rules="descriptionRules"
          v-model="role.description"
          @keyup="updateDescription"
          @keydown.enter.prevent
        >
        </v-textarea>
      </v-col>
    </v-col>
    <v-col class="bpt4" xs="12" sm="6" md="5">
      <brierley-info-side>
        <template v-slot:info-side-header>
          <div class="info_title">
            <v-icon>info</v-icon>{{ $t("message.info") }}
          </div>
        </template>
        <template v-slot:info-side-body>
          <div class="bpl5">
            {{ $t("message.infoBody") }}
          </div>
        </template>
      </brierley-info-side>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyInfoSide } from '@brierley/SharedComponents';
export default {
  components: {
    BrierleyInfoSide
  },
  props: {
    role: Object,
    nameErrorMsg: String,
    readonly: Boolean
  },
  data () {
    return {
      nameRules: [
        v => !!v.trim() || this.$t('message.nameIsRequired'),
        v => v && v.trim().length <= 50 || this.$t('message.nameLengthExceeded')
      ],
      descriptionRules: [
        v => v.trim().length <= 250 || this.$t('message.descriptionLengthExceeded')
      ]
    };
  },
  methods: {
    updateName () {
      this.$emit('update:role.roleName', this.role.roleName);
    },
    updateDescription () {
      this.$emit('update:role.description', this.role.description);
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          roleDetails: 'Role Details',
          nameLabel: 'Role Name *',
          descriptionLabel: 'Role Description',
          info: 'Info',
          infoBody: 'Enter the name of the role and a description that describes the role. Please ensure that the name of the role is unique and adequately identifies the role.',
          nameIsRequired: 'Role Name is required.',
          nameLengthExceeded: 'Role Name cannot contain more than 50 characters.',
          nameAlreadyExists: 'Role name already exists. Please enter a unique role name.',
          descriptionLengthExceeded: 'Role Description cannot contain more than 250 characters.'
        }
      },
      ja: {
        message: {
          roleDetails: 'ロール詳細',
          nameLabel: 'ロール名',
          descriptionLabel: 'ロール概要',
          info: 'インフォメーション',
          infoBody: 'LOD管理画面のユーザーと紐付けるロールを設定してください。',
          nameIsRequired: '必須項目です。',
          nameLengthExceeded: '最大文字数の50を超えています。',
          nameAlreadyExists: 'このロール名はすでに登録されています。別の名前を入力してください。',
          descriptionLengthExceeded: '最大文字数の250を超えています。'
        }
      }
    }
  }
};
</script>
