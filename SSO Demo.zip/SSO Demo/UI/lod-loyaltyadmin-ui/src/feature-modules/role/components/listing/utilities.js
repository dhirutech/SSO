const formatDate = function (inputDate) {
  let date = new Date(inputDate);
  let year = date.getUTCFullYear();
  let month = (1 + date.getUTCMonth()).toString();
  month = month.length > 1 ? month : '0' + month;
  let day = date.getUTCDate().toString();
  day = day.length > 1 ? day : '0' + day;
  return month + '/' + day + '/' + year;
};

const parseDate = function (inputDate) {
  let newDate = new Date();
  let mmddyyyy = inputDate.split('/');
  newDate.setDate (mmddyyyy[1]);
  newDate.setMonth(mmddyyyy[0] - 1);
  newDate.setFullYear (mmddyyyy[2]);
  return newDate.toISOString();
};

export {
  formatDate,
  parseDate
};
