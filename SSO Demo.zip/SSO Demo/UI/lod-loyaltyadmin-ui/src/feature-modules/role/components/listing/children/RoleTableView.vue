<template>
  <brierley-table-module>
    <template v-slot:tablehead>
      <tr class="text-left">
        <th
          v-for="item in header"
          :key="item.name"
          @click="item.name == 'roleName' ? sortBy(item) : null"
          class="text-left"
          :width="item.width"
        >
          <span class="fbold">{{ item.text }}</span>
          <v-icon
            v-if="item.sort != ''"
            small
            v-bind:class="{
              down: item.sort === 'asc',
              up: item.sort === 'desc'
            }"
            class="arrow uparw"
            >arrow_upward</v-icon
          >
        </th>
      </tr>
    </template>
    <template v-slot:tablebody>
      <tr v-for="role in roles" :key="role.roleName">
        <td class="row-role-font row-role-valign">
          <v-row class="d-flex head-name" :title="role.roleName" no-gutters>
            <v-col class="text-format">{{ role.roleName.length > 22 ? role.roleName.substr(0,22) + '...' : role.roleName }}
            <v-icon class="roles-lock-icon-size" v-if="role.isOutOfTheBox">mdi-lock</v-icon>
            </v-col>
          </v-row>
        </td>
        <td class="row-role-valign">
          <p class="bmb0" :title="$t('message.applicationPermissionsText')">
            {{ role.applicationPermissions.join(", ") }}
          </p>
        </td>
        <td class="row-role-valign">
          <div :title="role.description" class="text-left">
            {{ role.description.length > 100 ? role.description.substr(0,100) + '...' : role.description }}
          </div>
          <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
            <v-col>
              <brierley-controls
                :actions="getActions(role)"
                :language="language"
              >
              </brierley-controls>
            </v-col>
          </v-row>
        </td>
      </tr>
    </template>
  </brierley-table-module>
</template>
<script>
import {
  BrierleyTableModule
} from '@brierley/SharedComponents';
import BrierleyControls from '../../../../SharedComponents/BrierleyControls';
import { mapState } from 'vuex';

export default {
  components: {
    BrierleyTableModule,
    BrierleyControls
  },
  props: {
    roles: {
      type: Array
    },
    actions: {
      type: Array
    },
    language: {
      type: String,
      default: () => 'en'
    },
  },
  data () {
    return {
      sortKey: ['name'],
      sortOrder: ['asc'],
      isToggled: false,
      changeColor: false,
      header: [
        {
          name: 'roleName',
          text: this.$t('message.nameText'),
          sort: 'asc',
          width: '180'
        },
        {
          name: 'applicationPermissions',
          text: this.$t('message.applicationPermissionsText'),
          sort: '',
          width: '180'
        },
        {
          name: 'description',
          text: this.$t('message.descriptionText'),
          sort: '',
          width: '256'
        }
      ]
    };
  },
  computed: {
    ...mapState({
      dialog: state => state.roleModule.deactivateDialogStatus,
      sortRequest: state => state.roleModule.roleModule
    }),
  },
  methods: {
    getActions (role) {
      let self = this;
      if (role.isOutOfTheBox === true) {
        return self.actions.map(it =>{
          if (it.referenceId === 1001 || it.referenceId === 1003) {
            return { ...it, ...{ disable: true } };
          } else {
            if (role.roleName === 'Loyalty Administrator' && it.referenceId === 1002)
              return { ...it, ...{ disable: true } };
            else {
              switch (it.referenceId) {
              case 1000:
                return { ...it, ...{ click: { name: 'viewRole', params: { id: role.roleId } } } };
              case 1002:
                return { ...it, ...{ click: { name: 'cloneRole', params: { id: role.roleId } } } };
              }
            }
            return it;
          }
        });
      } else {
        return self.actions.map(it =>{
          switch (it.referenceId) {
          case 1000:
            return { ...it, ...{ click: { name: 'viewRole', params: { id: role.roleId } } } };
          case 1001:
            return { ...it, ...{ click: { name: 'editRole', params: { id: role.roleId } } } };
          case 1002:
            return { ...it, ...{ click: { name: 'cloneRole', params: { id: role.roleId } } } };
          case 1003:
            return { ...it, ...{ click: { id: role.roleId, name: role.roleName, dialog: self.dialog } } };
          }
          return it;
        });
      }
    },
    sortBy: function (item) {
      let i = this.header.indexOf(item);
      for (let j = 0; j < this.header.length; j++) {
        if (j === i) {
          this.header[j].sort =
            this.header[j].sort === '' || this.header[j].sort === 'desc'
              ? 'asc'
              : 'desc';
        } else {
          this.header[j].sort = '';
        }
      }
      this.sortKey = this.header[i].name;
      this.sortOrder = this.header[i].sort;
      this.arrowToggle();
      let newSortObj={
        SortColumn: this.header[i].name,
        IsDescending: this.header[i].sort === 'desc' ? true : false
      };
      this.$store.dispatch('roleModule/setSortRequest', newSortObj);
    },
    arrowToggle () {
      this.isToggled = !this.isToggled;
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          nameText: 'Role Name',
          applicationPermissionsText: 'Application Permissions',
          descriptionText: 'Description',
          viewText: 'View',
          editText: 'Edit',
          cloneText: 'Clone',
          deleteText: 'Delete',
          pauseText: 'Pause'
        }
      },
      ja: {
        message: {
          nameText: 'ロール名',
          applicationPermissionsText: '対象機能',
          descriptionText: 'ロール概要',
          viewText: '詳細',
          editText: '編集',
          cloneText: 'コピー',
          deleteText: '削除',
          pauseText: '停止'
        }
      }
    }
  }
};
</script>

<style scoped>
    i.v-icon.roles-lock-icon-size{
        font-size:20px !important;
        color: #bdbdbd !important;
    }
    i.v-icon.roles-lock-icon-size:before{
        font-size:20px !important;
        color: #bdbdbd !important;
    }
    td.row-role-font{
      align-self: center !important;
      width: 100%;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    td.row-role-font:before{
      align-self: center !important;
      width: 100%;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }
    td.row-role-font:after{
      align-self: center !important;
      width: 100%;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    td.row-role-valign{
      vertical-align: middle !important;
    }
    div.text-format{
      font-weight: bold;
      font-size:18;
      text-transform: uppercase;
      letter-spacing: normal;
    }
    div.text-format:before{
      font-weight: bold;
      font-size:18;
      text-transform: uppercase;
      letter-spacing: normal;
    }
    div.text-format:after{
      font-weight: bold;
      font-size:18;
      text-transform: uppercase;
      letter-spacing: normal;
    }

    .blackicon {
      font-size: 22px !important;
      color: rgb(85,85,85) !important;
    }
    .row-role-valign.text-left {
      text-align: left !important;
    }
</style>
