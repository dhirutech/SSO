<template>
  <v-row class="d-flex flex-column" no-gutters>
    <v-col cols="12" v-for="role in roles" :key="role.roleName">
      <v-row class="bmr0 bml0">
        <v-col class="bpt-grid-roles2 bpb-grid-roles2 bpl0 bpr0">
          <brierley-grid-card>
            <template v-slot:grid-card-body>
              <v-col sm="4" xs="12">
                <v-row>
                  <v-col md="12" class="bpb0 bpl-roles2">
                    <v-card-title :title="role.roleName" class="elipsis-fullwidth">
                      {{ role.roleName }}
                      <v-icon class="roles-lock-icon-size" v-if="role.isOutOfTheBox">mdi-lock</v-icon>
                    </v-card-title>
                  </v-col>
                </v-row>
              </v-col>
              <v-col sm="5" xs="12">
                <v-row no-gutters>
                  <v-col sm="11">
                    <p>
                      <strong>{{ $t("message.descriptionText") }}</strong>
                    </p>
                    <p class="text-left" :title="role.description">
                      {{ role.description.length > 100 ? role.description.substr(0,100) + '...' : role.description }}
                    </p>
                  </v-col>
                </v-row>
              </v-col>
              <v-col sm="3" xs="12">
                <v-row no-gutters>
                  <v-col sm="12">
                    <p>
                      <strong>{{
                        $t("message.applicationPermissionsText")
                      }}</strong>
                    </p>
                    <p
                      v-for="permission in role.applicationPermissions"
                      :key="permission"
                      class="elipsis-twoline"
                      :title="$t('message.applicationPermissionsText')"
                    >
                      {{ permission }}
                    </p>
                  </v-col>
                </v-row>
              </v-col>
              <v-col>
                <brierley-controls
                  :actions="getActions(role)"
                  :language="language"
                >
                </brierley-controls>
              </v-col>
            </template>
          </brierley-grid-card>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import {
  BrierleyGridCard
} from '@brierley/SharedComponents';
import BrierleyControls from '../../../../SharedComponents/BrierleyControls';
import { mapState } from 'vuex';

export default {
  components: {
    BrierleyControls,
    BrierleyGridCard
  },
  props: {
    roles: {
      type: Array
    },
    actions: {
      type: Array
    },
    language: {
      type: String,
      default: () => 'en'
    },
  },
  data () {
    return {
      isHidden: false
    };
  },
  computed: {
    ...mapState({
      dialog: state => state.roleModule.deactivateDialogStatus
    })
  },
  mounted: function () {
    window.scrollTo(0, 0);
  },
  methods: {
    getActions (role) {
      let self = this;
      if (role.isOutOfTheBox === true) {
        return self.actions.map(it =>{
          if (it.referenceId === 1001 || it.referenceId === 1003) {
            return { ...it, ...{ disable: true } };
          } else {
            if (role.roleName === 'Loyalty Administrator' && it.referenceId === 1002)
              return { ...it, ...{ disable: true } };
            else {
              switch (it.referenceId) {
              case 1000:
                return { ...it, ...{ click: { name: 'viewRole', params: { id: role.roleId } } } };
              case 1002:
                return { ...it, ...{ click: { name: 'cloneRole', params: { id: role.roleId } } } };
              }
            }
            return it;
          }
        });
      } else {
        return self.actions.map(it =>{
          switch (it.referenceId) {
          case 1000:
            return { ...it, ...{ click: { name: 'viewRole', params: { id: role.roleId } } } };
          case 1001:
            return { ...it, ...{ click: { name: 'editRole', params: { id: role.roleId } } } };
          case 1002:
            return { ...it, ...{ click: { name: 'cloneRole', params: { id: role.roleId } } } };
          case 1003:
            return { ...it, ...{ click: { id: role.roleId, name: role.roleName, dialog: self.dialog } } };
          }
          return it;
        });
      }
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          applicationPermissionsText: 'Application Permissions:',
          descriptionText: 'Role Description:',
          viewText: 'View',
          editText: 'Edit',
          cloneText: 'Clone',
          deleteText: 'Delete'
        }
      },
      ja: {
        message: {
          descriptionText: 'ロール概要：',
          applicationPermissionsText: '対象機能：',
          viewText: '詳細',
          editText: '編集',
          cloneText: 'コピー',
          deleteText: '削除'
        }
      }
    }
  }
};
</script>

<style scoped>
    i.v-icon.roles-lock-icon-size{
        font-size:20px !important;
        color: #bdbdbd !important;
    }
    i.v-icon.roles-lock-icon-size:before{
        font-size:20px !important;
        color: #bdbdbd !important;
        padding-left: 8px;
    }
    i.v-icon.roles-lock-icon-size:after{
        font-size:20px !important;
        color: #bdbdbd !important;
    }
    .text-left {
      text-align: left !important;
    }
</style>
