<template>
  <brierley-inner-view :footerOnly="false">
    <template v-slot:header>
      <span class="inner-head-role">{{ title }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn class="no-ripple" href target="_blank" text @click="closeScreen">
        <v-icon>mdi-close</v-icon>{{ $t("message.close") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <brierley-primary-stepper
        :currentStep="currentStep"
        :stepperSize="stepperSize"
      >
        <template v-slot:stepper-steps>
          <v-stepper-step step="1">{{
            $t("message.formOneTitle")
          }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="2">{{
            $t("message.formTwoTitle")
          }}</v-stepper-step>
          <v-divider v-if="!viewing"></v-divider>
          <v-stepper-step v-if="!viewing" step="3">{{
            $t("message.formThreeTitle")
          }}</v-stepper-step>
        </template>
        <template slot="stepper-content">
          <v-stepper-items>
            <v-stepper-content step="1">
              <v-row class="flex-column" no-gutters>
                <v-col>
                  <brierley-form-title
                    :formTitle="$t('message.formOneTitle')"
                    :currentStep="1"
                    :totalStep="viewing ? 2 : 3"
                    :infoText="$t('message.formOneInfoText')"
                    :showSteps="true"
                  ></brierley-form-title>
                </v-col>
                <v-col>
                  <v-form ref="stepOneForm" v-model="stepOneValid">
                    <role-information
                      :role.sync="role"
                      :readonly="readonly"
                      :nameErrorMsg="nameErrorMsg"
                    />
                  </v-form>
                </v-col>
              </v-row>
            </v-stepper-content>
            <v-stepper-content step="2">
              <v-row class="flex-column" no-gutters>
                <v-col>
                  <brierley-form-title
                    :formTitle="$t('message.formTwoTitle')"
                    :currentStep="2"
                    :totalStep="viewing ? 2 : 3"
                    :infoText="$t('message.formTwoInfoText')"
                    :showSteps="true"
                  ></brierley-form-title>
                </v-col>
                <v-col>
                  <brierley-role-assignment
                    :role.sync="role"
                    :services="filteredServices"
                    :methods="methods"
                    :readonly="readonly"
                    :disabledPermissions="disabledPermissions"
                  ></brierley-role-assignment>
                </v-col>
              </v-row>
            </v-stepper-content>
            <v-stepper-content v-if="!viewing" step="3">
              <v-row class="flex-column" no-gutters>
                <v-col>
                  <brierley-form-title
                    :formTitle="$t('message.formThreeTitle')"
                    :currentStep="3"
                    :totalStep="viewing ? 2 : 3"
                    :infoText="$t('message.formThreeInfoText')"
                    :showSteps="true"
                  ></brierley-form-title>
                </v-col>
                <v-col>
                  <role-review-and-save
                    :role.sync="role"
                    :services="filteredServices"
                    :methods="methods"
                    @step-one="currentStep = 1"
                    @step-two="currentStep = 2"
                  ></role-review-and-save>
                </v-col>
              </v-row>
            </v-stepper-content>
            <v-stepper-content v-if="!viewing" step="4">
              <v-row class="flex-column" no-gutters>
                <v-col>
                  <brierley-form-title
                    :formTitle="alertHeader"
                    :infoIcon="false"
                  >
                  </brierley-form-title>
                </v-col>
                <v-col class="bmt3 alert-m">
                  <brierley-alert
                    :isSiteLevel="true"
                    :alertType="alertType"
                    :alertBody="alertBody"
                    :alertHeader="alertHeader"
                    :icon="alertIcon"
                  ></brierley-alert>
                </v-col>
              </v-row>
            </v-stepper-content>
          </v-stepper-items>
        </template>
      </brierley-primary-stepper>
    </template>
    <template v-slot:footer-previous v-if="currentStep > 1 && currentStep < 4">
      <v-btn
        text
        class="mr-5 cancel no-ripple previous-margin-top"
        @click="currentStep--"
      >
        <v-icon class="bpr1">arrow_back</v-icon>{{ $t('message.previous') }}
      </v-btn>
    </template>
    <template v-slot:footer-redirect v-if="currentStep === 4">
      <v-btn
        class="primaryctabtn bmt2"
        @click.native="$router.push('/loyaltyadmin/role')"
        >{{ $t("message.goToRoles") }}</v-btn
      >
    </template>
    <template v-slot:footer>
      <v-btn
        v-if="currentStep < 4 && !viewing"
        text
        class="cancel no-ripple bmt2 bmr7"
        @click="cancelDialog = true"
      >
        {{ $t("message.cancel") }}
      </v-btn>
      <v-btn
        v-if="currentStep === 1"
        class="primaryctabtn bmt2"
        @click="validateStepOne"
        >{{ $t("message.nextRolePremissions") }}</v-btn
      >
      <v-btn
        v-else-if="currentStep == 2 && !viewing"
        class="primaryctabtn bmt2"
        @click="validateStepTwo"
        >{{ $t("message.nextPreview") }}</v-btn
      >
      <v-btn
        v-else-if="currentStep == 3"
        class="primaryctabtn bmt2"
        @click="submitRole"
        >{{ $t("message.saveRole") }}</v-btn
      >
      <v-btn
        v-if="currentStep === 2 && viewing"
        class="primaryctabtn bmt2 bml2"
        @click="cancel"
        >{{ $t("message.closeBtn") }}</v-btn
      >
      <brierley-dialogbox
        :dialog="cancelDialog"
        @closeMe="cancelDialog = $event"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            cancelDialogTitle
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-alert>
          <brierley-alert
            alertType="warning"
            :alertBody="cancelDialogBody"
            icon="notifications_active"
          ></brierley-alert>
        </template>
        <template v-slot:dialog-footer>
          <v-btn text class="cancel no-ripple" @click="noCancel">{{
            $t("message.no")
          }}</v-btn>
          <v-btn class="primaryctabtn" title="Default" @click="cancel">{{
            $t("message.yes")
          }}</v-btn>
        </template>
      </brierley-dialogbox>
      <brierley-dialogbox
        :dialog="stepTwoDialog"
        @closeMe="stepTwoDialog = $event"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            $t("message.error")
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-alert>
          <brierley-alert
            alertType="error"
            :alertBody="$t('message.mustSelectOneAccess')"
          ></brierley-alert>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            class="primaryctabtn"
            title="Default"
            @click="stepTwoDialog = false"
            >{{ $t("message.ok") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
      <brierley-dialogbox :dialog="error" @closeMe="error = $event">
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            $t("message.errorDialogTitle")
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-alert>
          <brierley-alert
            alertType="error"
            :alertBody="$t('message.errorDialogAlertBody')"
            icon="notifications_active"
          ></brierley-alert>
        </template>
        <template v-slot:dialog-footer>
          <v-btn class="primaryctabtn" title="Default" @click="error = false">{{
            $t("message.ok")
          }}</v-btn>
        </template>
      </brierley-dialogbox>
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  brierleyAlert,
  BrierleyDialogbox,
  BrierleyFormTitle,
  BrierleyInnerView,
  BrierleyPrimaryStepper,
  BrierleyRoleAssignment
} from '@brierley/SharedComponents';
import RoleInformation from './children/RoleInformation';
import RoleReviewAndSave from './children/RoleReviewAndSave';
import { mapState } from 'vuex';
export default {
  components: {
    brierleyAlert,
    BrierleyDialogbox,
    BrierleyFormTitle,
    BrierleyInnerView,
    BrierleyPrimaryStepper,
    BrierleyRoleAssignment,
    RoleInformation,
    RoleReviewAndSave
  },
  data () {
    return {
      currentStep: 1,
      cancelDialog: false,
      stepTwoDialog: false,
      stepOneValid: true,
      optionClick: '',
      stepperSize: 0,
      hiddenMethods: ['Activate', 'Deactivate', 'TBD'],
      alertIcon: 'mdi-alert',
      alertBody: this.$t('message.errorAlertBody'),
      alertHeader: this.$t('message.errorAlertHeader'),
      alertType: 'error',
      nameErrorMsg: '',
      originalRoleName: '',
      editing: false,
      cloning: false,
      viewing: false,
      readonly: false,
      error: false,
      cancelDialogTitle: this.$t('message.cancelDialogTitle'),
      cancelDialogBody: this.$t('message.cancelDialogBody'),
      emptyRole: {
        roleId: 0,
        roleName: '',
        isAdmin: false,
        description: '',
        permissions: []
      },
      triggeredFromCancelDialog: false
    };
  },
  created () {
    this.$store.dispatch('roleModule/getMethods');
    this.$store.dispatch('roleModule/getServices');
    this.$store.dispatch('roleModule/getDisabledPermissions');
    this.initialize();
  },
  computed: {
    ...mapState({
      role: state => state.roleModule.role,
      roleExists: state => state.roleModule.roleExists,
      services: state => state.roleModule.services,
      methods: state => state.roleModule.methods,
      roleResponse: state => state.roleModule.roleResponse,
      disabledPermissions: state => state.roleModule.disabledPermissions
    }),
    filteredMethods () {
      let self = this;
      return self.methods.filter(function (method) {
        return self.hiddenMethods.indexOf(method.name) < 0;
      });
    },
    filteredServices () {
      if (this.role.isAdmin) return this.services;
      else
        return this.services.filter(function (s) {
          return !s.isRestricted;
        });
    }
  },
  watch: {
    role (value) {
      this.$store.dispatch('roleModule/setRole', value);
    },
    'role.roleName' () {
      this.validateRoleName();
    },
    'role.description' () {
      this.role.description = this.role.description.trim();
    }
  },
  methods: {
    initialize: function () {
      let self = this;
      let roleId = self.$route.params.id;
      self.optionClick = self.$route.name;
      self.stepperSize = 4;
      self.readonly = false;
      self.error = false;

      if (roleId > 0) {
        if (self.$route.name === 'cloneRole') {
          self.cloning = true;
          self.title = self.$t('message.cloneRoleText');
        } else if (self.$route.name === 'viewRole') {
          self.viewing = true;
          self.title = self.$t('message.viewRoleText');
          self.stepperSize = 2;
          self.readonly = true;
        } else {
          self.editing = true;
          self.title = self.$t('message.editRoleText');
          self.cancelDialogTitle = self.$t('message.saveChangesTitle');
          self.cancelDialogBody = self.$t('message.saveChangesBody');
        }

        self.$store.dispatch('roleModule/getRole', roleId).then(() => {
          self.originalRoleName = self.role.roleName;
          if (self.cloning) {
            self.role.roleName = 'Copy of ' + self.role.roleName;
          }
        });
      } else {
        self.title = self.$t('message.newRoleText');
        self.$store.dispatch('roleModule/setRole', self.emptyRole);
      }
    },
    closeScreen () {
      const self = this;
      if (self.$route.name === 'viewRole') self.cancel();
      // Being in step 4 while creating/editing/cloning means the role was already saved
      // and there is nothing to cancel, hence, no dialog should be displayed, only redirect to listings.
      else if (self.currentStep === 4) self.$router.push('/loyaltyadmin/role');
      else self.cancelDialog = true;
    },
    validateRoleName () {
      if (this.readonly) {
        return;
      }

      const self = this;
      self.role.roleName = self.role.roleName.trim();
      self.$store
        .dispatch('roleModule/roleExists', self.role.roleName)
        .then(() => {
          if (
            self.roleExists &&
            (!self.editing || self.originalRoleName !== self.role.roleName)
          ) {
            self.nameErrorMsg = self.$t('message.nameAlreadyExists');
          } else {
            self.nameErrorMsg = '';
          }
        });
    },
    noCancel () {
      let self = this;
      self.cancelDialog = false;
      if (this.editing) {
        self.$router.push('/loyaltyadmin/role');
      }
    },
    cancel () {
      let self = this;
      self.cancelDialog = false;
      if (self.editing) {
        if (
          self.role.roleName !== '' &&
          self.role.roleName.length <= 50 &&
          self.role.description !== '' &&
          self.role.description.length <= 250 &&
          self.nameErrorMsg === ''
        ) {
          self.triggeredFromCancelDialog = true;
          self.submitRole();
        }
      } else {
        self.$router.push('/loyaltyadmin/role');
      }
    },
    validateStepOne () {
      if (this.readonly) {
        this.currentStep++;
        return true;
      }

      this.validateRoleName();
      this.$refs.stepOneForm.validate();

      if (this.stepOneValid) {
        this.currentStep++;
      }
    },
    validateStepTwo () {
      if (this.readonly) {
        return;
      }
      if (this.areRolePermissionsValid()) {
        this.currentStep++;
      } else {
        this.stepTwoDialog = true;
      }
    },
    areRolePermissionsValid () {
      let self = this;
      if (self.role.permissions.length > 0) {
        for (let i = 0; i < self.role.permissions.length; i++) {
          if (self.role.permissions[i].methodsId.length > 0) {
            return true;
          }
        }
      } else {
        return false;
      }
    },
    submitRole () {
      const self = this;
      self.$store
        .dispatch('roleModule/roleExists', self.role.roleName)
        .then(() => {
          if (
            self.roleExists &&
            (!self.editing || self.originalRoleName !== self.role.roleName)
          ) {
            self.nameErrorMsg = self.$t('message.nameAlreadyExists');
            self.currentStep = 1;
          } else {
            self.nameErrorMsg = '';
            if (self.editing && !self.cloning) {
              self.putRole();
            } else {
              self.postRole();
            }
          }
        })
        .catch(() => {
          self.error = true;
        });
    },
    putRole () {
      const self = this;
      self.$store.dispatch('roleModule/putRole', self.role).then(() => {
        if (!self.roleResponse.isError) {
          if (self.triggeredFromCancelDialog) {
            self.$router.push('/loyaltyadmin/role');
          } else {
            self.setSuccessAlert();
            self.currentStep = 4;
          }
        }
      });
    },
    postRole () {
      let self = this;
      self.$store.dispatch('roleModule/postRole', self.role).then(() => {
        if (!self.roleResponse.isError) {
          self.setSuccessAlert();
          self.currentStep = 4;
        }
      });
    },
    setSuccessAlert () {
      let self = this;
      self.alertIcon = 'done';
      self.alertType = 'success';
      self.alertHeader = self.$t('message.successAlertHeader');
      self.alertBody = self.editing
        ? self
          .$t('message.alertEditBody')
          .replace('#ROLENAME#', self.role.roleName)
        : self
          .$t('message.alertCreateBody')
          .replace('#ROLENAME#', self.role.roleName);
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          newRoleText: 'NEW ROLE',
          editRoleText: 'EDIT ROLE',
          cloneRoleText: 'CLONE ROLE',
          viewRoleText: 'VIEW ROLE',
          close: 'CLOSE',
          formOneTitle: 'ROLE INFORMATION',
          formTwoTitle: 'ROLE PERMISSIONS',
          formThreeTitle: 'REVIEW & SAVE',
          formFourTitle: 'SUCCESS',
          formOneInfoText: 'Basic information about the role is defined here.',
          formTwoInfoText:
            'Set the permissions and access level for the role by application.',
          formThreeInfoText:
            'The role information and role permissions you entered for the new role are displayed here for your review.',
          successAlertHeader: 'Success',
          alertCreateBody: 'The new role #ROLENAME# has been created.',
          alertEditBody: 'Changes to the role #ROLENAME# have been saved.',
          errorDialogTitle: 'Error Occurred',
          errorDialogAlertBody:
            'An error occurred and unable to save the new role. Please try again.',
          errorAlertHeader: 'Error',
          errorAlertBody:
            'An error occurred and unable to save the new role. Please try again.',
          previous: 'Previous',
          goToRoles: 'GoTo Roles',
          cancel: 'Cancel',
          nextRolePremissions: 'NEXT : ROLE PERMISSIONS',
          nextPreview: 'NEXT : REVIEW',
          saveRole: ' SAVE ROLE',
          cancelDialogTitle: 'Cancel Creating Role',
          cancelDialogBody:
            'Are you sure you wish to cancel creating a new role?',
          no: 'No',
          yes: 'Yes',
          nameAlreadyExists:
            'Role name already exists. Please enter a unique role name.',
          mustSelectOneAccess: 'You must select at least one access.',
          error: 'Error',
          ok: 'OK',
          saveChangesTitle: 'Save changes?',
          saveChangesBody: 'Would you like to save the changes you\'ve made?',
          closeBtn: 'Close'
        }
      },
      ja: {
        message: {
          newRoleText: '登録 - ロール',
          editRoleText: '編集 - ロール',
          cloneRoleText: 'コピー - ロール',
          viewRoleText: '参照 - ロール',
          close: '閉じる',
          formOneTitle: '基本情報',
          formTwoTitle: 'アクセス権限',
          formThreeTitle: '内容確認・保存',
          formFourTitle: '登録完了',
          formOneInfoText: 'ロールについての基本情報を設定してください。',
          formTwoInfoText:
            '各ロールのアクセス権限を設定対象機能ごとに設定してください。',
          formThreeInfoText:
            'ロールの基本情報とアクセス権限を確認してください。',
          successAlertHeader: '登録完了',
          alertCreateBody: 'ロール (#ROLENAME#) が作成されました。',
          alertEditBody: 'ロール (#ROLENAME#) が更新されました。',
          errorDialogTitle: 'エラー',
          errorDialogAlertBody:
            'エラーが発生したため登録できませんでした。もう一度お試しください。',
          errorAlertHeader: 'エラー',
          errorAlertBody:
            'エラーが発生したため登録できませんでした。もう一度お試しください。',
          previous: '戻る',
          goToRoles: 'ロール一覧へ',
          cancel: 'キャンセル',
          nextRolePremissions: '次へ',
          nextPreview: '次へ',
          saveRole: '保存',
          cancelDialogTitle: '登録キャンセル',
          cancelDialogBody: 'ロール登録をキャンセルします。よろしいですか？',
          no: 'いいえ',
          yes: 'はい',
          nameAlreadyExists:
            'このロール名はすでに登録されています。別の名前を入力してください。',
          mustSelectOneAccess: '最低1つのアクセス権限を選択してください。',
          error: 'エラー',
          ok: 'OK',
          saveChangesTitle: '保存',
          saveChangesBody: '変更内容を保存します。よろしいですか？',
          closeBtn: '閉じる'
        }
      }
    }
  }
};
</script>

<style>
.alert-m {
  margin: 40px 0px -4px 0px !important;
}
.previous-margin-top .v-btn__content {
  margin-top: 14px !important;
}
</style>
