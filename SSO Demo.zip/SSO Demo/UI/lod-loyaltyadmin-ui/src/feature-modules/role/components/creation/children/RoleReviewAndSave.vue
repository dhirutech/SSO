<template>
  <v-row no-gutters>
    <v-col class="gen2-forms form-light-bg" xs="12" sm="12" md="12">
      <v-row>
        <v-col xs="11" sm="11" md="11" class="bpt5">
          <h3>{{ $t("message.roleInformationText") }}</h3>
        </v-col>
        <v-col xs="1" sm="1" md="1">
          <v-btn text small color="#1959b8" @click="goToStepOne">
            <v-icon :title="$t('message.editText')" color="#212121">
              mdi-pencil
            </v-icon>
            <span class="btn-span">{{ $t("message.editText") }}</span>
          </v-btn>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12" class="bpb0">
          <p>
            <strong>{{ $t("message.roleNameText") }}</strong>
            <span>{{ role.roleName }}</span>
          </p>
          <p class="bmb0">
            <strong>{{ $t("message.roleDescriptionText") }}</strong>
            <span>{{ role.description }}</span>
          </p>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="11" sm="11" md="11" class="bpt5">
          <h3>{{ $t("message.rolePermissionsText") }}</h3>
        </v-col>
        <v-col xs="1" sm="1" md="1">
          <v-btn text small color="#1959b8" @click="goToStepTwo">
            <v-icon :title="$t('message.editText')" color="#212121">
              mdi-pencil
            </v-icon>
            <span class="btn-span">{{ $t("message.editText") }}</span>
          </v-btn>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12" class="bpb0">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-row v-for="(service, index) in services" :key="service.serviceId">
        <v-col xs="12" sm="12" md="12" class="bpt0">
          <p v-if="1 > 0" class="fbold text-uppercase bmt3">
            {{ service.name }}
          </p>
          <div v-for="ss in service.children" :key="ss.serviceId">
            <div v-if="Array.isArray(ss.children) && ss.children.length > 0">
              <div v-for="sss in ss.children" :key="sss.serviceId">
                <p>
                  <strong>{{ ss.name }}/{{ sss.name }}: </strong>
                  <span>{{ getMethodsByService(sss.serviceId) }}</span>
                </p>
              </div>
            </div>
            <p v-else>
              <strong>{{ ss.name }}: </strong>
              <span>{{ getMethodsByService(ss.serviceId) }}</span>
            </p>
          </div>
        </v-col>
        <v-col v-if="index < services.length - 1" xs="12" sm="12" md="12">
          <v-divider class="dashed"></v-divider>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
export default {
  props: {
    role: Object,
    services: Array,
    methods: Array
  },
  data () {
    return {
      permissions: []
    };
  },
  methods: {
    getMethodsByService (serviceId) {
      let self = this;
      let methodNames = [];
      for (let i = 0; i < self.role.permissions.length; i++) {
        if (self.role.permissions[i].serviceId === serviceId) {
          if (self.role.permissions[i].methodsId) {
            let arrMethods = self.role.permissions[i].methodsId
              .map(it => it)
              .sort();
            for (let x = 0; x < arrMethods.length; x++) {
              let found = self.methods.find(m => m.methodId === arrMethods[x]);
              methodNames.push(found.name);
            }
            return methodNames.join(', ');
          }
        }
      }
      return '';
    },
    goToStepOne () {
      this.$emit('step-one');
    },
    goToStepTwo () {
      this.$emit('step-two');
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          roleInformationText: 'Role Information',
          editText: 'EDIT',
          roleNameText: 'Role Name: ',
          roleDescriptionText: 'Role Description: ',
          rolePermissionsText: 'Role Permissions'
        }
      },
      ja: {
        message: {
          roleInformationText: '基本情報',
          editText: '編集',
          roleNameText: 'ロール名: ',
          roleDescriptionText: 'ロール概要: ',
          rolePermissionsText: 'アクセス権限'
        }
      }
    }
  }
};
</script>

<style lang="scss" scoped>
h3 {
  height: 25px;
  font-size: 18px;
  font-weight: bold;
  color: #000000;
  margin-left: 2px;
}
p {
  margin-left: 2px;
}
.btn-span {
  color: #0628b1;
  font-size: 0.9em !important;
  font-weight: 600;
}
</style>
