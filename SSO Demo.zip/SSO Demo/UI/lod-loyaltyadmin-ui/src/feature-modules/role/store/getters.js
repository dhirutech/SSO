const roleExists = (state)=> state.roleExists;
const getServices = (state) => state.services;
const getMethods = (state)=> state.methods;
const getRoles = (state)=> state.roles;
const getRolesSearched = (state)=> state.rolesSearched;
const getRoleResponse = (state)=> state.roleResponse;
const roleIsAssigned = (state)=> state.roleIsAssigned;
const getDeactivateDialogStatus = (state)=> state.deactivateDialogStatus;
const getselectedRole = (state)=> state.selectedRole;
const roleDeleteResponse = (state)=> state.roleDeleteResponse;
const getRole = (state)=> state.role;
const getCurrentView = (state)=> state.currentView;
const getDisabledPermissions = (state)=> state.disabledPermissions;
const getSortRequest = (state) => state.sortRequest;

export default {
  roleExists,
  getServices,
  getMethods,
  getRoles,
  getRolesSearched,
  getRoleResponse,
  roleIsAssigned,
  getDeactivateDialogStatus,
  getselectedRole,
  roleDeleteResponse,
  getRole,
  getCurrentView,
  getDisabledPermissions,
  getSortRequest
};
