const roleExists = (state, payload) => {
  state.roleExists = payload;
};

const roleIsAssigned = (state, payload) => {
  state.roleIsAssigned = payload;
};

const setServices = (state, payload) => {
  state.services = payload;
};

const setMethods = (state, payload) => {
  state.methods = payload;
};

const setRoles = (state, payload) => {
  state.roles = [...state.roles, ...payload.roles];
  state.rolesCount = payload.totalCount;
};

const initRoles = (state, payload) => {
  state.roles = payload.roles;
  state.rolesCount = payload.totalCount;
};

const setRolesSearched = (state, payload) => {
  state.rolesSearched = payload.roles;
  state.rolesCount = payload.totalCount;
};

const setRoleResponse = (state, payload) => {
  state.roleResponse = payload;
};

const deleteRole = (state, payload) => {
  state.roleDeleteResponse = payload;
};

const setDeactivateDialog = (state, paylod) => {
  state.deactivateDialogStatus = paylod;
};

const setCurrentView = (state, paylod) => {
  state.currentView = paylod;
};

const setSelectedRole = (state, paylod) => {
  state.selectedRole = paylod;
};

const setRole = (state, payload) => {
  state.role = payload;
};

const setDisabledPermissions = (state, payload) => {
  state.disabledPermissions = payload;
};

const setSortRequest = (state, payload) => {
  state.sortRequest = payload;
};

export default {
  roleExists,
  setServices,
  setMethods,
  setRoles,
  setRolesSearched,
  setRoleResponse,
  setDeactivateDialog,
  setSelectedRole,
  roleIsAssigned,
  deleteRole,
  setRole,
  setCurrentView,
  setDisabledPermissions,
  initRoles,
  setSortRequest
};
