export default {
  roleExists: false,
  services: [],
  methods: [],
  roles: [],
  rolesCount: 0,
  rolesSearched: [],
  roleResponse: {},
  deactivateDialogStatus: false,
  selectedRole: {
    id: 0,
    name: ''
  },
  currentView: 'grid_view',
  roleIsAssigned: false,
  roleDeleteResponse: '',
  role: {
    roleId: 0,
    roleName: '',
    isAdmin: false,
    description: '',
    permissions: []
  },
  sortRequest: {
    SortColumn: 'createddate',
    IsDescending: true
  },
  disabledPermissions: []
};
