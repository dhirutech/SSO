import * as api from '../api/module-api.js';

const roleExists = async ({ commit }, params) => {
  let response = await api.roleExistsAsync(params);
  commit('roleExists', response);
};

const roleIsAssigned = async ({ commit }, params) => {
  let response = await api.roleIsAssignedAsync(params);
  commit('roleIsAssigned', response);
};

const deleteRole = async ({ commit }, params) => {
  let response = await api.deleteRoleAsync(params);
  commit('deleteRole', response);
};

const getServices = async ({ commit }) => {
  let response = await api.getServicesAsync();
  commit('setServices', response);
};

const getMethods = async ({ commit }) => {
  let response = await api.getMethodsAsync();
  commit('setMethods', response);
};

const postRole = async ({ commit }, role) => {
  let response = await api.postRoleAsync(role);
  commit('setRoleResponse', response);
};

const setDialogStatus = ({ commit }, value) => {
  commit('setDeactivateDialog', value);
};

const setCurrentView = ({ commit }, value) => {
  commit('setCurrentView', value);
};

const setSelectedRole = ({ commit }, value) => {
  commit('setSelectedRole', value);
};

const getRole = async ({ commit }, roleId) => {
  let response = await api.getRoleAsync(roleId);
  commit('setRole', response);
};

const putRole = async ({ commit }, role) => {
  let response = await api.putRoleAsync(role);
  commit('setRoleResponse', response);
};

const setRole = async ({ commit }, role) => {
  commit('setRole', role);
};

const filterRoles = async ({ commit }, request) => {
  let response = await api.postFilterRolesAsync(request);
  if (request.PageNumber === 1)
    commit('initRoles', response);
  else
    commit('setRoles', response);
};

const searchRoles = async ({ commit }, request) => {
  let response = await api.postFilterRolesAsync(request);
  commit('setRolesSearched', response);
};

const seeMoreRoles = async ({ commit }, request) => {
  let response = request;
  commit('setRoles', response, 1);
};

const getDisabledPermissions = async ({ commit }) => {
  let response = await api.getDisabledPermissionsAsync();
  commit('setDisabledPermissions', response);
};

const setSortRequest = async ({ commit }, request) => {
  commit('setSortRequest', request);
};

export default {
  roleExists,
  getServices,
  getMethods,
  postRole,
  setDialogStatus,
  setSelectedRole,
  roleIsAssigned,
  deleteRole,
  getRole,
  putRole,
  setRole,
  filterRoles,
  searchRoles,
  seeMoreRoles,
  setCurrentView,
  getDisabledPermissions,
  setSortRequest,
};
