const STORE_DEFINITION_V1 = '/product/api/v1/storedefinitions';
const LOYALTY_CONFIGURATION_V1 = '/loyaltyconfiguration/api/v1';

export default {
  STORE_DEFINITION_V1,
  LOYALTY_CONFIGURATION_V1
};
