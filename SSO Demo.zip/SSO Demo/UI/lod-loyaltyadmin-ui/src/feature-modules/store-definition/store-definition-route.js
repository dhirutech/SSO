import StoreDefinitionSteps from './components/creation/StoreDefinitionSteps';
import StoreDefinitionLists from './components/listing/StoreDefinitionLists';

const storeDefinitionRoutes = [
  {
    path: '/loyaltyadmin/storedefinition/create',
    name: 'createStoreDefinition',
    component: StoreDefinitionSteps,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/storedefinition/edit/:id',
    name: 'editStoreDefinition',
    component: StoreDefinitionSteps,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/storedefinition/clone/:id',
    name: 'cloneStoreDefinition',
    component: StoreDefinitionSteps,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/storedefinition/view/:id',
    name: 'viewStoreDefinition',
    component: StoreDefinitionSteps,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/storedefinition',
    name: 'storeDefinitionList',
    component: StoreDefinitionLists,
    meta: {
      showNavigation: false
    }
  }
];

export default storeDefinitionRoutes;
