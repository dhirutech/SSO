import _ from 'lodash';

const getJsonData = data => {
  let unflatten = function (array, parent, tree) {
    tree = typeof tree !== 'undefined' ? tree : [];
    parent = typeof parent !== 'undefined' ? parent : { id: null };
    let children = _.filter(array, function (child) {
      if (child !== null && typeof child === 'object' && child.activeTF) {
        if (child.IsEdited === undefined) {
          child['IsEdited'] = true;
        }
        if (child.extend === undefined) {
          child['extend'] = true;
        }
        if (child.IsSaved === undefined) {
          child['IsSaved'] = true;
        }
        if (child.selected === undefined) {
          child['selected'] = false;
        }
        if (child.isDisplay === undefined) {
          child['isDisplay'] = false;
        }
      }
      return child.parentEntityId === parent.id && child.activeTF;
    });
    if (!_.isEmpty(children)) {
      if (parent.id === null) {
        tree = children;
      } else {
        parent['children'] = children;
      }
      _.each(children, function (child) {
        unflatten(array, child);
      });
    }
    return tree;
  };
  let finalResult = unflatten(data);
  let dummyChildren = finalResult[0];
  return dummyChildren;
};

export default {
  getJsonData
};
