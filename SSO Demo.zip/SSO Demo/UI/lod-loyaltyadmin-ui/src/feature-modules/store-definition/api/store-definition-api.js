import Vue from 'vue';
import constants from '../config/constants';
import utilities from '../utilities/store-definition-helper';

const storeDefinitionExistsAsync = async (storeSetName) => {
  let req = {
    storeDefName: storeSetName,
    isActive: true
  };
  return await Vue.prototype.$http
    .post(constants.STORE_DEFINITION_V1 + '/exists', req)
    .then((res) => {
      return res.data.data;
    });
};

const getBusinessEntitiesAlreadyAssigned = async () => {
  return await Vue.prototype.$http
    .get(constants.STORE_DEFINITION_V1 + '/businessentitylist')
    .then((res) => {
      return res.data.data;
    });
};

const getBusinessEntityNodeAsync = async () => {
  return await Vue.prototype.$http
    .get(constants.LOYALTY_CONFIGURATION_V1 + '/businessEntities/structure')
    .then((res) => {
      return utilities.getJsonData(res.data);
    });
};

const getStoreDefinitionsAsync = async (req) => {
  let queryString =
    '?PageSize=' + req.PageSize + '&PageNumber=' + req.PageNumber;
  if (req.SortBy)
    queryString =
      queryString +
      '&SortColumn=' +
      req.SortBy +
      '&IsDescending=' +
      (req.isDesc === true ? 'true' : 'false');
  return await Vue.prototype.$http
    .get(constants.STORE_DEFINITION_V1 + queryString)
    .then((res) => {
      return res.data.data;
    });
};

const postStoreDefinitionAsync = async (storeDefinition) => {
  return await Vue.prototype.$http
    .post(constants.STORE_DEFINITION_V1, storeDefinition)
    .then((res) => {
      return res.data;
    });
};

const getStoreDefinitionAsync = async (id) => {
  return await Vue.prototype.$http
    .get(constants.STORE_DEFINITION_V1 + '/' + id)
    .then((res) => {
      return res.data.data;
    });
};

const putStoreDefinitionAsync = async (req) => {
  return await Vue.prototype.$http
    .put(constants.STORE_DEFINITION_V1 + '/' + req.storeDefinitionId, req)
    .then((res) => {
      return res.data;
    });
};

const getCoreAttributesAsync = async () => {
  return await Vue.prototype.$http
    .get(constants.STORE_DEFINITION_V1 + '/coreattributes')
    .then((res) => {
      return res.data.data.attributes;
    });
};

const patchBusinessEntityAsync = async (req) => {
  return await Vue.prototype.$http
    .patch(constants.LOYALTY_CONFIGURATION_V1 + '/businessEntities/' + req.id + '/storedefinition/' + req.storeDefinitionId)
    .then((res) => {
      return res;
    });
};

export {
  storeDefinitionExistsAsync,
  getBusinessEntitiesAlreadyAssigned,
  getStoreDefinitionsAsync,
  getBusinessEntityNodeAsync,
  postStoreDefinitionAsync,
  getStoreDefinitionAsync,
  putStoreDefinitionAsync,
  getCoreAttributesAsync,
  patchBusinessEntityAsync
};
