<template>
  <v-row class="gen2-scroll-table mb-0" no-gutters>
    <v-col>
      <v-row class="table_container d-flex" no-gutters>
        <v-col class="table-center sticky-data-table gen2-forms form-light-bg">
          <v-flex class="sticky-data-table__scroll">
            <v-simple-table class="sticky-data-table__table">
              <thead>
                <tr>
                  <th class="sticky-first">
                    {{ $t("message.attributeName") }}
                  </th>
                  <th class="largecol">
                    {{ $t("message.dataType") }}
                  </th>
                  <th>
                    {{ $t("message.maxLength") }}
                    <column-tooltip
                      :header="$t('message.maxLength')"
                      :content="$t('message.maxLengthTooltip')"
                    />
                  </th>
                  <th class="largecol">
                    {{ $t("message.required") }}
                  </th>
                  <th class="largecol">
                    {{ $t("message.defaultField") }}
                    <column-tooltip
                      :header="$t('message.defaultField')"
                      :content="$t('message.defaultFieldTooltip')"
                    />
                  </th>
                  <th class="sticky-last">
                    {{ $t("message.actions") }}
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(attribute, i) in allAttributes" :key="i">
                  <td class="sticky-first">
                    <v-row class="content-info" no-gutters>
                      <v-col v-if="attribute.selected && !attribute.persisted">
                        <v-text-field
                          :label="$t('message.attributeName')"
                          :error="attributeNameError"
                          class="mini-field"
                          v-model="attribute.displayText"
                          maxlength="50"
                          required
                          filled
                        ></v-text-field>
                      </v-col>
                      <v-col v-else>
                        {{ attribute.displayText }}
                      </v-col>
                      <v-col
                        v-if="attribute.type === types[0]"
                        md="auto"
                        class="align-self-center"
                      >
                        <v-icon>lock</v-icon>
                      </v-col>
                    </v-row>
                  </td>
                  <td class="position-relative">
                    <span v-if="attribute.selected && !attribute.persisted">
                      <v-select
                        :label="$t('message.dataType')"
                        v-model="attribute.dataType"
                        :error="dataTypeError"
                        :items="dataTypes"
                        @change="cleanDefault(attribute)"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        filled
                      ></v-select>
                    </span>
                    <span v-else>
                      {{ attribute.dataType }}
                    </span>
                  </td>
                  <td>
                    <span
                      v-if="
                        attribute.selected &&
                          attribute.dataType === dataTypes[0]
                      "
                    >
                      <v-text-field
                        :label="$t('message.maxLength')"
                        v-model="attribute.stringMax"
                        :error="stringMaxError"
                        class="mini-field"
                        type="number"
                        min="1"
                        filled
                      ></v-text-field>
                    </span>
                    <span v-else-if="attribute.stringMax > 0">
                      {{ attribute.stringMax }}
                    </span>
                  </td>
                  <td>
                    {{ attribute.required ? "Yes" : "No" }}
                  </td>
                  <td>
                    <span v-if="attribute.selected">
                      <v-text-field
                        v-if="attribute.dataType === dataTypes[0]"
                        :label="$t('message.defaultField')"
                        :error="defaultValueError"
                        class="mini-field bmt-2"
                        ref="item.defaultValue"
                        v-model="attribute.defaultValue"
                        maxlength="100"
                        filled
                      ></v-text-field>
                      <v-text-field
                        v-else-if="attribute.dataType === dataTypes[1]"
                        :label="$t('message.defaultField')"
                        :error="defaultValueError"
                        class="mini-field bmt-2"
                        ref="item.defaultValue"
                        v-model="attribute.defaultValue"
                        type="number"
                        maxlength="100"
                        filled
                      ></v-text-field>
                      <v-menu
                        v-else-if="attribute.dataType === dataTypes[3]"
                        ref="dateMenu"
                        v-model="dateMenu"
                        :close-on-content-click="false"
                        :return-value.sync="unformattedDate"
                        transition="scale-transition"
                        offset-y
                        min-width="290px"
                      >
                        <template v-slot:activator="{ on }">
                          <v-text-field
                            :label="$t('message.defaultField')"
                            :error="defaultValueError"
                            v-model="formatedDate"
                            v-on="on"
                            class="mini-field bmt-2"
                            readonly
                            filled
                          ></v-text-field>
                        </template>
                        <v-date-picker
                          v-model="unformattedDate"
                          no-title
                          scrollable
                        >
                          <v-spacer></v-spacer>
                          <v-btn text color="primary" @click="dateMenu = false"
                            >Cancel</v-btn
                          >
                          <v-btn
                            text
                            color="primary"
                            @click="$refs.dateMenu[0].save(unformattedDate)"
                            >OK</v-btn
                          >
                        </v-date-picker>
                      </v-menu>
                      <v-select
                        v-else-if="attribute.dataType === dataTypes[2]"
                        :label="$t('message.defaultField')"
                        :error="defaultValueError"
                        v-model="attribute.defaultValue"
                        :items="booleans"
                        class="gen2select gen2select__dark mini-field"
                        append-icon="expand_more"
                        filled
                      ></v-select>
                    </span>
                    <span v-else>
                      {{ attribute.defaultValue }}
                    </span>
                  </td>
                  <td class="sticky-last">
                    <template v-if="attribute.selected">
                      <span>
                        <v-icon
                          class="primary-text"
                          @click="saveAttribute(attribute)"
                          >save</v-icon
                        >
                      </span>
                      <span
                        @click="cancelAttribute(attribute)"
                        class="material-icons icon-font20 pl-2"
                      >
                        cancel
                      </span>
                    </template>
                    <template v-else>
                      <v-icon
                        :disabled="attribute.type === types[0] || viewing"
                        color="#0628b1"
                        @click="selectAttribute(attribute)"
                      >
                        edit
                      </v-icon>
                      <v-icon
                        :disabled="
                          attribute.type === types[0] ||
                            attribute.persisted ||
                            viewing
                        "
                        color="#0628b1"
                        @click="deleteAttribute(attribute)"
                      >
                        delete
                      </v-icon>
                    </template>
                  </td>
                </tr>
              </tbody>
            </v-simple-table>
          </v-flex>
        </v-col>
      </v-row>
      <v-row v-if="errorMessages.length > 0">
        <v-col>
          <v-alert class="b-alert-error" type="error" :dismissible="false">
            <v-row class="alert-block align-center havebtn" no-gutters>
              <v-col class="alert-block__body">
                <h3>{{ $t("message.errorHeader") }}</h3>
                <p v-for="error in errorMessages" :key="error">{{ error }}</p>
              </v-col>
            </v-row>
          </v-alert>
        </v-col>
      </v-row>
    </v-col>
    <v-row v-if="viewing" no-gutters class="align-center bmt1">
      <v-col>
        <span class="text-uppercase assign disabled-text">
          <v-icon disabled class="pr-3 primary-text">add_circle_outline</v-icon>
          {{ $t("message.addNewAttribute") }}
        </span>
      </v-col>
    </v-row>
    <v-row v-else no-gutters class="align-center bmt1">
      <v-col>
        <span
          class="fbold text-uppercase assign primary-text cursor-p"
          @click="addNewAttribute()"
        >
          <v-icon class="pr-3 primary-text">add_circle_outline</v-icon>
          {{ $t("message.addNewAttribute") }}
        </span>
      </v-col>
    </v-row>
  </v-row>
</template>

<script>
import ColumnTooltip from './ColumnTooltip';
import { mapState } from 'vuex';
import * as utilities from '../../../../role/components/listing/utilities.js';
export default {
  components: {
    ColumnTooltip
  },
  data () {
    return {
      newObj: [],
      modes: ['Create', 'Edit'],
      types: ['Core', 'Extended'],
      dataTypes: ['String', 'Number', 'Boolean', 'Date'],
      encryptions: ['None', 'Symmetric', 'Asymmetric', 'Encoded'],
      booleans: ['True', 'False'],
      tempAttribute: {},
      selectedAttributeId: '',
      dateMenu: false,
      errorMessages: [],
      attributeNameError: false,
      dataTypeError: false,
      encryptionError: false,
      stringMaxError: false,
      defaultValueError: false,
      selectedAttribute: {},
      unformattedDate: ''
    };
  },
  props: {
    viewing: {
      type: Boolean
    }
  },
  computed: {
    ...mapState({
      coreAttributes: state => state.storeDefinitionModule.coreAttributes,
      storeDefinition: state => state.storeDefinitionModule.storeDefinition
    }),
    allAttributes () {
      return this.coreAttributes.concat(
        this.storeDefinition.extendedAttributes
      );
    },
    formatedDate () {
      if (!this.unformattedDate) return null;
      return utilities.formatDate(this.unformattedDate);
    }
  },
  methods: {
    cleanDefault (attribute) {
      attribute.defaultValue = '';
    },
    cleanErrorMessages () {
      this.errorMessages = [];
      this.attributeNameError = false;
      this.dataTypeError = false;
      this.encryptionError = false;
      this.stringMaxError = false;
    },
    deleteAttribute (attribute) {
      let self = this;
      let indexToRemove = -1;

      for (let i = 0; i < self.storeDefinition.extendedAttributes.length; i++) {
        if (
          self.storeDefinition.extendedAttributes[i].displayText ===
          attribute.displayText
        ) {
          indexToRemove = i;
        }
      }
      if (indexToRemove > -1) {
        self.storeDefinition.extendedAttributes.splice(indexToRemove, 1);
      }
      self.cleanErrorMessages();
    },
    selectAttribute (attribute) {
      let self = this;
      let anotherAttributeBeingEdited = false;

      for (let i = 0; i < self.storeDefinition.extendedAttributes.length; i++) {
        if (self.storeDefinition.extendedAttributes[i].selected === true) {
          anotherAttributeBeingEdited = true;
          break;
        }
      }
      if (!anotherAttributeBeingEdited) {
        attribute.selected = true;
        attribute.valid = false;
        attribute.mode = self.modes[1];
        if (attribute.dataType === self.dataTypes[3]) {
          self.unformattedDate = utilities.parseDate(attribute.defaultValue);
        }
        self.tempAttribute = JSON.parse(JSON.stringify(attribute));
      }
    },
    saveAttribute (item) {
      let self = this;
      self.errorMessages = [];
      self.attributeNameError = false;
      self.dataTypeError = false;
      self.stringMaxError = false;
      self.defaultValueError = false;
      self.handleDatatypes(item);

      if (item.displayText.length < 1) {
        self.errorMessages.push(self.$t('message.attributeNameIsRequired'));
        self.attributeNameError = true;
      }

      if (!self.isNameUnique(item)) {
        self.errorMessages.push(self.$t('message.nameAlreadyExists'));
        self.attributeNameError = true;
      }

      if (item.dataType.length < 1) {
        self.errorMessages.push(self.$t('message.dataTypeIsRequired'));
        self.dataTypeError = true;
      }

      if (item.dataType === self.dataTypes[0] && item.stringMax < 1) {
        self.errorMessages.push(self.$t('message.maxLengthIsRequired'));
        self.stringMaxError = true;
      }

      if (item.defaultValue.length < 1) {
        self.errorMessages.push(self.$t('message.defaultValueIsRequired'));
        self.defaultValueError = true;
      }

      if (item.persisted) {
        if (item.stringMax < self.tempAttribute.stringMax) {
          self.errorMessages.push(
            self.$t('message.maxLengthCanOnlyBeIncreased')
          );
          self.stringMaxError = true;
        }
      }

      if (self.errorMessages.length < 1) {
        item.valid = true;
        item.selected = false;
        self.selectedAttributeId = '';
        self.newObj = [];
      }
    },
    isNameUnique (attribute) {
      let self = this;
      for (let i = 0; i < self.allAttributes.length; i++) {
        if (
          (self.allAttributes[i].valid === true ||
            self.allAttributes[i].type === self.types[0]) &&
          self.allAttributes[i].displayText === attribute.displayText
        ) {
          return false;
        }
      }
      return true;
    },
    handleDatatypes (attribute) {
      let self = this;
      if (attribute.dataType !== self.dataTypes[0]) {
        attribute.stringMax = 0;
      }
      if (
        attribute.dataType === self.dataTypes[3] &&
        self.unformattedDate.length > 0
      ) {
        attribute.defaultValue = utilities.formatDate(
          new Date(self.unformattedDate)
        );
      }
      attribute.columnName = attribute.displayText.replace(/\s/g, '');
    },
    cancelAttribute (item) {
      if (item.mode === this.modes[0]) {
        this.deleteAttribute(item);
      } else {
        item.displayText = this.tempAttribute.displayText;
        item.dataType = this.tempAttribute.dataType;
        item.stringMax = this.tempAttribute.stringMax;
        item.required = this.tempAttribute.required;
        item.encryption = this.tempAttribute.encryption;
        item.defaultValue = this.tempAttribute.defaultValue;
        item.selected = false;
        item.valid = true;
      }
      this.cleanErrorMessages();
    },
    addNewAttribute () {
      let newAttribute = {
        tempId: new Date().valueOf(),
        displayText: '',
        columnName: '',
        dataType: this.dataTypes[0],
        stringMax: 0,
        required: '',
        encryption: 'None',
        predefinedValues: null,
        example: '',
        description: '',
        status: false,
        defaultValue: '',
        programId: -1,
        isDsar: true,
        isRtbf: true,
        isActive: true,
        type: this.types[1],
        valid: false,
        selected: true,
        persisted: false,
        mode: this.modes[0]
      };
      this.selectedAttribute = JSON.parse(JSON.stringify(newAttribute));
      this.unformattedDate = '';
      this.$store.commit(
        'storeDefinitionModule/addExtendedAttribute',
        newAttribute
      );
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          attributeName: 'Attribute Name',
          dataType: 'Data Type',
          maxLength: 'Max Length',
          required: 'Required',
          defaultField: 'Default Field',
          actions: 'Actions',
          addNewAttribute: 'Add new attribute',
          maxLengthTooltip:
            'The maximum character length allowed for string data.',
          defaultFieldTooltip:
            'This is the default value to use when no value is given.',
          attributeNameIsRequired: 'Attribute Name is required.',
          dataTypeIsRequired: 'Data Type is required.',
          maxLengthIsRequired: 'Max Length is required.',
          errorHeader: 'Error',
          nameAlreadyExists: 'Name already exists. Please use another name.',
          maxLengthCanOnlyBeIncreased: 'Max Length can only be increased.',
          defaultValueIsRequired: 'Default Field is required.'
        }
      },
      ja: {
        message: {
          attributeName: '項目名',
          dataType: 'データ型',
          maxLength: '最大長',
          required: '必須',
          defaultField: 'デフォルト値',
          actions: '操作',
          addNewAttribute: '項目を追加する',
          maxLengthTooltip: 'データ型がStringの場合のみ最大長が設定できます。',
          defaultFieldTooltip:
            'APIなどでこの項目に値が渡されない場合に、デフォルトとして設定する値を指定してください。',
          attributeNameIsRequired: '「項目名」は必須項目です。',
          dataTypeIsRequired: '「データ型」は必須項目です。',
          maxLengthIsRequired: '「最大長」は必須項目です。',
          errorHeader: 'エラー',
          nameAlreadyExists:
            '設定された名称はすでに存在します。別の名前を設定してください。',
          maxLengthCanOnlyBeIncreased: '最大長の値を短くすることはできません。',
          defaultValueIsRequired: '「デフォルト値」は必須項目です。'
        }
      }
    }
  }
};
</script>
<style scoped lang="scss">
.v-alert {
  max-width: 100% !important;
}
.sticky-data-table {
  overflow-y: hidden;
}
.icon-font20 {
  font-size: 20px !important;
  cursor: pointer;
}
.disabled-text {
  color: #bdbdbd;
  font-weight: 600;
}
</style>
