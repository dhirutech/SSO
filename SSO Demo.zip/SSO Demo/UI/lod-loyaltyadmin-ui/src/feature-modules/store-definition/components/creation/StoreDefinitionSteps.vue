<template>
  <brierley-inner-view
    :footerOnly="false"
    :showRightElem="currentStep === 2 ? true : false"
  >
    <template v-slot:header>
      <span class="inner-head">{{ title }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn class="no-ripple" href target="_blank" text @click="closeScreen">
        <v-icon>mdi-close</v-icon>{{ $t("message.close") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <brierley-primary-stepper
        :currentStep="currentStep"
        :isHideStepper="true"
      >
        <template slot="stepper-content">
          <v-stepper-items>
            <v-stepper-content step="1">
              <v-row class="flex-column" no-gutters>
                <v-col>
                  <brierley-form-title
                    :formTitle="formTitle"
                    :currentStep="1"
                    :totalStep="viewing ? 2 : 3"
                    :infoText="$t('message.formInfoText')"
                    :showSteps="false"
                  ></brierley-form-title>
                </v-col>
                <v-col>
                  <v-form
                    ref="storeDefinitionForm"
                    v-model="storeDefinitionFormValid"
                  >
                    <v-row no-gutters class="d-flex ">
                      <v-col
                        class="gen2-forms form-light-bg"
                        xs="12"
                        sm="6"
                        md="7"
                      >
                        <p class="fbold text-uppercase bmt3">
                          {{ $t("message.basicDetails") }}
                        </p>
                        <v-col sm="8" xs="12" class="bpa0">
                          <v-text-field
                            :label="$t('message.nameLabel')"
                            ref="storesetname"
                            :error-messages="nameErrorMsg"
                            :disabled="readonly"
                            :readonly="readonly"
                            filled
                            v-model="storeDefinition.name"
                            :rules="nameRules"
                          />
                        </v-col>
                        <v-col sm="8" xs="12" class="bpa0">
                          <v-textarea
                            :label="$t('message.descriptionLabel')"
                            filled
                            :disabled="readonly"
                            :readonly="readonly"
                            auto-grow
                            :rules="descriptionRules"
                            v-model="storeDefinition.description"
                          >
                          </v-textarea>
                        </v-col>
                      </v-col>
                      <v-col class="bpt4" xs="12" sm="6" md="5">
                        <brierley-info-side>
                          <template v-slot:info-side-header>
                            <div class="info_title">
                              <v-icon>info</v-icon>
                              {{ $t("message.infoHeader") }}
                            </div>
                          </template>
                          <template v-slot:info-side-body>
                            <div>
                              {{ $t("message.infoBody") }}
                            </div>
                          </template>
                        </brierley-info-side>
                      </v-col>
                    </v-row>
                    <v-row no-gutters class="d-flex">
                      <v-col
                        class="gen2-forms form-light-bg"
                        xs="12"
                        sm="12"
                        md="12"
                      >
                        <v-expansion-panels
                          class="role-assignment-expansions bpt3 bpb5"
                          accordion
                          v-model="panel"
                          expand
                        >
                          <v-expansion-panel>
                            <v-expansion-panel-header>{{
                              $t("message.storeAttributes")
                            }}</v-expansion-panel-header>
                            <v-expansion-panel-content>
                              <store-attributes :viewing="viewing" />
                            </v-expansion-panel-content>
                          </v-expansion-panel>
                          <v-expansion-panel>
                            <v-expansion-panel-header>{{
                              $t("message.programEntityMapping")
                            }}</v-expansion-panel-header>
                            <v-expansion-panel-content>
                              <v-row no-gutters class="d-flex ">
                                <v-col
                                  class="col-padding form-light-bg"
                                  xs="12"
                                  sm="12"
                                  md="12"
                                >
                                  <p>{{ $t("message.selectProgramEntity") }}</p>
                                </v-col>
                              </v-row>
                              <v-row no-gutters class="d-flex ">
                                <v-col
                                  class="col-padding form-light-bg"
                                  xs="12"
                                  sm="6"
                                  md="6"
                                >
                                  <p class="label-text">
                                    {{ $t("message.programEntity") }}
                                  </p>
                                  <brierley-block-with-chips
                                    v-model="storeDefinition.businessEntities"
                                  >
                                    <template v-slot:block-with-chips-title>
                                      <span class="chips-req-label">{{
                                        $t("message.selectedProgramEntity")
                                      }}</span>
                                    </template>
                                    <template v-slot:block-with-chips-body>
                                      <p
                                        class="font12 body-text fbold"
                                        v-if="
                                          storeDefinition.businessEntities
                                            .length === 0
                                        "
                                      >
                                        {{ $t("message.noProgramEntity") }}
                                      </p>
                                      <v-chip
                                        v-for="(entity,
                                        index) of storeDefinition.businessEntities"
                                        :key="index"
                                        @click:close="deleteEntity"
                                        close
                                        close-icon="close"
                                        :disabled="editing || viewing"
                                        >{{ entity.name }}</v-chip
                                      >
                                    </template>
                                  </brierley-block-with-chips>
                                  <p class="bmt2 bmb5">
                                    <span
                                      @click="openDialog"
                                      class="primary-text fbold text-uppercase"
                                      :class="{
                                        'cursor-p': !editing && !viewing,
                                        'gray-text': editing || viewing
                                      }"
                                      >{{
                                        $t("message.clickHereSelectText")
                                      }}</span
                                    >
                                  </p>
                                </v-col>
                                <v-col
                                  class="gen2-forms form-light-bg"
                                  xs="12"
                                  sm="6"
                                  md="6"
                                >
                                </v-col>
                              </v-row>
                            </v-expansion-panel-content>
                          </v-expansion-panel>
                          <v-col>
                            <p
                              class="custom-error-msg text-left"
                              v-if="businessEntityErrorMsg"
                            >
                              {{ businessEntityErrorMsg }}
                            </p>
                          </v-col>
                        </v-expansion-panels>
                      </v-col>
                    </v-row>
                  </v-form>
                </v-col>
              </v-row>
            </v-stepper-content>
            <v-stepper-content v-if="!viewing" step="2">
              <v-row class="flex-column" no-gutters>
                <v-col>
                  <brierley-form-title
                    :formTitle="alertHeader"
                    :infoIcon="false"
                  >
                  </brierley-form-title>
                </v-col>
                <v-col class="bmt3 alert-m">
                  <brierley-alert
                    :isSiteLevel="true"
                    :alertType="alertType"
                    :alertBody="alertBody"
                    :alertHeader="alertHeader"
                    :icon="alertIcon"
                  ></brierley-alert>
                </v-col>
              </v-row>
            </v-stepper-content>
          </v-stepper-items>
        </template>
      </brierley-primary-stepper>
    </template>
    <template v-slot:footer v-if="currentStep !== 2">
      <v-btn
        v-if="!viewing"
        text
        class="cancel no-ripple bmt2 bmr5"
        @click="closeScreen"
      >
        {{ $t("message.cancel") }}
      </v-btn>
      <v-btn
        v-if="!viewing"
        class="primaryctabtn bmt2"
        @click="submitStoreDefinition"
      >
        {{ $t("message.saveStore") }}
      </v-btn>
      <v-btn
        v-if="viewing"
        class="primaryctabtn"
        title="Default"
        @click="$router.push('/loyaltyadmin/storedefinition')"
        >{{ $t("message.close") }}</v-btn
      >
      <brierley-dialogbox
        class="fullwidth-dialog"
        :dialog="businessEntityDialog"
        @closeMe="doneBusinessEntityDialog"
        :scrollable="true"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ $t("message.progHierarchyText") }}
          </v-card-title>
        </template>

        <template v-slot:dialog-body-description>
          <v-col>
            <template>
              <div class="chart-container loyalty-org">
                <div class="entity-chart-container">
                  <div class="entity-chart">
                    <brierley-program-entity-chart
                      :entity="businessEntityNode"
                      :infoMessage="
                        $t('message.alreadyAssignedProgramEntityMessage')
                      "
                      :bus="bus"
                    >
                    </brierley-program-entity-chart>
                  </div>
                </div>
              </div>
            </template>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            text
            class="cancel no-ripple"
            @click="cancelBusinessEntityDialog"
          >
            {{ $t("message.cancel") }}
          </v-btn>
          <v-btn
            class="primaryctabtn btn-close"
            title="Default"
            @click="doneBusinessEntityDialog"
          >
            {{ $t("message.done") }}
          </v-btn>
        </template>
      </brierley-dialogbox>

      <brierley-dialogbox
        :dialog="cancelDialog"
        @closeMe="cancelDialog = $event"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            cancelDialogTitle
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-alert>
          <brierley-alert
            alertType="warning"
            :alertBody="cancelDialogBody"
            icon="notifications_active"
          ></brierley-alert>
        </template>
        <template v-slot:dialog-footer>
          <v-btn text class="cancel no-ripple" @click="noSave">{{
            $t("message.no")
          }}</v-btn>
          <v-btn class="primaryctabtn" title="Default" @click="save">{{
            $t("message.yes")
          }}</v-btn>
        </template>
      </brierley-dialogbox>

      <brierley-dialogbox :dialog="errorDialog" @closeMe="errorDialog = $event">
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            $t("message.errorDialogTitle")
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-alert>
          <brierley-alert
            alertType="error"
            :alertBody="errorBody"
            icon="notifications_active"
          ></brierley-alert>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            class="primaryctabtn"
            title="Default"
            @click="errorDialog = false"
            >{{ $t("message.ok") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </template>
    <template v-slot:footer-left v-if="currentStep === 2">
      <v-btn
        class="primaryctabtn"
        @click.native="$router.push('/loyaltyadmin/storedefinition')"
      >
        {{ $t("message.storedefs") }}
      </v-btn>
      <p class="fbold text-uppercase bpt5">{{ $t("message.subTitle") }}</p>
      <p class="btn-link">
        {{ $t("message.addQuestion") }}
        <span @click="clickHere">{{ $t("message.clickHere") }}</span>
      </p>
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  brierleyAlert,
  BrierleyBlockWithChips,
  BrierleyDialogbox,
  BrierleyFormTitle,
  BrierleyInfoSide,
  BrierleyInnerView,
  BrierleyPrimaryStepper,
  BrierleyProgramEntityChart
} from '@brierley/SharedComponents';
import StoreAttributes from './children/StoreAttributes';
import { mapState } from 'vuex';
import Vue from 'vue';
export default {
  components: {
    brierleyAlert,
    BrierleyBlockWithChips,
    BrierleyDialogbox,
    BrierleyFormTitle,
    BrierleyInnerView,
    BrierleyInfoSide,
    BrierleyPrimaryStepper,
    BrierleyProgramEntityChart,
    StoreAttributes
  },
  data () {
    return {
      panel: [],
      title: '',
      currentStep: 1,
      cancelDialog: false,
      stepTwoDialog: false,
      storeDefinitionFormValid: true,
      optionClick: '',
      stepperSize: 0,
      alertIcon: 'mdi-alert',
      alertBody: this.$t('message.errorAlertBody'),
      alertHeader: this.$t('message.errorAlertHeader'),
      alertType: 'error',
      nameErrorMsg: '',
      editing: false,
      cloning: false,
      viewing: false,
      readonly: false,
      cancelDialogTitle: this.$t('message.cancelDialogTitle'),
      cancelDialogBody: this.$t('message.cancelDialogBody'),
      emptyStoreDefinition: {
        storeDefinitionId: 0,
        name: '',
        description: '',
        businessEntityId: 0,
        businessEntities: [],
        extendedAttributes: []
      },
      originalStoreDefinition: {
        storeDefinitionId: 0,
        name: '',
        description: '',
        businessEntityId: 0,
        businessEntities: [],
        extendedAttributes: []
      },
      triggeredFromCancelDialog: false,
      nameRules: [
        v => !!v.trim() || this.$t('message.storeSetNameIsRequired'),
        v =>
          v && v.length < 50 || this.$t('message.storeSetNameLengthExceeded')
      ],
      descriptionRules: [
        v =>
          v.length < 500 || this.$t('message.storeSetDescriptionLengthExceeded')
      ],
      businessEntityDialog: false,
      bus: new Vue(),
      businessEntityErrorMsg: '',
      tempBusinessEntities: [],
      formTitle: '',
      errorDialog: false,
      errorBody: ''
    };
  },
  computed: {
    ...mapState({
      businessEntityNode: state =>
        state.storeDefinitionModule.businessEntityNode,
      storeDefinition: state => state.storeDefinitionModule.storeDefinition,
      businessEntitiesAlreadyAssigned: state =>
        state.storeDefinitionModule.businessEntitiesAlreadyAssigned,
      coreAttributes: state => state.storeDefinitionModule.coreAttributes
    })
  },
  created () {
    let self = this;
    self.initialize();
    self.attachBusEvents();
  },
  mounted () {
    window.scrollTo(0, 0);
    this.$nextTick(() => this.$refs.storesetname.$refs.input.focus());
  },
  watch: {
    storeDefinition (value) {
      this.$store.commit('storeDefinitionModule/setStoreDefinition', value);
    },
    'storeDefinition.name' () {
      this.storeDefinition.name = this.storeDefinition.name.trim();
      this.validateStoreName();
    },
    'storeDefinition.businessEntities' () {
      let self = this;
      if (!self.storeDefinition.businessEntities) {
        const emptyStoreDef = {
          storeDefinitionId: 0,
          name: '',
          description: '',
          businessEntityId: 0,
          businessEntities: [],
          extendedAttributes: []
        };
        self.$store.dispatch(
          'storeDefinitionModule/setStoreDefinition',
          emptyStoreDef
        );
      }
      if (self.storeDefinition.businessEntities.length > 0) {
        self.storeDefinition.businessEntityId =
          self.storeDefinition.businessEntities[0].id;
        self.businessEntityErrorMsg = '';
        if (!self.editing && !self.viewing && !self.cloning) {
          self.$store
            .dispatch(
              'storeDefinitionModule/getBusinessEntitiesAlreadyAssigned'
            )
            .then(() => {
              if (
                self.businessEntitiesAlreadyAssigned.includes(
                  self.storeDefinition.businessEntityId
                )
              ) {
                self.businessEntityErrorMsg = self.$t(
                  'message.programEntityAlreadyAssigned'
                );
              } else {
                self.businessEntityErrorMsg = '';
              }
            });
        }
      } else if (!self.editing) {
        self.storeDefinition.businessEntityId = 0;
      }
    }
  },
  methods: {
    unpersistClonedExtendedAttributes () {
      let s = this;
      for (let i = 0; i < s.storeDefinition.extendedAttributes.length; i++) {
        s.storeDefinition.extendedAttributes[i].persisted = false;
      }
    },
    clickHere () {
      let self = this;
      const shouldRedirect =
        self.editing || self.viewing || self.cloning ? true : false;
      self.resetData();
      self.attachBusEvents();
      self.currentStep = 1;
      self.$refs.storeDefinitionForm.resetValidation();
      if (shouldRedirect) {
        self.$router.push('/loyaltyadmin/storedefinition/create');
      }
    },
    resetData () {
      this.panel = [];
      this.title = '';
      this.cancelDialog = false;
      this.stepTwoDialog = false;
      this.storeDefinitionFormValid = true;
      this.optionClick = '';
      this.stepperSize = 0;
      this.editing = false;
      this.cloning = false;
      this.viewing = false;
      this.readonly = false;
      this.emptyStoreDefinition = {
        storeDefinitionId: 0,
        name: '',
        description: '',
        businessEntityId: 0,
        businessEntities: [],
        extendedAttributes: []
      };
      this.originalStoreDefinition = {
        storeDefinitionId: 0,
        name: '',
        description: '',
        businessEntityId: 0,
        businessEntities: [],
        extendedAttributes: []
      };
      this.triggeredFromCancelDialog = false;
      this.businessEntityDialog = false;
      this.bus = new Vue();
      this.businessEntityErrorMsg = '';
      this.tempBusinessEntities = [];
      this.formTitle = '';
      this.errorDialog = false;
      this.errorBody = '';

      this.title = this.$t('message.createTitleText');
      this.formTitle = this.$t('message.createFormTitleText');

      const emptyStoreDef = {
        storeDefinitionId: 0,
        name: '',
        description: '',
        businessEntityId: 0,
        businessEntities: [],
        extendedAttributes: []
      };
      this.$store.dispatch(
        'storeDefinitionModule/setStoreDefinition',
        emptyStoreDef
      );
    },
    setSuccessAlert () {
      let self = this;
      self.alertIcon = 'done';
      self.alertType = 'success';
      self.alertHeader = self.$t('message.successAlertHeader');
      self.alertBody = self.editing
        ? self
          .$t('message.alertEditBody')
          .replace('#STOREDEFNAME#', self.storeDefinition.name)
        : self
          .$t('message.alertCreateBody')
          .replace('#STOREDEFNAME#', self.storeDefinition.name);
      self.currentStep++;
    },
    cancelBusinessEntityDialog () {
      this.storeDefinition.businessEntities = this.tempBusinessEntities;
      this.businessEntityDialog = false;
    },
    doneBusinessEntityDialog () {
      this.businessEntityDialog = false;
    },
    initialize () {
      let self = this;
      let id = self.$route.params.id;
      self.optionClick = self.$route.name;
      self.stepperSize = 4;
      self.readonly = false;
      self.$store
        .dispatch('storeDefinitionModule/getCoreAttributes')
        .then(() => {
          if (id > 0) {
            if (self.$route.name === 'cloneStoreDefinition') {
              self.cloning = true;
              self.title = self.$t('message.cloneTitleText');
              self.formTitle = self.$t('message.cloneTitleText');
            } else if (self.$route.name === 'viewStoreDefinition') {
              self.viewing = true;
              self.title = self.$t('message.editTitleText');
              self.formTitle = self.$t('message.viewFormTitleText');
              self.readonly = true;
            } else {
              self.editing = true;
              self.title = self.$t('message.editTitleText');
              self.formTitle = self.$t('message.editFormTitleText');
              self.cancelDialogTitle = self.$t('message.saveChangesTitle');
              self.cancelDialogBody = self.$t('message.saveChangesBody');
            }

            self.$store
              .dispatch('storeDefinitionModule/getStoreDefinition', id)
              .then(() => {
                self.originalStoreDefinition = JSON.parse(
                  JSON.stringify(self.storeDefinition)
                );
                if (self.cloning) {
                  self.storeDefinition.name =
                    'Copy of ' + self.storeDefinition.name;
                  self.unpersistClonedExtendedAttributes();
                  self.storeDefinition.businessEntityId = 0;
                  self.storeDefinition.businessEntities = [];
                }
              });
          } else {
            const emptyStoreDef = {
              storeDefinitionId: 0,
              name: '',
              description: '',
              programEntityId: 0,
              programEntities: [],
              extendedAttributes: []
            };
            self.title = self.$t('message.createTitleText');
            self.formTitle = self.$t('message.createFormTitleText');
            self.$store.dispatch(
              'storeDefinitionModule/setStoreDefinition',
              emptyStoreDef
            );
          }
        });
    },
    closeScreen () {
      let self = this;
      if (this.currentStep === 2) {
        self.$router.push('/loyaltyadmin/storedefinition');
        return;
      }
      if (self.$route.name === 'viewStoreDefinition')
        self.$router.push('/loyaltyadmin/storedefinition');
      else self.cancelDialog = true;
    },
    validateStoreName () {
      let self = this;

      if (self.readonly) {
        return;
      }

      if (self.storeDefinition.name.length > 0) {
        self.$store
          .dispatch(
            'storeDefinitionModule/storeDefinitionExists',
            self.storeDefinition.name
          )
          .then(res => {
            if (
              res &&
              (!self.editing ||
                self.originalStoreDefinition.name !== self.storeDefinition.name)
            ) {
              self.nameErrorMsg = self.$t('message.storeSetNameAlreadyExists');
            } else {
              self.nameErrorMsg = '';
            }
          });
      }
    },
    noSave () {
      this.cancelDialog = false;
      this.$router.push('/loyaltyadmin/storedefinition');
    },
    save () {
      this.cancelDialog = false;
      this.triggeredFromCancelDialog = true;
      this.submitStoreDefinition();
    },
    submitStoreDefinition () {
      let self = this;
      self.errorBody = self.$t('message.errorDialogAlertBody');

      self.$refs.storeDefinitionForm.validate();
      if (self.storeDefinitionFormValid) {
        self.$store
          .dispatch(
            'storeDefinitionModule/storeDefinitionExists',
            self.storeDefinition.name.trim()
          )
          .then(res => {
            if (
              res &&
              (!self.editing ||
                self.originalStoreDefinition.name !== self.storeDefinition.name)
            ) {
              self.nameErrorMsg = self.$t('message.storeSetNameAlreadyExists');
            } else if (self.storeDefinition.businessEntityId < 1) {
              self.businessEntityErrorMsg = self.$t(
                'message.programEntityRequired'
              );
            } else {
              self.nameErrorMsg = '';
              self.businessEntityErrorMsg = '';

              if (!self.anyPendingAttribute()) {
                if (self.editing && !self.cloning) {
                  self.putStoreDefinition();
                } else {
                  self.postStoreDefinition();
                }
              } else {
                self.errorDialog = true;
                self.errorBody = self.$t('message.errorAttributesPending');
              }
            }
          })
          .catch(() => {
            self.errorDialog = true;
          });
      }
    },
    putStoreDefinition () {
      let self = this;
      self.$store
        .dispatch(
          'storeDefinitionModule/putStoreDefinition',
          self.storeDefinition
        )
        .then(res => {
          if (!res.isError) {
            self.setSuccessAlert();
          }
        })
        .catch(() => {
          self.errorDialog = true;
        });
    },
    postStoreDefinition () {
      let self = this;
      self.$store
        .dispatch('storeDefinitionModule/getBusinessEntitiesAlreadyAssigned')
        .then(() => {
          if (
            self.businessEntitiesAlreadyAssigned.includes(
              self.storeDefinition.businessEntityId
            )
          ) {
            self.businessEntityErrorMsg = self.$t(
              'message.programEntityAlreadyAssigned'
            );
          } else {
            self.businessEntityErrorMsg = '';
            self.$store
              .dispatch(
                'storeDefinitionModule/postStoreDefinition',
                self.storeDefinition
              )
              .then(res => {
                if (res.httpStatusCode === 200) {
                  let req = {
                    id: self.storeDefinition.businessEntityId,
                    storeDefinitionId: res.data.data.storeDefinitionId
                  };
                  self.$store
                    .dispatch('storeDefinitionModule/patchBusinessEntity', req)
                    .then(res => {
                      if (res.status === 200) {
                        self.setSuccessAlert();
                      }
                    });
                }
              })
              .catch(() => {
                self.errorDialog = true;
              });
          }
        })
        .catch(() => {
          self.errorDialog = true;
        });
    },
    anyPendingAttribute () {
      let self = this;
      for (let i = 0; i < self.storeDefinition.extendedAttributes.length; i++) {
        if (self.storeDefinition.extendedAttributes[i].valid === false) {
          return true;
        }
      }
      return false;
    },
    selectEntity (entity) {
      let self = this;
      if (
        !self.storeDefinition.businessEntities.filter(function (e) {
          return e.id === entity.id;
        }).length > 0
      ) {
        self.storeDefinition.businessEntities = [];
        self.storeDefinition.businessEntities.push(entity);
        self.storeDefinition.businessEntityId = entity.id;
      } else {
        self.storeDefinition.businessEntities = [];
        self.storeDefinition.businessEntityId = 0;
      }

      self.$store.commit(
        'storeDefinitionModule/setStoreDefinition',
        self.storeDefinition
      );

      self.$store.commit(
        'storeDefinitionModule/setBusinessEntityNode',
        self.businessEntityNode
      );
    },
    deleteEntity () {
      this.storeDefinition.businessEntities = [];
    },
    openDialog () {
      if (!this.editing && !this.viewing) {
        this.businessEntityDialog = true;
        this.tempBusinessEntities = this.storeDefinition.businessEntities;
        this.getBusinessEntityNode();
      }
    },
    getBusinessEntityNode () {
      let self = this;
      self.$store
        .dispatch('storeDefinitionModule/getBusinessEntitiesAlreadyAssigned')
        .then(() => {
          self.$store.dispatch('storeDefinitionModule/getBusinessEntityNode');
        });
    },
    attachBusEvents () {
      let self = this;
      self.bus.$on('entity-selected', entity => {
        self.selectEntity(entity);
      });
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          createTitleText: 'CREATE STORE DEFINITION',
          editTitleText: 'STORE  DEFINITION',
          cloneTitleText: 'CLONE STORE DEFINITION',
          close: 'CLOSE',
          createFormTitleText: 'NEW STORE DEFINITION',
          editFormTitleText: 'EDIT STORE DEFINITION DETAILS',
          viewFormTitleText: 'STORE DEFINITION DETAILS',
          formInfoText:
            'Basic details, store attributes, and program entity mapping are defined here.',
          infoHeader: 'Info',
          infoBody:
            'A store definition is required for every program entity that will be sending store data.',
          basicDetails: 'Basic details',
          nameLabel: 'Store Set Name',
          descriptionLabel: 'Store Set Description',
          errorAlertHeader: 'Error',
          errorAlertBody:
            'An error occurred and unable to save the new store. Please try again.',
          cancel: 'Cancel',
          saveStore: 'SAVE & CONTINUE',
          cancelDialogTitle: 'Save Store Definition?',
          cancelDialogBody: 'Do you wish to save the store definition?',
          no: 'No',
          yes: 'Yes',
          nameAlreadyExists:
            'Store name already exists. Please enter a unique store name.',
          error: 'Error',
          ok: 'OK',
          saveChangesTitle: 'Save Store Definition Changes?',
          saveChangesBody: 'Do you wish to save the store definition changes?',
          storeSetNameIsRequired: 'Store Set Name is required.',
          storeSetNameLengthExceeded:
            'Store Set Name cannot contain more than 50 characters.',
          storeSetNameAlreadyExists:
            'Store Set Name already exists. Please enter a unique Store Set Name.',
          storeSetDescriptionLengthExceeded:
            'Store Set Description cannot contain more than 500 characters.',
          progHierarchyText: 'Program Hierarchy',
          clickHereSelectText: 'Click Here to Select',
          done: 'Done',
          selectProgramEntity:
            'Please select a Program Entity that this store definition should be mapped to:',
          programEntity: 'PROGRAM ENTITY',
          noProgramEntity: 'No Program Entity Selected',
          selectedProgramEntity: 'Selected Program Entity',
          alreadyAssignedProgramEntityMessage:
            'This Program Entity has already been assigned to another store definition and cannot be selected anymore.',
          programEntityRequired: 'Program Entity is required.',
          programEntityAlreadyAssigned:
            'The program entity you selected is already mapped to another store definition. Please select another program entity.',
          storeAttributes: 'Store Attributes',
          programEntityMapping: 'Program Entity Mapping',
          errorDialogTitle: 'Unable to Save',
          errorDialogAlertBody:
            'An error occurred and unable to save store definition. Please try again.',
          errorAttributesPending:
            'There are changes in the Store Attributes that haven’t been saved.',
          successAlertHeader: 'Success',
          alertCreateBody:
            'The new store definition #STOREDEFNAME# has been created.',
          alertEditBody:
            'Changes to the store definition #STOREDEFNAME# have been saved.',
          storedefs: 'GOTO STORE DEFINITIONS',
          clickHere: 'Click Here',
          subTitle: 'Add new Store Definition?',
          addQuestion: 'Would you like to create/add a new store definition? '
        }
      },
      ja: {
        message: {
          createTitleText: '店舗情報定義 登録',
          editTitleText: '店舗情報定義 更新',
          cloneTitleText: '店舗情報定義 コピー',
          close: '閉じる',
          createFormTitleText: '店舗情報定義 登録',
          editFormTitleText: '店舗情報定義 編集',
          viewFormTitleText: '店舗情報定義 参照',
          formInfoText:
            '基本情報、店舗項目、および紐づけるプログラムエンティティを設定してください',
          infoHeader: 'インフォメーション',
          infoBody:
            '店舗データを利用するプログラムエンティティには、少なくとも1つの店舗情報定義を紐づける必要があります。',
          basicDetails: '基本情報',
          nameLabel: '店舗情報定義名',
          descriptionLabel: '店舗情報定義概要',
          errorAlertHeader: 'エラー',
          errorAlertBody:
            'エラーが発生したため、店舗情報定義の保存に失敗しました。もう一度お試しください。',
          cancel: 'キャンセル',
          saveStore: '保存して続ける',
          cancelDialogTitle: '店舗情報定義を保存しますか？',
          cancelDialogBody: '編集中の店舗情報定義を保存しますか？',
          no: 'いいえ',
          yes: 'はい',
          nameAlreadyExists:
            '設定された名称はすでに存在します。別の値を設定してください。',
          error: 'エラー',
          ok: 'OK',
          saveChangesTitle: '店舗情報定義を保存しますか？',
          saveChangesBody: '編集中の店舗情報定義を保存します。よろしいですか？',
          storeSetNameIsRequired: '「店舗情報定義名」は必須項目です。',
          storeSetNameLengthExceeded:
            '「店舗情報定義名」は50文字以内で設定してください。',
          storeSetNameAlreadyExists:
            '設定された「店舗情報定義名」はすでに存在します。別の値を設定してください。',
          storeSetDescriptionLengthExceeded:
            '「店舗情報定義概要」は500文字以内で設定してください。',
          progHierarchyText: 'プログラム構成',
          clickHereSelectText: 'ここをクリックして選択',
          done: '確定する',
          selectProgramEntity:
            '店舗情報定義を紐づけるプログラムエンティティを選択してください:',
          programEntity: 'プログラムエンティティ',
          noProgramEntity: 'プログラムエンティティが選択されていません',
          selectedProgramEntity: '選択されたプログラムエンティティ',
          alreadyAssignedProgramEntityMessage:
            'このプログラムエンティティはすでに他の店舗情報定義と紐づけられているため、選択できません。',
          programEntityRequired: '「プログラムエンティティ」は必須項目です。',
          programEntityAlreadyAssigned:
            'このプログラムエンティティはすでに他の店舗情報定義と紐づけられているため、選択できません。',
          storeAttributes: '店舗項目',
          programEntityMapping: 'プログラムエンティティマッピング',
          errorDialogTitle: '保存に失敗しました',
          errorDialogAlertBody:
            'エラーが発生したため、店舗情報定義の保存に失敗しました。もう一度お試しください。',
          errorAttributesPending: '店舗項目定義の保存に失敗しました。',
          successAlertHeader: '更新成功',
          alertCreateBody:
            '店舗情報定義: #STOREDEFNAME# が正常に登録されました。',
          alertEditBody:
            '店舗情報定義: #STOREDEFNAME# が正常に更新されました。',
          storedefs: '店舗情報定義一覧へ',
          clickHere: 'ここをクリックしてください',
          subTitle: '店舗情報定義を追加する',
          addQuestion: '別の店舗情報定義を追加するには、'
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.col-padding {
  padding-left: 20px;
  padding-top: 20px;
}
.pdt3 {
  padding-top: 5px;
}
.chips-req-label {
  color: inherit;
  font-size: inherit !important;
}
.gray-text {
  color: gray !important;
}
</style>
