<template>
  <v-row class="d-flex flex-column" no-gutters>
    <v-col cols="12" v-for="storeDef in storeDefinitions" :key="storeDef.name">
      <brierley-grid-card>
        <template v-slot:grid-card-body>
          <v-col sm="4" xs="12">
            <v-row>
              <v-col md="12" class="bpt0 bpb0">
                <v-card-title :title="storeDef.name" class="elipsis-fullwidth">
                  {{ storeDef.name }}
                </v-card-title>
              </v-col>
            </v-row>
          </v-col>
          <v-col sm="5" xs="12">
            <v-row no-gutters>
              <v-col sm="11">
                <p>
                  <strong>
                    {{
                      storeDef.businessEntity !== null
                        ? storeDef.businessEntity.name +
                          " " +
                          $t("message.descriptionText")
                        : $t("message.descriptionText")
                    }}
                  </strong>
                </p>
                <p class="text-left" :title="storeDef.description">
                  {{
                    storeDef.description.length > 80
                      ? storeDef.description.substr(0, 80) + "..."
                      : storeDef.description
                  }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col sm="3" xs="12">
            <v-row no-gutters>
              <v-col sm="12">
                <p>
                  <strong>{{ $t("message.programEntityText") }}</strong>
                </p>
                <p class="elipsis-twoline">
                  {{
                    storeDef.businessEntity !== null
                      ? storeDef.businessEntity.name
                      : ""
                  }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col>
            <brierley-controls
              :actions="getActions(storeDef)"
              :language="language"
            >
            </brierley-controls>
          </v-col>
        </template>
      </brierley-grid-card>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyGridCard } from '@brierley/SharedComponents';
import BrierleyControls from '../../../../SharedComponents/BrierleyControls';
import { mapState } from 'vuex';

export default {
  components: {
    BrierleyControls,
    BrierleyGridCard
  },
  props: {
    actions: {
      type: Array
    },
    language: {
      type: String,
      default: () => 'en'
    }
  },
  data () {
    return {
      isHidden: false
    };
  },
  computed: {
    ...mapState({
      storeDefinitions: state => state.storeDefinitionModule.storeDefinitions
    })
  },
  mounted: function () {
    window.scrollTo(0, 0);
  },
  methods: {
    getActions (storeDefObj) {
      let self = this;
      return self.actions.map(it => {
        switch (it.referenceId) {
        case 1000:
          return {
            ...it,
            ...{
              click: {
                name: 'viewStoreDefinition',
                params: { id: storeDefObj.storeDefinitionId }
              }
            }
          };
        case 1001:
          return {
            ...it,
            ...{
              click: {
                name: 'editStoreDefinition',
                params: { id: storeDefObj.storeDefinitionId }
              }
            }
          };
        case 1002:
          return {
            ...it,
            ...{
              click: {
                name: 'cloneStoreDefinition',
                params: { id: storeDefObj.storeDefinitionId }
              }
            }
          };
        }
        return it;
      });
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          programEntityText: 'Program Entity:',
          descriptionText: 'Store Set Description:',
          viewText: 'View',
          editText: 'Edit',
          cloneText: 'Clone',
          deleteText: 'Delete'
        }
      },
      ja: {
        message: {
          programEntityText: 'プログラムエンティティ: ',
          descriptionText: '店舗定義情報概要: ',
          viewText: '詳細を見る',
          editText: '編集',
          cloneText: 'コピー',
          deleteText: '削除'
        }
      }
    }
  }
};
</script>

<style scoped>
.text-left {
  text-align: left !important;
}
</style>
