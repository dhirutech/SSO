<template>
  <brierley-table-module v-if="orderedStoreDefinitions.length > 0">
    <template v-slot:tablehead>
      <tr class="text-left">
        <th
          v-for="item in header"
          :key="item.name"
          @click="
            item.name == 'name' || item.name == 'programEntity'
              ? sortBy(item)
              : null
          "
          class="text-left"
          :width="item.width"
        >
          <span class="fbold">{{ item.text }}</span>
          <v-icon
            v-if="item.sort != ''"
            small
            v-bind:class="{
              down: item.sort === 'asc',
              up: item.sort === 'desc'
            }"
            class="arrow uparw"
            >arrow_upward</v-icon
          >
        </th>
      </tr>
    </template>
    <template v-slot:tablebody>
      <tr v-for="storeDef in orderedStoreDefinitions" :key="storeDef.name">
        <td class="row-store-def-font row-store-def-valign">
          <v-row class="d-flex head-name" :title="storeDef.name" no-gutters>
            <v-col class="text-format"
              >{{
                storeDef.name.length > 22
                  ? storeDef.name.substr(0, 22) + "..."
                  : storeDef.name
              }}
            </v-col>
          </v-row>
        </td>
        <td>
          <p :title="storeDef.description" class="text-left">
            {{
              storeDef.description.length > 80
                ? storeDef.description.substr(0, 80) + "..."
                : storeDef.description
            }}
          </p>
        </td>
        <td>
          <div :title="storeDef.programEntityId" class="text-justify">
            {{
              storeDef.businessEntity !== null
                ? storeDef.businessEntity.name
                : ""
            }}
          </div>
          <v-row class="d-flex d-inline-flex hover-actions-2" no-gutters>
            <v-col>
              <brierley-controls
                :actions="getActions(storeDef)"
                :language="language"
              >
              </brierley-controls>
            </v-col>
          </v-row>
        </td>
      </tr>
    </template>
  </brierley-table-module>
</template>

<script>
import { BrierleyTableModule } from '@brierley/SharedComponents';
import BrierleyControls from '../../../../SharedComponents/BrierleyControls';
import { mapState } from 'vuex';

export default {
  components: {
    BrierleyControls,
    BrierleyTableModule
  },
  props: {
    actions: {
      type: Array
    },
    language: {
      type: String,
      default: () => 'en'
    }
  },
  data () {
    return {
      isHidden: false,
      isToggled: false,
      header: [
        {
          name: 'name',
          text: this.$t('message.nameText'),
          sort: 'asc',
          width: '180'
        },
        {
          name: 'description',
          text: this.$t('message.descriptionText'),
          sort: '',
          width: '256'
        },
        {
          name: 'programEntity',
          text: this.$t('message.programEntityText'),
          sort: '',
          width: '180'
        }
      ]
    };
  },
  computed: {
    ...mapState({
      orderedStoreDefinitions: state =>
        state.storeDefinitionModule.storeDefinitions,
      searchRequest: state => state.storeDefinitionModule.searchRequest,
      sortObj: state => state.storeDefinitionModule.sortObj
    })
  },
  mounted: function () {
    window.scrollTo(0, 0);
  },
  methods: {
    getActions (storeDefObj) {
      let self = this;
      return self.actions.map(it => {
        switch (it.referenceId) {
        case 1000:
          return {
            ...it,
            ...{
              click: {
                name: 'viewStoreDefinition',
                params: { id: storeDefObj.storeDefinitionId }
              }
            }
          };
        case 1001:
          return {
            ...it,
            ...{
              click: {
                name: 'editStoreDefinition',
                params: { id: storeDefObj.storeDefinitionId }
              }
            }
          };
        case 1002:
          return {
            ...it,
            ...{
              click: {
                name: 'cloneStoreDefinition',
                params: { id: storeDefObj.storeDefinitionId }
              }
            }
          };
        }
        return it;
      });
    },
    sortBy: function (item) {
      let i = this.header.indexOf(item);
      for (let j = 0; j < this.header.length; j++) {
        if (j === i) {
          this.header[j].sort =
            this.header[j].sort === '' || this.header[j].sort === 'desc'
              ? 'asc'
              : 'desc';
        } else {
          this.header[j].sort = '';
        }
      }
      this.sortKey = this.header[i].name;
      this.sortOrder = this.header[i].sort;
      this.arrowToggle();
      let newSortObj = {
        SortBy: this.header[i].name,
        isDesc: this.header[i].sort === 'desc' ? true : false
      };
      this.$store.dispatch('storeDefinitionModule/setSortObj', newSortObj);
      let searchPaginationData = { PageNumber: 1 };
      let requestForLazyLoading = {
        ...this.searchRequest,
        ...searchPaginationData,
        ...newSortObj
      };
      this.$store.dispatch(
        'storeDefinitionModule/getStoreDefinitions',
        requestForLazyLoading
      );
    },
    arrowToggle () {
      this.isToggled = !this.isToggled;
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          nameText: 'Store Set Name',
          programEntityText: 'Program Entity',
          descriptionText: 'Store Set Description',
          viewText: 'View',
          editText: 'Edit',
          cloneText: 'Clone',
          deleteText: 'Delete'
        }
      },
      ja: {
        message: {
          nameText: '店舗情報定義名',
          programEntityText: 'プログラムエンティティ',
          descriptionText: '店舗情報定義概要',
          viewText: '詳細を見る',
          editText: '編集',
          cloneText: 'コピー',
          deleteText: '削除'
        }
      }
    }
  }
};
</script>

<style scoped>
td.row-store-def-font {
  align-self: center !important;
  width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
td.row-store-def-font:before {
  align-self: center !important;
  width: 100%;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}
td.row-store-def-font:after {
  align-self: center !important;
  width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
td.row-store-def-valign {
  vertical-align: middle !important;
}
div.text-format {
  font-weight: bold;
  font-size: 18;
  text-transform: uppercase;
  letter-spacing: normal;
}
div.text-format:before {
  font-weight: bold;
  font-size: 18;
  text-transform: uppercase;
  letter-spacing: normal;
}
div.text-format:after {
  font-weight: bold;
  font-size: 18;
  text-transform: uppercase;
  letter-spacing: normal;
}
.text-left {
  text-align: left !important;
}
</style>
