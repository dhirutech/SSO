<template>
  <brierley-inner-view :footerOnly="false">
    <template v-slot:header>
      <span class="inner-head bpl1" style="position:relative; right:5px">{{
        $t("message.headerText")
      }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>{{ $t("message.headerCloseText") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row class="d-flex flex-column bpt5" no-gutters>
        <v-col>
          <brierley-form-title
            :formTitle="$t('message.formTitleText')"
            :infoText="$t('message.formInfoText')"
          />
        </v-col>
      </v-row>
      <v-row class="d-flex gen2-search-filter bpt2" no-gutters>
        <v-col class="text-left" cols="6">
          <v-row class="d-flex grid-search" no-gutters>
            <v-col class="bpr2">
              <h3>{{ $t("message.formSubTitleText") }}</h3>
            </v-col>
          </v-row>
        </v-col>
        <v-col cols="6" class="text-right align-self-center">
          <div class="bmr1 d-inline-block">
            <brierley-view-option
              :viewList="cardlist"
              @viewChanged="changeView($event)"
            />
          </div>
          <brierley-icon-with-head
            @click.native="$router.push('/loyaltyadmin/storedefinition/create')"
            :iconTitle="$t('message.createNewIconText')"
            :iconName="'add_circle'"
          ></brierley-icon-with-head>
        </v-col>
      </v-row>
      <v-row v-if="storeDefinitions.length == 0" no-gutters>
        <brierley-no-result></brierley-no-result>
      </v-row>
      <store-definition-card-view
        v-if="viewType == 'card_view'"
        :actions="actions[language]"
        :language="language"
      />
      <store-definition-grid-view
        v-if="viewType == 'grid_view'"
        :actions="actions[language]"
        :language="language"
      />
      <store-definition-table-view
        v-if="viewType == 'table_view'"
        :actions="actions[language]"
        :language="language"
      />
      <v-col align="center" justify="center" class="bpt6 bmb3">
        <v-row
          v-if="scrollInProgress"
          class="d-flex d-inline-flex flex-column load-more-listing text-center"
          no-gutters
        >
          <v-col class="bpa2">
            <v-progress-circular
              :width="3"
              indeterminate
              color="brown"
            ></v-progress-circular>
          </v-col>
          <v-col>{{ $t("message.loadingText") }}</v-col>
        </v-row>
      </v-col>
    </template>
    <template v-slot:footer>
      <v-btn
        text
        class="primaryctabtn no-ripple"
        @click.native="$router.push('/gettingstarted')"
        >{{ $t("message.closeText") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>

<script>
import {
  BrierleyFormTitle,
  BrierleyInnerView,
  BrierleyIconWithHead,
  BrierleyViewOption,
  BrierleyNoResult
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import StoreDefinitionCardView from './children/StoreDefinitionCardView';
import StoreDefinitionGridView from './children/StoreDefinitionGridView';
import StoreDefinitionTableView from './children/StoreDefinitionTableView';
export default {
  components: {
    BrierleyFormTitle,
    StoreDefinitionCardView,
    StoreDefinitionGridView,
    StoreDefinitionTableView,
    BrierleyInnerView,
    BrierleyIconWithHead,
    BrierleyViewOption,
    BrierleyNoResult
  },
  data () {
    return {
      isHidden: false,
      scrollInProgress: false,
      error: false,
      totalPages: 0,
      errorDialog: false,
      alertMessage: '',
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('message.gridView')
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('message.tableView')
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('message.cardView')
        }
      ],
      language: {
        type: String,
        default: () => 'en'
      },
      actions: {
        en: [
          {
            id: 1000,
            name: 'View',
            value: 'view details',
            referenceId: 1000,
            icon: 'fe-eye',
            disable: false
          },
          {
            id: 1001,
            name: 'Edit',
            value: 'edit',
            referenceId: 1001,
            icon: 'fe-edit',
            disable: false
          },
          {
            id: 1002,
            name: 'Clone',
            value: 'clone',
            referenceId: 1002,
            icon: 'fe-copy',
            disable: false
          }
        ],
        ja: [
          {
            id: 1010,
            name: 'View',
            value: '詳細',
            referenceId: 1000,
            icon: 'fe-eye',
            disable: false
          },
          {
            id: 1011,
            name: 'Edit',
            value: '編集',
            referenceId: 1001,
            icon: 'fe-edit',
            disable: false
          },
          {
            id: 1012,
            name: 'Clone',
            value: 'コピー',
            referenceId: 1002,
            icon: 'fe-copy',
            disable: false
          }
        ]
      },
      fromDateDialog: false,
      toDateDialog: false
    };
  },
  computed: {
    ...mapState({
      storeDefinitions: state => state.storeDefinitionModule.storeDefinitions,
      storeDefinitionsCount: state =>
        state.storeDefinitionModule.storeDefinitionsCount,
      viewType: state => state.storeDefinitionModule.currentView,
      sortObj: state => state.storeDefinitionModule.sortObj,
      searchRequest: state => state.storeDefinitionModule.searchRequest
    })
  },
  created () {
    this.language = this.getLanguage();
  },
  mounted () {
    this.language = this.getLanguage();
    let self = this;
    let newSortObj = {};
    if (!self.sortObj) {
      let newSortObj = {
        SortBy: 'CreatedDate',
        isDesc: true
      };
      this.$store.dispatch('storeDefinitionModule/setSortObj', newSortObj);
    } else {
      newSortObj = this.sortObj;
    }
    let newSearchRequest = {
      PageNumber: 1,
      PageSize: 10
    };
    this.$store.dispatch(
      'storeDefinitionModule/setSearchRequest',
      newSearchRequest
    );
    let requestForLazyLoading = {
      ...newSearchRequest,
      ...newSortObj
    };
    this.$store.dispatch(
      'storeDefinitionModule/getStoreDefinitions',
      requestForLazyLoading
    );

    window.addEventListener('scroll', this.onScroll);
  },
  beforeDestroy () {
    window.removeEventListener('scroll', this.onScroll);
  },
  watch: {
    storeDefinitions () {
      this.scrollInProgress = false;
    }
  },
  methods: {
    getLanguage () {
      // TODO: this would be part of user Account Data, once it is there this should be updated to get it from
      // there.
      let lng = localStorage.getItem('language');
      if (lng === null || lng === '') {
        return 'en';
      }
      return lng;
    },
    changeView (view) {
      let self = this;
      let newSortObj = {
        SortBy: 'CreatedDate',
        isDesc: true
      };
      this.$store.dispatch('storeDefinitionModule/setSortObj', newSortObj);
      let newSearchRequest = {
        PageNumber: 1,
        PageSize: 10
      };
      this.$store.dispatch(
        'storeDefinitionModule/setSearchRequest',
        newSearchRequest
      );
      self.$store.dispatch('storeDefinitionModule/setCurrentView', view);
      this.$store.dispatch(
        'storeDefinitionModule/getStoreDefinitions',
        newSearchRequest
      );
    },
    getDocHeight () {
      let D = document;
      return Math.max(D.body.scrollHeight, D.documentElement.scrollHeight);
    },
    onScroll () {
      let winheight =
        window.innerHeight ||
        (document.documentElement || document.body).clientHeight;
      let docheight = this.getDocHeight();
      let scrollTop =
        window.pageYOffset ||
        (document.documentElement || document.body.parentNode || document.body)
          .scrollTop;
      let trackLength = docheight - winheight;
      let pctScrolled = Math.floor(scrollTop / trackLength * 100);
      this.totalPages = Math.ceil(this.storeDefinitionsCount / 10);
      if (
        pctScrolled >= 75 &&
        this.searchRequest.PageNumber < this.totalPages &&
        !this.scrollInProgress
      ) {
        this.scrollInProgress = true;
        let newSearchRequest = {
          PageNumber: this.searchRequest.PageNumber + 1,
          PageSize: this.searchRequest.PageSize + 10
        };
        this.$store.dispatch(
          'storeDefinitionModule/setSearchRequest',
          newSearchRequest
        );
        let searchPaginationData = { PageNumber: 1 };
        let requestForLazyLoading = {
          ...this.searchRequest,
          ...searchPaginationData,
          ...this.sortObj
        };
        this.$store.dispatch(
          'storeDefinitionModule/getStoreDefinitions',
          requestForLazyLoading
        );
      }
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          headerText: 'STORE DEFINITION',
          headerCloseText: 'CLOSE',
          formTitleText: 'Store Definition(s)',
          formInfoText: 'Store Definitions can be managed on this screen.',
          formSubTitleText: 'Store Definition List',
          createNewIconText: 'Create a new Definition',
          closeText: 'Close',
          deactivateDialogTitle: 'Deactivate Store',
          deactivateDialogAlertBody:
            'Do you wish to deactivate the store #STORENAME#?',
          errorDialogTitle: 'Store cannot be deactivated',
          errorDialogAlertBody:
            'This store cannot be deactivated because it\'s already assigned to users.',
          cancel: 'Cancel',
          deactivate: 'Deactivate',
          ok: 'Ok',
          errorHandlingDialogTitle: 'Error Occurred',
          errorHandlingDialogAlertBody:
            'An unexpected error occurred while trying to deactivate the store. Please try again.',
          loadingText: 'LOAD MORE',
          gridView: 'Grid view',
          tableView: 'Table view',
          cardView: 'Card view'
        }
      },
      ja: {
        message: {
          headerText: '店舗情報定義',
          headerCloseText: '閉じる',
          formTitleText: '店舗情報定義',
          formSubTitleText: '店舗情報定義一覧',
          formInfoText: '店舗情報として管理する項目を定義します。',
          createNewIconText: '店舗情報定義登録',
          closeText: '閉じる',
          deactivateDialogTitle: '店舗情報定義 無効化',
          deactivateDialogAlertBody:
            '次の店舗情報を無効化します: #STORENAME#\nよろしいですか？',
          errorDialogTitle: '店舗情報定義の無効化に失敗しました',
          errorDialogAlertBody:
            'すでにユーザに紐づいているため、店舗定義情報を無効化できません。',
          cancel: 'キャンセル',
          deactivate: '無効化',
          ok: 'OK',
          errorHandlingDialogTitle: 'エラーが発生しました',
          errorHandlingDialogAlertBody:
            '店舗情報定義の無効化中に予期せぬエラーが発生しました。もう一度お試しください。',
          loadingText: 'ロード中',
          gridView: 'グリッドビュー',
          tableView: 'テーブルビュー',
          cardView: 'カードビュー'
        }
      }
    }
  }
};
</script>
