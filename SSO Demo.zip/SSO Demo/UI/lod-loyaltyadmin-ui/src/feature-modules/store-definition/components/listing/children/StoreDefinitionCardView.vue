<template>
  <v-row>
    <v-col
      md="6"
      sm="12"
      xs="12"
      v-for="(storeDef, index) in storeDefinitions"
      :key="index"
    >
      <brierley-card>
        <template v-slot:header>
          <h2 :title="storeDef.name" class="bmb2">
            {{
              storeDef.name.length > 29
                ? storeDef.name.substr(0, 29) + "..."
                : storeDef.name
            }}
          </h2>
        </template>
        <template v-slot:body>
          <p>
            <strong>
              {{
                storeDef.businessEntity !== null
                  ? storeDef.businessEntity.name +
                    " " +
                    $t("message.descriptionText")
                  : $t("message.descriptionText")
              }}
            </strong>
          </p>
          <p class="elipsis-twoline text-left" :title="storeDef.description">
            <span>{{ storeDef.description }}</span>
          </p>
          <br />
          <p>
            <strong>{{ $t("message.programEntityText") + ": " }}</strong>
            {{
              storeDef.businessEntity !== null
                ? storeDef.businessEntity.name
                : ""
            }}
          </p>
        </template>
        <template v-slot:footer>
          <v-col>
            <brierley-controls
              :actions="getActions(storeDef)"
              :language="language"
            >
            </brierley-controls>
          </v-col>
        </template>
      </brierley-card>
    </v-col>
  </v-row>
</template>

<script>
import { BrierleyCard } from '@brierley/SharedComponents';
import BrierleyControls from '../../../../SharedComponents/BrierleyControls';
import { mapState } from 'vuex';

export default {
  components: {
    BrierleyCard,
    BrierleyControls
  },
  props: {
    actions: {
      type: Array
    },
    language: {
      type: String,
      default: () => 'en'
    }
  },
  computed: {
    ...mapState({
      storeDefinitions: state => state.storeDefinitionModule.storeDefinitions
    })
  },
  methods: {
    getActions (storeDefObj) {
      let self = this;
      return self.actions.map(it => {
        switch (it.referenceId) {
        case 1000:
          return {
            ...it,
            ...{
              click: {
                name: 'viewStoreDefinition',
                params: { id: storeDefObj.storeDefinitionId }
              }
            }
          };
        case 1001:
          return {
            ...it,
            ...{
              click: {
                name: 'editStoreDefinition',
                params: { id: storeDefObj.storeDefinitionId }
              }
            }
          };
        case 1002:
          return {
            ...it,
            ...{
              click: {
                name: 'cloneStoreDefinition',
                params: { id: storeDefObj.storeDefinitionId }
              }
            }
          };
        }
        return it;
      });
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          programEntityText: 'Program Entity',
          descriptionText: 'Store Set Description:',
          viewText: 'View Details',
          editText: 'Edit',
          cloneText: 'Clone'
        }
      },
      ja: {
        message: {
          programEntityText: 'プログラムエンティティ',
          descriptionText: '店舗定義情報概要: ',
          viewText: '詳細を見る',
          editText: '編集',
          cloneText: 'コピー'
        }
      }
    }
  }
};
</script>

<style scoped>
.text-left {
  text-align: left !important;
}
</style>
