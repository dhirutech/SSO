const setStoreDefinition = (state, payload) => {
  state.storeDefinition = payload;
};

const setSearchRequest = (state, payload) => {
  state.searchRequest = payload;
};

const setDisabled = (bEntity, disabledEntities, storeDefinition) => {
  if (disabledEntities.includes(bEntity.id)) {
    bEntity.isDisabled = true;
    bEntity.color = 'gray';
  } else {
    bEntity.isDisabled = false;
    bEntity.color = 'black';
  }
  bEntity.programs = [];

  if (bEntity.id === storeDefinition.businessEntityId) {
    bEntity.selected = !bEntity.selected;
  } else {
    bEntity.selected = false;
  }

  if (bEntity.children && bEntity.children.length > 0) {
    for (let i = 0; i < bEntity.children.length; i++) {
      setDisabled(bEntity.children[i], disabledEntities, storeDefinition);
    }
  }
  return bEntity;
};

const setBusinessEntityNode = (state, payload) => {
  state.businessEntityNode = setDisabled(
    payload,
    state.businessEntitiesAlreadyAssigned,
    state.storeDefinition
  );
};

const setBusinessEntitiesAlreadyAssigned = (state, payload) => {
  state.businessEntitiesAlreadyAssigned = payload;
};

const setStoreDefinitions = (state, payload) => {
  state.storeDefinitions = payload.storeDefinitions;
  state.storeDefinitionsCount = payload.totalCount;
};

const setCurrentView = (state, payload) => {
  state.currentView = payload;
};

const setSortObj = (state, payload) => {
  state.sortObj = payload;
};

const setCoreAttributes = (state, payload) => {
  state.coreAttributes = payload;
};

const addExtendedAttribute = (state, payload) => {
  state.storeDefinition.extendedAttributes.push(payload);
};

export default {
  setStoreDefinition,
  setStoreDefinitions,
  setCurrentView,
  setBusinessEntityNode,
  setBusinessEntitiesAlreadyAssigned,
  setSortObj,
  setSearchRequest,
  setCoreAttributes,
  addExtendedAttribute
};
