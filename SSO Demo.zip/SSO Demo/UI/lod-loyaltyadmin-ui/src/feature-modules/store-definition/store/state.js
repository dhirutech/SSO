export default {
  storeDefinition: {
    storeDefinitionId: 0,
    name: '',
    description: '',
    businessEntityId: 0,
    businessEntities: [],
    extendedAttributes: []
  },
  storeDefinitions: [],
  storeDefinitionsCount: 0,
  currentView: 'grid_view',
  businessEntityNode: {},
  businessEntitiesAlreadyAssigned: [],
  sortObj: {
    SortBy: 'CreatedDate',
    isDesc: true
  },
  searchRequest: {
    PageNumber: 1,
    PageSize: 10
  },
  coreAttributes: []
};
