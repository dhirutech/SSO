import * as api from '../api/store-definition-api.js';

// eslint-disable-next-line
const storeDefinitionExists = async ({ commit }, storeSetName) => {
  return await api.storeDefinitionExistsAsync(storeSetName);
};

const getBusinessEntityNode = async ({ commit }) => {
  let response = await api.getBusinessEntityNodeAsync();
  commit('setBusinessEntityNode', response);
};

const setStoreDefinition = ({ commit }, value) => {
  commit('setStoreDefinition', value);
};

const setSearchRequest = ({ commit }, value) => {
  commit('setSearchRequest', value);
};

const getBusinessEntitiesAlreadyAssigned = async ({ commit }) => {
  let response = await api.getBusinessEntitiesAlreadyAssigned();
  commit('setBusinessEntitiesAlreadyAssigned', response);
};

// eslint-disable-next-line
const postStoreDefinition = async ({ commit }, storeDefinition) => {
  return await api.postStoreDefinitionAsync(storeDefinition);
};

const getStoreDefinitions = async ({ commit }, request) => {
  let response = await api.getStoreDefinitionsAsync(request);
  commit('setStoreDefinitions', response);
};

const setCurrentView = ({ commit }, value) => {
  commit('setCurrentView', value);
};

const setSortObj = ({ commit }, value) => {
  commit('setSortObj', value);
};

const getStoreDefinition = async ({ commit }, id) => {
  let response = await api.getStoreDefinitionAsync(id);
  commit('setStoreDefinition', response);
  return response;
};

// eslint-disable-next-line
const putStoreDefinition = async ({ commit }, req) => {
  return await api.putStoreDefinitionAsync(req);
};

const getCoreAttributes = async ({ commit }) => {
  let response = await api.getCoreAttributesAsync();
  commit('setCoreAttributes', response);
};

// eslint-disable-next-line
const patchBusinessEntity = async ({ commit }, id, storeDefinitionId) => {
  return await api.patchBusinessEntityAsync(id, storeDefinitionId);
};

export default {
  storeDefinitionExists,
  setStoreDefinition,
  getStoreDefinitions,
  setCurrentView,
  getBusinessEntityNode,
  getBusinessEntitiesAlreadyAssigned,
  postStoreDefinition,
  setSortObj,
  setSearchRequest,
  getStoreDefinition,
  putStoreDefinition,
  getCoreAttributes,
  patchBusinessEntity
};
