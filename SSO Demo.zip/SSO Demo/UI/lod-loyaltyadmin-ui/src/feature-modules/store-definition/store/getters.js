const storeDefinition = (state) => state.storeDefinition;
const businessEntityNode = (state) => state.businessEntityNode;
const businessEntitiesAlreadyAssigned = (state) =>
  state.businessEntitiesAlreadyAssigned;
const getStoreDefinitions = (state) => state.storeDefinitions;
const getCurrentView = (state) => state.currentView;
const sortObj = (state) => state.sortObj;
const searchRequest = (state) => state.searchRequest;
const coreAttributes = (state) => state.coreAttributes;
const extensionAttributes = (state) => state.extensionAttributes;

export default {
  storeDefinition,
  getStoreDefinitions,
  getCurrentView,
  businessEntityNode,
  businessEntitiesAlreadyAssigned,
  sortObj,
  searchRequest,
  coreAttributes,
  extensionAttributes
};
