<template>
  <brierley-inner-view>
    <template
      v-slot:header
      v-if="$route.path.includes('/loyaltyadmin/CommunicationsManagementEdit')"
    >
      <span class="inner-head">{{ $t("communicationEditMessage") }}</span>
    </template>
    <template v-slot:header v-else>
      <span class="inner-head">{{ $t("communicationMessage") }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>{{ $t("close") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <brierley-primary-stepper
        :currentStep="communicationCurrentStep"
        :stepperSize="6"
        class="mt-1"
      >
        <template v-slot:stepper-steps>
          <v-stepper-step step="1">{{ $t("basicInfoStepper") }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="2">{{
            $t("deliveryChannelStepper")
          }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="3">{{ $t("selectMsgStepper") }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="4">{{
            $t("personalizationStepper")
          }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="5">{{ $t("reviewStepper") }}</v-stepper-step>
        </template>
        <template slot="stepper-content">
          <Validation-Observer>
            <form id="user_form">
              <v-stepper-items>
                <v-stepper-content step="1">
                  <Validation-Observer v-slot="{ handleSubmit }">
                    <form
                      id="basic_form"
                      @submit.prevent="handleSubmit(onsubmit)"
                    >
                      <basic-info />
                    </form>
                  </Validation-Observer>
                </v-stepper-content>
                <v-stepper-content step="2">
                  <delivery-channel />
                </v-stepper-content>
                <v-stepper-content step="3">
                  <provider-layout v-on:selectedMsgId="selectedMsgId" />
                </v-stepper-content>
                <v-stepper-content step="4">
                  <personalization
                    :selectedMessage="selectedMessage"
                    v-on:ReviewButtonEnable="ReviewButtonEnable"
                  />
                </v-stepper-content>
                <v-stepper-content step="5">
                  <review-layout />
                </v-stepper-content>
                <v-stepper-content step="6">
                  <template v-if="communicationCurrentStep === 6">
                    <v-row class="flex-column bmt4" no-gutters>
                      <v-col>
                        <brierley-form-title
                          :formTitle="$t('successFormTitle')"
                          :infoText="$t('successInfoText')"
                        ></brierley-form-title>
                      </v-col>
                      <v-col class="bpt5">
                        <brierley-alert
                          :isSiteLevel="true"
                          alertType="success"
                          :alertBody="$t('alertBodyText')"
                          :alertHeader="$t('successAlertHeader')"
                          icon="done"
                        ></brierley-alert>
                      </v-col>
                    </v-row>
                  </template>
                </v-stepper-content>
                <cancel-pop-up v-if="showPopUpDialogue" />
              </v-stepper-items>
            </form>
          </Validation-Observer>
        </template>
      </brierley-primary-stepper>
    </template>
    <template
      v-slot:footer-previous
      v-if="communicationCurrentStep > 1 && communicationCurrentStep < 6"
    >
      <v-btn
        id="user_btn_previous"
        @click="onPreviousClick()"
        text
        class="mr-5 cancel no-ripple"
      >
        <v-icon class="bpr1">arrow_back</v-icon>{{ $t("previousBtn") }}
      </v-btn>
    </template>
    <template v-slot:footer>
      <v-btn
        id="user_btn_cancel"
        v-if="communicationCurrentStep < 6"
        @click="cancelOpenPopUp()"
        text
        class="cancel no-ripple bmt2 bmr5"
        >{{ $t("cancelBtnText") }}</v-btn
      >
      <v-btn
        v-if="communicationCurrentStep == 1"
        form="basic_form"
        type="submit"
        class="primaryctabtn bmt2 bml2"
        >{{ $t("nextDeliveryChannelBtnText") }}</v-btn
      >
      <v-btn
        id="user_btn_preview"
        v-else-if="communicationCurrentStep == 2"
        @click="onSaveDeliveryChannel()"
        class="primaryctabtn bmt2"
        >{{ $t("nextSelectTemplateBtnText") }}</v-btn
      >
      <v-btn
        id="user_btn_saveUser"
        v-else-if="communicationCurrentStep == 3"
        class="primaryctabtn bmt2"
        :disabled="personalizationBtnStatus"
        @click="onSaveDeliveryChannel()"
        >{{ $t("personalizationBtn") }}</v-btn
      >
      <v-btn
        id="user_btn_saveUser"
        v-if="!goToCommMsgBtn"
        class="primaryctabtn bmt2"
        @click="goToListPage()"
        >{{ $t("goToCommTxt") }}</v-btn
      >
      <v-btn
        id="user_btn_saveUser"
        v-else-if="communicationCurrentStep == 4"
        @click="onSaveDeliveryChannel()"
        class="primaryctabtn bmt2"
        :disabled="disableReviewButton"
        >{{ $t("reviewAndSaveBtn") }}</v-btn
      >
      <v-btn
        id="user_btn_saveUser"
        v-else-if="communicationCurrentStep == 5"
        @click="onSaveDeliveryChannel()"
        class="primaryctabtn bmt2"
        >{{ $t("publishBtn") }}</v-btn
      >
    </template>
    <template v-slot:footer-redirect v-if="communicationCurrentStep === 6">
      <v-btn
        id="user_btn_goToUsers"
        class="primaryctabtn bmt2"
        @click="gotoInitialPage()"
        >{{ $t("goToCommBtn") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyInnerView,
  BrierleyPrimaryStepper,
  BrierleyFormTitle,
  brierleyAlert
} from '@brierley/SharedComponents';
import BasicInfo from './child/basicInfo.vue';
import DeliveryChannel from './child/deliveryChannel.vue';
import cancelPopUp from './child/cancelPopUp.vue';
import ProviderLayout from './child/providerLayout.vue';
import Personalization from './child/personalization.vue';
import ReviewLayout from './child/reviewLayout.vue';
import { mapState } from 'vuex';
import { communicationManagementStepper } from '../../../i18n/language.js';
export default {
  components: {
    BrierleyInnerView,
    BrierleyPrimaryStepper,
    BrierleyFormTitle,
    brierleyAlert,
    cancelPopUp,
    BasicInfo,
    DeliveryChannel,
    ProviderLayout,
    Personalization,
    ReviewLayout
  },
  data () {
    return {
      selectedMessage: null,
      disabled: true,
      statusValue: 0,
      disableReviewButton: true,
      selectedTemplateId: '',
      commonMessageId: 0,
      messagePersonalizations: [],
      gridView: 'grid_view',
      templateArr: []
    };
  },
  i18n: communicationManagementStepper,
  computed: {
    ...mapState('communicationManagementModule', {
      localSelectMsg: state => {
        return state.localSelectMsgRes;
      }
    }),
    ...mapState('communicationManagementModule', {
      personalizationBtnStatus: state => {
        return state.personalizationBtnStatus;
      }
    }),
    ...mapState('communicationManagementModule', {
      goToCommMsgBtn: state => {
        return state.goToCommMsgBtn;
      }
    }),
    ...mapState('communicationManagementModule', {
      templateIdEdit: state => {
        return state.templateIdEdit;
      }
    }),
    ...mapState('communicationManagementModule', {
      showPopUpDialogue: state => {
        return state.showPopUpDialogue;
      }
    }),
    ...mapState('communicationManagementModule', {
      communicationCurrentStep: state => {
        return state.communicationCurrentStep;
      }
    }),
    ...mapState('communicationManagementModule', {
      communicationDetails: state => {
        return state.communicationDetails;
      }
    }),
    ...mapState('communicationManagementModule', {
      selectedProgramId: state => {
        return state.selectedProgramId;
      }
    }),
    ...mapState('communicationManagementModule', {
      deliveryChannelData: state => {
        return state.deliveryChannelData;
      }
    }),
    ...mapState('communicationManagementModule', {
      providerData: state => {
        return state.providerData;
      }
    }),
    ...mapState('communicationManagementModule', {
      commonMessageIdRes: state => {
        return state.commonMessageId;
      }
    }),
    ...mapState('communicationManagementModule', {
      selectedMsg: state => {
        return state.selectedMsg;
      }
    }),
    ...mapState('communicationManagementModule', {
      memberAttributeList: state => {
        return state.memberAttributeList;
      }
    }),
    ...mapState('communicationManagementModule', {
      commonMessageSuccessResponse: state => {
        return state.commonMessageSuccessResponse;
      }
    }),
    ...mapState('communicationManagementModule', {
      communicationMsgTemplates: state => {
        return state.communicationMsgList;
      }
    }),
    ...mapState('communicationManagementModule', {
      getMessageAttributeRes: state => {
        return state.getMessageAttributeRes;
      }
    }),
    ...mapState('communicationManagementModule', {
      communicationsProviderMessageFieldsList: state => {
        return state.communicationsProviderMessageFieldsList;
      }
    }),
    ...mapState('communicationManagementModule', {
      selectedMessage: state => {
        return state.selectedMessage;
      }
    }),
    ...mapState('communicationManagementModule', {
      personalisation: state => {
        return state.personalisation;
      }
    })
  },
  methods: {
    onsubmit () {
      this.$store.commit(
        'communicationManagementModule/setCommunicationCurrentStep',
        this.communicationCurrentStep += 1
      );
    },
    gotoInitialPage () {
      this.$router.push('/loyaltyadmin/communications');
    },
    cancelOpenPopUp () {
      this.$store.commit(
        'communicationManagementModule/showPopUpDialogueMutation',
        true
      );
    },
    onPreviousClick () {
      this.$store.commit(
        'communicationManagementModule/setCommunicationCurrentStep',
        this.communicationCurrentStep -= 1
      );
    },
    onSaveDeliveryChannel () {
      if (this.communicationCurrentStep === 4) {
        this.testMessageArr = [];
        let display;
        for (let i = 0; i < this.memberAttributeList.length; i++) {
          for (let j = 0; j < this.getMessageAttributeRes.length; j++) {
            if (
              this.getMessageAttributeRes[j].personalizationAttributeId ===
              this.memberAttributeList[i].personalizationAttributeId
            ) {
              display = this.getMessageAttributeRes[j].displayName;
              this.testMessageArr[i] = {
                name: this.communicationsProviderMessageFieldsList[i],
                displayName: display
              };
            } else {
              display = '';
            }
          }
        }
      }
      if (
        this.communicationCurrentStep > 2 ||
        this.commonMessageIdRes && this.selectedMsg.id
      ) {
        this.commonMessageId = this.commonMessageIdRes;
        this.selectedTemplateId = this.selectedMsg.id;
        if (
          this.commonMessageSuccessResponse &&
          this.commonMessageSuccessResponse.templateId !== ''
        ) {
          if (
            this.selectedTemplateId.toString() ===
            this.commonMessageSuccessResponse.templateId
          ) {
            if (
              this.commonMessageSuccessResponse.messagePersonalizations !== null
            ) {
              this.memberAttributeList.filter(res => {
                this.commonMessageSuccessResponse.messagePersonalizations.forEach(
                  val => {
                    if (
                      res.personalizationElement === val.personalizationElement
                    ) {
                      res.messagePersonalizationId =
                        val.messagePersonalizationId;
                    }
                  }
                );
              });
              this.messagePersonalizations = this.memberAttributeList;
            } else {
              if (this.memberAttributeList.length > 0)
                this.messagePersonalizations = this.memberAttributeList;
            }
          }
        }
      }
      if (this.commonMessageIdRes) {
        this.commonMessageId = this.commonMessageIdRes;
      }
      if (this.communicationCurrentStep === 5) {
        this.statusValue = 1;
      }
      if (this.localSelectMsg && this.communicationCurrentStep === 3) {
        this.messagePersonalizations = [];
        this.$store.commit(
          'communicationManagementModule/localSelectMsg',
          false
        );
      }
      let saveDeliveryChannel = {
        commMessageId: this.commonMessageId,
        programId: this.selectedProgramId,
        commChannelId: this.communicationDetails.deliveryChannelType,
        name: this.communicationDetails.communicationName,
        description: this.communicationDetails.communicationDescription,
        templateId: this.selectedTemplateId,
        status: this.statusValue,
        messagePersonalizations: this.messagePersonalizations
      };
      if (this.messagePersonalizations.length === 0) {
        this.$store.commit(
          'communicationManagementModule/localSelectMsg',
          true
        );
      }
      if (saveDeliveryChannel.templateId) {
        this.templateArr = this.communicationMsgTemplates.filter(
          x => x.id === saveDeliveryChannel.templateId
        );
        this.$store.dispatch(
          'communicationManagementModule/getEmailSubjectAction',
          this.templateArr
        );
      }
      this.$store.dispatch(
        'communicationManagementModule/providerObjAction',
        this.deliveryChannelData[0].providersList
      );
      this.$store.dispatch(
        'communicationManagementModule/getCommunicationsMsgTemplates',
        this.deliveryChannelData[0].providersList[0].name
      );
      this.$store
        .dispatch(
          'communicationManagementModule/saveDeliveryChannelDraft',
          saveDeliveryChannel
        )
        .then(res => {
          if (res.status === 201 || res.status === 200) {
            this.review(res.data.data);
            this.$store.commit(
              'communicationManagementModule/setCommunicationCurrentStep',
              this.communicationCurrentStep + 1
            );
          }
        });
    },
    review (val) {
      let name = '';
      let templateName = '';
      let fromEmail = '';
      let subjectLine = '';
      for (let i = 0; i < this.deliveryChannelData[0].channelList.length; i++) {
        if (
          val.commChannelId === this.deliveryChannelData[0].channelList[i].Id
        ) {
          name = this.deliveryChannelData[0].channelList[0].name;
        }
      }
      for (let i = 0; i < this.communicationMsgTemplates.length; i++) {
        if (parseInt(val.templateId) === this.communicationMsgTemplates[i].id) {
          templateName = this.communicationMsgTemplates[i].messageName;
          fromEmail = this.communicationMsgTemplates[i].fromEmail;
          subjectLine = this.communicationMsgTemplates[i].subjectLine;
        }
      }
      let communicationData = {};
      communicationData = {
        communicationName: val.name,
        communicationDes: val.description,
        selectedDeliveryChannel: name,
        selectedEmailTemplate: templateName,
        fromEmail: fromEmail,
        subject: subjectLine,
        personalizationMappingArray: this.testMessageArr
      };
      this.$store.dispatch(
        'communicationManagementModule/ReviewDataAction',
        communicationData
      );
    },
    selectedMsgId (value) {
      this.selectedMessage = value;
      this.disabled = false;
      this.$store.commit(
        'communicationManagementModule/personalizationBtnStatusMutation',
        false
      );
    },
    ReviewButtonEnable (value) {
      this.disableReviewButton = value;
    }
  },
  mounted () {
    this.$store.commit(
      'communicationManagementModule/personalizationBtnStatusMutation',
      true
    );
    this.$store.dispatch(
      'communicationManagementModule/selectedProgramIdAction',
      this.$root.GlobalStoreEventStore.getters.getProgram.programId
    );
    this.$store.dispatch('communicationManagementModule/getMessageAttribute');
    this.$store.dispatch(
      'communicationManagementModule/setCommunicationObjAction',
      {
        communicationName: '',
        communicationDescription: '',
        deliveryChannelType: 1
      }
    );
    if (this.communicationCurrentStep !== 1) {
      this.$store.commit(
        'communicationManagementModule/setCommunicationCurrentStep',
        this.communicationCurrentStep = 1
      );
    }
  },
  watch: {
    '$root.GlobalStoreEventStore.state.program.programId' (value) {
      this.getDefaultProgram(value);
    }
  },
  created () {
    this.$store.commit(
      'communicationManagementModule/showPopUpDialogueMutation',
      false
    );
    this.$store.commit(
      'communicationManagementModule/templateErrorMutation',
      true
    );
    this.$store.commit('communicationManagementModule/selectedMsgMutation', '');
    this.$store.dispatch(
      'communicationManagementModule/getChannelProviderDataAction'
    );
    if (this.$route.name === 'CommunicationsManagementEdit') {
      this.$store.dispatch(
        'communicationManagementModule/editCommunicationManagementAction',
        this.$route.query.res
      );
    }
  }
};
</script>
