<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <brierley-form-title
        :formTitle="formTitle"
        :currentStep="3"
        :totalStep="5"
        :infoText="$t('providerInfo')"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <v-col
      class="bpt5 label-text"
      v-if="goToCommMsgBtn && viewType !== 'card_view'"
    >
      {{ $t("providerSelectMsg") }}
    </v-col>
    <v-col class="bpt5 label-text" v-if="!goToCommMsgBtn">
      {{ noData }}
    </v-col>
    <v-col class="bpt5 label-text" v-if="cardViewEnb">
      {{ noData }}
    </v-col>
    <v-col class="gray-bg bmb2 bpx3 bpy2 ">
      <v-row class="flex-column " no-gutters>
        <v-col>
          <v-row class="" no-gutters>
            <v-col cols="6">
              <!-- <v-row class="d-flex gen2-search-filter" no-gutters>
                <v-col class="text-left" cols="11">
                  <brierley-grid-search
                    :labelText="$t('searchForTemplateText')"
                    icon="mdi-magnify"
                    @SearchInit="onSearchText"
                  ></brierley-grid-search>
                </v-col>
              </v-row> -->
            </v-col>
            <v-col cols="6" class="text-right bpt1" v-if="goToCommMsgBtn">
              <brierley-view-option
                :viewList="cardlist"
                @viewChanged="typeview($event)"
              ></brierley-view-option>
              <!-- <brierley-icon-with-head
                iconName="add_circle"
                iconTitle="create a new Template"
              ></brierley-icon-with-head> -->
            </v-col>
          </v-row>
        </v-col>
        <v-col v-if="viewType == 'grid_view' && goToCommMsgBtn">
          <v-row class="notification-templates bpb1">
            <v-col
              cols="12"
              sm="6"
              v-for="(item, i) in communicationMsgTemplates"
              :key="i"
            >
              <v-card class="gen2-search-card">
                <v-row id="wrapper" no-gutters @click="selectMsg(item, i)">
                  <v-col
                    id="left"
                    class="gen2-search-card__head text-uppercase elipsis-fullwidth"
                    >{{ item.messageName }}</v-col
                  >
                  <v-col id="right" class="action-icons text-right">
                    <v-icon
                      class="dark-selected "
                      v-if="item.isSelected === true"
                    >
                      check_circle
                    </v-icon>
                    <v-icon class="" v-if="item.isSelected === false">
                      panorama_fish_eye
                    </v-icon>
                  </v-col>
                  <v-col cols="12">
                    <p>
                      {{ $t("providerCreatedOn") }} :
                      {{ format_date(item.creationDate) }}
                    </p>
                    <p>{{ format_time(item.creationDate) }}</p>
                  </v-col>
                </v-row>
              </v-card>
            </v-col>
          </v-row>
        </v-col>
        <v-col v-if="viewType == 'card_view' && goToCommMsgBtn">
          <brierley-no-result
            :noResultMessage="noData"
            noRecordFoundHeader=""
            id="viewuser_img_no_data"
          >
            <template v-slot:custom-heading>
              <h3 class="custom-head-noresult transform-none">
                {{ $t("providerSupportText") }}
              </h3>
            </template>
          </brierley-no-result>
        </v-col>
        <v-col v-if="!goToCommMsgBtn">
          <brierley-no-result
            :noResultMessage="noData"
            noRecordFoundHeader=""
            id="viewuser_img_no_data"
          >
            <template v-slot:custom-heading>
              <h3 class="custom-head-noresult transform-none">
                 {{ $t("providerSupportText") }} <br />
                {{ $t("previewEmailText") }}
              </h3>
            </template>
          </brierley-no-result>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import {
  BrierleyViewOption,
  BrierleyFormTitle,
  BrierleyNoResult,
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import moment from 'moment';
import { communicationProviderLayoutObj } from '../../../../i18n/language.js';
export default {
  data () {
    return {
      providerObj: [],
      localSelectMsg: false,
      formTitle: '',
      noData: '',
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('gridViewText'),
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('cardViewText'),
        },
      ],
    };
  },
  i18n: communicationProviderLayoutObj,
  components: {
    BrierleyViewOption,
    BrierleyFormTitle,
    BrierleyNoResult,
  },
  methods: {
    format_date (value) {
      if (value) {
        return moment(String(value)).format('DD/MMM/YYYY');
      }
    },
    typeview (val) {
      this.$store.commit(
        'communicationManagementModule/viewTypeMutation',
        val
      );
      if (this.viewType === 'card_view') {
        this.$store.commit(
          'communicationManagementModule/personalizationBtnStatusMutation',
          true
        );
        this.$store.commit(
          'communicationManagementModule/cardViewEnableMutation',
          true
        );
      } else {
        this.$store.commit(
          'communicationManagementModule/personalizationBtnStatusMutation',
          false
        );
        this.$store.commit(
          'communicationManagementModule/cardViewEnableMutation',
          false
        );
      }
    },
    format_time (value) {
      if (value) {
        return moment(String(value)).format('hh:mm A');
      }
    },
    selectMsg (val, idx) {
      this.localSelectMsg = true;
      this.$store.commit(
        'communicationManagementModule/localSelectMsg',
        true
      );
      val.isSelected = true;
      for (let i = 0; i < this.communicationMsgTemplates.length; i++) {
        if (i !== idx) {
          this.communicationMsgTemplates[i].isSelected = false;
        } else {
          this.$store.commit(
            'communicationManagementModule/selectedMsgMutation',
            this.communicationMsgTemplates[i]
          );
          this.$emit('selectedMsgId', this.communicationMsgTemplates[i]);
          this.communicationMsgTemplates[
            i
          ].provider = this.providerData[0].name;
          this.$store.dispatch(
            'communicationManagementModule/getCommunicationsProviderMsgFields',
            this.communicationMsgTemplates[i]
          );
        }
      }
    },
  },
  watch: {
    providerData () {
      this.formTitle = this.$t('provider') + ' ' + this.providerData[0].name;
    },
    providerRes () {
      if (this.$route.path.includes('/loyaltyadmin/CommunicationsManagementEdit') &&
      !this.localSelectMsg) {
        this.$store.dispatch(
          'communicationManagementModule/getCommunicationsMsgTemplates',
          this.providerRes[0].name
        );
      }
    },
    communicationMsgTemplates () {
      if (this.$route.path.includes('/loyaltyadmin/CommunicationsManagementEdit') &&
      this.localSelectMsg === false) {
        this.communicationMsgTemplates.forEach((res) => {
          // eslint-disable-next-line eqeqeq
          if (this.editRes.templateId == res.id) {
            res.isSelected = true;
            this.$store.commit('communicationManagementModule/selectedMsgMutation', res);
            this.$emit('selectedMsgId', res);
            res.provider = this.providerRes[0].name;
            this.$store.dispatch(
              'communicationManagementModule/getCommunicationsProviderMsgFields',
              res
            );
            return;
          } else {
            res.isSelected = false;
          }
        });
      } else {
        this.communicationMsgTemplates.forEach((res) => {
          if (this.selectedMsg.id === res.id) {
            res.isSelected = true;
            return;
          }
        });
      }

    },
  },
  mounted () {
    this.viewType = 'grid_view';
  },
  computed: {
    ...mapState('communicationManagementModule', {
      editRes: (state) => {
        return state.editRes;
      },
    }),
    ...mapState('communicationManagementModule', {
      communicationMsgTemplates: (state) => {
        return state.communicationMsgList;
      },
    }),
    ...mapState('communicationManagementModule', {
      cardViewEnb: (state) => {
        return state.cardViewEnb;
      },
    }),
    ...mapState('communicationManagementModule', {
      templateIdEdit: (state) => {
        return state.templateIdEdit;
      },
    }),
    ...mapState('communicationManagementModule', {
      viewType: (state) => {
        return state.viewType;
      },
    }),
    ...mapState('communicationManagementModule', {
      goToCommMsgBtn: (state) => {
        return state.goToCommMsgBtn;
      },
    }),
    ...mapState('communicationManagementModule', {
      deliveryChannelData: (state) => {
        return state.deliveryChannelData;
      },
    }),
    ...mapState('communicationManagementModule', {
      providerData: (state) => {
        return state.providerData;
      },
    }),
    ...mapState('communicationManagementModule', {
      selectedMsg: (state) => {
        return state.selectedMsg;
      },
    }),
    ...mapState('communicationManagementModule', {
      providerRes: (state) => {
        return state.providerRes;
      },
    }),
  },
};
</script>
