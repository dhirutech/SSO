<template>
  <v-row no-gutters class="d-flex">
    <v-col>
      <brierley-form-title
        :formTitle="$t('reviewFormTitle')"
        :currentStep="5"
        :totalStep="5"
        :infoText="$t('reviewInfoText')"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <v-col class="gen2-forms form-light-bg" xs="12" sm="12" md="12">
      <v-row justify="space-between">
        <v-col class="bmt3" xs="11" sm="11" md="11">
          <h3 class="fbold bml1">{{ $t('reviewBasicTitle') }}</h3>
        </v-col>
        <v-col class="hoverEdit bmt3" >
          <span
            class="primary-text fbold text-right text-uppercase"
             @click="editBasicInfo()"
          >
            <v-icon class="bpr1" color="#000">create</v-icon>{{ $t('editIconBtn') }}
          </span>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-col class="bml1 mt-2 pl-0">
        <p>
          <strong>{{ $t('reviewCommName') }}:</strong>
          <span class="pl-1">{{ reviewData.communicationName }}</span>
        </p>
        <p class="textWrap">
          <strong>{{ $t('reviewCommDes') }}:</strong>
          <span> {{ reviewData.communicationDes }}</span>
        </p>
      </v-col>
      <v-row>
        <v-col class="bmt2" xs="11" sm="11" md="11">
          <h3 class="fbold bml1">{{ $t('reviewDeliveryTitle') }}</h3>
        </v-col>
        <v-col class="hoverEdit bmt2">
          <span class="primary-text fbold text-right text-uppercase"  @click="editDeliveryChannel()">
            <v-icon class="bpr1" color="#000">create</v-icon>{{ $t('editIconBtn') }}
          </span>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-col class="bml1 mt-2 pl-0">
        <p>
          <strong>{{ $t('reviewDeliveryName') }}:</strong>
          <span class="pl-1">{{ reviewData.selectedDeliveryChannel }}</span>
        </p>
      </v-col>
      <v-row>
        <v-col class="bmt2" xs="11" sm="11" md="11">
          <h3 class="fbold bml1">{{ $t('reviewEmailTitle') }}</h3>
        </v-col>
        <v-col class="hoverEdit bmt2">
          <span class="primary-text fbold text-right text-uppercase"  @click="editEmailTemplate()">
            <v-icon class="bpr1" color="#000">create</v-icon>{{ $t('editIconBtn') }}
          </span>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-col class="bml1 mt-2 pl-0">
        <p>
          <strong>{{ $t('reviewSelectedEmail') }}:</strong>
          <span class="pl-1">{{ reviewData.selectedEmailTemplate }}</span>
        </p>
      </v-col>
      <v-row>
        <v-col class="bmt2" xs="11" sm="11" md="11">
          <h3 class="fbold bml1">{{ $t('reviewMsgTitle') }}</h3>
        </v-col>
        <v-col class="hoverEdit bmt2">
          <span class="primary-text fbold text-right text-uppercase"  @click="editMsgPersonalization()">
            <v-icon class="bpr1" color="#000">create</v-icon>{{ $t('editIconBtn') }}
          </span>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-col class="bml1 mt-2 pl-0">
        <p>
          <strong>{{ $t('reviewFromEmail') }}:</strong>
          <span class="pl-1">{{ reviewData.fromEmail }}</span>
        </p>
        <p>
          <strong>{{ $t('reviewSub') }}:</strong>
          <span class="pl-1">{{ reviewData.subject }}</span>
        </p>
      </v-col>
    </v-col>
    <v-col>
        <v-row>
        <v-col class="bmt2" xs="11" sm="11" md="11">
          <h3 class="fbold bml1">{{ $t('personalizationMappingTitle') }}</h3>
        </v-col>
        <v-col class="hoverEdit bmt2">
          <span class="primary-text fbold text-right text-uppercase"  @click="editMsgPersonalization()">
            <v-icon class="bpr1" color="#000">create</v-icon>{{ $t('editIconBtn') }}
          </span>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-col class="bml1 mt-2 pl-0">
        <p v-for="(item, i ) in reviewData.personalizationMappingArray" :key="i">
          <strong>user.{{item.name}} =</strong>
          <span class="pl-1">{{ item.displayName }}</span>
        </p>
      </v-col>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyFormTitle } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { communicationManagementReviewLayout } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyFormTitle
  },
  data () {
    return {
      channelReviewData: []
    };
  },
  i18n: communicationManagementReviewLayout,
  methods: {
    editBasicInfo () {
      this.$store.commit(
        'communicationManagementModule/setCommunicationCurrentStep',
        1
      );
    },
    editDeliveryChannel () {
      this.$store.commit(
        'communicationManagementModule/setCommunicationCurrentStep',
        2
      );
    },
    editEmailTemplate () {
      this.$store.commit(
        'communicationManagementModule/setCommunicationCurrentStep',
        3
      );
    },
    editMsgPersonalization () {
      this.$store.commit(
        'communicationManagementModule/setCommunicationCurrentStep',
        4
      );
    }
  },
  computed: {
    ...mapState('communicationManagementModule', {
      communicationsProviderMessageFieldsList: (state) => {
        return state.communicationsProviderMessageFieldsList;
      },
    }),
    ...mapState('communicationManagementModule', {
      getMessageAttributeRes: (state) => {
        return state.getMessageAttributeRes;
      },
    }),
    ...mapState('communicationManagementModule', {
      communicationMockData: state => {
        return state.communicationMockData;
      }
    }),
    ...mapState('communicationManagementModule', {
      reviewData: state => {
        return state.reviewData;
      }
    }),
    ...mapState('communicationManagementModule', {
      deliveryChannelData: state => {
        return state.deliveryChannelData;
      }
    })
  }
};
</script>
<style scoped>
.hoverEdit {
    cursor: pointer !important;
}
</style>
