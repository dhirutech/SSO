<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closePopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
          {{ $t("cardTitle") }}</v-card-title>
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <brierley-alert
                 icon="notifications_active"
                  alertType="warning"
                  :alertBody="alertMsg"
                ></brierley-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="org_btn_cancelDeleteDialog"
            text
            class="primaryctabtn bmt2"
            @click="closeDeleteEntityPopupWhenClickNo()"
            >{{ $t("closeBtnTextPopUp") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox, brierleyAlert } from '@brierley/SharedComponents';
import { communicationManagementAlertPopup } from '../../../../i18n/language.js';
import { mapState } from 'vuex';
export default {
  data () {
    return {
      dialog: false
    };
  },
  components: {
    BrierleyDialogbox,
    brierleyAlert,
  },
  i18n: communicationManagementAlertPopup,
  computed: {
    ...mapState('communicationManagementModule', {
      alertMsg: (state) => {
        return state.alertMsg;
      },
    }),
  },
  methods: {
    closePopup () {
      this.$store.commit(
        'communicationManagementModule/showAlertPopUpDialogueMutation',
        false
      );
    },
    closeDeleteEntityPopupWhenClickNo () {
      this.closePopup();
    }
  },
};
</script>
