<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <brierley-form-title
        :formTitle="$t('personalizationFormTitle')"
        :currentStep="4"
        :totalStep="5"
        infoText="info texts"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <Validation-Observer v-slot="{ handleSubmit }">
      <form id="connect_popup" @submit.prevent="handleSubmit(onSubmitPopup)">
        <brierley-dialogbox
          :dialog="messageDialog"
          @closeMe="closePopUp()"
          :persistent="false"
          max-width="1065"
          class="customfullheightdialog"
        >
          <template v-slot:dialog-header v-if="templateError">
            <v-card-title class="gen2-dialog-title text-uppercase">{{
              $t('templateHeader')
            }}</v-card-title>
          </template>
          <template v-slot:dialog-header v-else>
            <v-card-title class="gen2-dialog-title text-uppercase">
              {{ $t('testMessageText') }}</v-card-title
            >
          </template>
          <template v-slot:dialog-body-description>
            <v-row
              no-gutters
              class="bmt2"
              v-if="testMessageStep === 1 && templateError"
            >
              <v-col sm="10" class="gen2-forms form-light-bg">
                <v-row class="flex-column" no-gutters>
                  <v-col class="label-text">{{ $t('subjectText') }}</v-col>
                  <v-col sm="10">
                    <v-text-field
                      autocomplete="off"
                      :label="$t('Subject')"
                      :disabled="true"
                      v-model="selectedMessage.subjectLine"
                      auto-grow
                      filled
                    ></v-text-field>
                  </v-col>
                </v-row>
                <v-row class="flex-column" no-gutters>
                  <v-col class="label-text">{{ $t('testEmailText') }}</v-col>
                  <v-col sm="11">
                    <v-row
                      class="flex-column block-with-chips editable-chips"
                      no-gutters
                    >
                      <v-col class="block-with-chips__label">
                        <template>
                          <span class="req-label">{{ $t('emailIdText') }}</span>
                        </template>
                      </v-col>
                      <v-col class="block-with-chips__body">
                        <v-combobox
                          v-model="emailChips"
                          chips
                          clearable
                          :label="$t('emailIdText')"
                          multiple
                          solo
                          append-icon="false"
                          clear-icon="false"
                          class="editable-chips__field"
                        >
                          <template
                            v-slot:selection="{ attrs, item, select, selected }"
                          >
                            <v-chip
                              v-bind="attrs"
                              :input-value="selected"
                              close
                              title
                              @click="select"
                              @click:close="remove(item)"
                            >
                              <strong>{{ item }}</strong>
                            </v-chip>
                          </template>
                        </v-combobox>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
                <v-row class="flex-column pt-4" no-gutters>
                  <v-col class="label-text">{{
                    $t('customAttributeText')
                  }}</v-col>
                  <v-col sm="11">
                    <v-row class="flex-column" no-gutters>
                      <v-col class="bmb5 bpb4 pl-2 pr-2">
                        <v-row class="flex-column member-attr-table" no-gutters>
                          <v-col
                            class="member-attr-table__rows attributeRow pl-2 pr-2 mt-2"
                          >
                            <v-row
                              no-gutters
                              v-for="(item, i) in testMessageArr"
                              :key="i"
                            >
                              <v-col class="name" cols="4"
                                >{{ item.name }}
                              </v-col>
                              <v-col class="icon" cols="2"
                                ><v-icon>forward</v-icon></v-col
                              >
                              <v-col class="field" cols="6">
                                <v-text-field
                                  autocomplete="off"
                                  filled
                                  :label="$t('memberAttributeText')"
                                  :value="item.displayName"
                                  @input="changeName($event, i)"
                                ></v-text-field>
                              </v-col>
                            </v-row>
                          </v-col>
                        </v-row>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
            <v-row no-gutters class="bmt2" v-if="!templateError">
              <v-col>
                <brierley-no-result
                  :noResultMessage="noData"
                  noRecordFoundHeader=""
                  id="viewuser_img_no_data"
                >
                  <template v-slot:custom-heading>
                    <h3 class="custom-head-noresult transform-none">
                      {{ $t('providerNotres') }} <br />
                      {{ $t('plsTryLaterText') }}
                    </h3>
                  </template>
                </brierley-no-result>
              </v-col>
            </v-row>
          </template>
          <template
            v-slot:dialog-body-alert
            v-if="testMessageStep === 2 && templateError"
          >
            <v-alert icon="done" class="success b-alert-success max-width-full">
              <h3>
                {{ $t('successTxt') }}
              </h3>
              <p>{{ $t('templateSuccessTxt') }}</p>
            </v-alert>
          </template>
          <template v-slot:dialog-footer v-if="templateError">
            <v-btn
              text
              class="cancel no-ripple cursor-p btn-hover-none"
              @click="closePopUp()"
              v-if="testMessageStep === 1"
              >{{ $t('cancelBtnText') }}</v-btn
            >
            <v-btn
              class="primaryctabtn text-uppercase cursor-p"
              title="Default"
              type="submit"
              @click="sendTestTemplate()"
              :disabled="emailChips.length === 0 || disableSaveBtn"
              v-if="testMessageStep === 1"
              >{{ $t('sendBtnText') }}</v-btn
            >
            <v-btn
              data-qe-id="prom_BasicInfo_Audience_button_Done"
              class="primaryctabtn"
              v-if="testMessageStep === 2"
              @click="closePopUp()"
              >{{ $t('close') }}</v-btn
            >
          </template>
          <template v-slot:dialog-footer v-else>
            <v-btn
              class="primaryctabtn text-uppercase cursor-p"
              title="Default"
              @click="closePopUp()"
              >{{ $t('close') }}</v-btn
            >
          </template>
        </brierley-dialogbox>
      </form>
    </Validation-Observer>
    <v-col>
      <v-row no-gutters class="bmt5">
        <v-col sm="7" class="gen2-forms form-light-bg">
          <v-row class="flex-column " no-gutters>
            <v-col class="label-text">{{
              $t('personalizationMsgDetails')
            }}</v-col>
            <v-col sm="8">
              <v-text-field
                autocomplete="off"
                :label="$t('emailLabel')"
                :disabled="true"
                v-model="messageDetails.email"
                filled
              ></v-text-field>
            </v-col>
            <v-col sm="8">
              <v-text-field
                autocomplete="off"
                :label="$t('Subject')"
                :disabled="true"
                v-model="messageDetails.subjectLine"
                filled
              ></v-text-field>
            </v-col>
          </v-row>
        </v-col>
        <v-col sm="5">
          <brierley-info-side>
            <template v-slot:info-side-header>
              <div class="info_title">
                <v-icon>info</v-icon>{{ $t('personalizationInfo') }}
              </div>
            </template>
            <template v-slot:info-side-body>
              <div>
                {{ $t('personalizationInfoText') }}
              </div>
            </template>
          </brierley-info-side>
        </v-col>
      </v-row>
    </v-col>
    <v-col class="bpt4">
      <v-row no-gutters class="notification-templates">
        <v-col class="label-text text-left">
          {{ $t('personalization') }}
        </v-col>
        <v-col
          class="gen2-search-card__head text-uppercase elipsis-fullwidth min-height-20 alignText"
          @click="testMessage()"
        >
          <v-icon color="#0628b1">fact_check</v-icon
          >{{ $t('testMessageText') }}</v-col
        >
      </v-row>
    </v-col>
    <v-col class="gray-bg bmb2 bpa5">
      <v-row class="flex-column" no-gutters>
        <v-col class="bpb5 bmb4">
          <v-row class="notification-templates bpb1">
            <v-col cols="12" sm="6" v-for="(item, i) in 1" :key="i">
              <v-card class="gen2-search-card">
                <v-row id="wrapper" no-gutters class="flex-column">
                  <v-col
                    id="left"
                    class="gen2-search-card__head text-uppercase elipsis-fullwidth min-height-20"
                    >{{ selectedMessage.messageName }}</v-col
                  >
                  <!-- <v-col id="right" class="action-icons text-right">
                    <v-icon class="dark-selected">mdi-bookmark</v-icon
                    >
                  </v-col> -->
                  <v-col>
                    <p>
                      {{ $t('personalizationCreatedOn') }} :
                      {{ format_date(selectedMessage.creationDate) }}
                    </p>
                    <p>{{ format_time(selectedMessage.creationDate) }}</p>
                  </v-col>
                </v-row>
              </v-card>
            </v-col>
          </v-row>
        </v-col>
        <v-col class="bmb5 bpb4">
          <brierleyTabs class="gray-bg">
            <template v-slot:tabs-header>
              <v-tab>{{ $t('personalizationMemberAttributes') }}</v-tab>
            </template>
            <template v-slot:tabs-body>
              <v-tab-item>
                <v-row class="flex-column member-attr-table" no-gutters>
                  <v-col class="member-attr-table__head">
                    <v-row no-gutters>
                      <v-col class="head"
                        >{{ $t('personProviderMsgFields') }}
                        <v-icon
                          class="info-icon"
                          :title="$t('providerMsgTitle')"
                          >info_outline</v-icon
                        ></v-col
                      >
                      <v-col class="head"
                        >{{ $t('personApplicationFields') }}
                        <v-icon
                          class="info-icon"
                          :title="$t('applicationTitle')"
                          >info_outline</v-icon
                        ></v-col
                      >
                    </v-row>
                  </v-col>
                  <v-col
                    class="member-attr-table__rows"
                    v-for="(item, i) in communicationsProviderMessageFieldsList"
                    :key="i"
                  >
                    <v-row no-gutters>
                      <v-col class="name" cols="4">{{ item }} </v-col>
                      <v-col class="icon" cols="2"
                        ><v-icon>forward</v-icon></v-col
                      >
                      <v-col
                        class="field"
                        cols="6"
                        v-if="
                          $route.path.includes(
                            '/loyaltyadmin/CommunicationsManagementEdit'
                          ) && !localSelectMsgRes
                        "
                      >
                        <v-select
                          :items="getMessageAttributeRes"
                          @input="
                            selectedAttribute(
                              item,
                              i,
                              selectedProvider[i].personalizationAttributeId
                            )
                          "
                          item-text="displayName"
                          item-value="personalizationAttributeId"
                          v-model="
                            selectedProvider[i].personalizationAttributeId
                          "
                          filled
                          attach
                          offset-y
                          class="gen2select gen2select__dark mini-list"
                          label="Member Attribute"
                          append-icon="expand_more"
                        ></v-select>
                      </v-col>
                      <v-col class="field" cols="6" v-else>
                        <v-select
                          :items="getMessageAttributeRes"
                          @input="selectedAttribute(item, i, res)"
                          item-text="displayName"
                          item-value="personalizationAttributeId"
                          v-model="res"
                          filled
                          attach
                          offset-y
                          class="gen2select gen2select__dark mini-list"
                          label="Member Attribute"
                          append-icon="expand_more"
                        ></v-select>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </v-tab-item>
            </template>
          </brierleyTabs>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import {
  BrierleyInfoSide,
  BrierleyFormTitle,
  BrierleyTabs,
  BrierleyDialogbox,
  BrierleyNoResult
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import moment from 'moment';
import { communicationPersonalizationLayoutObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyInfoSide,
    BrierleyFormTitle,
    BrierleyTabs,
    BrierleyDialogbox,
    BrierleyNoResult
  },
  data () {
    return {
      selectedProvider: null,
      emailChips: [],
      messageDialog: false,
      attributeRes: null,
      memberAttr: [],
      response: [],
      noData: '',
      testMessageArr: [],
      disableSaveBtn: false
    };
  },
  i18n: communicationPersonalizationLayoutObj,
  props: {
    selectedMessage: {
      type: []
    }
  },
  watch: {
    editRes () {
      if (
        this.editRes.messagePersonalizations !== null &&
        this.$route.path.includes('/loyaltyadmin/CommunicationsManagementEdit')
      ) {
        this.$emit('ReviewButtonEnable', false);
        this.selectedProvider = this.editRes.messagePersonalizations
          .slice()
          .reverse();
      }
    }
  },
  methods: {
    closePopUpText () {
      this.$store.commit(
        'communicationManagementModule/templateErrorMutation',
        true
      );
    },
    sendTestTemplate () {
      let emailParameters = {};
      for (let i = 0; i < this.testMessageArr.length; i++) {
        emailParameters[this.testMessageArr[i].name] = this.testMessageArr[
          i
        ].displayName;
      }
      let obj = {
        providerName: this.deliveryChannelData[0].providersList[0].name,
        emailTemplateId: this.testMessageId,
        emailIds: [...this.emailChips],
        emailParameters: emailParameters
      };
      this.$store
        .dispatch('communicationManagementModule/testTemplateAction', obj)
        .then((res) => {
          if (res.status === 201 || res.status === 200) {
            if (this.testMessageStep === 1) {
              this.$store.commit(
                'communicationManagementModule/testMessageStepMutation',
                this.testMessageStep + 1
              );
            }
          }
        })
        .catch((err) => {
          if (err.response.status === 400 || err.response.status === 404) {
            this.$store.commit(
              'communicationManagementModule/templateErrorMutation',
              false
            );
          }
        });
    },
    closePopUp () {
      this.$store.commit(
        'communicationManagementModule/templateErrorMutation',
        true
      );
      this.messageDialog = false;
      this.emailChips = [];
      if (this.testMessageStep === 2) {
        this.$store.commit(
          'communicationManagementModule/testMessageStepMutation',
          this.testMessageStep - 1
        );
      }
    },
    changeName (event, idx) {
      if (event === '') {
        this.disableSaveBtn = true;
      } else {
        this.disableSaveBtn = false;
        this.testMessageArr[idx].displayName = event;
      }
    },
    remove (item) {
      this.emailChips.splice(this.emailChips.indexOf(item), 1);
      this.emailChips = [...this.emailChips];
    },
    testMessage () {
      this.testMessageArr = [];
      let display = '';
      for (
        let i = 0;
        i < this.communicationsProviderMessageFieldsList.length;
        i++
      ) {
        this.testMessageArr[i] = {
          name: this.communicationsProviderMessageFieldsList[i],
          displayName: display
        };
      }
      this.messageDialog = true;
    },
    selectedAttribute (item, ind, res) {
      let alreadySelected = false;
      if (this.memberAttr.length > 0) {
        this.memberAttr.forEach((x, i) => {
          if (x.index === ind) {
            let messagePersonalizations = [
              {
                index: ind,
                messagePersonalizationId: 0,
                personalizationElement: item,
                personalizationAttributeId: res
              }
            ];
            alreadySelected = true;
            this.memberAttr[i] = messagePersonalizations[0];
          }
        });
      }
      if (alreadySelected === false) {
        let messagePersonalizations = [
          {
            index: ind,
            messagePersonalizationId: 0,
            personalizationElement: item,
            personalizationAttributeId: res
          }
        ];
        if (this.memberAttr.length === 0) {
          this.memberAttr = messagePersonalizations;
        } else {
          this.memberAttr.push(messagePersonalizations[0]);
        }
      }
      if (
        this.communicationsProviderMessageFieldsList.length ===
        this.memberAttr.length
      ) {
        this.$store.commit(
          'communicationManagementModule/memberAttributeMutation',
          this.memberAttr
        );
        this.$emit('ReviewButtonEnable', false);
      } else {
        this.$emit('ReviewButtonEnable', true);
      }
      if (this.editRes.messagePersonalizations !== null) {
        this.$emit('ReviewButtonEnable', false);
      }
    },
    format_date (value) {
      if (value) {
        return moment(String(value)).format('DD/MMM/YYYY');
      }
    },
    format_time (value) {
      if (value) {
        return moment(String(value)).format('hh:mm A');
      }
    }
  },
  computed: {
    ...mapState('communicationManagementModule', {
      localSelectMsgRes: (state) => {
        return state.localSelectMsgRes;
      }
    }),
    ...mapState('communicationManagementModule', {
      editRes: (state) => {
        return state.editRes;
      }
    }),
    ...mapState('communicationManagementModule', {
      communicationsProviderMessageFieldsList: (state) => {
        return state.communicationsProviderMessageFieldsList;
      }
    }),
    ...mapState('communicationManagementModule', {
      getMessageAttributeRes: (state) => {
        return state.getMessageAttributeRes;
      }
    }),
    ...mapState('communicationManagementModule', {
      memberAttributeList: (state) => {
        return state.memberAttributeList;
      }
    }),
    ...mapState('communicationManagementModule', {
      personalisation: (state) => {
        return state.personalisation;
      }
    }),
    ...mapState('communicationManagementModule', {
      newMsgInEditRes: (state) => {
        return state.newMsgInEditRes;
      }
    }),
    ...mapState('communicationManagementModule', {
      deliveryChannelData: (state) => {
        return state.deliveryChannelData;
      }
    }),
    ...mapState('communicationManagementModule', {
      testMessageId: (state) => {
        return state.testMessageId;
      }
    }),
    ...mapState('communicationManagementModule', {
      testMessageStep: (state) => {
        return state.testMessageStep;
      }
    }),
    ...mapState('communicationManagementModule', {
      templateError: (state) => {
        return state.templateError;
      }
    }),
    ...mapState('communicationManagementModule', {
      messageDetails: (state) => {
        return state.messageDetails;
      }
    })
  }
};
</script>
<style lang="scss" scoped>
.min-height-20 {
  min-height: 20px;
}
.alignText {
  text-align: end !important;
  cursor: pointer !important;
}
.attributeRow {
  background: whitesmoke;
}
.v-input.v-text-field .v-input__slot {
  background: white !important;
}
.gen2select__dark.mini-list {
  width: 304px;
  max-width: 304px !important;
}
</style>
<style lang="scss">
.block-with-chips.editable-chips {
  min-height: 150px !important;
  max-height: 150px !important;
  .block-with-chips__label {
    max-height: 25px;
  }
  .block-with-chips__body {
    overflow-x: hidden;
    .editable-chips__field {
      .v-input__control {
        min-height: 97px;
        .v-input__slot {
          margin-bottom: 0 !important;
          box-shadow: none !important;
          background: none !important;
          min-height: 100px;
          padding: 0 !important;
          .v-select__slot {
            top: -17px !important;
            position: relative;
            .v-label {
              display: none;
            }
            .v-select__selections {
              position: absolute;
              top: 0;
              margin-left: 0px;
              width: 100%;
              input {
                padding: 0 !important;
                //min-height: 114px !important;
              }
              .v-chip {
                min-width: 230px !important;
                max-width: 230px !important;
                margin-left: 0px;
                margin-right: 8px;
                &__content {
                  font-weight: 300 !important;
                  padding-top: 0 !important;
                }
              }
            }
          }
        }
        .v-text-field__details {
          display: none;
        }
      }
    }
  }
}
</style>
