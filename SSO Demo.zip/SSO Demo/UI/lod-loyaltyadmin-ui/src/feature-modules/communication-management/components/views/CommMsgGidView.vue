<template>
  <v-row>
    <v-col cols="12" v-for="(commMsg, index) in commlistdata" :key="index">
      <v-card class="gen2-card gen2-typo3">
        <v-row no-gutters>
          <v-col sm="4" xs="12" class="bpr5">
            <v-card-title class="elipsis-fullwidth">
              <v-icon
                class="primary-text icon-btn-hover-none"
                v-if="commMsg.isBookMarked === true"
                @click="updateBookmark(commMsg, index)"
                >mdi-bookmark</v-icon
              >
              <v-icon
                id="prom_grid_bookmark_false"
                v-else
                class="primary-text icon-btn-hover-none"
                @click="updateBookmark(commMsg, index)"
                >bookmark_border</v-icon
              >
              {{ commMsg.name === "" ? "" : commMsg.name }}
            </v-card-title>
            <div class="gen2-card-copy">
              <p class="elipsis-fullwidth" id="viewuser_email">
                <strong>{{ $t("MessageName") }}: </strong>
                {{ commMsg.channelName === "" ? "" : commMsg.channelName }}
              </p>
              <p id="viewuser_phone">
                <strong>{{ $t("Author") }}: </strong>
                {{
                  commMsg.authorFullName === "" ? "" : commMsg.authorFullName
                }}
              </p>
            </div>
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span
                  title="Edit"
                  v-if="commMsg.status === 'DRAFT'"
                  class="active"
                  @click="editCommunication(commMsg)"
                >
                  <v-icon id="viewuser_edit-icon" class="blackicon"
                    >fe fe-edit</v-icon
                  >
                  <span class="edit-icon" id="viewuser-edit">{{
                    $t("editLabel")
                  }}</span>
                </span>
                <span title="Copy" @click="previewUser(commMsg)">
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >fe fe-copy</v-icon
                  >
                  <span class="copy-icon" id="viewuser-copy">{{
                    $t("previewLabel")
                  }}</span>
                </span>
                <span
                  title="Delete"
                  v-if="commMsg.status === 'DRAFT'"
                  @click="deleteCommMsg(commMsg)"
                >
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >fe fe-trash-2</v-icon
                  >
                  <span class="delete-icon" id="Delete-copy">{{
                    $t("Delete")
                  }}</span>
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
          <v-col sm="3" xs="12" class="bpr3">
            <p class="bmt0">
              <strong>{{ $t("Description") }}</strong>
            </p>
            <p class="bmt0 elipsis-twoline">{{ commMsg.description }}</p>
          </v-col>
          <v-col sm="3" xs="12">
            <v-row no-gutters class="pr-3 mb-4">
              <v-col class="text-xs-left">
                <p class="bmt0">
                  <strong>{{ $t("Modifieddate") }} :</strong>
                  {{ format_date(commMsg.updatedDate) }}
                </p>
              </v-col>
            </v-row>
            <v-row no-gutters class="pr-3">
              <v-col class="text-xs-left">
                <p class="bmt0">
                  <strong>{{ $t("Createddate") }} :</strong>
                  {{ format_date(commMsg.createdDate) }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col class="gen2-card-status">
            <p class="bmt0">
              <strong>{{ $t("statusLabel") }}</strong>
            </p>
            <brierley-status
              v-if="commMsg.status === 'DRAFT'"
              title="Draft"
              status="Draft"
            ></brierley-status>
            <brierley-status
              v-if="commMsg.status === 'PUBLISHED'"
              title="Published"
              status="Published"
            ></brierley-status>
          </v-col>
          <v-col sm="12">
            <brierley-card-icons>
              <template v-slot:action-icons>
                <!-- <span title="VIEW DETAILS" class="active">
                  <v-icon class="blackicon" title="View Details"
                    >fe fe-eye</v-icon
                  >
                  <span
                    id="view_btn_Grid_View"
                    @click="$emit('viewmemberdetails', true)"
                    >{{ $t("viewDetails") }}</span
                  >
                </span> -->
                <!-- <span title="Copy">
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >fe fe-copy</v-icon
                  >
                  <span class="copy-icon" id="viewuser-copy">{{
                    $t("copyLabel")
                  }}</span>
                </span> -->
                <!-- <span title="PAUSE">
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >pause</v-icon
                  >
                  <span class="pause-icon">Pause</span>
                </span> -->
                <!-- <span title="Stop">
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >fe fe-stop-circle</v-icon
                  >
                  <span class="stop-icon" id="viewuser-copy">Stop</span>
                </span> -->
                <!-- <span title="Delete" v-if="commMsg.status === 'DRAFT'" @click="deleteCommMsg(commMsg)">
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >fe fe-trash-2</v-icon
                  >
                  <span class="delete-icon" id="Delete-copy">Delete</span>
                </span> -->
              </template>
            </brierley-card-icons>
          </v-col>
        </v-row>
      </v-card>
    </v-col>
    <v-col v-if="filterCount === 0">
      <brierley-no-result
        :noResultMessage="noData"
        id="viewuser_img_no_data"
      ></brierley-no-result>
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyStatus,
  BrierleyCardIcons,
  BrierleyNoResult
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { communicationLanguageObj } from './../../../../i18n/language.js';
import moment from 'moment';

export default {
  components: {
    BrierleyCardIcons,
    BrierleyStatus,
    BrierleyNoResult
  },
  i18n: communicationLanguageObj,
  data () {
    return {
      isHidden: false,
      btext: '',
      msg: '',
      header: '',
      isBookmarked: true,
      templatesArrs: []
    };
  },
  props: {
    commlistdata: {
      type: Array,
      defualt: []
    },
    filterCount: {
      type: Number
    }
  },
  methods: {
    getEmailSubject (data) {
      this.templatesArrs = this.templateArr.filter(
        x => x.id === parseInt(data.templateId)
      );
      this.$store.commit(
        'communicationManagementModule/selectedTemplatesArrMutation',
        this.templatesArrs
      );
      this.$store
        .dispatch(
          'communicationManagementModule/getEmailSubjectAction',
          this.templatesArrs
        )
        .then(res => {
          if (res) {
            this.$store.commit(
              'communicationManagementModule/messageDataMutation',
              res.data.data
            );
            this.templateData(this.templatesArrs);
          }
        });
    },
    templateData (val) {
      let obj = {};
      obj.provider = this.providerName;
      obj.id = val[0].id;
      this.$store
        .dispatch(
          'communicationManagementModule/getCommunicationsProviderMsgFields',
          obj
        )
        .then(res => {
          if (res) {
            this.frameObj(res);
          }
        });
    },
    frameObj (res) {
      let commObjectArray = [];
      for (let i = 0; i < res.data.data.length; i++) {
        let obj = {};
        obj.personalizationElement = res.data.data[i];
        obj.msgAttributes = this.getMessageAttributeRes;
        obj.selectedAttribute = this.personalisation[
          i
        ].personalizationAttributeId;
        commObjectArray.push(obj);
      }
      this.$store.commit(
        'communicationManagementModule/commObjectArrayMutation',
        commObjectArray
      );
    },
    previewUser (val) {
      this.$store
        .dispatch(
          'communicationManagementModule/getPreviewDetailsAction',
          val.commMessageId
        )
        .then(res => {
          if (res) {
            this.getEmailSubject(res.data.data);
            this.$store.commit(
              'communicationManagementModule/personalisationMutation',
              res.data.data.messagePersonalizations
            );
            this.$router.push('/loyaltyadmin/CommunicationsManagementPreview');
          }
        });
    },
    updateBookmark (item) {
      this.$emit('onBookmarked', { item: item, commMsgId: item.commMessageId });
    },
    editCommunication (comMessage) {
      this.$store.commit('communicationManagementModule/localSelectMsg', false);
      if (comMessage.commMessageId) {
        this.$router.push({
          name: 'CommunicationsManagementEdit',
          query: { res: comMessage.commMessageId }
        });
      }
    },
    deleteCommMsg (val) {
      this.$store.commit(
        'communicationManagementModule/showDeletePopUpDialogueMutation',
        true
      );
      this.$store.commit(
        'communicationManagementModule/deleteCommMessageIdMutation',
        val.commMessageId
      );
    },
    format_date (value) {
      if (value) {
        return moment(String(value)).format('MMM Do YYYY');
      }
    }
  },
  computed: {
    ...mapState('communicationManagementModule', {
      personalisation: state => {
        return state.personalisation;
      }
    }),
    ...mapState('userviewModule', [
      'showdialog',
      'params',
      'programId',
      'deliveryChannelData'
    ]),
    ...mapState('communicationManagementModule', {
      templateIdEdit: state => {
        return state.templateIdEdit;
      }
    }),
    ...mapState('communicationManagementModule', {
      getMessageAttributeRes: state => {
        return state.getMessageAttributeRes;
      }
    }),
    ...mapState('communicationManagementModule', {
      templateArr: state => {
        return state.templateArr;
      }
    }),
    ...mapState('communicationManagementModule', {
      providerName: state => {
        return state.providerName;
      }
    })
  }
};
</script>

<style lang="scss" scoped>
#link {
  color: #0628b1;
  position: relative;
  top: 2px;
  right: 2px;
}

.accountlock {
  font-size: 20px !important;
  font-size: 1.125rem;
  margin-top: -6px;
  margin-left: 2px !important;
  color: #bdbdbd;
}
</style>
