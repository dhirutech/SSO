<template>
  <v-row class="d-flex flex-column" no-gutter>
    <brierley-table-module v-if="commlistdata.length > 0">
      <template v-slot:tablehead>
        <tr class="text-left">
          <th
            v-for="item in header"
            :key="item.name"
            @click="
              sortBy(item);
              arrowToggle();
            "
            class="text-left"
            :width="item.width"
          >
            {{ item.text }}
          </th>
        </tr>
      </template>

      <template v-slot:tablebody>
        <tr v-for="(item, index) in commlistdata" :key="item.name">
          <td class="vertical-middle">
            <v-row
              class="head-name user-display-name"
              :title="item.name"
              no-gutters
            >
              <v-col>
                <v-row no-gutters>
                  <v-col
                    class="max-width-40"
                    @click="updateBookmark(item, index)"
                  >
                    <v-icon
                      id="prom_table_bookmark_true"
                      class="cursor-p"
                      v-if="item.isBookMarked === true"
                      >bookmark</v-icon
                    >
                    <v-icon
                      id="prom_table_bookmark_false"
                      class="cursor-p"
                      v-else
                      >bookmark_border</v-icon
                    >
                  </v-col>
                  <v-col class="elipsis-twoline text-uppercase">
                    {{ item.name }}
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
          </td>
          <td class="vertical-middle">
            {{ item.channelName }}
          </td>
          <td class="vertical-middle">
            {{ item.description }}
          </td>
          <td class="vertical-middle">
            {{ item.authorFullName === "" ? "" : item.authorFullName }}
          </td>
          <td class="vertical-middle">
            {{ format_date(item.createdDate) }}
          </td>
          <td class="vertical-middle">
            <brierley-status
              v-if="item.status === 'DRAFT'"
              title="Draft"
              status="Draft"
            ></brierley-status>
            <brierley-status
              v-if="item.status === 'PUBLISHED'"
              title="Published"
              status="Published"
            ></brierley-status>
            <v-row class="d-inline-flex hover-actions" no-gutters>
              <v-col>
                <brierleyCardIcons>
                  <template v-slot:action-icons>
                    <!-- <span title="VIEW DETAILS" class="active">
                      <v-icon class="blackicon" title="View Details"
                        >fe fe-eye</v-icon
                      >
                      <span
                        id="view_btn_Grid_View"
                        @click="$emit('viewmemberdetails', true)"
                        >{{ $t("viewDetails") }}</span
                      >
                    </span> -->
                    <span
                      title="Edit"
                      v-if="item.status === 'DRAFT'"
                      @click="editCommunication(item)"
                      class="active"
                    >
                      <v-icon class="blackicon" id="viewuser-edit-icon"
                        >fe fe-edit</v-icon
                      >
                      <span class="edit-icon" id="viewuser-edit">{{
                        $t("editLabel")
                      }}</span>
                    </span>
                    <span title="Copy" @click="previewUser(item)">
                      <v-icon class="blackicon" id="viewuser-icon"
                        >feather-icon fe fe-copy</v-icon
                      >
                      <span class="copy-icon" id="viewuser-copy">{{
                        $t("previewLabel")
                      }}</span>
                    </span>
                    <!-- <span title="Copy" @click="cloneUser(item.id)">
                      <v-icon class="blackicon" id="viewuser-icon"
                        >feather-icon fe fe-copy</v-icon
                      >
                      <span class="copy-icon" id="viewuser-copy">{{
                        $t("copyLabel")
                      }}</span>
                    </span>
                    <span title="PAUSE">
                      <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                        >pause</v-icon
                      >
                      <span class="pause-icon">Pause</span>
                    </span>
                    <span title="Stop">
                      <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                        >fe fe-stop-circle</v-icon
                      >
                      <span class="stop-icon" id="viewuser-copy">Stop</span>
                    </span> -->
                    <span
                      title="Delete"
                      v-if="item.status === 'DRAFT'"
                      @click="deleteCommMsg(item)"
                    >
                      <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                        >fe fe-trash-2</v-icon
                      >
                      <span class="delete-icon" id="Delete-copy"
                        >{{ $t("Delete") }}
                      </span>
                    </span>
                  </template>
                </brierleyCardIcons>
              </v-col>
            </v-row>
          </td>
        </tr>
      </template>
    </brierley-table-module>
    <v-col v-if="filterCount === 0">
      <brierley-no-result
        :noResultMessage="noData"
        id="viewuser_img_no_data"
      ></brierley-no-result>
    </v-col>
  </v-row>
</template>

<script>
import _ from 'lodash';

import {
  BrierleyCardIcons,
  BrierleyTableModule,
  BrierleyStatus,
  BrierleyNoResult
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { communicationLanguageObj } from './../../../../i18n/language.js';
import moment from 'moment';

export default {
  components: {
    BrierleyCardIcons,
    BrierleyTableModule,
    BrierleyStatus,
    BrierleyNoResult
  },
  i18n: communicationLanguageObj,
  data () {
    return {
      sortKey: ['name'],
      sortOrder: ['asc'],
      isToggled: false,
      changeColor: false,
      isBookmarked: true,
      btext: '',
      msg: '',
      headertext: '',
      templatesArrs: [],
      header: [
        {
          name: 'name',
          text: this.$t('CommunicationName'),
          sort: 'asc',
          width: '215'
        },
        {
          name: 'programs',
          text: this.$t('MessageName'),
          sort: '',
          width: '170'
        },
        {
          name: 'Description',
          text: this.$t('Description'),
          sort: '',
          width: '215'
        },
        {
          name: 'Author',
          text: this.$t('Author'),
          sort: '',
          width: '215'
        },
        {
          name: 'createddate',
          text: this.$t('createdOnText'),
          sort: '',
          width: '170'
        },
        { name: 'status', text: this.$t('statusText'), sort: '', width: '180' }
      ]
    };
  },

  props: {
    commlistdata: {
      type: Array,
      default: function () {
        return [];
      }
    },
    filterCount: {
      type: Number
    }
  },
  computed: {
    campaigns: function () {
      return _.orderBy(this.campaignslist, this.sortKey, this.sortOrder);
    },
    ...mapState('userviewModule', ['showdialog', 'params']),
    ...mapState('communicationManagementModule', {
      templateIdEdit: state => {
        return state.templateIdEdit;
      }
    }),
    ...mapState('communicationManagementModule', {
      getMessageAttributeRes: state => {
        return state.getMessageAttributeRes;
      }
    }),
    ...mapState('communicationManagementModule', {
      templateArr: state => {
        return state.templateArr;
      }
    }),
    ...mapState('communicationManagementModule', {
      providerName: state => {
        return state.providerName;
      }
    }),
    ...mapState('communicationManagementModule', {
      personalisation: state => {
        return state.personalisation;
      }
    })
  },
  methods: {
    getEmailSubject (data) {
      this.templatesArrs = this.templateArr.filter(
        x => x.id === parseInt(data.templateId)
      );
      this.$store.commit(
        'communicationManagementModule/selectedTemplatesArrMutation',
        this.templatesArrs
      );
      this.$store
        .dispatch(
          'communicationManagementModule/getEmailSubjectAction',
          this.templatesArrs
        )
        .then(res => {
          if (res) {
            this.$store.commit(
              'communicationManagementModule/messageDataMutation',
              res.data.data
            );
            this.templateData(this.templatesArrs);
          }
        });
    },
    templateData (val) {
      let obj = {};
      obj.provider = this.providerName;
      obj.id = val[0].id;
      this.$store
        .dispatch(
          'communicationManagementModule/getCommunicationsProviderMsgFields',
          obj
        )
        .then(res => {
          if (res) {
            this.frameObj(res);
          }
        });
    },
    frameObj (res) {
      let commObjectArray = [];
      for (let i = 0; i < res.data.data.length; i++) {
        let obj = {};
        obj.personalizationElement = res.data.data[i];
        obj.msgAttributes = this.getMessageAttributeRes;
        obj.selectedAttribute = this.personalisation[
          i
        ].personalizationAttributeId;
        commObjectArray.push(obj);
      }
      this.$store.commit(
        'communicationManagementModule/commObjectArrayMutation',
        commObjectArray
      );
    },
    previewUser (val) {
      this.$store
        .dispatch(
          'communicationManagementModule/getPreviewDetailsAction',
          val.commMessageId
        )
        .then(res => {
          if (res) {
            this.getEmailSubject(res.data.data);
            this.$store.commit(
              'communicationManagementModule/personalisationMutation',
              res.data.data.messagePersonalizations
            );
            this.$router.push('/loyaltyadmin/CommunicationsManagementPreview');
          }
        });
    },
    updateBookmark (item) {
      this.$emit('onBookmarked', { item: item, commMsgId: item.commMessageId });
    },
    deleteCommMsg (val) {
      this.$store.commit(
        'communicationManagementModule/showDeletePopUpDialogueMutation',
        true
      );
      this.$store.commit(
        'communicationManagementModule/deleteCommMessageIdMutation',
        val.commMessageId
      );
    },
    format_date (value) {
      if (value) {
        return moment(String(value)).format('MMM Do YYYY');
      }
    },
    editCommunication (comMessage) {
      this.$store.commit('communicationManagementModule/localSelectMsg', false);
      if (comMessage.commMessageId) {
        this.$router.push({
          name: 'CommunicationsManagementEdit',
          query: { res: comMessage.commMessageId }
        });
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.arrow {
  transform: rotate(-180deg);
}
.arrow.down {
  transform: rotate(2deg);
}
.accountlock {
  font-size: 20px !important;
  font-size: 1.125rem;
  margin-top: -6px;
  margin-left: 2px !important;
  color: #bdbdbd;
}
#link {
  color: #0628b1;
  position: relative;
  bottom: -20px;
}
.max-width-40 {
  max-width: 40px !important;
}
</style>
