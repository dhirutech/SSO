<template>
  <v-col class="">
    <h2 class="font28 primary-text fbold bmt5">
      {{ $t("headerTxt") }}
      <span class="list-count primary-text"
        >({{ filterCount }} {{ $t("CommunicationMessages") }})</span
      >
    </h2>
    <v-row no-gutters v-if="this.userCountRes === 0 && !loadmore">
      <v-col class="create-communication bpx6 bpy9">
        <img src="../../../assets/images/communication-bg.png" />
        <div class="create-communication__info">
          <strong class="create-communication__title"
            >{{ $t("createFirstTxt") }}
            <span>{{ $t("communicationMsgTxt") }}</span></strong
          >
          <p class="bmt3 bmb6">{{ $t("noMsgTxt") }}</p>
        </div>
        <v-btn
          class="primaryctabtn"
          title="Default"
          @click.native="redirectCommManagement()"
          >{{ $t("clickHereTxt") }}</v-btn
        >
      </v-col>
    </v-row>
    <alert-pop-up v-if="showAlertPopUpDialogue" />
    <delete-pop-up v-if="showDeletePopUp" />
    <v-row class="flex-column" no-gutters v-if="userCountRes > 0">
      <v-col class="communication-message-list-page">
        <v-row class="d-flex gen2-search-filter bpt2" no-gutters>
          <v-col class="text-left" cols="4">
            <v-row class="loyalty-users-common" no-gutters>
              <v-col class="bpr2 grid-search">
                <v-text-field
                  autocomplete="off"
                  class="search-field"
                  id="communication-message_searchComm"
                  :label="$t('SearchCommunicationMessages')"
                  prepend-inner-icon="mdi-magnify"
                  v-model="searchText"
                  @input="isTyping = true"
                ></v-text-field>
              </v-col>
            </v-row>
          </v-col>
          <v-col cols="8" class="text-right align-self-center">
            <brierley-filter
              v-on:click.native="isHidden = !isHidden"
            ></brierley-filter>
            <div class="bmr1 d-inline-block">
              <brierley-view-option
                id="viewuser_viewoptions"
                :viewList="cardlist"
                @viewOptionClicked="hideFilter()"
                @viewChanged="viewType = $event"
              ></brierley-view-option>
            </div>
            <!-- <brierley-icon-with-head
              class="loyalty-users-common__create-user"
              @click.native="redirectCommManagement()"
              :iconTitle="$t('create a comm. message')"
              :iconName="'add_circle'"
              id="viewuser_btn_createUser"
            ></brierley-icon-with-head> -->
            <v-btn
              @click.native="redirectCommManagement()"
              depressed
              id="viewuser_btn_createUser"
              class="next primarycreatecampbutton primaryctabtn"
              :title="$t('createCommMessage')"
            >
              {{ $t("createCommMessage") }}
              <!-- Create A COMM.. MESSAGE -->
            </v-btn>
          </v-col>
          <v-col cols="12" class="filter-dropdown bmt1">
            <brierley-filter-result v-if="isHidden">
              <template v-slot:body-content>
                <v-row no-gutters class="bmb6">
                  <v-col cols="4">
                    <h3>{{ $t("activityDate") }}</h3>
                    <v-row class="main-wrapper__header">
                      <v-col cols="10" class="todate">
                        <v-menu
                          ref="startDatePopup"
                          v-model="startDatePopup"
                          :close-on-content-click="false"
                          :return-value.sync="filterStartRange"
                          transition="scale-transition"
                          offset-y
                          min-width="290px"
                        >
                          <template v-slot:activator="{ on }">
                            <v-text-field
                              autocomplete="off"
                              id="user_loyaltyAdmin_filterStartRangeFormated"
                              readonly
                              v-model="startDateFormatted"
                              @blur="
                                filterStartRange = parseDate(startDateFormatted)
                              "
                              :label="$t('fromLabel')"
                              append-icon="mdi-calendar-range"
                              v-on="on"
                              class="darktxtfield__light"
                              filled
                            ></v-text-field>
                          </template>
                          <v-date-picker
                            v-model="filterStartRange"
                            no-title
                            scrollable
                            :max="filterEndRange"
                          >
                            <v-spacer></v-spacer>
                            <v-btn
                              text
                              color="primary"
                              @click="closestartDatePopup()"
                              >{{ $t("cancelBtnText") }}</v-btn
                            >
                            <v-btn
                              text
                              color="primary"
                              @click="
                                $refs.startDatePopup.save(filterStartRange)
                              "
                              >{{ $t("okBtnText") }}</v-btn
                            >
                          </v-date-picker>
                        </v-menu>
                      </v-col>
                      <v-col cols="10" class="todate">
                        <v-menu
                          ref="endDatePopup"
                          v-model="endDatePopup"
                          :close-on-content-click="false"
                          :return-value.sync="filterEndRange"
                          transition="scale-transition"
                          offset-y
                          min-width="290px"
                        >
                          <template v-slot:activator="{ on }">
                            <v-text-field
                              autocomplete="off"
                              id="user_loyaltyAdmin_filterEndRangeFormated"
                              readonly
                              v-model="endDateFormatted"
                              @blur="
                                filterEndRange = parseDate(endDateFormatted)
                              "
                              :label="$t('toLabel')"
                              append-icon="mdi-calendar-range"
                              v-on="on"
                              class="darktxtfield__light"
                              filled
                            ></v-text-field>
                          </template>
                          <v-date-picker
                            v-model="filterEndRange"
                            no-title
                            scrollable
                            :min="filterStartRange"
                          >
                            <v-spacer></v-spacer>
                            <v-btn
                              text
                              color="primary"
                              @click="closeendDatePopup()"
                              >{{ $t("cancelBtnText") }}</v-btn
                            >
                            <v-btn
                              text
                              color="primary"
                              @click="$refs.endDatePopup.save(filterEndRange)"
                              >{{ $t("okBtnText") }}</v-btn
                            >
                          </v-date-picker>
                        </v-menu>
                      </v-col>
                    </v-row>
                  </v-col>
                  <v-col cols="5" class="bpl6">
                    <h3>{{ $t("channel") }}</h3>
                    <v-row no-gutters>
                      <v-col cols="5">
                        <v-checkbox
                          id="viewuser_chk_active"
                          class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                          :label="$t('Email')"
                          value="1"
                          v-model="selectedStatusFilterActive"
                        ></v-checkbox>
                        <v-checkbox
                          id="viewuser_chk_active"
                          class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                          :label="$t('Sms')"
                          :disabled="true"
                          value="Active"
                          v-model="selectedStatusFilterActive"
                        ></v-checkbox>
                      </v-col>
                      <v-col>
                        <v-checkbox
                          id="viewuser_chk_active"
                          class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                          :label="$t('PushNotification')"
                          value="Active"
                          :disabled="true"
                          v-model="selectedStatusFilterActive"
                        ></v-checkbox>
                        <v-checkbox
                          id="viewuser_chk_active"
                          class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                          :label="$t('LoyaltyMessages')"
                          value="Active"
                          :disabled="true"
                          v-model="selectedStatusFilterActive"
                        ></v-checkbox>
                      </v-col>
                      <v-col cols="12">
                        <h3>{{ $t("bookmark") }}</h3>
                      </v-col>
                      <v-col cols="12">
                        <v-checkbox
                          id="viewuser_chk_active"
                          class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                          :label="$t('showAllBookmarks')"
                          value="Active"
                          :disabled="true"
                          v-model="selectedStatusFilterActive"
                        ></v-checkbox>
                      </v-col>
                    </v-row>
                  </v-col>
                  <v-col cols="3">
                    <h3>{{ $t("statusLabel") }}</h3>
                    <v-row no-gutters>
                      <v-col cols="8">
                        <v-checkbox
                          id="viewuser_chk_active"
                          class="active-checkbox mt-0 checkbox-custom checkbox-custom__light count_checkbox"
                          :label="$t('draftLable')"
                          value="0"
                          v-model="draftStatus"
                        ></v-checkbox>
                        <span class="count_value"
                          >({{ commMsgCompleteRes.draftStatusCount }})</span
                        >
                        <v-checkbox
                          id="viewuser_chk_inActive"
                          class="active-checkbox mt-0 checkbox-custom checkbox-custom__light count_checkbox"
                          :label="$t('publishedLable')"
                          value="1"
                          v-model="publishStatus"
                        ></v-checkbox>
                        <span class="count_value"
                          >({{ commMsgCompleteRes.publishedStatusCount }})</span
                        >
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </template>
              <template v-slot:footer>
                <v-btn
                  text
                  :title="$t('resetAll')"
                  class="cancel bmt3 float-left btn-hover-none bpl0"
                  @click="resetAllFilters()"
                >
                  {{ $t("resetAll") }}
                </v-btn>
                <v-btn
                  text
                  :title="$t('clearBtnText')"
                  class="mr-5 cancel bmt3"
                  id="viewuser_btn_clear"
                  @click="hideFilter()"
                  >{{ $t("clearBtnText") }}</v-btn
                >
                <v-btn
                  depressed
                  :title="$t('filterBtnText')"
                  class="next bmt3 primaryctabtn"
                  @click="filterCommMsg"
                  id="viewuser_btn_apply_filter"
                  >{{ $t("filterBtnText") }}</v-btn
                >
              </template>
            </brierley-filter-result>
          </v-col>
        </v-row>
        <communication-grid-view
          v-if="viewType == 'grid_view'"
          :commlistdata="getCommMsgListRes"
          :filterCount="filterCount"
          @onBookmarked="onBookmarked"
        />
        <communication-table-view
          v-if="viewType == 'table_view'"
          :commlistdata="getCommMsgListRes"
          :filterCount="filterCount"
          @onBookmarked="onBookmarked"
        />
      </v-col>
    </v-row>
    <v-col align="center">
      <loadmore
        :loadingText="$t('loading')"
        v-if="loadmore"
        id="viewuser_loadmore"
        class="margin-auto"
      />
    </v-col>
  </v-col>
</template>
<script>
import {
  BrierleyFilter,
  BrierleyFilterResult,
  BrierleyViewOption,
  Loadmore
} from '@brierley/SharedComponents';
import CommunicationGridView from './views/CommMsgGidView';
import alertPopUp from './child/alertPopUp.vue';
import CommunicationTableView from './views/CommMsgTableView';
import { communicationLanguageObj } from '../../../i18n/language.js';
import deletePopUp from './child/deletePopUp.vue';
import { mapState } from 'vuex';
import _ from 'lodash';
export default {
  components: {
    BrierleyFilter,
    BrierleyFilterResult,
    BrierleyViewOption,
    alertPopUp,
    CommunicationGridView,
    CommunicationTableView,
    Loadmore,
    deletePopUp
  },
  i18n: communicationLanguageObj,
  data () {
    return {
      templatesArr: [],
      selectedStatusFilterActive: null,
      publishStatus: null,
      draftStatus: null,
      filterStartRange: null,
      filterEndRange: null,
      startDate: '',
      endDate: '',
      loadmore: true,
      isHidden: false,
      searchText: '',
      isTyping: false,
      viewType: '',
      alertData: '',
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('GridView')
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('TableView')
        }
      ]
    };
  },
  methods: {
    onBookmarked (val) {
      let commMsgBookMarkInput = {
        referenceId: val.commMsgId,
        targetTableName: 'commmsg'
      };
      this.$store
        .dispatch(
          'communicationManagementModule/commMsgBookmarkAction',
          commMsgBookMarkInput
        )
        .then(() => {
          this.$store.dispatch(
            'communicationManagementModule/getCommMsgListAction',
            this.params
          );
        });
    },
    searchInit (searchText) {
      this.params.searchText = searchText;
      this.params.searchText =
        searchText === '' || searchText === undefined
          ? ''
          : this.params.searchText;
      this.params.pageNumber = 1;
      this.params.pageSize = 10;
      this.$store.dispatch(
        'communicationManagementModule/getCommMsgListAction',
        this.params
      );
    },
    filterCommMsg () {
      if (this.draftStatus !== null || this.publishStatus !== null) {
        if (this.draftStatus !== null && this.publishStatus === null) {
          this.params.draftStatus = '&Status=' + this.draftStatus;
        } else if (this.draftStatus === null && this.publishStatus !== null) {
          this.params.draftStatus = '&Status=' + this.publishStatus;
        } else {
          this.params.draftStatus = '';
        }
      } else {
        this.params.draftStatus = '';
      }
      this.params.status = !this.selectedStatusFilterActive
        ? ''
        : '&ChannelId=' + parseInt(this.selectedStatusFilterActive);
      this.params.pageNumber = 1;
      this.params.pageSize = 10;
      this.startDate = !this.filterStartRange
        ? ''
        : '&FromDate=' + this.filterStartRange;
      this.endDate = !this.filterEndRange
        ? ''
        : '&ToDate=' + this.filterEndRange;
      this.params.filterStartRange = this.startDate;
      this.params.filterEndRange = this.endDate;
      this.isHidden = false;
      this.$store.dispatch(
        'communicationManagementModule/getCommMsgListAction',
        this.params
      );
    },
    resetAllFilters () {
      this.selectedStatusFilterActive = null;
      this.publishStatus = null;
      this.draftStatus = null;
      this.filterStartRange = null;
      this.filterEndRange = null;
      this.startDate = '', this.endDate = '';
      this.filterCommMsg();
    },
    onScroll () {
      window.onscroll = () => {
        if (
          document.documentElement.scrollHeight ===
          document.documentElement.scrollTop + window.innerHeight
        ) {
          this.params.pageSize += 10;
          this.commMsgList();
        }
      };
    },
    commMsgList () {
      this.loadmore = true;
      if (
        this.params.pageNumber * this.params.pageSize <
        this.userCountRes + 12
      ) {
        this.$store.dispatch(
          'communicationManagementModule/getCommMsgListAction',
          this.params
        );
        this.$store.commit(
          'communicationManagementModule/showAlertPopUpDialogueMutation',
          false
        );
        this.$store.dispatch(
          'communicationManagementModule/getAllProgramStatusForCommunication'
        );
      } else {
        this.loadmore = false;
      }
    },
    hideFilter () {
      this.isHidden = false;
    },
    redirectCommManagement () {
      let id = localStorage.getItem('programId');
      this.$store.dispatch('communicationManagementModule/programIdAction', id);
      this.$store
        .dispatch(
          'communicationManagementModule/getChannelByProgramAction',
          this.programId
        )
        .then(res => {
          if (res.status === 201 || res.status === 200) {
            this.$router.push('CommunicationsManagement');
          }
        })
        .catch(err => {
          if (err.response.status === 400 || err.response.status === 404) {
            let programId = this.programId;
            let programName = this.allProgramStatusListForCommunication.filter(
              x => x.programId === programId
            );
            this.alertData =
              this.$t('pgmErrorTxt') +
              programName[0].name +
              this.$t('adminContactTxt');
            this.$store.commit(
              'communicationManagementModule/alertPopUpDialogueMsgMutation',
              this.alertData
            );
            this.$store.commit(
              'communicationManagementModule/showAlertPopUpDialogueMutation',
              true
            );
          }
        });
    },
    formatDate (date) {
      if (!date) return null;
      const [year, month, day] = date.split('-');
      return `${month}/${day}/${year}`;
    },
    globalProgramAction () {
      this.params.ProgramId = localStorage.getItem('programId');
      this.params.searchText = '';
      this.$store.dispatch(
        'communicationManagementModule/getCommMsgListAction',
        this.params
      );
      this.$store.commit(
        'communicationManagementModule/showAlertPopUpDialogueMutation',
        false
      );
      this.$store.dispatch(
        'communicationManagementModule/getAllProgramStatusForCommunication'
      );
      this.commMsgList();
      window.addEventListener('scroll', this.onScroll);
    },
    getData (val) {
      this.templatesArr = val.data.data;
      this.$store.commit(
        'communicationManagementModule/templateArrMutation',
        this.templatesArr
      );
    }
  },
  watch: {
    '$root.GlobalStoreEventStore.state.programList' () {
      this.globalProgramAction();
    },
    userDataRes () {
      if (
        this.userDataRes.defaultListView === 'grid' ||
        this.userDataRes.defaultListView === 'GridView'
      ) {
        this.viewType = 'grid_view';
      } else if (
        this.userDataRes.defaultListView === 'table' ||
        this.userDataRes.defaultListView === 'TableView'
      ) {
        this.viewType = 'table_view';
      } else {
        this.viewType = 'grid_view';
      }
    },
    filterStartRange () {
      this.startDateFormatted = this.formatDate(this.filterStartRange);
    },
    filterEndRange () {
      this.endDateFormatted = this.formatDate(this.filterEndRange);
    },
    getCommMsgListRes () {
      if (this.userCountRes === 0) {
        this.loadmore = false;
      }
      this.loadmore = false;
    },
    searchText: function () {
      const self = this;
      _.debounce(function () {
        self.isTyping = false;
        self.params.pageNumber = 1;
      }, 3000)();
    },
    isTyping: function (value) {
      if (this.searchText === '') {
        this.params.searchText = '';
      }
      if (!value) {
        this.searchInit(this.searchText);
      }
    }
  },
  created () {
    let userId = localStorage.getItem('userId');
    this.$store.dispatch('communicationManagementModule/getUserData', userId);
  },
  mounted () {
    this.$store.dispatch('communicationManagementModule/getMessageAttribute');
    this.params.ProgramId = localStorage.getItem('programId');
    let id = localStorage.getItem('programId');
    this.$store
      .dispatch('communicationManagementModule/getChannelByProgramAction', id)
      .then(res => {
        this.$store.commit(
          'communicationManagementModule/setProviderNameMutation',
          res.data.data[0].providerName
        );
        this.$store
          .dispatch(
            'communicationManagementModule/getCommunicationsMsgTemplates',
            res.data.data[0].providerName
          )
          .then(res => {
            if (res) {
              this.getData(res);
            }
          });
      });
    this.params.searchText = '';
    this.$store.dispatch('communicationManagementModule/programIdAction', id);
    this.$store.dispatch(
      'communicationManagementModule/getCommMsgListAction',
      this.params
    );
    this.$store.commit(
      'communicationManagementModule/showAlertPopUpDialogueMutation',
      false
    );
    this.$store.dispatch(
      'communicationManagementModule/getAllProgramStatusForCommunication'
    );
    this.commMsgList();
    window.addEventListener('scroll', this.onScroll);
  },
  beforeDestroy () {
    window.removeEventListener('scroll', this.onScroll);
  },
  computed: {
    ...mapState('communicationManagementModule', [
      'getCommMsgListRes',
      'params',
      'userCountRes',
      'showAlertPopUpDialogue',
      'showDeletePopUp',
      'allProgramStatusListForCommunication',
      'alertMsg',
      'userDataRes',
      'commMsgCompleteRes',
      'filterCount',
      'programId'
    ])
  }
};
</script>

<style lang="scss" scoped>
.create-communication {
  background: #f5f5f5;
  position: relative;
  margin-top: 54px;
  border-radius: 0 40px 0 0;
  &__info {
    max-width: 368px;
  }
  &__title {
    font-size: 35px !important;
    font-weight: 300;
    line-height: normal;
    span {
      font-size: 35px !important;
      font-weight: bold;
    }
  }
  img {
    position: absolute;
    right: -24px;
    bottom: 40px;
  }
}
.text-left {
  float: left;
}
.count_checkbox {
  display: inline-block;
}
.count_value {
  display: inline-block;
  position: relative;
  bottom: 6px;
  left: 6px;
  min-width: 70px;
}
</style>
