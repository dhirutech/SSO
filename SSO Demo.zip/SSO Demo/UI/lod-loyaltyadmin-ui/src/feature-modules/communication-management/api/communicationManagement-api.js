import Vue from 'vue';

const getCommunicationsMessageTemplates = payload => {
  debugger
  return Vue.prototype.$http.get(
    '/communication/api/v1/communicationmanagement/getmessagetemplates/' +
      payload
  );
};

const saveDeliveryChannelData = payload => {
  debuuger
  return Vue.prototype.$http.post(
    'communication/api/v1/communicationmanagement/savemessage',
    payload
  );
};

const getCommunicationsProviderMessageFields = payload => {
  debugger
  return Vue.prototype.$http.get(
    'communication/api/v1/providerconfiguration/getattributes/' +
      payload.provider +
      '/' +
      payload.id
  );
};

const getChannelByProgram = payload => {
  debugger
  return Vue.prototype.$http.get(
    'communication/api/v1/providerconfiguration/channelsbyprogram/' + payload
  );
};
const getChannelProviderData = () => {
  debugger
  return Vue.prototype.$http.get(
    'communication/api/v1/providerconfiguration/getchannelsandproviders'
  );
};
const getMessageAttributeData = () => {
  debugger
  return Vue.prototype.$http.get(
    'communication/api/v1/communicationmanagement/getmessageattribute'
  );
};

const nameExistsOrNot = payload => {
  debugger
  return Vue.prototype.$http.get(
    'communication/api/v1/communicationmanagement/ismessageexist/' +
      payload.pgmId +
      '/' +
      payload.name
  );
};

const commMsgBookmark = payload => {
  debugger
  return Vue.prototype.$http.post(
    'communication/api/v1/bookmark/userbookmark/' +
      payload.referenceId +
      '/' +
      payload.targetTableName
  );
};

const getAllProgramStatusForCommunicationManagement = () => {
  debugger
  return Vue.prototype.$http.get('loyaltyconfiguration/api/v1/programs');
};

const getCommMsgSearch = payload => {
  debugger
  return Vue.prototype.$http.get(
    'communication/api/v1/communicationmanagement/getall?ProgramId=' +
      payload.ProgramId +
      '&PageSize=' +
      payload.pageSize +
      '&PageNumber=' +
      payload.pageNumber +
      '&SearchText=' +
      payload.searchText +
      payload.filterStartRange +
      payload.filterEndRange +
      payload.status +
      payload.draftStatus
  );
};

const getUserApi = userId => {
  return Vue.prototype.$http.get('https://localhost:44305/identity/api/v1/users/' + userId);
};

const getCommunicationsIdResponse = payload => {
  debugger
  return Vue.prototype.$http.get(
    '/communication/api/v1/communicationmanagement/getmessage/' + payload
  );
};

const deleteCommMessage = payload => {
  debugger
  return Vue.prototype.$http.delete(
    'communication/api/v1/communicationmanagement/deletemessage/' + payload
  );
};

const testTemplateData = payload => {
  debugger
  return Vue.prototype.$http.post(
    'communication/api/v1/communicationmanagement/sendsingleemail',
    payload
  );
};

const getEmailSubjectData = payload => {
debugger 
 return Vue.prototype.$http.get(
    'communication/api/v1/communicationmanagement/getmessageheader/' + payload
  );
};

export {
  testTemplateData,
  getEmailSubjectData,
  commMsgBookmark,
  getCommunicationsMessageTemplates,
  saveDeliveryChannelData,
  getCommunicationsProviderMessageFields,
  getChannelProviderData,
  getMessageAttributeData,
  getCommMsgSearch,
  getCommunicationsIdResponse,
  getChannelByProgram,
  nameExistsOrNot,
  getAllProgramStatusForCommunicationManagement,
  deleteCommMessage,
  getUserApi
};
