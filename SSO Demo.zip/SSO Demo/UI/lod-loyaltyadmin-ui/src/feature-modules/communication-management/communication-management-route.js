import CommunicationLayout from './components/communicationLayout.vue';
import communicationDashboard from './components/communicationDashboard.vue';
import CommunicationsManagementPreview from './components/CommunicationPersonalizationPreview.vue';

const communicationManagementRoutes = [
  {
    path: '/loyaltyadmin/CommunicationsManagementnew',
    name: 'CommunicationLayoutNew',
    component: CommunicationLayout,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/communicationsnew',
    name: 'communicationDashboardNew',
    component: communicationDashboard,
    meta: {
      showNavigation: true
    }
  },
  {
    path: '/loyaltyadmin/CommunicationsManagementEditnew',
    name: 'CommunicationsManagementEditNew',
    component: CommunicationLayout,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/CommunicationsManagementPreviewnew',
    name: 'CommunicationsManagementPreviewNew',
    component: CommunicationsManagementPreview,
    meta: {
      showNavigation: false
    }
  }
];

export default communicationManagementRoutes;
