import {
  getCommunicationsMessageTemplates,
  saveDeliveryChannelData,
  getCommunicationsProviderMessageFields,
  getChannelProviderData,
  getChannelByProgram,
  getMessageAttributeData,
  getCommMsgSearch,
  getCommunicationsIdResponse,
  deleteCommMessage,
  nameExistsOrNot,
  commMsgBookmark,
  getAllProgramStatusForCommunicationManagement,
  testTemplateData,
  getUserApi,
  getEmailSubjectData
} from '../api/communicationManagement-api';

const testTemplateAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    testTemplateData(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getAllProgramStatusForCommunication = context => {
  return new Promise((resolve, reject) => {
    getAllProgramStatusForCommunicationManagement()
      .then(res => {
        resolve(res);
        context.commit('getAllProgramsCommunicationMutation', res.data);
      })
      .catch(err => {
        reject(err);
        if (err.response.status === 400 || err.response.status === 404) {
          context.commit(
            'getAllProgramsCommunicationMutation',
            err.response.data.data
          );
        }
      });
  });
};

const checkNameExistingOrNotAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    nameExistsOrNot(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getCommunicationsMsgTemplates = (context, payload) => {
  return new Promise((resolve, reject) => {
    getCommunicationsMessageTemplates(payload)
      .then(result => {
        resolve(result);
        if (result.data.data.length > 0) {
          result.data.data.forEach(res => {
            res.isSelected = false;
          });
        }
        context.commit('communicationMsgListMutation', result.data.data);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getCommunicationsProviderMsgFields = (context, payload) => {
  return new Promise((resolve, reject) => {
    getCommunicationsProviderMessageFields(payload)
      .then(res => {
        resolve(res);
        context.commit('communicationsProviderMessageFields', res.data.data);
      })
      .catch(err => {
        reject(err);
      });
  });
};
const getChannelByProgramAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getChannelByProgram(payload)
      .then(res => {
        resolve(res);
        let deliveryChannelData = [];
        deliveryChannelData = [
          {
            channelList: [
              {
                name: res.data.data[0].channelName.toUpperCase(),
                Id: res.data.data[0].channelId,
                isSelected: true,
                icon: 'mail'
              }
            ],
            providersList: [
              {
                name: res.data.data[0].providerName
              }
            ]
          }
        ];
        context.commit('deliveryChannelDataMutation', deliveryChannelData);
      })
      .catch(err => {
        reject(err);
      });
  });
};
const saveDeliveryChannelDraft = (context, payload) => {
  return new Promise((resolve, reject) => {
    saveDeliveryChannelData(payload)
      .then(res => {
        resolve(res);
        context.commit(
          'testMessageTemplateIdMutation',
          res.data.data.templateId
        );
        context.commit('commonMessageIdMutation', res.data.data.commMessageId);
        context.commit('commonMessageSuccessResponseMutation', res.data.data);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const commMsgBookmarkAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    commMsgBookmark(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getCommListDataAction = (context, payload) => {
  let obj = {
    ProgramId: payload,
    pageSize: 10,
    pageNumber: 1,
    searchText: '',
    filterEndRange: '',
    filterStartRange: '',
    status: '',
    draftStatus: ''
  };
  return new Promise((resolve, reject) => {
    getCommMsgSearch(obj)
      .then(result => {
        resolve(result);
        context.commit(
          'userSearchListMutation',
          result.data.data.commMessageProps
        );
        context.commit('userCountMutation', result.data.data);
      })
      .catch(err => {
        reject(err);
        if (err.response.status === 400 || err.response.status === 404) {
          context.commit(
            'userSearchListMutation',
            err.response.data.data.commMessageProps
          );
          context.commit('userCountMutation', err.response.data.data);
          context.commit('loadMore', false);
        }
      });
  });
};
const getChannelProviderDataAction = context => {
  getChannelProviderData().then(channelProviderDataRes => {
    let deliveryChannelData = [];
    deliveryChannelData = [
      {
        channelList: [
          {
            name: channelProviderDataRes.data.data.channelsList[0].name.toUpperCase(),
            Id: channelProviderDataRes.data.data.channelsList[0].channelId,
            isSelected: true,
            icon: 'mail'
          }
        ],
        providersList: [
          {
            providerId:
              channelProviderDataRes.data.data.providersList[0].providerId,
            name: channelProviderDataRes.data.data.providersList[0].name
          }
        ]
      }
    ];
    context.commit('deliveryChannelDataMutation', deliveryChannelData);
  });
};

const deleteCommMsgAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    deleteCommMessage(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};
const getUserData = (context, payload) => {
  getUserApi(payload)
    .then(res => {
      context.commit('userData', res.data.userAccountPreference);
    })
    .catch();
};
const setCommunicationObjAction = (context, payload) => {
  context.commit('setCommunicationObjMutation', payload);
};

const goToCommMsgBtnAction = (context, payload) => {
  context.commit('goToCommMsgMutation', payload);
};

const programIdAction = (context, payload)=>{
  context.commit('programIdMutation', payload);
};

const ReviewDataAction = (context, payload) => {
  context.commit('ReviewDataMutation', payload);
};
const providerObjAction = (context, payload) => {
  context.commit('providerObjMutation', payload);
};
const selectedProgramIdAction = (context, payload) => {
  context.commit('selectedProgramIdMutation', payload);
};
const getMessageAttribute = (context, payload) => {
  getMessageAttributeData(payload)
    .then(result => {
      context.commit('getMessageAttributeMutation', result.data.data);
    })
    .catch();
};
const getCommMsgListAction = (context, value) => {
  return new Promise((resolve, reject) => {
    getCommMsgSearch(value)
      .then(result => {
        resolve(result);
        context.commit(
          'userSearchListMutation',
          result.data.data.commMessageProps
        );
        context.commit('userCountMutation', result.data.data);
      })
      .catch(err => {
        reject(err);
        if (err.response.status === 400 || err.response.status === 404) {
          context.commit(
            'userSearchListMutation',
            err.response.data.data.commMessageProps
          );
          context.commit('userCountMutation', err.response.data.data);
          context.commit('loadMore', false);
        }
      });
  });
};

const editCommunicationManagementAction = (context, payload) => {
  getCommunicationsIdResponse(payload)
    .then(result => {
      let communicationEditDetails = {
        communicationName: result.data.data.name,
        communicationDescription: result.data.data.description
      };
      let commMessageIdEdit = result.data.data.commMessageId;
      let deliveryEditChannelData = [
        {
          channelList: [
            {
              name: 'EMAIL',
              Id: result.data.data.commChannelId,
              isSelected: true,
              icon: 'mail'
            }
          ],
          providersList: [
            {
              providerId: 1,
              name: 'MAPP'
            }
          ]
        }
      ];
      let obj = {};
      obj.commChannelId = result.data.data.commChannelId;
      obj.commMessageId = result.data.data.commMessageId;
      obj.createdDate = result.data.data.createdDate;
      obj.description = result.data.data.description;
      obj.messagePersonalizations = result.data.data.messagePersonalizations;
      obj.name = result.data.data.name;
      obj.programId = result.data.data.programId;
      obj.status = result.data.data.status;
      obj.templateId = result.data.data.templateId;
      obj.updatedDate = result.data.data.updatedDate;
      context.commit('editResMutation', obj);
      context.commit('commonMessageSuccessResponseMutation', obj);
      context.commit(
        'personalisationMutation',
        result.data.data.messagePersonalizations
      );
      context.commit('templateIdEditMutation', result.data.data.templateId);
      context.commit('commonMessageIdEditMutation', commMessageIdEdit);
      context.commit(
        'communicationEditDetailsMutation',
        communicationEditDetails
      );
      context.commit(
        'deliveryEditChannelDataMutation',
        deliveryEditChannelData
      );
    })
    .catch();
};

const getPreviewDetailsAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getCommunicationsIdResponse(payload)
      .then(res => {
        resolve(res);
        context.commit('templateIdEditMutation', res.data.data.templateId);
        context.commit(
          'personalisationMutation',
          res.data.data.messagePersonalizations
        );
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getEmailSubjectAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getEmailSubjectData(payload[0].groupId)
      .then(res => {
        resolve(res);
        res.data.data.subjectLine = payload[0].subjectLine;
        context.commit('setEmailSubjectMutation', res.data.data);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export default {
  getCommListDataAction,
  getCommunicationsMsgTemplates,
  deleteCommMsgAction,
  getEmailSubjectAction,
  saveDeliveryChannelDraft,
  programIdAction,
  getPreviewDetailsAction,
  ReviewDataAction,
  checkNameExistingOrNotAction,
  goToCommMsgBtnAction,
  getChannelByProgramAction,
  providerObjAction,
  selectedProgramIdAction,
  setCommunicationObjAction,
  getCommunicationsProviderMsgFields,
  getChannelProviderDataAction,
  getMessageAttribute,
  commMsgBookmarkAction,
  getCommMsgListAction,
  editCommunicationManagementAction,
  getAllProgramStatusForCommunication,
  testTemplateAction,
  getUserData
};
