const setCommunicationCurrentStep = (state, payload) => {
  state.communicationCurrentStep = payload;
};
const communicationMsgListMutation = (state, payload) => {
  state.communicationMsgList = payload;
};
const showPopUpDialogueMutation = (state, payload) => {
  state.showPopUpDialogue = payload;
};
const showAlertPopUpDialogueMutation = (state, payload) => {
  state.showAlertPopUpDialogue = payload;
};
const nameExistsOrNotMutation = (state, payload) => {
  state.nameExistsOrNot = payload;
};
const getAllProgramsCommunicationMutation = (state, payload) => {
  state.allProgramStatusListForCommunication = payload;
};
const alertPopUpDialogueMsgMutation = (state, payload) => {
  state.alertMsg = payload;
};

const deliveryChannelDataMutation = (state, payload) => {
  state.providerRes = payload[0].providersList;
  state.communicationDetails.deliveryChannelType = payload[0].channelList[0].Id;
  state.deliveryChannelData = payload;
};
const selectedProgramIdMutation = (state, payload) => {
  state.selectedProgramId = payload;
};
const providerObjMutation = (state, payload) => {
  state.providerData = payload;
};
const setCommunicationObjMutation = (state, payload) => {
  state.communicationDetails = payload;
};
const communicationsProviderMessageFields = (state, payload) => {
  state.communicationsProviderMessageFieldsList = payload;
};
const commonMessageIdMutation = (state, payload) => {
  state.commonMessageId = payload;
};
const commonMessageIdEditMutation = (state, payload) => {
  state.commonMessageId = payload;
};
const templateIdEditMutation = (state, payload) => {
  state.templateIdEdit = parseInt(payload);
};
const commonMessageSuccessResponseMutation = (state, payload) => {
  state.commonMessageSuccessResponse = payload;
};
const selectedMsgMutation = (state, payload) => {
  state.selectedMessage = payload;
  state.selectedMsg = payload;
};
const getMessageAttributeMutation = (state, payload) => {
  state.getMessageAttributeRes = payload;
};
const memberAttributeMutation = (state, payload) => {
  state.memberAttributeList = payload;
};
const ReviewDataMutation = (state, payload) => {
  state.reviewData = payload;
};
const userSearchListMutation = (state, payload) => {
  state.getCommMsgListRes = payload;
};
const showDeletePopUpDialogueMutation = (state, payload) => {
  state.showDeletePopUp = payload;
};
const userCountMutation = (state, payload) => {
  state.commMsgCompleteRes = payload;
  state.filterCount = payload.filterListCount;
  state.userCountRes = payload.publishedStatusCount + payload.draftStatusCount;
};

const communicationEditDetailsMutation = (state, payload) => {
  state.communicationDetails.communicationName = payload.communicationName;
  state.communicationDetails.communicationDescription =
    payload.communicationDescription;
};
const deliveryEditChannelDataMutation = (state, payload) => {
  state.deliveryChannelData = payload;
};

const personalizationBtnStatusMutation = (state, payload) => {
  state.personalizationBtnStatus = payload;
};

const goToCommMsgMutation = (state, payload) => {
  state.goToCommMsgBtn = payload;
};
const deleteCommMessageIdMutation = (state, payload) => {
  state.deleteCommMsgId = payload;
};

const personalisationMutation = (state, payload) => {
  state.personalisation = payload;
};

const testMessageTemplateIdMutation = (state, payload) => {
  state.testMessageId = payload;
};

const testMessageStepMutation = (state, payload) => {
  state.testMessageStep = payload;
};

const templateErrorMutation = (state, payload) => {
  state.templateError = payload;
};

const newMsgInEdit = (state, payload) => {
  state.newMsgInEditRes = payload;
};

const programIdMutation = (state, payload)=>{
  state.programId = parseInt(payload);
};

const btnDisableMutation = (state, payload)=>{
  state.btnDisable = payload;
};

const viewTypeMutation = (state, payload) => {
  state.viewType = payload;
};

const userData = (state, payload) => {
  state.userDataRes = payload;
};

const cardViewEnableMutation = (state, payload) => {
  state.cardViewEnb = payload;
};

const editResMutation = (state, payload) => {
  state.editRes = payload;
};

const localSelectMsg = (state, payload) => {
  state.localSelectMsgRes = payload;
};

const setEmailSubjectMutation = (state, payload) => {
  state.messageDetails = payload;
};

const messageDataMutation = (state, payload) => {
  state.messageData = payload;
};

const commObjectArrayMutation = (state, payload) => {
  state.commObjectArray = payload;
};

const setProviderNameMutation = (state, payload) => {
  state.providerName = payload;
};

const templateArrMutation = (state, payload) => {
  state.templateArr = payload;
};

const selectedTemplatesArrMutation = (state, payload) => {
  state.selectedTemplatesArr = payload;
};

export default {
  selectedTemplatesArrMutation,
  templateArrMutation,
  setProviderNameMutation,
  commObjectArrayMutation,
  messageDataMutation,
  localSelectMsg,
  setEmailSubjectMutation,
  editResMutation,
  personalisationMutation,
  cardViewEnableMutation,
  btnDisableMutation,
  programIdMutation,
  viewTypeMutation,
  testMessageTemplateIdMutation,
  deleteCommMessageIdMutation,
  alertPopUpDialogueMsgMutation,
  showDeletePopUpDialogueMutation,
  setCommunicationCurrentStep,
  ReviewDataMutation,
  goToCommMsgMutation,
  templateErrorMutation,
  nameExistsOrNotMutation,
  testMessageStepMutation,
  communicationMsgListMutation,
  showAlertPopUpDialogueMutation,
  showPopUpDialogueMutation,
  providerObjMutation,
  commonMessageIdEditMutation,
  selectedProgramIdMutation,
  setCommunicationObjMutation,
  communicationsProviderMessageFields,
  deliveryChannelDataMutation,
  commonMessageIdMutation,
  selectedMsgMutation,
  templateIdEditMutation,
  getMessageAttributeMutation,
  memberAttributeMutation,
  commonMessageSuccessResponseMutation,
  userSearchListMutation,
  userCountMutation,
  communicationEditDetailsMutation,
  deliveryEditChannelDataMutation,
  personalizationBtnStatusMutation,
  getAllProgramsCommunicationMutation,
  userData,
  newMsgInEdit
};
