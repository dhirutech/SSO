import Vue from 'vue';

let mlist = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sept',
  'Oct',
  'Nov',
  'Dec'
];

// created on
Vue.filter('filterDate', function (value) {
  let dateNumber = new Date(value);
  if (value === null || value === undefined) return 'N/A';
  let dateNumberOridinal = dateNumber.getDate();
  if (dateNumberOridinal > 3 && dateNumberOridinal < 21)
    return (
      mlist[dateNumber.getMonth()] +
      ' ' +
      dateNumberOridinal +
      'th' +
      ' ' +
      dateNumber.getFullYear()
    );

  switch (dateNumberOridinal % 10) {
  case 1:
    return (
      mlist[dateNumber.getMonth()] +
        ' ' +
        dateNumberOridinal +
        'st' +
        ' ' +
        dateNumber.getFullYear()
    );
  case 2:
    return (
      mlist[dateNumber.getMonth()] +
        ' ' +
        dateNumberOridinal +
        'nd' +
        ' ' +
        dateNumber.getFullYear()
    );
  case 3:
    return (
      mlist[dateNumber.getMonth()] +
        ' ' +
        dateNumberOridinal +
        'rd' +
        ' ' +
        dateNumber.getFullYear()
    );
  default:
    return (
      mlist[dateNumber.getMonth()] +
        ' ' +
        dateNumberOridinal +
        'th' +
        ' ' +
        dateNumber.getFullYear()
    );
  }
});

// last activity
Vue.filter('lastLoginTime', function (value) {
  if (value === null || value === undefined) return ' ';
  let dateNumber = new Date(value);
  let dateNumberOridinal = dateNumber.getDate();
  if (dateNumberOridinal > 3 && dateNumberOridinal < 21)
    return (
      mlist[dateNumber.getMonth()] +
      ' ' +
      dateNumberOridinal +
      'th' +
      ' ' +
      dateNumber.getFullYear() +
      ' ' +
      dateNumber.getHours() +
      ':' +
      dateNumber.getMinutes() +
      '  EST'
    );

  switch (dateNumberOridinal % 10) {
  case 1:
    return (
      mlist[dateNumber.getMonth()] +
        ' ' +
        dateNumberOridinal +
        'st' +
        ' ' +
        dateNumber.getFullYear() +
        ':' +
        dateNumber.getMinutes() +
        '  EST'
    );
  case 2:
    return (
      mlist[dateNumber.getMonth()] +
        ' ' +
        dateNumberOridinal +
        'nd' +
        ' ' +
        dateNumber.getFullYear() +
        ':' +
        dateNumber.getMinutes() +
        '  EST'
    );
  case 3:
    return (
      mlist[dateNumber.getMonth()] +
        ' ' +
        dateNumberOridinal +
        'rd' +
        ' ' +
        dateNumber.getFullYear() +
        ':' +
        dateNumber.getMinutes() +
        '  EST'
    );
  default:
    return (
      mlist[dateNumber.getMonth()] +
        ' ' +
        dateNumberOridinal +
        'th' +
        ' ' +
        dateNumber.getFullYear() +
        ':' +
        dateNumber.getMinutes() +
        '  EST'
    );
  }
});

// initials
Vue.filter('initials', function (data) {
  let names = data.split(' '),
    initials = names[0].substring(0, 1).toUpperCase();
  if (names.length > 1) {
    initials += names[names.length - 1].substring(0, 1).toUpperCase();
  }
  return initials;
});
