import Vue from 'vue';

const getUsersSearch = (parameters) => {
  return Vue.prototype.$http.get(
    '/identity/api/v2/users/getall?PageNumber=' +
      parameters.pageNumber +
      '&SearchText=' +
      encodeURIComponent(parameters.searchText) +
      '&PageSize=' +
      parameters.pageSize +
      '&NameSortType=' +
      parameters.nameSortType +
      '&EmailSortType=' +
      parameters.emailSortType +
      '&ExternalIdSortType=' +
      parameters.externalIdSortType +
      '&StatusSortType=' +
      parameters.statusSortType +
      parameters.status +
      parameters.filterStartRange +
      parameters.filterEndRange +
      parameters.selectedProgramId +
      parameters.selectedRoleId
  );
};

const setdeactivateUser = (parameters) => {
  return Vue.prototype.$http.delete('/identity/api/v1/users/' + parameters);
};

const updateUserStatus = (userId) => {
  return Vue.prototype.$http.patch('/identity/api/v2/users/' + userId);
};

const getAccessReportDataAPI = (parameters) => {
  return Vue.prototype.$http.get(`https://kona-dev-api.brierleycloud.net/identity/api/v2/users/get/accessReport?PageSize=${parameters.pageSize}&PageNumber=${parameters.pageNumber}`);
};

const getAccessReportDataSearchAPI= (searchText) => {
  return Vue.prototype.$http.get(`https://kona-dev-api.brierleycloud.net/identity/api/v2/users/get/accessReport?SearchText=${searchText}`);
};

const fetchRolesDataActionAPI = () => {
  // need to integrate api for roles
  // return Vue.prototype.$http.get('http://localhost:8000/fetchRoles');
};

const fetchProgramsDataActionAPI= () => {
  // need to integrate api for programs
  // return Vue.prototype.$http.get('http://localhost:8000/fetchPrograms');
};

const downloadreportActionAPI = () => {
  return Vue.prototype.$http.get('https://kona-dev-api.brierleycloud.net/identity/api/v2/users/download/accessreport');
};

const accessreportFilterActionAPI = (parameters) => {
  return Vue.prototype.$http.get(`https://kona-dev-api.brierleycloud.net/identity/api/v2/users/get/accessReport?PageSize=${parameters.pageSize}&PageNumber=${parameters.pageNumber}` +
  parameters.selectednoOfDays +
  parameters.filterStartRange +
  parameters.filterEndRange +
  parameters.selectedprogramID +
  parameters.selectedroleID +
  parameters.selectedstatus
  );
};

export {
  getUsersSearch,
  setdeactivateUser,
  updateUserStatus,
  getAccessReportDataAPI,
  fetchRolesDataActionAPI,
  fetchProgramsDataActionAPI,
  getAccessReportDataSearchAPI,
  downloadreportActionAPI,
  accessreportFilterActionAPI
};
