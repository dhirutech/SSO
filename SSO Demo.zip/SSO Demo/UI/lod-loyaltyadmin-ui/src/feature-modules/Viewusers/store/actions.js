import {
  getUsersSearch,
  setdeactivateUser,
  updateUserStatus,
  getAccessReportDataAPI,
  fetchRolesDataActionAPI,
  fetchProgramsDataActionAPI,
  getAccessReportDataSearchAPI,
  downloadreportActionAPI,
  accessreportFilterActionAPI,
} from '../api/viewusers-api';
import Vue from 'vue';

const getUsersListAction = (context, value) => {
  getUsersSearch(value)
    .then((result) => {
      Vue.prototype.$http
        .get('loyaltyconfiguration/api/v1/programs')
        .then((response) => {
          const programsList = response.data;
          if (
            result.data.usersSearchResult.length !== 0 &&
            result.data.userCount !== 0
          ) {
            let count = 1;
            result.data.usersSearchResult.forEach((res) => {
              if (res.userPrograms) {
                if (res.userPrograms.length > 0) {
                  res.userPrograms.forEach((role) => {
                    let roles = {};
                    let roleAssigned = [];
                    let access = '';
                    role.userRoleDetails.forEach((userRole) => {
                      if (access !== '') {
                        access = access + ', ' + userRole.roleName;
                      } else {
                        access = userRole.roleName;
                      }
                      roleAssigned.push(userRole.roleName);
                    });
                    roles['title'] = 'Programs';
                    roles['list'] = [
                      {
                        programId: role.programId,
                        name: role.programName,
                        access: access,
                        options: [
                          {
                            head: 'Role Assigned',
                            items: roleAssigned,
                          },
                        ],
                      },
                    ];
                    if (res.programRoles !== undefined) {
                      if (roles.list.length > 0) {
                        roles.list.forEach((role) => {
                          programsList.filter((program) => {
                            if (role.programId === program.programId) {
                              role.name = program.name;
                            }
                          });
                        });
                      }
                      res.programRoles.list.push(roles.list[0]);
                    } else {
                      if (roles.list.length > 0) {
                        roles.list.forEach((role) => {
                          programsList.filter((program) => {
                            if (role.programId === program.programId) {
                              role.name = program.name;
                            }
                          });
                        });
                      }
                      res.programRoles = roles;
                    }
                  });
                }
              }
              if (count === result.data.usersSearchResult.length) {
                result.pageNumber = value.pageNumber;
                context.commit('userSearchListMutation', result);
              }
              count++;
            });
          } else {
            context.commit('userCountMutation', result);
          }
        });
    })
    .catch();
};

const deactivateUserAction = (context, value) => {
  return new Promise((resolve, reject) => {
    setdeactivateUser(value)
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const getDeleteUserList = (context, value) => {
  getUsersSearch(value).then((res) => {
    context.commit('getDeleteUserListMutations', res);
  });
};

const updateUserStatusAction = (context, value) => {
  return new Promise((resolve, reject) => {
    updateUserStatus(value)
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const getAccessReportDataAction = (context, parameters) => {
  return new Promise((resolve, reject) => {
    getAccessReportDataAPI(parameters)
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const getAccessReportDataSearchAction = (context, value) => {
  return new Promise((resolve, reject) => {
    getAccessReportDataSearchAPI(value)
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const fetchRolesDataAction = () => {
  return new Promise((resolve, reject) => {
    fetchRolesDataActionAPI()
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const fetchProgramsDataAction = () => {
  return new Promise((resolve, reject) => {
    fetchProgramsDataActionAPI()
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const downloadreportAction = () => {
  return new Promise((resolve, reject) => {
    downloadreportActionAPI()
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const accessreportFilterAction = (context, value) => {
  return new Promise((resolve, reject) => {
    accessreportFilterActionAPI(value)
      .then((res) => resolve(res))
      .catch((err) => reject(err));
  });
};

export default {
  getUsersListAction,
  deactivateUserAction,
  getDeleteUserList,
  updateUserStatusAction,
  getAccessReportDataAction,
  fetchRolesDataAction,
  fetchProgramsDataAction,
  getAccessReportDataSearchAction,
  downloadreportAction,
  accessreportFilterAction,
};
