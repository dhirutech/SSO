const getUserList = state => state.userslist;

export default { getUserList };
