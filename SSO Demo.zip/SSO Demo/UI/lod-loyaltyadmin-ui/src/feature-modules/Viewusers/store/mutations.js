const userSearchListMutation = (state, payload) => {
  if (payload.pageNumber === 1) {
    state.userslist = [], state.userslist = payload.data.usersSearchResult;
    state.userCount = payload.data.userCount;
  } else {
    state.userslist = state.userslist.concat(payload.data.usersSearchResult);
    state.userCount = payload.data.userCount;
  }
};

const closepopUpMutation = (state, payload) => {
  state.showdialog = payload;
};

const userCountMutation = (state, payload) => {
  if (
    payload.data.userCount === 0 &&
    payload.data.usersSearchResult.length === 0
  ) {
    state.userCount = payload.data.userCount;
    state.userslist = payload.data.usersSearchResult;
  }
};

const getuserId = (state, payload) => {
  state.userId = payload;
};

const getLoadState = (state, payload) => {
  state.load = payload;
};

const getDeleteUserListMutations = (state, payload) => {
  state.userslist = payload.data.usersSearchResult;
};
const closeEmailPopUpMutation = (state, payload) => {
  state.showEmailDialog = payload;
};
const getAccessReportDatamutation = (state, payload) => {
  if (state.accessReportparams.pageNumber === 1)
    state.accessReportData = payload;
  else {
    for (let index = 0; index < payload.length; index++) {
      state.accessReportData.push(payload[index]);
    }
  }
};

const getAccessReportDataSearchmutation = (state, payload) => {
  state.accessReportData = payload;
};
const resetgetAccessReportDataSearchmutation = (state, payload) => {
  state.accessReportData = payload;
};

const fetchRolesDatamutation = (state, payload) => {
  state.allRolesStatus = payload;
};

const fetchProgramsDatamutation = (state, payload) => {
  state.allPrograms = payload;
};

const resetAccessReportDatamutation = (state) => {
  state.accessReportData.length = 0;
};
const accessreportFilterMutation = (state, payload) => {
  state.accessReportData = payload;
};
export default {
  userSearchListMutation,
  closepopUpMutation,
  getuserId,
  getDeleteUserListMutations,
  getLoadState,
  closeEmailPopUpMutation,
  userCountMutation,
  getAccessReportDatamutation,
  fetchRolesDatamutation,
  fetchProgramsDatamutation,
  getAccessReportDataSearchmutation,
  resetgetAccessReportDataSearchmutation,
  resetAccessReportDatamutation,
  accessreportFilterMutation

};
