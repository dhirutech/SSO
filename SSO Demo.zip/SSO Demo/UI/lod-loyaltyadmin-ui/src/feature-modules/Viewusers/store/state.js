export default {
  moduleVar: 'I am Module',
  dashboard: {},
  userslist: [],
  showdialog: false,
  userId: '',
  userCount: 0,
  params: {
    searchText: null,
    pageSize: 10,
    pageNumber: 1,
    nameSortType: null,
    emailSortType: null,
    externalIdSortType: null,
    statusSortType: null,
    filterEndRange: '',
    filterStartRange: '',
    selectedProgramId: '',
    selectedRoleId: '',
    selectedStatusFilterInactive: '',
    selectedStatusFilterActive: '',
    selectedStatusFilterExpiredLink: '',
    status: ''
  },
  updateUserStatusResult: [],
  showEmailDialog: false,
  accessReportData: [],
  allRolesStatus: [],
  allPrograms: [],
  numberofDays: [
    {
      itemtext: '30 days',
      itemvalue: '30'
    }, {
      itemtext: '60 days',
      itemvalue: '60'
    }, {
      itemtext: '90 days',
      itemvalue: '90'
    }, {
      itemtext: '120 days',
      itemvalue: '120'
    }, {
      itemtext: '180 days',
      itemvalue: '180'
    }
  ],
  accessReportparams: {
    pageNumber: 1,
    pageSize: 10,
    searchText: '',
    filterStartRange: '',
    filterEndRange: '',
    selectedprogramID: '',
    selectedroleID: '',
    selectednoOfDays: '',
    selectedstatus: ''
  }
};
