<template>
  <v-row>
    <v-col
      md="6"
      sm="12"
      xs="12"
      v-for="(user, index) in userlistdata"
      :key="index"
    >
      <brierley-card-with-logo :title="user.name">
        <template v-slot:avatartext>{{ user.name | initials }}</template>
        <template v-slot:heading>
          <h2 class="bmb1 elipsis-fullwidth ">
            {{ user.name === '' ? 'N/A' : user.name }}
          </h2>
        </template>
        <template v-slot:headers>
          <v-col xs="12" sm="7" md="7">
            <p class="elipsis-fullwidth">
              <strong>{{ $t('emailText') }}&nbsp;</strong>
              {{ user.email === '' ? 'N/A' : user.email }}
            </p>
          </v-col>
          <v-col class="text-right">
            <p class="elipsis-fullwidth">
              <strong>{{ $t('phoneText') }}</strong>
              <span
                >&nbsp;{{
                  user.phoneNumber === '' ? 'N/A' : user.phoneNumber
                }}</span
              >
            </p>
          </v-col>
        </template>
        <template v-slot:body>
          <p>
            <strong>{{ $t('programsLabel') }}</strong>
          </p>
          <p>
            <strong>{{ $t('rewardsLabel') }}</strong>
            <span
              >&nbsp;{{
                user.mrewardsU === undefined ? 'N/A' : user.mrewardsU
              }}</span
            >
          </p>
          <p>
            <strong>{{ $t('mRewardsLabel') }}</strong>
            <span
              >&nbsp;{{
                user.mrewardsK === undefined ? 'N/A' : user.mrewardsK
              }}</span
            >
          </p>
          <br />
          <p>
            <strong>{{ $t('createdLabel') }}</strong>
            <span>&nbsp;{{ user.createdDate | filterDate }}</span>
          </p>
          <p>
            <strong>{{ $t('lastActivityLabel') }}</strong>
            <span>&nbsp;{{ user.lastLoginTime | lastLoginTime }}</span>
          </p>
          <p>
            <strong>{{ $t('externalIdText') }}</strong>
            <span
              >&nbsp;{{
                user.externalId === '' ? 'N/A' : user.externalId
              }}</span
            >
          </p>
        </template>
        <template v-slot:icons>
          <brierleyCardIcons>
            <template v-slot:action-icons>
              <span
                class="active"
                :title="$t('editLabel')"
                @click="editUser(user.id)"
              >
                <v-icon id="viewuser_edit-icon">fe fe-edit</v-icon>
                <span class="edit-icon" id="viewuser-edit">{{
                  $t('editLabel')
                }}</span>
              </span>
              <span @click="cloneUser(user.id)" :title="$t('copyLabel')">
                <v-icon id="viewuser_Copy_icon">feather-icon fe fe-copy</v-icon>
                <span class="copy-icon" id="viewuser-copy">{{
                  $t('copyLabel')
                }}</span>
              </span>
              <span
                :title="$t('activateLabel')"
                v-if="user.userStatus.userStatusId === 5"
                @click="setuserStatus(user)"
              >
                <v-icon id="viewuser_active_icon" class="blackicon cursor-p"
                  >fe-user-check</v-icon
                >
                <span class="deactivate-icon">{{ $t('activateLabel') }}</span>
              </span>
              <span
                :title="$t('labelDeactivate')"
                v-if="user.userStatus.userStatusId === 4"
                @click="setuserStatus(user)"
              >
                <v-icon id="viewuser_deactive_icon" class="blackicon cursor-p"
                  >fe-user-x</v-icon
                >
                <span class="deactive-icon">{{ $t('deActivateLabel') }}</span>
              </span>
            </template>
          </brierleyCardIcons>
        </template>
        <template v-slot:status>
          <div class="avatar-status-section">
            <strong id="status">{{ $t('statusLabel') }}</strong>
            <brierley-status
              :title="
                user.userStatus
                  ? checkuserStatusActive(user)
                  : checkuserStatusDeactive(user)
              "
              :status="
                user.userStatus
                  ? checkuserStatusActive(user)
                  : checkuserStatusDeactive(user)
              "
            ></brierley-status>
            <a
              style="text-decoration: none"
              v-if="
                user.userStatus != null &&
                  user.userStatus.statusName === 'Expired Link'
              "
              id="viewuser_resendlink_cardview"
            >
              <strong id="resendlink" v-on:click.once="resend(user)">{{
                $t('resendLinkText')
              }}</strong>
            </a>
          </div>
        </template>
      </brierley-card-with-logo>
    </v-col>
    <v-col>
      <close-pop-up
        :dialog="showdialog"
        :headertext="header"
        :btntext="btext"
        :message="msg"
      ></close-pop-up>
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyStatus,
  BrierleyCardIcons,
  BrierleyCardWithLogo
} from '@brierley/SharedComponents';
import ClosePopUp from './closepopUp';
import { mapState } from 'vuex';
import { userCardViewObj } from './../../../../i18n/language.js';
export default {
  components: {
    BrierleyStatus,
    BrierleyCardIcons,
    BrierleyCardWithLogo,
    ClosePopUp
  },
  i18n: userCardViewObj,
  data () {
    return {
      isHidden: false,
      btext: '',
      msg: '',
      header: ''
    };
  },

  props: {
    userlistdata: {
      type: Array,
      default: function () {
        return [];
      }
    }
  },

  methods: {
    checkuserStatusActive (user) {
      if (user.active === false && user.userStatus === null) {
        return this.$t('inActiveText');
      } else if (user.active === false && user.userStatus !== null) {
        return user.userStatus.statusName;
      } else if (user.active === true) {
        return user.userStatus.statusName;
      }
    },
    cloneUser (id) {
      this.$router.push({
        name: 'UserLayoutClone',
        query: { res: id }
      });
    },
    editUser (id) {
      this.$router.push({
        name: 'UserLayoutEdit',
        query: { res: id }
      });
    },
    checkuserStatusDeactive (user) {
      if (user.userStatus === null && user.active === true) {
        return this.$t('activeText');
      } else {
        return this.$t('inActiveText');
      }
    },
    setuserstatusText (user) {
      if (user.active === false) this.$t('activeText');
      else if (
        user.active === true && user.userStatus === null ||
        user.active === true && user.userStatus.userStatusId === 4
      )
        return this.$t('deActiveText');
      else return this.$t('activeText');
    },
    setuserStatus (user) {
      if (
        user.active === false ||
        user.active === true && user.userStatus.userStatusId === 5
      )
        this.setactivateUser(user);
      else if (
        user.active === true && user.userStatus === null ||
        user.active === true && user.userStatus.userStatusId === 4
      )
        this.setdeactivateUser(user);
    },
    setactivateUser (user) {
      this.header = this.$t('activateUserText');
      this.msg = this.$t('activateText');
      this.btext = this.$t('activateText');
      this.$store.commit('userviewModule/getuserId', user.id);
      this.$store.commit('userviewModule/closepopUpMutation', true);
    },
    setdeactivateUser (user) {
      this.header = this.$t('deActivateUserText');
      this.msg = this.$t('deActivateText');
      this.btext = this.$t('deActivateText');
      this.$store.commit('userviewModule/getuserId', user.id);
      this.$store.commit('userviewModule/closepopUpMutation', true);
    },
    resend (user) {
      this.$emit('resendEmailReqest', user);
    }
  },

  computed: {
    ...mapState('userviewModule', ['showdialog', 'params'])
  }
};
</script>

<style lang="scss" scoped>
#resendlink {
  color: #0628b1;
}
.avatar-status-section {
  margin-top: -14px;
}
</style>
