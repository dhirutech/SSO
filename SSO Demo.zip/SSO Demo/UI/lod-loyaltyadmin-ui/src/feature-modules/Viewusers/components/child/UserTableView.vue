<template>
  <v-row class="d-flex flex-column" no-gutter>
    <brierley-table-module v-if="userlistdata.length > 0">
      <template v-slot:tablehead>
        <tr class="text-left">
          <th
            v-for="item in header"
            :key="item.name"
            @click="
              sortBy(item)
              arrowToggle()
            "
            class="text-left"
            :width="item.width"
          >{{ item.text }}
          </th>
        </tr>
      </template>

      <template v-slot:tablebody>
        <tr v-for="item in userlistdata" :key="item.name">
          <td>
            <v-row
              class="d-flex head-name user-display-name"
              :title="item.name"
              no-gutters
            >
              <v-col class="elipsis-twoline">{{ item.name }}</v-col>
              <!-- <v-col >
                <v-icon title="bookmark" class="accountlock">lock</v-icon>
              </v-col> -->
            </v-row>
          </td>
          <td>
            <span v-if="item.programRoles">
              <span
                v-for="(list, index) in item.programRoles.list"
                :key="index"
              >
                <span v-if="index < 1">
                  <v-row class="flex-column" no-gutters>
                    <v-col
                      ><strong>{{ list.name }}</strong></v-col
                    >
                    <v-col>
                      <span>{{
                        list.access == undefined ||
                        list.access == null ||
                        list.access == ''
                          ? 'N/A'
                          : list.access
                      }}</span>
                    </v-col>
                  </v-row>
                </span>
              </span>
              <brierley-expantion-list
                v-if="item.programRoles.list.length > 1"
                :moreCount="item.programRoles.list.length - 1"
                :moreText="'MORE'"
                :listData="item.programRoles"
              ></brierley-expantion-list>
            </span>
          </td>
          <td>
            <div :title="item.externalId" class="elipsis-description">
              {{ item.externalId == '' ? 'N/A' : item.externalId }}
            </div>
          </td>
          <td class="text-nowrap">{{ item.createdDate | filterDate }}</td>
          <td>{{ item.lastLoginTime | lastLoginTime }}</td>
          <td>
            <brierleyStatus
              :title="
                item.userStatus
                  ? checkuserStatusActive(item)
                  : checkuserStatusDeactive(item)
              "
              :status="
                item.userStatus
                  ? checkuserStatusActive(item)
                  : checkuserStatusDeactive(item)
              "
            ></brierleyStatus>
            <a
              v-if="
                item.userStatus != null &&
                  item.userStatus.statusName == 'Expired Link'
              "
              id="viewuser_resendlink_tableview"
            >
              <strong class="primary-text" v-on:click.once="resend(item)">
                {{ $t('resendLinkText') }}
              </strong>
            </a>
            <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
              <v-col>
                <brierleyCardIcons>
                  <template v-slot:action-icons>
                    <span
                      class="active"
                      :title="$t('editLabel')"
                      @click="editUser(item.id)"
                    >
                      <v-icon class="blackicon" id="viewuser-edit-icon"
                        >fe fe-edit</v-icon
                      >
                      <span class="edit-icon" id="viewuser-edit">{{
                        $t('editLabel')
                      }}</span>
                    </span>
                    <span :title="$t('copyLabel')" @click="cloneUser(item.id)">
                      <v-icon class="blackicon" id="viewuser-icon"
                        >feather-icon fe fe-copy</v-icon
                      >
                      <span class="copy-icon" id="viewuser-copy">{{
                        $t('copyLabel')
                      }}</span>
                    </span>
                    <span
                      :title="$t('activateLabel')"
                      v-if="item.userStatus.userStatusId === 5"
                      @click="setuserStatus(item)"
                    >
                      <v-icon
                        id="viewuser_activeicon"
                        class="blackicon cursor-p"
                        >fe-user-check</v-icon
                      >
                      <span class="deactivate-icon">{{
                        $t('activateLabel')
                      }}</span>
                    </span>
                    <span
                      :title="$t('labelDeactivate')"
                      v-if="item.userStatus.userStatusId === 4"
                      @click="setuserStatus(item)"
                    >
                      <v-icon
                        id="viewuser_deactiveicon"
                        class="blackicon cursor-p"
                        >fe-user-x</v-icon
                      >
                      <span class="deactive-icon">{{
                        $t('deActivateLabel')
                      }}</span>
                    </span>
                  </template>
                </brierleyCardIcons>
              </v-col>
            </v-row>
          </td>
        </tr>
      </template>
    </brierley-table-module>
    <v-col>
      <close-pop-up
        :dialog="showdialog"
        :headertext="headertext"
        :btntext="btext"
        :message="msg"
      ></close-pop-up>
    </v-col>
  </v-row>
</template>

<script>
import _ from 'lodash';

import {
  BrierleyStatus,
  BrierleyCardIcons,
  BrierleyTableModule,
  BrierleyExpantionList
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import ClosePopUp from './closepopUp';
import { userTableViewObj } from './../../../../i18n/language.js';
export default {
  components: {
    BrierleyStatus,
    BrierleyCardIcons,
    BrierleyTableModule,
    BrierleyExpantionList,
    ClosePopUp
  },
  i18n: userTableViewObj,
  data () {
    return {
      sortKey: ['name'],
      sortOrder: ['asc'],
      isToggled: false,
      changeColor: false,
      btext: '',
      msg: '',
      headertext: '',
      header: [
        { name: 'name', text: this.$t('nameText'), sort: 'asc' },
        { name: 'programs', text: this.$t('programsText'), sort: '' },
        {
          name: 'externalid',
          text: this.$t('externalIdText'),
          sort: '',
          width: '215'
        },
        {
          name: 'createddate',
          text: this.$t('createdOnText'),
          sort: '',
          width: '170'
        },
        {
          name: 'lastactivity',
          text: this.$t('lastActivityText'),
          sort: '',
          width: '150'
        },
        { name: 'status', text: this.$t('statusText'), sort: '', width: '180' }
      ]
    };
  },

  props: {
    userlistdata: {
      type: Array,
      default: function () {
        return [];
      }
    }
  },

  methods: {
    sortBy: function (item) {
      let i = this.header.indexOf(item);
      for (let j = 0; j < this.header.length; j++) {
        if (j === i) {
          this.header[j].sort =
            this.header[j].sort === '' || this.header[j].sort === 'desc'
              ? 'asc'
              : 'desc';
        } else {
          this.header[j].sort = '';
        }
      }
      this.sortKey = this.header[i].name;
      this.sortOrder = this.header[i].sort;
    },
    cloneUser (id) {
      this.$router.push({
        name: 'UserLayoutClone',
        query: { res: id }
      });
    },
    editUser (id) {
      this.$router.push({
        name: 'UserLayoutEdit',
        query: { res: id }
      });
    },
    arrowToggle () {
      this.isToggled = !this.isToggled;
    },
    checkuserStatusActive (user) {
      if (user.active === false && user.userStatus === null) {
        return this.$t('inActiveText');
      } else if (user.active === false && user.userStatus !== null) {
        return user.userStatus.statusName;
      } else if (user.active === true) {
        return user.userStatus.statusName;
      }
    },
    checkuserStatusDeactive (user) {
      if (user.userStatus === null && user.active === true) {
        return this.$t('activeText');
      } else {
        return this.$t('inActiveText');
      }
    },
    resend (user) {
      this.$emit('resendEmailReqest', user);
    },
    setuserStatus (user) {
      if (
        user.active === false ||
        user.active === true && user.userStatus.userStatusId === 5
      )
        this.setactivateUser(user);
      else if (
        user.active === true && user.userStatus === null ||
        user.active === true && user.userStatus.userStatusId === 4
      )
        this.setdeactivateUser(user);
    },
    userstatusText (user) {
      if (user.active === false) return this.$t('activeText');
      else if (
        user.active === true && user.userStatus === null ||
        user.active === true && user.userStatus.userStatusId === 4
      )
        return this.$t('deActivateText');
      else return this.$t('activeText');
    },
    setactivateUser (user) {
      this.headertext = this.$t('activateUserText');
      this.msg = this.$t('activateText');
      this.btext = this.$t('activateText');
      this.$store.commit('userviewModule/getuserId', user.id);
      this.$store.commit('userviewModule/closepopUpMutation', true);
    },
    setdeactivateUser (user) {
      this.headertext = this.$t('deActivateUserText');
      this.msg = this.$t('deActivateLabelText');
      this.btext = this.$t('deActivateLabelText');
      this.$store.commit('userviewModule/getuserId', user.id);
      this.$store.commit('userviewModule/closepopUpMutation', true);
    }
  },
  computed: {
    campaigns: function () {
      return _.orderBy(this.campaignslist, this.sortKey, this.sortOrder);
    },
    ...mapState('userviewModule', ['showdialog', 'params'])
  }
};
</script>
<style lang="scss" scoped>
.arrow {
  transform: rotate(-180deg);
}
.arrow.down {
  transform: rotate(2deg);
}
.accountlock {
  font-size: 20px !important;
  font-size: 1.125rem;
  margin-top: -6px;
  margin-left: 2px !important;
  color: #bdbdbd;
}
</style>
