<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="dialog"
        @closeMe="closePopUp()"
        :persistent="false"
        id="viewUser_btn_dialog_Close"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase"
            >{{ $t("sentEmailText") }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <brierley-alert
                  alertType="success"
                  :alertBody="$t('alertMessageText')"
                ></brierley-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="viewUser_btn_CloseDialog"
            class="primaryctabtn text-uppercase"
            title
            @click="closePopUp()"
            >{{ $t("okBtnText") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox, brierleyAlert } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { successPopUpObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyDialogbox,
    brierleyAlert
  },
  i18n: successPopUpObj,
  props: {
    dialog: {
      type: Boolean,
      default: false
    },
    persistent: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    closePopUp () {
      this.$store.commit('userviewModule/closeEmailPopUpMutation', false);
      this.$store.dispatch('userviewModule/getUsersListAction', this.params);
    }
  },
  computed: {
    ...mapState('userviewModule', ['userslist', 'params', 'showEmailDialog'])
  }
};
</script>
