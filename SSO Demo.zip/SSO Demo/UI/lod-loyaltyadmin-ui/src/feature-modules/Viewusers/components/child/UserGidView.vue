<template>
  <v-row>
    <v-col cols="12" v-for="(user, index) in userlistdata" :key="index">
      <v-card class="gen2-card gen2-typo3">
        <v-row no-gutters>
          <v-col md="3" sm="12" xs="12">
            <v-card-title class="elipsis-fullwidth">
              &nbsp; {{ user.name === '' ? 'N/A' : user.name }}
              <v-icon title="Title Here " class="accountlock">{{
                user.accountlock
              }}</v-icon>
            </v-card-title>
            <div class="gen2-card-copy">
              <p class="elipsis-fullwidth" id="viewuser_email">
                <strong>{{ $t('emailText') }}</strong>
                &nbsp; {{ user.email === '' ? 'N/A' : user.email }}
              </p>
              <p id="viewuser_phone">
                <strong>{{ $t('phoneText') }}</strong>
                &nbsp; {{ user.phoneNumber === '' ? 'N/A' : user.phoneNumber }}
              </p>
              <p id="viewuser_externalid">
                <strong>{{ $t('externalIdText') }}</strong>
                &nbsp;{{ user.externalId === '' ? 'N/A' : user.externalId }}
              </p>
            </div>
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span
                  :title="$t('editLabel')"
                  class="active"
                  @click="editUser(user.id)"
                >
                  <v-icon id="viewuser_edit-icon" class="blackicon"
                    >fe fe-edit</v-icon
                  >
                  <span class="edit-icon" id="viewuser-edit">{{
                    $t('editLabel')
                  }}</span>
                </span>
                <span :title="$t('copyLabel')" @click="cloneUser(user.id)">
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >feather-icon fe fe-copy</v-icon
                  >
                  <span class="copy-icon" id="viewuser-copy">{{
                    $t('copyLabel')
                  }}</span>
                </span>
                <span
                  :title="$t('activateLabel')"
                  v-if="user.userStatus.userStatusId === 5"
                  @click="setuserStatus(user)"
                >
                  <v-icon id="viewuser_activeicon" class="blackicon cursor-p"
                    >fe-user-check</v-icon
                  >
                  <span class="deactivate-icon">{{ $t('activateLabel') }}</span>
                </span>
                <span
                  :title="$t('labelDeactivate')"
                  v-if="user.userStatus.userStatusId === 4"
                  @click="setuserStatus(user)"
                >
                  <v-icon id="viewuser_deactiveicon" class="blackicon cursor-p"
                    >fe-user-x</v-icon
                  >
                  <span class="deactive-icon">{{ $t('deActivateLabel') }}</span>
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
          <v-col md="3" sm="12" xs="12" class="">
            <p class="bmt0">
              <strong>{{ $t('programsLabel') }}</strong>
            </p>
            <span v-if="user.programRoles">
              <span
                v-for="(list, index) in user.programRoles.list"
                :key="index"
              >
                <span v-if="index < 1">
                  <p v-if="list.name">
                    <strong>{{ list.name }} :</strong>
                  </p>
                  <p class="bmt0 elipsis-twoline">
                    {{ list.access === undefined ? 'N/A' : list.access }}
                  </p>
                </span>
              </span>
              <brierley-expantion-list
                v-if="user.programRoles.list.length > 1"
                :moreCount="user.programRoles.list.length - 1"
                :moreText="'MORE'"
                :listData="user.programRoles"
              ></brierley-expantion-list>
            </span>
          </v-col>
          <v-col md="4" sm="12" xs="12" class="bpr6 bpl6">
            <v-row no-gutters class="pr-3 mb-4">
              <v-col class="text-xs-left">
                <p class="bmt0">
                  <strong>{{ $t('createdLabel') }}</strong>
                </p>
              </v-col>
              <v-col class="text-xs-right">
                <p class="bmt0">{{ user.createdDate | filterDate }}</p>
              </v-col>
            </v-row>
            <v-row no-gutters class="pr-3">
              <v-col class="text-xs-left">
                <p>
                  <strong>{{ $t('lastActivityLabel') }}</strong>
                </p>
              </v-col>
              <v-col class="text-xs-right bpr3 bpl3">
                <p>{{ user.lastLoginTime | lastLoginTime }}</p>
              </v-col>
            </v-row>
          </v-col>
          <v-col class="gen2-card-status">
            <p class="bmt0">
              <strong>{{ $t('statusLabel') }}</strong>
            </p>
            <brierley-status
              :title="
                user.userStatus
                  ? checkuserStatusActive(user)
                  : checkuserStatusDeactive(user)
              "
              :status="
                user.userStatus
                  ? checkuserStatusActive(user)
                  : checkuserStatusDeactive(user)
              "
            ></brierley-status>
            <a
              style="text-decoration: none"
              v-if="
                user.userStatus != null &&
                  user.userStatus.statusName == 'Expired Link'
              "
              id="viewuser_resendlink_gridview"
            >
              <strong id="link" v-on:click.once="resend(user)">{{
                $t('resendLinkText')
              }}</strong>
            </a>
          </v-col>
        </v-row>
      </v-card>
    </v-col>
    <v-col>
      <close-pop-up
        :dialog="showdialog"
        :headertext="header"
        :btntext="btext"
        :message="msg"
      ></close-pop-up>
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyStatus,
  BrierleyCardIcons,
  BrierleyExpantionList
} from '@brierley/SharedComponents';
import ClosePopUp from './closepopUp';
import { mapState } from 'vuex';
import { userGridViewObj } from './../../../../i18n/language.js';
export default {
  components: {
    BrierleyStatus,
    BrierleyCardIcons,
    BrierleyExpantionList,
    ClosePopUp
  },
  i18n: userGridViewObj,
  data () {
    return {
      isHidden: false,
      btext: '',
      msg: '',
      header: ''
    };
  },
  props: {
    userlistdata: {
      type: Array,
      defualt: []
    }
  },
  methods: {
    checkuserStatusActive (user) {
      if (user.active === false && user.userStatus === null) {
        return this.$t('inActiveText');
      } else if (user.active === false && user.userStatus !== null) {
        return user.userStatus.statusName;
      } else if (user.active === true) {
        return user.userStatus.statusName;
      }
    },
    cloneUser (id) {
      this.$router.push({
        name: 'UserLayoutClone',
        query: { res: id }
      });
    },
    editUser (id) {
      this.$router.push({
        name: 'UserLayoutEdit',
        query: { res: id }
      });
    },
    checkuserStatusDeactive (user) {
      if (user.userStatus === null && user.active === true) {
        return this.$t('activeText');
      } else {
        return this.$t('inActiveText');
      }
    },
    setuserStatus (user) {
      if (
        user.active === false ||
        user.active === true && user.userStatus.userStatusId === 5
      )
        this.setactivateUser(user);
      else if (
        user.active === true && user.userStatus === null ||
        user.active === true && user.userStatus.userStatusId === 4
      )
        this.setdeactivateUser(user);
    },
    userstatusText (user) {
      if (user.active === false) return this.$t('activeText');
      else if (
        user.active === true && user.userStatus === null ||
        user.active === true && user.userStatus.userStatusId === 4
      )
        return this.$t('deActivateText');
      else return this.$t('activeText');
    },
    setactivateUser (user) {
      this.header = this.$t('activateUserText');
      this.msg = this.$t('activateText');
      this.btext = this.$t('activateText');
      this.$store.commit('userviewModule/getuserId', user.id);
      this.$store.commit('userviewModule/closepopUpMutation', true);
    },
    setdeactivateUser (user) {
      this.header = this.$t('deActivateUserText');
      this.msg = this.$t('deActivateLabelText');
      this.btext = this.$t('deActivateLabelText');
      this.$store.commit('userviewModule/getuserId', user.id);
      this.$store.commit('userviewModule/closepopUpMutation', true);
    },
    resend (user) {
      this.$emit('resendEmailReqest', user);
    }
  },
  computed: {
    ...mapState('userviewModule', ['showdialog', 'params'])
  }
};
</script>

<style lang="scss" scoped>
#link {
  color: #0628b1;
  position: relative;
  top: 2px;
  right: 2px;
}

.accountlock {
  font-size: 20px !important;
  font-size: 1.125rem;
  margin-top: -6px;
  margin-left: 2px !important;
  color: #bdbdbd;
}
</style>
