<template>
  <brierley-inner-view>
    <template v-slot:header>
      <v-flex class="toggle-menu-custom">
        <v-btn class="no-ripple iconbtn" text @click="menutoggle = !menutoggle">
          <v-icon>
            fe-menu
          </v-icon>
        </v-btn>
        <brierley-toggle-menu v-if="menutoggle"></brierley-toggle-menu>
      </v-flex>
      <span class="inner-head text-uppercase">
        <small class="white-text opacity75 bpr1">VIEW USERS </small>
        / activity report
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>keyboard_backspace</v-icon>
        BACK
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row no-gutters>
        <v-col class="loyalty-users-common">
          <v-row class="d-flex flex-column bpt4" no-gutters>
            <v-col>
              <brierley-form-title
                formTitle="Activity report"
                infoText="userInfoText"
              >
                <!-- <template v-slot:list-count>
                  <span class="list-count"
                    >({{ userCount }} {{ $t('usersLabel') }})</span
                  >
                </template> -->
              </brierley-form-title>
            </v-col>
          </v-row>
          <v-row class="gen2-search-filter bpt2" no-gutters>
            <v-col class="text-left bmb2" cols="6">
              <v-row class="d-flex grid-search" no-gutters>
                <v-col class="bpr2">
                  <v-text-field
                    autocomplete="off"
                    class="search-field"
                    id="user_loyaltyAdmin_searchUser"
                    label="Search"
                    prepend-inner-icon="mdi-magnify"
                  ></v-text-field>
                </v-col>
              </v-row>
            </v-col>
            <v-col cols="6" class="text-right align-self-center">
              <brierley-filter
                v-on:click.native="isHidden = !isHidden"
              ></brierley-filter>
              <brierley-icon-with-head
                iconTitle="DOWNLOAD REPORT"
                iconName="'get_app'"
              ></brierley-icon-with-head>
            </v-col>
            <v-col cols="12" class="filter-dropdown bmt1">
              <brierley-filter-result v-if="isHidden">
                <template v-slot:body-content>
                  <v-row no-gutters class="bmb6">
                    <v-col cols="5" class=" gen2-forms form-dark-bg">
                      <h3>Activity Date Range</h3>
                      <v-row class="main-wrapper__header">
                        <v-col cols="1">
                          <v-radio-group
                            column
                            class="radiolight radiolight__dark bmt0"
                          >
                            <v-radio value="radio-2"></v-radio>
                          </v-radio-group>
                        </v-col>
                        <v-col cols="10" class="todate bpr5">
                          <v-select
                            filled
                            attach
                            offset-y
                            class="gen2select gen2select__light"
                            label="Select"
                            append-icon="expand_more"
                          ></v-select>
                        </v-col>
                      </v-row>
                      <v-row>
                        <v-col cols="1">
                          <v-radio-group
                            column
                            class="radiolight radiolight__dark bmt0"
                          >
                            <v-radio value="radio-2"></v-radio>
                          </v-radio-group>
                        </v-col>
                        <v-col cols="10" class="todate bpr5">
                          <p class="f600 mt-3">CUSTOM</p>
                          <v-menu
                            ref="endDatePopup"
                            v-model="endDatePopup"
                            :close-on-content-click="false"
                            :return-value.sync="filterEndRange"
                            transition="scale-transition"
                            offset-y
                            min-width="290px"
                          >
                            <template v-slot:activator="{ on }">
                              <v-text-field
                                autocomplete="off"
                                readonly
                                label="From"
                                append-icon="mdi-calendar-range"
                                v-on="on"
                                class="darktxtfield__light"
                                filled
                              ></v-text-field>
                            </template>
                            <v-date-picker
                              v-model="filterEndRange"
                              no-title
                              scrollable
                              :min="filterStartRange"
                            >
                              <v-spacer></v-spacer>
                              <v-btn text color="primary">{{
                                $t('cancelBtnText')
                              }}</v-btn>
                              <v-btn text color="primary">{{
                                $t('okBtnText')
                              }}</v-btn>
                            </v-date-picker>
                          </v-menu>
                          <v-menu
                            ref="endDatePopup"
                            v-model="endDatePopup"
                            :close-on-content-click="false"
                            :return-value.sync="filterEndRange"
                            transition="scale-transition"
                            offset-y
                            min-width="290px"
                          >
                            <template v-slot:activator="{ on }">
                              <v-text-field
                                autocomplete="off"
                                readonly
                                label="To"
                                append-icon="mdi-calendar-range"
                                v-on="on"
                                class="darktxtfield__light"
                                filled
                              ></v-text-field>
                            </template>
                            <v-date-picker
                              v-model="filterEndRange"
                              no-title
                              scrollable
                              :min="filterStartRange"
                            >
                              <v-spacer></v-spacer>
                              <v-btn text color="primary">{{
                                $t('cancelBtnText')
                              }}</v-btn>
                              <v-btn text color="primary">{{
                                $t('okBtnText')
                              }}</v-btn>
                            </v-date-picker>
                          </v-menu>
                        </v-col>
                      </v-row>
                    </v-col>
                    <v-col cols="4">
                      <h3>EVENT BY</h3>
                      <v-row no-gutters>
                        <v-col cols="9">
                          <v-select
                            filled
                            attach
                            offset-y
                            class="gen2select gen2select__light"
                            label="Select Event"
                            append-icon="expand_more"
                          ></v-select>
                        </v-col>
                      </v-row>
                    </v-col>
                    <v-col cols="3">
                      <h3>EVENTS</h3>
                      <v-row no-gutters>
                        <v-col class="pt-0">
                          <v-checkbox
                            id="viewuser_chk_active"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            label="Login - Success"
                            value="Active"
                          ></v-checkbox>
                          <v-checkbox
                            id="viewuser_chk_inActive"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            label="Login - Failed"
                            value="Inactive"
                          ></v-checkbox>
                          <v-checkbox
                            id="viewuser_chk_expired_link"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            label="Logout"
                            value="Expired Link"
                          ></v-checkbox>
                          <v-checkbox
                            id="viewuser_chk_pending_signUp"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            label="Lock"
                            value="Pending Signup"
                          ></v-checkbox>
                          <v-checkbox
                            id="viewuser_chk_drafts"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            label="Unlock"
                            value="Draft"
                          ></v-checkbox>
                        </v-col>
                      </v-row>
                    </v-col>
                  </v-row>
                </template>
                <template v-slot:footer>
                  <v-btn
                    text
                    title="Clear & Close"
                    class="mr-5 cancel bmt3"
                    id="viewuser_btn_clear"
                    >Clear</v-btn
                  >
                  <v-btn
                    title="Apply Filters"
                    depressed
                    class="next bmt3 primaryctabtn"
                    id="viewuser_btn_apply_filter"
                    >FILTER</v-btn
                  >
                </template>
              </brierley-filter-result>
            </v-col>
            <v-col cols="12">
              <v-row class="gen2-scroll-table sticky-left mb-0" no-gutters>
                <v-col>
                  <v-row class="table_container max-width-full" no-gutters>
                    <v-col
                      class="table-center sticky-data-table gen2-forms form-light-bg"
                    >
                      <v-flex class="sticky-data-table__scroll">
                        <v-simple-table class="sticky-data-table__table">
                          <thead>
                            <tr>
                              <th class="sticky-first">
                                Activity Date
                              </th>
                              <th>
                                Activity By
                              </th>
                              <th>
                                IP Address
                              </th>
                              <th>
                                Device
                              </th>
                              <th>
                                User Agent
                              </th>
                              <th>
                                Event Type
                              </th>
                              <th class="largecol">
                                Event Details
                              </th>
                              <th class="largecol">
                                Role
                              </th>
                              <th class="largecol">
                                extra
                              </th>
                              <th class="largecol">
                                description
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="i in 15" :key="i">
                              <td class="sticky-first elipsis-fullwidth">
                                Jan 1st 2020 <br />
                                04:14 AM ISTM
                              </td>
                              <td>
                                John
                              </td>
                              <td>
                                Smith
                              </td>
                              <td>
                                02/01/2020
                              </td>
                              <td>
                                3/11/2020
                              </td>
                              <td>
                                Active
                              </td>
                              <td>
                                GAP
                              </td>
                              <td>
                                Loyalty Manager
                              </td>
                              <td>
                                Extra
                              </td>
                              <td>discription</td>
                            </tr>
                          </tbody>
                        </v-simple-table>
                      </v-flex>
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </template>
    <template v-slot:footer>
      <v-btn
        text
        title="Close"
        class="primaryctabtn no-ripple"
        @click.native="$router.push('/gettingstarted')"
        >CLOSE</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyFormTitle,
  BrierleyFilter,
  BrierleyFilterResult,
  BrierleyInnerView,
  BrierleyIconWithHead,
  BrierleyToggleMenu
} from '@brierley/SharedComponents';
export default {
  components: {
    BrierleyFormTitle,
    BrierleyFilter,
    BrierleyFilterResult,
    BrierleyInnerView,
    BrierleyIconWithHead,
    BrierleyToggleMenu
  },
  data () {
    return {
      menutoggle: false,
      startDatePopup: false,
      endDatePopup: false,
      status: '',
      active: '',
      inActive: '',
      expire: '',
      startDate: '',
      searchUser: 'Search Users',
      searchText: '',
      isTyping: false,
      endDate: '',
      program: '',
      role: '',
      pendingSignUp: '',
      drafts: '',
      search: '',
      noData: '',
      isHidden: false,
      loadmore: true,
      showPopUp: false,
      viewType: 'grid_view',
      usersearchText: '',
      selectedStatusFilterPendingSignUp: '',
      selectedStatusFilterExpiredLink: '',
      selectedStatusFilterInactive: '',
      selectedStatusFilterActive: '',
      selectedRoleId: '',
      selectedProgramId: '',
      filterStartRange: null,
      filterEndRange: null
    };
  }
};
</script>
