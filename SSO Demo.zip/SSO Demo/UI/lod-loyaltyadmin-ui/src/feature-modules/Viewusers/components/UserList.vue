<template>
  <brierley-inner-view>
    <template v-slot:header>
      <span class="inner-head bpl1" style="position: relative; right: 5px">
        {{ $t("headerText") }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>
        {{ $t("closeBtnText") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row no-gutters>
        <v-col class="loyalty-users-common">
          <v-row class="d-flex flex-column bpt4" no-gutters>
            <v-col>
              <brierley-form-title
                :formTitle="$t('usersText')"
                :infoText="$t('userInfoText')"
              >
                >
                <template v-slot:list-count>
                  <span class="list-count"
                    >({{ userCount }} {{ $t("usersLabel") }})</span
                  >
                </template>
              </brierley-form-title>
            </v-col>
          </v-row>
          <v-row class="d-flex gen2-search-filter bpt2" no-gutters>
            <v-col class="text-left" cols="5">
              <v-row class="d-flex grid-search" no-gutters>
                <v-col class="bpr2">
                  <v-text-field
                    autocomplete="off"
                    class="search-field"
                    id="user_loyaltyAdmin_searchUser"
                    :label="$t('searchUsersText')"
                    prepend-inner-icon="mdi-magnify"
                    v-model="searchText"
                    @input="isTyping = true"
                  ></v-text-field>
                </v-col>
              </v-row>
            </v-col>
            <v-col cols="7" class="text-right align-self-center">
              <brierley-filter
                v-on:click.native="isHidden = !isHidden"
              ></brierley-filter>
              <div class="bmr1 d-inline-block">
                <brierley-view-option
                  id="viewuser_viewoptions"
                  :viewList="cardlist"
                  @viewOptionClicked="hideFilter()"
                  @viewChanged="viewType = $event"
                ></brierley-view-option>
              </div>
              <div class="bmr1 d-inline-block">
                <v-menu offset-y>
                  <template v-slot:activator="{ on, attrs }">
                    <v-btn text v-bind="attrs" v-on="on" class="no-ripple bpl1 f600 btn-hover-none">
                       <img height="24" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAH8SURBVHgB7dvxUcIwFMfx154D6AbtBjiB6CKWCWAERmCEMoILaJ3AbkA3kAmo73n2L5u8pBRakt/nrocewsmXEJoWiAAAAAAAeiTaH2RZdp+m6bpt2yX/uqTbUvP/vWuaZk8DWQNxnCxJkg/5kW5bw6GeOVRDnlLblYHEEb9PtLwayJMxEN9ZQWHE6WS8bciTMRAXX1Ng+DE9kSfbS2xB4VmSp5TACoEUCKRAIAUCKRBIcUeeDoeDun5zked5O8X9+8IIUiCQAoEUCKRAIAUCKRBIgUAKBFIgkAKBFMZ1z1hrmbnxXethBCkQSOF9uGPm5AzqG1/WvFW8Hflk6lGu+DtpmJGnIOYgPt9Vnk6nPceoaGQ3PYJ4tFR8seKJt6ELCfaI4lgwSSsQSIFACgRSIJAimkC8o7gZ9RNmAVoM+RhebC+xLtLDdrt1ukGMc5BEei/L0ilSrJO0c6SY38WcIs16Nc+L0Udeodd91/E8UvIDfKXzyafxX4qi+O4LZRtBFU2vocuzjiRjIK76SRPrDnZdQRfp3y6AbQTt6DrP4Fz0TinGQPLsyRdAaMJIQ/Z8B/qSeahvxFrfxeTbMXwAK+cbr3ir6fqGBGoNm4kxjpjV0btLMrzrWeOImPeD1Dgi1kBOcUSMgZzjiNgCecURMQWqfeMAAAAAABj9AG2N2M3Yi9HnAAAAAElFTkSuQmCC" alt="table_arrow_right">
                      <span class="f600 pl-2">REPORT</span>
                    </v-btn>
                  </template>
                  <v-list class="view-details-dropdown text-left pb-10">
                    <v-list-item v-for="(item, index) in items" :key="index">
                      <v-list-item-title>
                        <v-list-item-action @click="$router.push(item.route)">
                          <p class="mb-0">
                            <img height="20" style="position: relative; bottom: -6px;" :src="item.image">
                            <span class="f600 pl-2" >
                            {{ item.title }}
                            </span>
                          </p>
                        </v-list-item-action>
                      </v-list-item-title>
                    </v-list-item>
                  </v-list>
                </v-menu>
              </div>
              <brierley-icon-with-head
                class="loyalty-users-common__create-user"
                @click.native="$router.push('/loyaltyadmin/user/create')"
                :iconTitle="$t('createNewUser')"
                :iconName="'add_circle'"
                id="viewuser_btn_createUser"
              ></brierley-icon-with-head>
            </v-col>
            <v-col cols="12" class="filter-dropdown bmt1">
              <brierley-filter-result v-if="isHidden">
                <template v-slot:body-content>
                  <v-row no-gutters class="bmb6">
                    <v-col cols="4">
                      <h3>{{ $t("activityDate") }}</h3>
                      <v-row class="main-wrapper__header">
                        <v-col cols="10" class="todate">
                          <v-menu
                            ref="startDatePopup"
                            v-model="startDatePopup"
                            :close-on-content-click="false"
                            :return-value.sync="filterStartRange"
                            transition="scale-transition"
                            offset-y
                            min-width="290px"
                          >
                            <template v-slot:activator="{ on }">
                              <v-text-field
                                autocomplete="off"
                                id="user_loyaltyAdmin_filterStartRangeFormated"
                                readonly
                                v-model="startDateFormatted"
                                @blur="
                                  filterStartRange = parseDate(
                                    startDateFormatted
                                  )
                                "
                                :label="$t('fromLabel')"
                                append-icon="mdi-calendar-range"
                                v-on="on"
                                class="darktxtfield__light"
                                filled
                              ></v-text-field>
                            </template>
                            <v-date-picker
                              v-model="filterStartRange"
                              no-title
                              scrollable
                              :max="filterEndRange"
                            >
                              <v-spacer></v-spacer>
                              <v-btn
                                text
                                color="primary"
                                @click="closestartDatePopup()"
                                >{{ $t("cancelBtnText") }}</v-btn
                              >
                              <v-btn
                                text
                                color="primary"
                                @click="
                                  $refs.startDatePopup.save(filterStartRange)
                                "
                                >{{ $t("okBtnText") }}</v-btn
                              >
                            </v-date-picker>
                          </v-menu>
                        </v-col>
                        <v-col cols="10" class="todate">
                          <v-menu
                            ref="endDatePopup"
                            v-model="endDatePopup"
                            :close-on-content-click="false"
                            :return-value.sync="filterEndRange"
                            transition="scale-transition"
                            offset-y
                            min-width="290px"
                          >
                            <template v-slot:activator="{ on }">
                              <v-text-field
                                autocomplete="off"
                                id="user_loyaltyAdmin_filterEndRangeFormated"
                                readonly
                                v-model="endDateFormatted"
                                @blur="
                                  filterEndRange = parseDate(endDateFormatted)
                                "
                                :label="$t('toLabel')"
                                append-icon="mdi-calendar-range"
                                v-on="on"
                                class="darktxtfield__light"
                                filled
                              ></v-text-field>
                            </template>
                            <v-date-picker
                              v-model="filterEndRange"
                              no-title
                              scrollable
                              :min="filterStartRange"
                            >
                              <v-spacer></v-spacer>
                              <v-btn
                                text
                                color="primary"
                                @click="closeendDatePopup()"
                                >{{ $t("cancelBtnText") }}</v-btn
                              >
                              <v-btn
                                text
                                color="primary"
                                @click="$refs.endDatePopup.save(filterEndRange)"
                                >{{ $t("okBtnText") }}</v-btn
                              >
                            </v-date-picker>
                          </v-menu>
                        </v-col>
                      </v-row>
                    </v-col>
                    <v-col cols="4">
                      <h3>{{ $t("programLabel") }}</h3>
                      <v-row no-gutters>
                        <v-col cols="9">
                          <v-select
                            id="viewuser_select_program"
                            :items="allProgramStatus"
                            item-text="name"
                            item-value="programId"
                            filled
                            attach
                            offset-y
                            v-model="selectedProgramId"
                            class="gen2select gen2select__light"
                            :label="$t('selectProgramLabel')"
                            append-icon="expand_more"
                          ></v-select>
                        </v-col>
                      </v-row>
                      <h3>{{ $t("roleLabel") }}</h3>
                      <v-row no-gutters>
                        <v-col cols="9">
                          <v-select
                            id="viewuser_select_role"
                            :items="allRolesStatus"
                            item-text="roleName"
                            item-value="roleId"
                            filled
                            attach
                            offset-y
                            v-model="selectedRoleId"
                            class="gen2select gen2select__light"
                            :label="$t('selectRoleLabel')"
                            append-icon="expand_more"
                          ></v-select>
                        </v-col>
                      </v-row>
                    </v-col>
                    <v-col cols="4">
                      <h3>{{ $t("statusLabel") }}</h3>
                      <v-row>
                        <v-col cols="6 pt-0">
                          <v-checkbox
                            id="viewuser_chk_active"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            :label="$t('activeLabel')"
                            value="Active"
                            v-model="selectedStatusFilterActive"
                          ></v-checkbox>
                          <v-checkbox
                            id="viewuser_chk_inActive"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            :label="$t('inActiveLabel')"
                            value="Inactive"
                            v-model="selectedStatusFilterInactive"
                          ></v-checkbox>
                          <v-checkbox
                            id="viewuser_chk_expired_link"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            :label="$t('expiredLinkLabel')"
                            value="Expired Link"
                            v-model="selectedStatusFilterExpiredLink"
                          ></v-checkbox>
                        </v-col>
                        <v-col cols="6 pt-0">
                          <v-checkbox
                            id="viewuser_chk_pending_signUp"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            :label="$t('pendingLabel')"
                            value="Pending Signup"
                            v-model="selectedStatusFilterPendingSignUp"
                          ></v-checkbox>
                          <v-checkbox
                            id="viewuser_chk_drafts"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            :label="$t('draftLabel')"
                            value="Draft"
                            v-model="selectedStatusFilterDrafts"
                          ></v-checkbox>
                        </v-col>
                      </v-row>
                    </v-col>
                  </v-row>
                </template>
                <template v-slot:footer>
                  <v-btn
                    text
                    title="Clear & Close"
                    class="mr-5 cancel bmt3"
                    id="viewuser_btn_clear"
                    @click="resetFilter()"
                    >{{ $t("clearBtnText") }}</v-btn
                  >
                  <v-btn
                    title="Apply Filters"
                    depressed
                    class="next bmt3 primaryctabtn"
                    @click="filterPromotion"
                    id="viewuser_btn_apply_filter"
                    >{{ $t("filterBtnText") }}</v-btn
                  >
                </template>
              </brierley-filter-result>
            </v-col>
          </v-row>
          <user-card-view
            v-if="viewType == 'card_view'"
            :userlistdata="userslist"
            @resendEmailReqest="resendEmail"
          />
          <user-grid-view
            v-if="viewType == 'grid_view'"
            :userlistdata="userslist"
            @resendEmailReqest="resendEmail"
          />
          <user-table-view
            v-if="viewType == 'table_view'"
            :userlistdata="userslist"
            @resendEmailReqest="resendEmail"
          />
          <v-col v-if="userslist.length === 0 && !loadmore">
            <brierley-no-result
              :noResultMessage="noData"
              id="viewuser_img_no_data"
            ></brierley-no-result>
          </v-col>
          <v-col align="center">
            <loadmore
              loadingText="loading"
              v-if="loadmore"
              id="viewuser_loadmore"
              class="margin-auto"
            />
          </v-col>
          <Success-Pop-Up v-if="showEmailDialog" :dialog="showEmailDialog" />
        </v-col>
      </v-row>
    </template>
    <template v-slot:footer>
      <v-btn
        text
        title="Close"
        class="primaryctabtn no-ripple"
        @click.native="$router.push('/gettingstarted')"
        >{{ $t("closeBtnText") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyFormTitle,
  BrierleyFilter,
  BrierleyFilterResult,
  BrierleyInnerView,
  BrierleyIconWithHead,
  BrierleyViewOption,
  BrierleyNoResult,
  Loadmore,
} from '@brierley/SharedComponents';
import UserCardView from '../components/child/UserCardView';
import UserGridView from '../components/child/UserGidView';
import UserTableView from '../components/child/UserTableView';
import { mapState } from 'vuex';
import SuccessPopUp from './child/SuccessPopUp';
import _ from 'lodash';
import { viewUsersObj } from '../../../i18n/language.js';
export default {
  components: {
    BrierleyFormTitle,
    BrierleyNoResult,
    BrierleyFilter,
    BrierleyFilterResult,
    UserCardView,
    UserGridView,
    BrierleyInnerView,
    BrierleyIconWithHead,
    BrierleyViewOption,
    Loadmore,
    UserTableView,
    SuccessPopUp,
  },
  i18n: viewUsersObj,
  data () {
    return {
      startDatePopup: false,
      endDatePopup: false,
      status: '',
      active: '',
      inActive: '',
      expire: '',
      startDate: '',
      searchUser: 'Search Users',
      searchText: '',
      isTyping: false,
      endDate: '',
      program: '',
      role: '',
      pendingSignUp: '',
      drafts: '',
      search: '',
      noData: '',
      isHidden: false,
      loadmore: true,
      showPopUp: false,
      viewType: 'grid_view',
      usersearchText: '',
      selectedStatusFilterPendingSignUp: '',
      selectedStatusFilterExpiredLink: '',
      selectedStatusFilterInactive: '',
      selectedStatusFilterActive: '',
      selectedRoleId: '',
      selectedProgramId: '',
      filterStartRange: null,
      filterEndRange: null,
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('gridViewText'),
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('tableViewText'),
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('cardViewText'),
        },
      ],
      items: [
        {
          image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAANBSURBVHgB7ZqPcdMwFMa/cAzQLECdBaAbxMcEzQLETFLDAnSCBibgWICkC/BngTRdADpBgr+zTR1HsmX7PVfu+Xf37kBnv+pnyfKTWmBkZGTkGREmsU7ibxIH4biCZ7BDB+XwRjqCvqxX0mv0J7yHB9KHnuPJpU2dkiDGE0u/gD9MkAqrSvskTNSlfRMmqtI+ChM1aV+FiYq0z8JEXNp3YSIqPQRhIiY9FGEiIj0kYZJLt2Zowp15iX7ZOFxzjvTg4SyLXtDaPNgIk7iG+8nKKrtHjL6EQ3Tbe2+TWEIAbeEAsocMqyxnazSFL5K4g/whwjbLXcnE0n5ocG0T2KE1qhejhyR+JbFL4j5r4/VvUP/ecg14m93fCI0RvkD1osQHcYn6lTlC9evwBw4jXUZaOIB9GrODl2hOVJFzi4bvtLTwZ0vOH5aOxTg+6woteWdJ/LTk/o4GSApHsMvapm8MN2EyzXKV89fdd4Sk8B2aT7kYzTo+s/ycNRyREg4tuZY198VoPlIhHEZZe/MQGdo4El8gzy1Oa3V+So8WRG3huaHtA3TgiH40tL8r/kdTmN/CwND+DXqw4HgotZ0V+6EpHBjaNjjtkCR5lVYmzP/Rt/AO+vw2tP3//GkKm76x99CF73F5Bk3Qk7AkAdpvXo4+q5rCpnf1HM2h6CqJG6QFRt21U1T0RVN4Z2gL4H5vudiJkJaQV6ge7deWfJVIVFqBIQe3h64HcwHSTcfekIfFC6u1svgE5mqrdrsoVVqa9r8RmhEhrb1NfeJUDwrXvoe5bq9FSvgaHQr6EjFOR7u4CZnAfDBw45Jce/OwQDsCPE5zRrFsNI0ur5k75BUTJqanzqlet+JWEeF4g2/bHjpNZ0BWOLTk40nFFN2ZwnzqUZ4BlZg6OOkQXy05OSpdRnpWIev07uZo/DGpLSi9RLNKitcuIHiItwbExVzFp3icGUXBvIpaoMMxre2phmj/+ZBgg3TXw5KQfXyFdMQoUlW4cGbygdyiBTHMVY6v4fSrljoipMv/XjG6iu6zPgYYADxg44agjXguOscACZFWUJyW5dEvzwguSp/QUrTtplqT/PDvHOmqTGkuRjwt4UK2w8iIlX/QqeX81FqMDwAAAABJRU5ErkJggg==',
          title: 'ACTIVITY REPORT',
          route: '/loyaltyadmin/viewuser/activityreport',
        },
        {
          image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAE/SURBVHgB7ZrbDcIwDEVvEQOwEUyC2IROBozAJMAElFiUH8RH3DqpY+6R7k8FJEfE7iMFCCEkOLuUc8o9ZTDMM+UIZ8iEhoJxJX1AWVl30mfUEXYjPVTO4tK/JmVBj4rSK/imw1vYTNq7sGAq3YKwYCbdirBgIt2SsDBbujVhYZZ0i8LCZOlWhYVJ0i0LC2rp1oWFj3QWEYRVrLE8F+iZfFrqFJ8dZn7fChnz+XVM5pa1Wv9uSVM4OhSODs/DBlg96/r8lumfwiUdHdawAdY1bEoJYderhjUcHTYtA7T3yOaNyYrc3UPttmgPHR1+7zJmwRqODpuWAdomVLVp8UorOhSOztwaXmrnYTIa4UfK5utY9hWOFzRL+gq/XFCAHeq+eqh5RXGPQvTjAJ5kjyjMIeU0DrZUbuMctiCEkMi8AHMbLLIvH6J7AAAAAElFTkSuQmCC',
          title: 'ACCESS REPORT',
          route: '/loyaltyadmin/viewuser/accessreport',
        },
      ],
    };
  },

  methods: {
    closestartDatePopup () {
      this.startDatePopup = false;
    },
    closeendDatePopup () {
      this.endDatePopup = false;
    },
    formatDate (date) {
      if (!date) return null;
      const [year, month, day] = date.split('-');
      return `${month}/${day}/${year}`;
    },
    searchInit (searchText) {
      this.noData = searchText === '' ? '' : this.$t('noResultsFoundText');
      this.params.searchText = searchText;
      this.params.pageNumber = 1;
      this.$store.dispatch('userviewModule/getUsersListAction', this.params);
    },
    filterPromotion () {
      this.params.pageNumber = 1;
      this.startDate = !this.filterStartRange
        ? ''
        : '&FromDate=' + this.filterStartRange;
      this.endDate = !this.filterEndRange
        ? ''
        : '&ToDate=' + this.filterEndRange;
      this.program = !this.selectedProgramId
        ? ''
        : '&ProgramId=' + this.selectedProgramId;
      this.role = !this.selectedRoleId ? '' : '&RoleId=' + this.selectedRoleId;
      this.active = !this.selectedStatusFilterActive
        ? ''
        : this.selectedStatusFilterActive + ',';
      this.inActive = !this.selectedStatusFilterInactive
        ? ''
        : this.selectedStatusFilterInactive + ',';
      this.expire = !this.selectedStatusFilterExpiredLink
        ? ''
        : this.selectedStatusFilterExpiredLink + ',';
      this.pendingSignUp = !this.selectedStatusFilterPendingSignUp
        ? ''
        : this.selectedStatusFilterPendingSignUp + ',';
      this.drafts = !this.selectedStatusFilterDrafts
        ? ''
        : this.selectedStatusFilterDrafts;
      this.status =
        this.active +
        this.inActive +
        this.expire +
        this.pendingSignUp +
        this.drafts;
      this.params.status = !this.status ? '' : '&Status=' + this.status;
      this.params.filterStartRange = this.startDate;
      this.params.filterEndRange = this.endDate;
      this.params.selectedProgramId = this.program;
      this.params.selectedRoleId = this.role;
      this.isHidden = false;
      this.$store.dispatch('userviewModule/getUsersListAction', this.params);
      this.clearFields();
    },
    clearFields () {
      this.startDate = '';
      this.endDate = '';
      this.program = '';
      this.role = '';
      this.active = '';
      this.inactive = '';
      this.expire = '';
      this.pendingSignUp = '';
      this.drafts = '';
      this.isHidden = false;
    },
    getUsersListData () {
      this.loadMore = true;
      this.$store.dispatch('userviewModule/getUsersListAction', this.params);
    },

    onScroll () {
      window.onscroll = () => {
        if (
          document.documentElement.scrollHeight ===
            document.documentElement.scrollTop + window.innerHeight &&
          this.userslist.length !== this.userCount
        ) {
          this.params.pageNumber += 1;
          this.loadmore = true;
          this.getUsersListData();
        }
      };
    },
    hideFilter () {
      this.isHidden = false;
    },
    resetFilter () {
      this.clearAllFields();
      this.clearFields();
      this.filterPromotion();
      this.isHidden = false;
    },
    clearAllFields () {
      this.params.selectedProgramId = undefined;
      this.params.selectedRoleId = undefined;
      this.selectedStatusFilterActive = undefined;
      this.selectedStatusFilterInactive = undefined;
      this.selectedStatusFilterExpiredLink = undefined;
      this.filterEndRange = undefined;
      this.filterStartRange = undefined;
      this.selectedProgramId = undefined;
      this.selectedRoleId = undefined;
      this.selectedStatusFilterPendingSignUp = undefined;
      this.selectedStatusFilterDrafts = undefined;
    },
    changeUserStatus (pageNo, pageSize) {
      this.params.pageSize = pageSize;
      this.params.pageNumber = pageNo;
      this.$store.dispatch('userviewModule/getDeleteUserList', this.params);
    },
    resendEmail (user) {
      this.$store
        .dispatch('userviewModule/updateUserStatusAction', user.id)
        .then((res) => {
          if (res.data === true || res.status === 200 || res.status === 201) {
            this.$store.commit('userviewModule/closeEmailPopUpMutation', true);
            this.changeUserStatus(
              1,
              this.params.pageSize * this.params.pageNumber
            );
          }
        });
    },
  },

  watch: {
    filterStartRange () {
      this.startDateFormatted = this.formatDate(this.filterStartRange);
    },
    filterEndRange () {
      this.endDateFormatted = this.formatDate(this.filterEndRange);
    },
    userslist () {
      this.loadmore = false;
    },
    searchText: function () {
      const self = this;
      _.debounce(function () {
        self.isTyping = false;
        self.params.pageNumber = 1;
      }, 3000)();
    },
    isTyping: function (value) {
      if (this.searchText === '') {
        this.params.searchText = '';
      }
      if (!value) {
        this.searchInit(this.searchText);
      }
    },
  },
  mounted () {
    this.params.searchText = '';
    this.$store.dispatch('userModule/getAllProgramStatusAction');
    this.$store.dispatch('userModule/getAllRolesAssignmentAction');
    window.addEventListener('scroll', this.onScroll);
    this.$store.dispatch('userviewModule/getUsersListAction', this.params);
  },
  beforeDestroy () {
    window.removeEventListener('scroll', this.onScroll);
  },
  computed: {
    ...mapState('userModule', {
      allProgramStatus: (state) => {
        return state.allProgramStatusList;
      },
    }),
    ...mapState('userviewModule', [
      'userslist',
      'params',
      'showEmailDialog',
      'userCount',
    ]),
    ...mapState('userModule', {
      allRolesStatus: (state) => {
        return state.allRolesStatusList;
      },
    }),
  },
};
</script>
