<template>
  <brierley-inner-view>
    <template v-slot:header>
      <v-flex class="toggle-menu-custom">
        <v-btn class="no-ripple iconbtn" text @click="menutoggle = !menutoggle">
          <v-icon> fe-menu </v-icon>
        </v-btn>
        <brierley-toggle-menu v-if="menutoggle"></brierley-toggle-menu>
      </v-flex>
      <span class="inner-head text-uppercase">
        <small class="white-text opacity75 bpr1">VIEW USERS </small>
        / ACCESS REPORT
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        @click.native="$router.push('/loyaltyadmin/viewuser')"
      >
        <v-icon>keyboard_backspace</v-icon>
        BACK
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row no-gutters>
        <v-col class="loyalty-users-common">
          <v-row class="d-flex flex-column bpt4" no-gutters>
            <v-col>
              <brierley-form-title formTitle="Access report" infoText="TBD">
                <!-- <template v-slot:list-count>
                  <span class="list-count"
                    >({{ userCount }} {{ $t('usersLabel') }})</span
                  >
                </template> -->
              </brierley-form-title>
            </v-col>
          </v-row>
          <v-row class="gen2-search-filter bpt2" no-gutters>
            <v-col class="text-left bmb2" cols="6">
              <v-row class="d-flex grid-search" no-gutters>
                <v-col class="bpr2">
                  <v-text-field
                    autocomplete="off"
                    class="search-field"
                    id="user_loyaltyAdmin_searchUser"
                    label="Search By Email, First Name, Last Name"
                    prepend-inner-icon="mdi-magnify"
                    @keyup="searchaccessReport()"
                    v-model="searchText"
                  ></v-text-field>
                </v-col>
              </v-row>
            </v-col>
            <v-col cols="6" class="text-right align-self-center">
              <brierley-filter
                v-on:click.native="isHidden = !isHidden"
              ></brierley-filter>
              <brierley-icon-with-head
                iconTitle="DOWNLOAD REPORT"
                iconName="get_app"
                @clicked="downloadReport()"
              ></brierley-icon-with-head>
            </v-col>
            <v-col cols="12" class="filter-dropdown mt-3">
              <brierley-filter-result v-if="isHidden">
                <template v-slot:body-content>
                  <v-row no-gutters class="bmb6">
                    <v-col cols="5">
                      <h3>USER LOGGED</h3>
                      <v-radio-group
                        column
                        class="radiolight radiolight__dark bmt0 access-reports-select"
                      >
                        <v-row class="main-wrapper__header">
                          <v-col cols="1">
                            <v-radio
                              value="radio-1"
                              @click="hidedatefield = false"
                            ></v-radio>
                          </v-col>
                          <v-col cols="10" class="todate bpr5">
                            <v-select
                              filled
                              attach
                              :items="numberofDays"
                              item-text="itemtext"
                              item-value="itemvalue"
                              offset-y
                              class="gen2select gen2select__light"
                              label="Select"
                              append-icon="expand_more"
                              v-model="selectedDays"
                            ></v-select>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="1" class="pt-0">
                            <v-radio
                              value="radio-2"
                              @click="hidedatefield = true"
                            ></v-radio>
                          </v-col>
                          <v-col cols="10" class="todate bpr5">
                            <p class="f600 mb-2">CUSTOM</p>
                            <v-menu
                              ref="startDatePopup"
                              v-model="startDatePopup"
                              :close-on-content-click="false"
                              :return-value.sync="filterStartRange"
                              transition="scale-transition"
                              offset-y
                              min-width="290px"
                              v-if="hidedatefield"
                            >
                              <template v-slot:activator="{ on }">
                                <v-text-field
                                  autocomplete="off"
                                  id="user_access_loyaltyAdmin_filterStartRangeFormated"
                                  readonly
                                  v-model="startDateFormatted"
                                  :label="$t('fromLabel')"
                                  append-icon="mdi-calendar-range"
                                  v-on="on"
                                  class="darktxtfield__light"
                                  filled
                                ></v-text-field>
                              </template>
                              <v-date-picker
                                v-model="filterStartRange"
                                no-title
                                scrollable
                              >
                                <v-spacer></v-spacer>
                                <v-btn
                                  text
                                  color="primary"
                                  @click="closestartDatePopup()"
                                  >{{ $t("cancelBtnText") }}</v-btn
                                >
                                <v-btn
                                  text
                                  color="primary"
                                  @click="
                                    $refs.startDatePopup.save(filterStartRange)
                                  "
                                  >{{ $t("okBtnText") }}</v-btn
                                >
                              </v-date-picker>
                            </v-menu>
                            <v-menu
                              ref="endDatePopup"
                              v-model="endDatePopup"
                              :close-on-content-click="false"
                              :return-value.sync="filterEndRange"
                              transition="scale-transition"
                              offset-y
                              min-width="290px"
                              v-if="hidedatefield"
                            >
                              <template v-slot:activator="{ on }">
                                <v-text-field
                                  autocomplete="off"
                                  id="user_loyaltyAdmin_filterEndRangeFormated"
                                  readonly
                                  v-model="endDateFormatted"
                                  :label="$t('toLabel')"
                                  append-icon="mdi-calendar-range"
                                  v-on="on"
                                  class="darktxtfield__light"
                                  filled
                                ></v-text-field>
                              </template>
                              <v-date-picker
                                v-model="filterEndRange"
                                no-title
                                scrollable
                              >
                                <v-spacer></v-spacer>
                                <v-btn
                                  text
                                  color="primary"
                                  @click="closeendDatePopup()"
                                  >{{ $t("cancelBtnText") }}</v-btn
                                >
                                <v-btn
                                  text
                                  color="primary"
                                  @click="
                                    $refs.endDatePopup.save(filterEndRange)
                                  "
                                  >{{ $t("okBtnText") }}</v-btn
                                >
                              </v-date-picker>
                            </v-menu>
                          </v-col>
                        </v-row>
                      </v-radio-group>
                    </v-col>
                    <v-col cols="4">
                      <h3>ROLE</h3>
                      <v-row no-gutters>
                        <v-col cols="9">
                          <v-select
                            id="viewuser_select_role"
                            :items="allRolesStatus"
                            item-text="roleName"
                            item-value="roleID"
                            filled
                            attach
                            offset-y
                            v-model="selectedRoleId"
                            class="gen2select gen2select__light"
                            :label="$t('selectRoleLabel')"
                            append-icon="expand_more"
                          ></v-select>
                        </v-col>
                      </v-row>
                      <h3>PROGRAM</h3>
                      <v-row no-gutters>
                        <v-col cols="9">
                          <v-select
                            filled
                            attach
                            :items="allPrograms"
                            item-text="programName"
                            item-value="programID"
                            v-model="selectedProgramID"
                            offset-y
                            class="gen2select gen2select__light"
                            :label="$t('selectProgramLabel')"
                            append-icon="expand_more"
                          ></v-select>
                        </v-col>
                      </v-row>
                    </v-col>
                    <v-col cols="3">
                      <h3>STATUS</h3>
                      <v-row>
                        <v-col class="pt-0">
                          <v-checkbox
                            id="viewuser_chk_active"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            :label="$t('activeLabel')"
                            value="Active"
                            v-model="selectedStatusFilterActive"
                          ></v-checkbox>
                          <v-checkbox
                            id="viewuser_chk_inActive"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            :label="$t('inActiveLabel')"
                            value="Inactive"
                            v-model="selectedStatusFilterInactive"
                          ></v-checkbox>
                          <v-checkbox
                            id="viewuser_chk_expired_link"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            :label="$t('expiredLinkLabel')"
                            value="Expired Link"
                            v-model="selectedStatusFilterExpiredLink"
                          ></v-checkbox>
                          <v-checkbox
                            id="viewuser_chk_pending_signUp"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            :label="$t('pendingLabel')"
                            value="Pending Signup"
                            v-model="selectedStatusFilterPendingSignUp"
                          ></v-checkbox>
                          <v-checkbox
                            id="viewuser_chk_drafts"
                            class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                            :label="$t('draftLabel')"
                            value="Draft"
                            v-model="selectedStatusFilterDraft"
                          ></v-checkbox>
                        </v-col>
                      </v-row>
                    </v-col>
                  </v-row>
                </template>
                <template v-slot:footer>
                  <v-btn
                    text
                    :title="$t('clearandcloseText')"
                    class="mr-5 cancel bmt3"
                    id="viewuser_btn_clear"
                    @click="resetFilter()"
                    >Clear</v-btn
                  >
                  <v-btn
                    :title="$t('applyfilterText')"
                    depressed
                    class="next bmt3 primaryctabtn"
                    id="viewuser_btn_apply_filter"
                    @click="filterReports()"
                    >FILTER</v-btn
                  >
                </template>
              </brierley-filter-result>
            </v-col>
            <v-col cols="12">
              <v-row class="gen2-scroll-table sticky-left mb-0" no-gutters>
                <v-col>
                  <v-row class="table_container max-width-full" no-gutters>
                    <v-col
                      class="table-center sticky-data-table gen2-forms form-light-bg"
                    >
                      <v-flex class="sticky-data-table__scroll">
                        <v-simple-table
                          class="sticky-data-table__table"
                        >
                          <thead>
                            <tr>
                              <th
                                :class="item.class"
                                v-for="(item, i) in accessReportHeader"
                                :key="i"
                              >
                                {{ item.text }}
                                <v-icon
                                  v-if="item.isSortableColumn"
                                  v-bind:class="{
                                    down: item.sortType === 'asc',
                                    up: item.sortType === 'desc',
                                  }"
                                  class="arrow uparw cursor-p"
                                  >arrow_drop_down</v-icon
                                >
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr
                              id="no_result_row_access_report"
                              class="text-center"
                              v-if="accessReportData.length === 0"
                            >
                              <td colspan="6"  class="noresultfound">
                                No Results for the search criteria
                              </td>
                            </tr>
                            <tr v-for="(item, i) in accessReportData" :key="i">
                              <td
                                :class="
                                  item.email
                                    ? 'sticky-first elipsis-fullwidth'
                                    : 'sticky-first elipsis-fullwidth'
                                "
                              >
                                {{ item.email }}
                              </td>
                              <td>{{ item.firstName }}</td>
                              <td>{{ item.lastName }}</td>
                              <td>{{ item.createdDate }}</td>
                              <td>{{ item.lastLoginTime }}</td>
                              <td>{{ item.status }}</td>
                              <td>{{ item.program ? item.program : "N/A" }}</td>
                              <td>{{ item.role }}</td>
                              <td>{{ item.extra ? item.extra : "N/A" }}</td>
                              <td>
                                {{
                                  item.description ? item.description : "N/A"
                                }}
                              </td>
                            </tr>
                          </tbody>
                        </v-simple-table>
                      </v-flex>
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>
              <v-row>
                <v-col align="center" v-if="loadmore">
                  <loadmore loadingText="load more" class="margin-auto" />
                </v-col>
              </v-row>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </template>
    <template v-slot:footer>
      <v-btn
        text
        title="Close"
        class="primaryctabtn no-ripple"
        @click.native="closeAccessRepost()"
        >{{ $t("closeText") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyFormTitle,
  BrierleyFilter,
  BrierleyFilterResult,
  BrierleyInnerView,
  BrierleyIconWithHead,
  BrierleyToggleMenu,
  Loadmore,
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { acceptreportdatalangObj } from '../../../i18n/language';
export default {
  i18n: acceptreportdatalangObj,
  components: {
    BrierleyFormTitle,
    BrierleyFilter,
    BrierleyFilterResult,
    BrierleyInnerView,
    BrierleyIconWithHead,
    BrierleyToggleMenu,
    Loadmore,
  },
  data () {
    return {
      menutoggle: false,
      startDatePopup: false,
      endDatePopup: false,
      status: '',
      active: '',
      inActive: '',
      expire: '',
      pendingSignUp: '',
      drafts: '',
      searchText: '',
      isTyping: false,
      noData: '',
      isHidden: false,
      loadmore: true,
      selectedStatusFilterPendingSignUp: '',
      selectedStatusFilterExpiredLink: '',
      selectedStatusFilterInactive: '',
      selectedStatusFilterActive: '',
      selectedStatusFilterDraft: '',
      selectedRoleId: '',
      selectedProgramID: '',
      selectedDays: '',
      filterStartRange: null,
      filterEndRange: null,
      accessReportHeader: [
        {
          text: 'Email',
          value: 'Email',
          isSortableColumn: true,
          sortType: 'desc',
          class: 'sticky-first',
        },
        {
          text: ' First Name',
          value: ' First Name',
          isSortableColumn: true,
          sortType: 'desc',
          class: '',
        },
        {
          text: ' Last Name',
          value: ' Last Name',
          isSortableColumn: true,
          sortType: 'asc',
          class: '',
        },
        {
          text: 'Created',
          value: 'Created',
          isSortableColumn: true,
          sortType: 'desc',
          class: '',
        },
        {
          text: 'Last Login',
          value: 'Last Login',
          isSortableColumn: true,
          sortType: 'desc',
          class: '',
        },
        {
          text: 'Status',
          value: 'Status',
          isSortableColumn: true,
          sortType: 'desc',
          class: '',
        },
        {
          text: 'Program',
          isSortableColumn: false,
          sortType: 'desc',
          value: 'Program',
          class: 'largecol',
        },
        {
          text: 'Role',
          isSortableColumn: false,
          sortType: 'desc',
          value: 'Role',
          class: 'largecol',
        },
        {
          text: 'Extra',
          isSortableColumn: false,
          sortType: 'desc',
          value: 'extra',
          class: 'largecol',
        },
        {
          text: 'Description',
          isSortableColumn: false,
          sortType: 'desc',
          value: 'description',
          class: 'largecol',
        },
      ],
      hidedatefield: false,
      startDateFormatted: '',
      endDateFormatted: '',
      filtlerParams: {
        numberofDays: '',
        startDate: '',
        endDate: '',
        roleID: '',
        programID: '',
      },
      refactoraccessReportData: [],
    };
  },
  watch: {
    filterStartRange () {
      this.startDateFormatted = this.formatDate(this.filterStartRange);
    },
    filterEndRange () {
      this.endDateFormatted = this.formatDate(this.filterEndRange);
    },
  },
  computed: {
    ...mapState('userviewModule', {
      accessReportData: (state) => {
        return state.accessReportData;
      },
      allRolesStatus: (state) => {
        return state.allRolesStatus;
      },
      allPrograms: (state) => {
        return state.allPrograms;
      },
      numberofDays: (state) => {
        return state.numberofDays;
      },
      accessReportparams: (state) => {
        return state.accessReportparams;
      },
    }),
  },
  beforeDestroy () {
    window.removeEventListener('scroll', this.onScroll);
  },
  mounted () {
    window.addEventListener('scroll', this.onScroll);
    this.getUsersAccessListData();
    this.fetchRoles();
    this.fetchPrograms();
  },
  methods: {
    onScroll () {
      window.onscroll = () => {
        if (
          document.documentElement.scrollHeight ===
          document.documentElement.scrollTop + window.innerHeight
        ) {
          this.loadmore = true;
          this.accessReportparams.pageNumber += 1;
          this.getUsersAccessListData();
        }
      };
    },
    getUsersAccessListData () {
      this.$store
        .dispatch(
          'userviewModule/getAccessReportDataAction',
          this.accessReportparams
        )
        .then((res) => {
          if (res.status === 200) {
            this.loadmore = false;
            this.$store.commit(
              'userviewModule/getAccessReportDatamutation',
              res.data.usersSearchResult
            );
          }
        })
        .catch();
    },
    searchaccessReport () {
      if (this.searchText !== '') {
        this.accessReportparams.searchText = this.searchText.trim();
        this.$store
          .dispatch(
            'userviewModule/getAccessReportDataSearchAction',
            this.accessReportparams.searchText
          )
          .then((res) => {
            if (res.status === 200 && res.data.length !== 0) {
              this.loadmore = false;
              this.$store.commit(
                'userviewModule/resetgetAccessReportDataSearchmutation',
                []
              );
              this.$store.commit(
                'userviewModule/getAccessReportDataSearchmutation',
                res.data.usersSearchResult
              );
            }
            // else if (res.status === 200 && res.data.length === 0) {
            //   this.getUsersAccessListData();
            // }
          })
          .catch();
      } else this.getUsersAccessListData();
    },
    fetchRoles () {
      this.$store
        .dispatch('userviewModule/fetchRolesDataAction')
        .then((res) => {
          if (res.status === 200) {
            this.$store.commit(
              'userviewModule/fetchRolesDatamutation',
              res.data
            );
          }
        })
        .catch();
    },
    fetchPrograms () {
      this.$store
        .dispatch('userviewModule/fetchProgramsDataAction')
        .then((res) => {
          if (res.status === 200) {
            this.$store.commit(
              'userviewModule/fetchProgramsDatamutation',
              res.data
            );
          }
        })
        .catch();
    },
    closestartDatePopup () {
      this.startDatePopup = false;
    },
    closeendDatePopup () {
      this.endDatePopup = false;
    },
    formatDate (date) {
      if (!date) return null;
      const [year, month, day] = date.split('-');
      return `${month}/${day}/${year}`;
    },
    filterReports () {
      this.programID = !this.selectedProgramID ? '' : '&ProgramId=' + this.selectedProgramID;
      this.roleID = !this.selectedRoleId ? '' : '&RoleId=' + this.selectedRoleId;
      this.startDateFormatted = !this.startDateFormatted ? '' : '&FromDate=' + this.startDateFormatted;
      this.endDateFormatted = !this.endDateFormatted ? '' : '&ToDate=' + this.endDateFormatted;
      this.selectedDays = !this.selectedDays ? '' : '&NoOfDays=' + this.selectedDays;
      this.active = !this.selectedStatusFilterActive ? '' : this.selectedStatusFilterActive + ',';
      this.inActive = !this.selectedStatusFilterInactive ? '' : this.selectedStatusFilterInactive + ',';
      this.expire = !this.selectedStatusFilterExpiredLink ? '' : this.selectedStatusFilterExpiredLink + ',';
      this.pendingSignUp = !this.selectedStatusFilterPendingSignUp ? '' : this.selectedStatusFilterPendingSignUp + ',';
      this.drafts = !this.selectedStatusFilterDraft ? '' : this.selectedStatusFilterDraft;
      this.status = this.active + this.inActive + this.expire + this.pendingSignUp + this.drafts;
      let Status = '&status=' + this.status;
      this.accessReportparams.pageNumber = 1;
      this.accessReportparams.pageSize = 10;
      this.accessReportparams.filterStartRange = this.startDateFormatted;
      this.accessReportparams.filterEndRange = this.endDateFormatted;
      this.accessReportparams.selectedprogramID = this.programID;
      this.accessReportparams.selectedroleID = this.roleID;
      this.accessReportparams.selectednoOfDays = this.selectedDays;
      this.accessReportparams.selectedstatus = Status;
      this.$store.commit('userviewModule/resetAccessReportDatamutation');
      this.loadmore = true;
      this.isHidden = false;
      this.$store.dispatch('userviewModule/accessreportFilterAction', this.accessReportparams)
        .then(res => {
          if (res.status === 200) {
            this.loadmore = false;
            this.$store.commit('userviewModule/accessreportFilterMutation', res.data.usersSearchResult);
            this.resetFilter();
          }
        })
        .catch(err => {
          if (err) {
            this.loadmore = false;
          }

        });
    },
    resetFilter () {
      this.selectedRoleId = this.selectedProgramID = undefined;
      this.startDateFormatted = this.endDateFormatted = this.selectedStatusFilterPendingSignUp = this.selectedStatusFilterExpiredLink = this.selectedStatusFilterInactive = this.selectedStatusFilterActive = this.selectedStatusFilterDraft =
        '';
      this.isHidden = false;
    },
    downloadReport () {
      let a = document.createElement('a');
      this.$store
        .dispatch('userviewModule/downloadreportAction')
        .then((res) => {
          if (res.status === 200)
            a.href =
              'data:application/octet-stream,' + encodeURIComponent(res.data);
          a.download = 'AccessReport.csv';
          a.click();
        })
        .catch();
    },
    closeAccessRepost () {
      let resetData = '';
      this.accessReportparams.pageNumber = 1;
      this.$store.commit('userviewModule/resetAccessReportDatamutation', resetData);
      this.$router.push('/loyaltyadmin/viewuser');
    }
  },
};
</script>

<style lang="scss">
.access-reports-select {
  &.v-input--radio-group {
    .v-input__control {
      div.v-input__slot {
        padding: 0 16px !important;
      }
    }
  }
}
.noresultfound {
  position: relative;
  left: 400px;
  color: #1037e0;
  font-style: normal;
  font-weight: 700;
}
</style>
