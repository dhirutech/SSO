<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="dialog"
        @closeMe="closepopUp()"
        :persistent="false"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            headertext
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <p>{{ $t("areYouSureText") }} {{ message }} {{ $t("thisUserText") }}</p>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn text class="cancel no-ripple cursor-p" @click="closepopUp()"
            >{{ $t("noBtnText") }}</v-btn
          >
          <v-btn class="primaryctabtn cursor-p" @click="activateuser()"
            >{{ $t("yesBtnText") }} {{ btntext }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { closePopUpObj } from './../../../../i18n/language.js';
export default {
  data () {
    return {};
  },
  components: {
    BrierleyDialogbox
  },
  i18n: closePopUpObj,
  props: {
    dialog: {
      type: Boolean,
      default: false
    },
    persistent: {
      type: Boolean,
      default: false
    },
    headertext: {
      type: String,
      default: 'Deactivate User'
    },
    message: {
      type: String,
      default: 'deactivate'
    },
    btntext: {
      type: String,
      default: 'Deactivate'
    }
  },
  methods: {
    activateuser () {
      this.$store
        .dispatch('userviewModule/deactivateUserAction', this.userId)
        .then(res => {
          if (res.status === 200) {
            this.getUserListDelete(
              1,
              this.params.pageSize * this.params.pageNumber
            );
          }
          this.$store.commit('userviewModule/closepopUpMutation', false);
        });
    },
    closepopUp () {
      this.$store.commit('userviewModule/closepopUpMutation', false);
    },
    getUserListDelete (pageNo, pageSize) {
      this.params.pageSize = pageSize;
      this.params.pageNumber = pageNo;
      this.$store.dispatch('userviewModule/getDeleteUserList', this.params);
    }
  },
  computed: {
    ...mapState('userviewModule', [
      'userId',
      'params',
      'showdialog',
      'userslist'
    ])
  }
};
</script>
