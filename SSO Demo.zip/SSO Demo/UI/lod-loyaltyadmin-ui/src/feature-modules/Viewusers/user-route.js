import UserList from '../Viewusers/components/UserList.vue';
import AccessReport from '../Viewusers/components/AccessReport.vue';
import ActivityReport from '../Viewusers/components/ActivityReport.vue';

const viewuserRoutes = [
  {
    path: '/loyaltyadmin/viewuser',
    name: 'viewuser',
    component: UserList,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/viewuser/accessreport',
    name: 'accessreport',
    component: AccessReport,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/viewuser/activityreport',
    name: 'activityreport',
    component: ActivityReport,
    meta: {
      showNavigation: false
    }
  }
];

export default viewuserRoutes;
