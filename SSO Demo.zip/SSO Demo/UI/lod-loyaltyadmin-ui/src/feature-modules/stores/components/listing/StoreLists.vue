<template>
  <v-col>
    <v-row class="flex-column bpa0" no-gutters>
      <v-col class="page-head bpt4" v-if="storeList && storeList.length > 0">
        <brierley-page-headings
          :pageSubHeading="$t('message.mainHeader')"
          :pageSecondaryHeading="
            `(${storeList.length} ${$t('message.mainHeader')})`
          "
        ></brierley-page-headings>
      </v-col>
      <v-col class="bpt4">
        <v-row class="d-flex gen2-search-filter" no-gutters>
          <v-col class="text-left" cols="5">
            <v-row class="d-flex grid-search" no-gutters>
              <v-col class="bpr2">
                <v-text-field
                  autocomplete="off"
                  class="search-field bmb0"
                  :label="$t('message.searchLabel')"
                  prepend-inner-icon="mdi-magnify"
                  v-model="searchQuery"
                  @input="isTyping = true"
                ></v-text-field>
              </v-col>
            </v-row>
          </v-col>
          <v-col class="text-right">
            <v-row class="d-flex d-inline-flex align-center" no-gutters>
              <v-col>
                <v-row
                  v-on:click="isHidden = !isHidden"
                  class="d-flex d-inline-flex"
                  no-gutters
                >
                  <brierley-filter class="bmt1"></brierley-filter>
                </v-row>
              </v-col>
              <v-col>
                <v-row class="d-flex d-inline-flex" no-gutters>
                  <v-col class="mt-1">
                    <brierley-view-option
                      :viewList="viewList"
                      @viewChanged="changeView($event)"
                    ></brierley-view-option>
                  </v-col>
                </v-row>
              </v-col>
              <v-col>
                <v-row class="d-flex d-inline-flex" no-gutters>
                  <v-col class="mt-1">
                    <v-btn
                      text
                      class="no-ripple bpl1 f600 btn-hover-none switch-entity-btn"
                      :title="$t('message.switchEntity')"
                      @click="displayEntitySwitcher"
                    >
                      <span class="f600">{{ $t('message.switchEntity') }}</span>
                    </v-btn>
                  </v-col>
                </v-row>
              </v-col>
              <v-col>
                <v-btn
                  id="stores_create"
                  depressed
                  tile
                  class="primaryctabtn bml1 max-height-40px"
                  @click="openProgramSwitcher()"
                >
                  <span class="white--text fbold">{{
                    $t('message.createLabel')
                  }}</span>
                </v-btn>
              </v-col>
            </v-row>
          </v-col>
          <v-col cols="12" class="filter-dropdown bmt1">
            <brierley-filter-result v-if="isHidden">
              <template v-slot:body-content>
                <v-row no-gutters class="bmb6">
                  <v-col cols="4" class="bmr6">
                    <h3>{{ $t('message.openDateRange') }}</h3>
                    <v-row class="main-wrapper__header">
                      <v-col class="todate" cols="8">
                        <v-menu
                          ref="openDateFromMenu"
                          v-model="openDateFromMenu"
                          :close-on-content-click="false"
                          :return-value.sync="searchRequest.openDateFrom"
                          transition="scale-transition"
                          offset-y
                          min-width="290px"
                        >
                          <template v-slot:activator="{ on }">
                            <v-text-field
                              v-model="searchRequest.openDateFrom"
                              :label="$t('message.fromTxt')"
                              append-icon="date_range"
                              v-on="on"
                              class="darktxtfield__light"
                              filled
                            ></v-text-field>
                          </template>
                          <v-date-picker
                            v-model="searchRequest.openDateFrom"
                            no-title
                            scrollable
                          >
                            <v-spacer></v-spacer>
                            <v-btn
                              text
                              color="primary"
                              @click="openDateFromMenu = false"
                              >Cancel</v-btn
                            >
                            <v-btn
                              text
                              color="primary"
                              @click="OpenDateFromSubmit()"
                              >OK</v-btn
                            >
                          </v-date-picker>
                        </v-menu>
                        <v-menu
                          ref="openDateToMenu"
                          v-model="openDateToMenu"
                          :close-on-content-click="false"
                          :return-value.sync="searchRequest.openDateTo"
                          transition="scale-transition"
                          offset-y
                          min-width="290px"
                        >
                          <template v-slot:activator="{ on }">
                            <v-text-field
                              v-model="searchRequest.openDateTo"
                              :label="$t('message.toTxt')"
                              append-icon="date_range"
                              v-on="on"
                              class="darktxtfield__light"
                              filled
                            ></v-text-field>
                          </template>
                          <v-date-picker
                            v-model="searchRequest.openDateTo"
                            no-title
                            scrollable
                          >
                            <v-spacer></v-spacer>
                            <v-btn
                              text
                              color="primary"
                              @click="openDateToMenu = false"
                              >Cancel</v-btn
                            >
                            <v-btn
                              text
                              color="primary"
                              @click="OpenDateToSubmit()"
                              >OK</v-btn
                            >
                          </v-date-picker>
                        </v-menu>
                        <span
                          class="custom-error-msg"
                          v-if="openDateErrorMsg"
                          >{{ $t('message.errorMsg') }}</span
                        >
                      </v-col>
                    </v-row>
                  </v-col>
                  <v-col cols="4" class="bmr6">
                    <h3>{{ $t('message.closeDateRange') }}</h3>
                    <v-row class="main-wrapper__header">
                      <v-col class="todate" cols="8">
                        <v-menu
                          ref="closeDateFromMenu"
                          v-model="closeDateFromMenu"
                          :close-on-content-click="false"
                          :return-value.sync="searchRequest.closeDateFrom"
                          transition="scale-transition"
                          offset-y
                          min-width="290px"
                        >
                          <template v-slot:activator="{ on }">
                            <v-text-field
                              v-model="searchRequest.closeDateFrom"
                              :label="$t('message.fromTxt')"
                              append-icon="date_range"
                              v-on="on"
                              class="darktxtfield__light"
                              filled
                            ></v-text-field>
                          </template>
                          <v-date-picker
                            v-model="searchRequest.closeDateFrom"
                            no-title
                            scrollable
                          >
                            <v-spacer></v-spacer>
                            <v-btn
                              text
                              color="primary"
                              @click="closeDateFromMenu = false"
                              >Cancel</v-btn
                            >
                            <v-btn
                              text
                              color="primary"
                              @click="closeDateFromSubmit()"
                              >OK</v-btn
                            >
                          </v-date-picker>
                        </v-menu>
                        <v-menu
                          ref="closeDateToMenu"
                          v-model="closeDateToMenu"
                          :close-on-content-click="false"
                          :return-value.sync="searchRequest.closeDateTo"
                          transition="scale-transition"
                          offset-y
                          min-width="290px"
                        >
                          <template v-slot:activator="{ on }">
                            <v-text-field
                              v-model="searchRequest.closeDateTo"
                              :label="$t('message.toTxt')"
                              append-icon="date_range"
                              v-on="on"
                              class="darktxtfield__light"
                              filled
                            ></v-text-field>
                          </template>
                          <v-date-picker
                            v-model="searchRequest.closeDateTo"
                            no-title
                            scrollable
                          >
                            <v-spacer></v-spacer>
                            <v-btn
                              text
                              color="primary"
                              @click="closeDateToMenu = false"
                              >Cancel</v-btn
                            >
                            <v-btn
                              text
                              color="primary"
                              @click="closeDateToSubmit()"
                              >OK</v-btn
                            >
                          </v-date-picker>
                        </v-menu>
                        <span v-if="closeDateErrorMsg" class="custom-error-msg"
                          >{{ $t('message.errorMsg') }}.</span
                        >
                      </v-col>
                    </v-row>
                  </v-col>
                  <v-col cols="2" class="bml0">
                    <h3>{{ $t('message.status') }}</h3>
                    <v-row no-gutters>
                      <v-col cols="12 pt-0">
                        <v-checkbox
                          id="programList_chk_active"
                          class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                          :label="$t('message.active')"
                          value="Active"
                          v-model="status"
                        ></v-checkbox>
                        <v-checkbox
                          id="programList_chk_draft"
                          class="active-checkbox mt-0 checkbox-custom checkbox-custom__light"
                          :label="$t('message.inactive')"
                          value="inactive"
                          v-model="status"
                        ></v-checkbox>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </template>
              <template v-slot:footer>
                <v-btn text class="mr-5 cancel bmt3" @click="resetFilter()">{{
                  $t('message.resetBtn')
                }}</v-btn>
                <v-btn
                  depressed
                  class="next bmt3 primaryctabtn"
                  id="stores_btnFilterstore"
                  :loading="loading"
                  @click="submitFilterStore()"
                  >{{ $t('message.applyFilterBtn') }}</v-btn
                >
              </template>
            </brierley-filter-result>
          </v-col>
        </v-row>
      </v-col>
      <v-col>
        <store-card-view
          v-if="viewType == 'card_view'"
          :actions="actions[language]"
          :language="language"
          @showStoreDetail="showStoreDetail"
          :filterResult="filterRespone"
        />
        <store-grid-view
          v-if="viewType == 'grid_view'"
          :actions="actions[language]"
          :language="language"
          @showStoreDetail="showStoreDetail"
          :filterResult="filterRespone"
        />
        <store-table-view
          v-if="viewType == 'table_view'"
          :actions="actions[language]"
          :language="language"
          @showStoreDetail="showStoreDetail"
          :filterResult="filterRespone"
          :searchRequest="searchRequest"
        />
      </v-col>
      <v-col v-if="storeList.length === 0">
        <brierley-no-result
          :noRecordFoundHeader="$t('message.noRecordFoundHeader')"
          :noResultMessage="$t('message.noResultMessage')"
        >
        </brierley-no-result>
      </v-col>
      <v-col align="center" justify="center" class="bpt6 bmb3">
        <v-row
          v-if="scrollInProgress"
          class="d-flex d-inline-flex flex-column load-more-listing text-center"
          no-gutters
        >
          <v-col class="bpa2">
            <v-progress-circular
              :width="3"
              indeterminate
              color="brown"
            ></v-progress-circular>
          </v-col>
          <v-col>{{ $t('message.loadingText') }}</v-col>
        </v-row>
      </v-col>
      <v-col> </v-col>
    </v-row>
    <brierley-entity-switcher
      :show="showEntitySwitcher"
      :entities="businessEntities"
      :entitySelectedId="businessEntityId"
      @entity-selected="refreshStores"
      @close="closeEntitySwitcher"
    ></brierley-entity-switcher>
    <v-col>
      <store-view-details-pop-up
        v-if="openStoreDetailModel"
        :storeId="storeId"
        @closeMe="
          openStoreDetailModel = false
          storeId = null
        "
      />
    </v-col>
    <program-entity-dialog
      :dialog="chooseProgramEntity"
      :entities="businessEntities"
      @entity-selected="uploadStore"
      @close="cancelEntitySelect"
    ></program-entity-dialog>
  </v-col>
</template>
<script>
import {
  BrierleyEntitySwitcher,
  BrierleyFilter,
  BrierleyViewOption,
  BrierleyNoResult,
  BrierleyPageHeadings,
  BrierleyFilterResult
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import StoreCardView from './children/StoreCardView';
import StoreGridView from './children/StoreGridView';
import StoreTableView from './children/StoreTableView';
import { storeListsObj } from '../../../../i18n/language.js';
import constants from '../../config/constants';
import _ from 'lodash';
import StoreViewDetailsPopUp from '../StoreViewDetailsPopUp';
import ProgramEntityDialog from '../ProgramEntityDialog.vue';

export default {
  i18n: storeListsObj,
  components: {
    BrierleyEntitySwitcher,
    BrierleyFilter,
    BrierleyViewOption,
    BrierleyNoResult,
    StoreCardView,
    StoreGridView,
    StoreTableView,
    BrierleyFilterResult,
    BrierleyPageHeadings,
    StoreViewDetailsPopUp,
    ProgramEntityDialog
  },
  data () {
    return {
      loading: false,
      isHidden: false,
      scrollInProgress: false,
      error: false,
      totalPages: 0,
      errorDialog: false,
      openDateFromMenu: false,
      openDateToMenu: false,
      closeDateFromMenu: false,
      closeDateToMenu: false,
      openDateErrorMsg: false,
      closeDateErrorMsg: false,
      status: ['Active'],
      filterRespone: null,
      viewList: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('message.gridView')
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('message.tableView')
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('message.cardView')
        }
      ],
      language: {
        type: String,
        default: () => 'en'
      },
      searchQuery: '',
      isTyping: false,
      actions: constants.ACTIONS,
      fromDateDialog: false,
      toDateDialog: false,
      showEntitySwitcher: false,
      searchRequest: {
        searchText: null,
        pageNumber: 1,
        pageSize: 20,
        status: false,
        openDateFrom: null,
        openDateTo: null,
        closeDateFrom: null,
        closeDateTo: null,
        businessEntityId: 0
      },
      openStoreDetailModel: false,
      storeId: null,
      chooseProgramEntity: false,
      entitySwitcherClicked: false
    };
  },
  computed: {
    ...mapState({
      stores: (state) => state.storeModule.stores,
      tableStores: (state) => state.storeModule.tableStores,
      storesCount: (state) => state.storeModule.storesCount,
      viewType: (state) => state.storeModule.currentView,
      sortObj: (state) => state.storeModule.sortObj,
      businessEntities: (state) => state.storeModule.businessEntities,
      businessEntityId: (state) => state.storeModule.businessEntityId,
      filterApplied: (state) => state.storeModule.filterApplied,
      sortApplied: (state) => state.storeModule.sortApplied
    }),
    storeList: {
      get () {
        if (this.viewType === 'table_view') {
          if (this.filterApplied === true) {
            return this.filterRespone;
          } else if (this.sortApplied === true) {
            return this.tableStores;
          } else {
            return this.tableStores.filter((item) => {
              return item.status === true;
            });
          }
        } else {
          return this.filterRespone
            ? this.filterRespone
            : this.stores.filter((item) => {
              return item.status === true;
            });
        }
      }
    }
  },
  created () {
    this.language = this.getLanguage();
    this.initialize();
  },
  mounted () {
    this.language = this.getLanguage();
    this.scroll();
    window.scrollTo(0, 50);
    // let newSearchRequest = {
    //   pageNumber: 1,
    //   pageSize: 10
    // };
    // this.$store.dispatch(
    //   'storeModule/setSearchRequest',
    //   newSearchRequest
    // );
    // let requestForLazyLoading = {
    //   ...newSearchRequest,
    //   ...newSortObj
    // };
    // this.$store.dispatch(
    //   'storeModule/getStores',
    //   requestForLazyLoading
    // );
  },
  watch: {
    stores () {
      this.scrollInProgress = false;
    },
    searchQuery: _.debounce(function () {
      this.isTyping = false; // eslint-disable-line no-invalid-this
      this.searchRequest.PageNumber = 1; // eslint-disable-line no-invalid-this
    }, 1000),
    isTyping: function (value) {
      if (this.searchQuery === '') {
        this.searchRequest.searchText = '';
      }
      if (!value) {
        this.searchStore();
      }
    }
  },
  methods: {
    initialize () {
      let s = this;
      s.$store.commit('storeModule/setStores', undefined);
      s.$store
        .dispatch('storeDefinitionModule/getBusinessEntityNode')
        .then(() => {
          let programId = localStorage.getItem('programId');
          if (programId !== null) {
            s.$store.dispatch('storeModule/setBusinessEntities', programId);
          }
        })
        .then(() => {
          s.showEntitySwitcher = true;
        });
    },
    sortStore (entityId) {
      let newSortObj = {};
      newSortObj = {
        sortColumn: 'CreatedDate',
        isDescending: true
      };
      this.$store.dispatch('storeModule/setSortObj', newSortObj);
      let searchPaginationData = { pageNumber: 1, pageSize: 20 };
      let requestForLazyLoading = {
        ...this.searchRequest,
        ...searchPaginationData,
        ...newSortObj
      };
      this.searchRequest.status = 'active';
      this.searchRequest.businessEntityId = entityId;
      this.$store
        .dispatch('storeModule/sortStores', requestForLazyLoading)
        .then((response) => {
          this.$store.commit('storeModule/setTableStores', response);
        });
    },
    searchStore () {
      let searchPaginationData = {
        searchText: this.searchQuery,
        PageNumber: 1,
        PageSize: 10
      };
      let requestForSerachBox = {
        ...this.searchRequest,
        ...searchPaginationData
      };
      this.$store.dispatch('storeModule/searchStores', requestForSerachBox);
    },
    getLanguage () {
      let lng = localStorage.getItem('language');
      if (lng === null || lng === '') {
        return 'en';
      }
      return lng;
    },
    changeView (view) {
      let self = this;
      self.$store.dispatch('storeModule/setCurrentView', view);
    },
    refreshStores (entityId) {
      this.searchRequest.businessEntityId = entityId;
      this.$store
        .dispatch('storeModule/setBusinessEntityId', entityId)
        .then(() => {
          this.$store
            .dispatch('storeModule/filterStores', this.searchRequest)
            .finally(() => {
              this.showEntitySwitcher = false;
            });
        });
      this.sortStore(entityId);
    },
    closeEntitySwitcher () {
      this.showEntitySwitcher = false;
      if (!this.entitySwitcherClicked) {
        this.$router.push('/settings');
      }
      this.entitySwitcherClicked = false;
    },
    displayEntitySwitcher () {
      let s = this;
      let programId = localStorage.getItem('programId');
      if (programId !== null) {
        s.$store
          .dispatch('storeModule/setBusinessEntities', programId)
          .then(() => {
            s.entitySwitcherClicked = true;
            s.showEntitySwitcher = true;
          });
      }
    },
    showStoreDetail (storeId) {
      this.storeId = storeId;
      this.openStoreDetailModel = true;
    },
    resetFilter () {
      this.searchRequest.searchText = '';
      this.searchRequest.openDateFrom = '';
      this.searchRequest.openDateTo = '';
      this.searchRequest.closeDateFrom = '';
      this.searchRequest.closeDateTo = '';
      this.searchRequest.searchText = '';
      this.status = ['Active'];
      this.openDateErrorMsg = false;
      this.closeDateErrorMsg = false;
    },
    submitFilterStore () {
      this.$store.dispatch('storeModule/isFilterApplied', true);
      this.$store.dispatch('storeModule/isSortApplied', false);
      if (this.openDateErrorMsg || this.closeDateErrorMsg) {
        return true;
      }
      for (let i = 0; i < this.status.length; i++) {
        if (this.status[i] === 'Active') {
          this.searchRequest.status = 'active';
        } else if (this.status[i] === 'inactive') {
          this.searchRequest.status = 'inactive';
        }
      }
      if (this.status.length > 1) {
        this.searchRequest.status = 'both';
      }
      let filterRequest = {
        searchText: this.searchRequest.searchText,
        openDateFrom: this.searchRequest.openDateFrom
          ? new Date(this.searchRequest.openDateFrom).toISOString()
          : '',
        openDateTo: this.searchRequest.openDateTo
          ? new Date(this.searchRequest.openDateTo).toISOString()
          : '',
        closeDateFrom: this.searchRequest.closeDateFrom
          ? new Date(this.searchRequest.closeDateFrom).toISOString()
          : '',
        closeDateTo: this.searchRequest.closeDateTo
          ? new Date(this.searchRequest.closeDateTo).toISOString()
          : '',
        status: this.searchRequest.status,
        pageSize: 20,
        pageNumber: 1,
        sortColumn: '',
        isDescending: true,
        businessEntityId: this.searchRequest.businessEntityId
      };
      this.loading = true;
      this.$store
        .dispatch('storeModule/getFilterActions', filterRequest)
        .then((res) => {
          this.loading = false;
          if (res) {
            if (res.stores.length > 0) {
              this.filterRespone = res.stores;
              this.isHidden = false;
            }
          } else {
            this.filterRespone = [];
            this.isHidden = false;
          }
        })
        .catch(() => {
          this.loading = false;
          this.isHidden = false;
          this.dialog = true;
        });
    },
    OpenDateFromSubmit () {
      if (this.searchRequest.openDateFrom) {
        let openDateFrom = this.searchRequest.openDateFrom;
        this.$refs.openDateFromMenu.save(openDateFrom);
      }
      if (this.searchRequest.openDateTo) {
        let toDate = this.searchRequest.openDateTo;
        if (this.searchRequest.openDateFrom < toDate) {
          let openDateTo = this.searchRequest.openDateTo;
          this.$refs.openDateToMenu.save(openDateTo);
          this.openDateErrorMsg = false;
        } else {
          if (this.searchRequest.openDateFrom > toDate) {
            let openDateTo = this.searchRequest.openDateTo;
            this.$refs.openDateToMenu.save(openDateTo);
            this.openDateErrorMsg = true;
          }
        }
      }
    },
    OpenDateToSubmit () {
      if (this.searchRequest.openDateTo) {
        let openDateTo = this.searchRequest.openDateTo;
        this.$refs.openDateToMenu.save(openDateTo);
      }
      if (this.searchRequest.openDateFrom) {
        let fromDate = this.searchRequest.openDateFrom;
        if (this.searchRequest.openDateTo < fromDate) {
          let openDateTo = this.searchRequest.openDateTo;
          this.$refs.openDateToMenu.save(openDateTo);
          this.openDateErrorMsg = true;
        } else {
          if (this.searchRequest.openDateTo > fromDate) {
            let openDateTo = this.searchRequest.openDateTo;
            this.$refs.openDateToMenu.save(openDateTo);
            this.openDateErrorMsg = false;
          }
        }
      }
    },
    closeDateFromSubmit () {
      if (this.searchRequest.closeDateFrom) {
        let closeDateFrom = this.searchRequest.closeDateFrom;
        this.$refs.closeDateFromMenu.save(closeDateFrom);
      }
      if (this.searchRequest.closeDateTo) {
        let todate = this.searchRequest.closeDateTo;
        if (this.searchRequest.closeDateFrom < todate) {
          let closeDateTo = this.searchRequest.closeDateTo;
          this.$refs.closeDateToMenu.save(closeDateTo);
          this.closeDateErrorMsg = false;
        } else {
          if (this.searchRequest.closeDateFrom > todate) {
            let closeDateTo = this.searchRequest.closeDateTo;
            this.$refs.closeDateToMenu.save(closeDateTo);
            this.closeDateErrorMsg = true;
          }
        }
      }
    },
    closeDateToSubmit () {
      if (this.searchRequest.closeDateTo) {
        let closeDateTo = this.searchRequest.closeDateTo;
        this.$refs.closeDateToMenu.save(closeDateTo);
      }
      if (this.searchRequest.closeDateFrom) {
        let todate = this.searchRequest.closeDateFrom;
        if (this.searchRequest.closeDateTo < todate) {
          let closeDateTo = this.searchRequest.closeDateTo;
          this.$refs.closeDateToMenu.save(closeDateTo);
          this.closeDateErrorMsg = true;
        } else {
          if (this.searchRequest.closeDateTo > todate) {
            let closeDateTo = this.searchRequest.closeDateTo;
            this.$refs.closeDateToMenu.save(closeDateTo);
            this.closeDateErrorMsg = false;
          }
        }
      }
    },
    scroll () {
      window.onscroll = () => {
        if (
          document.documentElement.scrollHeight ===
            document.documentElement.scrollTop + window.innerHeight &&
          this.loadMore === true &&
          !this.load
        ) {
          this.pageNumber++;
          // this.storeList()
          // this.getProgramsList(this.pageNumber, this.PageSize);
        }
      };
    },
    cancelEntitySelect () {
      this.chooseProgramEntity = false;
    },
    uploadStore (entity) {
      this.chooseProgramEntity = false;
      const businessEntity = {
        businessEntityId: entity.entityId,
        businessEntityName: entity.entityName
      };
      this.$store.commit(
        'storeModule/setSelectedBusinessEntity',
        businessEntity
      );
      this.$router.push('/loyaltyadmin/stores/upload');
    },
    openProgramSwitcher () {
      let programId = this.$root.GlobalStoreEventStore.state.program.programId;
      if (programId !== null) {
        this.$store
          .dispatch('storeModule/setBusinessEntities', programId)
          .then(() => {
            this.chooseProgramEntity = true;
          });
      }
    }
  },
  beforeDestroy () {
    window.onscroll = null;
  }
};
</script>
