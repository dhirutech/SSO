<template>
  <brierley-inner-view class="gen2-container-py0" v-if="!uploadStoreStatus">
    <template v-slot:header>
      <span class="inner-head">
        <img
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAuCAYAAAC7zE4hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAPVSURBVHgB7ZlPTBNBFMYfxqMFjkIi9AInDARvkghn0Fi9iAnammDUeCA1sV5MCAZN8AByMRo80JgonrTG4hFq4MifBi7CwRaSws0WuK/zTTub2WVBEybpS5xfstnt62ba+fre7DevNY7jxMhyYmqEkA5ZTswpshjBCmkIK6QhrJCGsEIagq2QyY/pQ7Evsxlii8OQ38V9J9wRceYWljzxoBgXWPrIaZGNq+sblN/apc/vx9xYsXRAKZGVc19fEzdYljbK+tXzuLwulvblOTX7gyK9l+R1bnuHuMFOSAjWcb5VXg/dv0GTbz7R/MIy1dedoXBTAw0/GaTkhzSxw2FGz5UHzq98wX2NdTH28JknFhlIiHV0z+EEq4xEySLrcChi/X1ybdRjPV2dgU/1asJKyJGxdzR0r98Tg7hqnVREb/bR/OIKcYKNkBAst7Uj1scWbxyxthYh3LIbw3rpj1UbNvZnulKqMZFt/hjKOpXO0MSLuPseyv3arQQbK8QmI7Hm6SLqMayJue1dT4kjK4G/7KsFCyGReVGfiLA8+gNGWSEdWCF/rGo4DPBbHhAZeHwoBivkh4sVYrFGojzr60J/jeHBo2fpUfdVA/ufjSFsP9IQVkhDWCENYUTI4t6/eTnch92If0eiYqo9hvuUP1Rj+1tnQf4xaGz0NfWxFXhtsuNuREgYZ/VFcU7OfAu8b3VtwxVAn0Tq+7x8GtfXlk02OeROfmRsqvIZ3jGv304cEjMrRMMTfPLtjBvLLC7LGBrC+mdivHBTozFDb0RI7DIylUzILC4dey/ex4FJKNAJhwHPiXN5vBCV9g6kmLhvdX2TursuuPcnZ9I0PvpI/ADejMIPhbHVrgfU1YbkvtzfDGkW42bXfxqzTmZKW+x7m881iIkviXOjfH0UEAbZh8kp2sU1toJ6wyK3VRACFygq2mgjL6fkNlGBzEIWQ3zv2GWPGe2/HPjZea280Z7DdzXV+DCUkSE50YxobekTDqK9rVVUbo1nzcqubVb+p9l0Y8hACIKxO9pa3Th+rInROA0n7spDFwJCYny9hPPbBTk2yr37YjmrUc7xp+OV7DWTkf+1ITe5K7I7G0NYH2kIVh1yrJFqncQZMaxturVScOqOAzZCYuHHkxwWBuCMbs/V3m7XXyKmLA/e4wQbIWFF/MABlI35rszGrMjSlbVyxoabzrLpjoPTxATYFKJOaaZhX2BlICKyEcYZDCcGpXgo+5Lwqhz6kAo2QooesxQpIkr5OKSvFIcSlwvW/hjC2h9DWCENYYU0hBXSEFZIQ1ghDQEfeYcsJ+YPfxGcHgk/LlMAAAAASUVORK5CYII="
        />
        {{ $t("uploadStore") }}</span
      >
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        data-qe-id="upload_Store_btn"
        @click.native="$router.push('/loyaltyadmin/store')"
      >
        <v-icon>mdi-close</v-icon>{{ $t("close") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row class="flex-column bpt5" no-gutters>
        <v-col>
          <brierley-form-title
            :formTitle="$t('chooseFile')"
            :infoText="$t('chooseUploadFileInfo')"
          >
          </brierley-form-title>
        </v-col>
        <v-col class="bmt5">
          <v-row no-gutters>
            <v-col xs="12" sm="6">
              <v-row class="flex-column" no-gutters>
                <v-col>
                  <p>
                    {{ $t("uploadStoreInfo") }}
                  </p>
                  <p class="label-text bmt5">
                    {{ $t("importStoreTasks") }}
                  </p>
                  <p>
                    {{ $t("importStoreTasks_1") }} <br />
                    {{ $t("importStoreTasks_2") }}<br />
                    {{ $t("importStoreTasks_3") }}
                    <br />
                    {{ $t("importStoreTasks_4") }}
                  </p>
                </v-col>
                <v-col class="bmt3 bmb5">
                  <v-divider class="dashed"></v-divider>
                </v-col>
                <v-col class="label-text">
                  {{ $t("uploadCSV") }}
                </v-col>
                <v-col class="max-width-450">
                  <vue-dropzone
                    ref="myVueDropzone"
                    id="dropzone"
                    class="store-upload__browse"
                    :options="dropzoneOptions"
                    :include-styling="false"
                    :useCustomSlot="true"
                    @vdropzone-file-added="onFileAdded"
                    @vdropzone-error="onUploadError"
                    @vdropzone-drop="onFileDropped"
                  >
                    <div class="dropzone-container">
                      <div class="upload-image" v-if="isUploaded">
                        <div class="store-upload__browse__text">
                          <div class="store-upload__browse--close">
                            <v-icon>insert_drive_file</v-icon>
                            <v-icon
                              :disabled="loading"
                              class="store-upload__browse--close-icon"
                              id="store_upload_close_icon"
                              @click="confirmDelete"
                              >close</v-icon
                            >
                          </div>
                          <span
                            class="elipsis-fullwidth d-inline-block"
                            :title="selectedFile.name"
                            >{{ selectedFile.name }}</span
                          >
                        </div>
                      </div>
                      <div class="file-selector" v-show="!isUploaded">
                        <v-icon>add_photo_alternate</v-icon>
                        <p>
                          {{ $t("dropCSVFile") }}
                          <span
                            class="cursor-p"
                            id="store_upload_media_trigger"
                            >{{ $t("browse") }}</span
                          >
                        </p>
                      </div>
                    </div>
                  </vue-dropzone>
                </v-col>
              </v-row>
            </v-col>
            <v-col xs="12" sm="5" offset-sm="1">
              <brierley-info-side>
                <template v-slot:info-side-header>
                  <div class="info_title">
                    <v-icon>info</v-icon>
                    {{ $t("info") }}
                  </div>
                </template>
                <template v-slot:info-side-body>
                  <v-row no-gutters class="flex-column">
                    <v-col>{{ $t("csvTemplate") }}</v-col>
                    <v-col class="bmt1 fbold">
                      {{ $t("one") }}
                      <span
                        class="primary-text fbold cursor-p"
                        @click="downloadTemplate()"
                        >{{ $t("store_Template") }}</span
                      >
                    </v-col>
                  </v-row>
                </template>
              </brierley-info-side>
            </v-col>
            <v-col sm="12" class="bmt5 mb-1" v-if="dropZoneError">
              <brierley-alert
                class="bmb3"
                :isSiteLevel="true"
                :alertHeader="customAlertType"
                alertType="error"
                icon="warning"
                :alertBody="customAlertBody"
              ></brierley-alert>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </template>
    <template v-slot:footer-previous>
      <v-btn
        text
        class="mr-5 cancel no-ripple"
        data-qe-id="store_Upload_previous_btn"
      >
        <v-icon class="bpr1">arrow_back</v-icon>
        {{ $t("previous") }}
      </v-btn>
    </template>
    <template v-slot:footer>
      <p class="bmb1 text-right" v-if="loading">{{ $t("importInProgress") }}</p>
      <v-btn
        text
        class="cancel no-ripple  bmr6"
        data-qe-id="store_Upload_cancel_btn"
        >{{ $t("cancel") }}</v-btn
      >
      <v-btn
        :disabled="disableImport"
        :loading="loading"
        class="primaryctabtn"
        data-qe-id="store_Upload_import_btn"
        @click="importFile"
        >{{ $t("import") }}</v-btn
      >
    </template>
  </brierley-inner-view>
  <StoreStatus v-else-if="uploadStoreStatus !== ''"></StoreStatus>
</template>
<script>
import {
  BrierleyInnerView,
  BrierleyFormTitle,
  brierleyAlert,
  BrierleyInfoSide
} from '@brierley/SharedComponents';
import vue2Dropzone from 'vue2-dropzone';
import StoreStatus from './StoreStatus';
import { mapState } from 'vuex';
import * as api from '../api/store.api';
import { storeUploadObj } from '../../../i18n/language';

export default {
  i18n: storeUploadObj,
  components: {
    vueDropzone: vue2Dropzone,
    BrierleyInnerView,
    BrierleyFormTitle,
    brierleyAlert,
    BrierleyInfoSide,
    StoreStatus
  },
  data () {
    return {
      selectedFile: null,
      dropZoneError: '',
      loading: false,
      status: false,
      dropzoneOptions: {
        url: 'https://httpbin.org/post',
        thumbnailWidth: 150,
        maxFilesize: 1000,
        uploadMultiple: false,
        acceptedFiles: '.csv',
        maxFiles: 1,
        autoProcessQueue: false,
        addRemoveLinks: true,
        clickable: '#store_upload_media_trigger',
        accept: function (file, done) {
          done();
        }
      },
      isUploaded: false
    };
  },
  mounted () {
    window.scrollTo(0, 0);
    this.$store.dispatch('storeModule/downloadStoreTemplate');
  },
  methods: {
    onFileAdded (file) {
      this.isUploaded = true;
      if (!this.dropZoneError) {
        this.selectedFile = file;
        if (this.selectedFile.type === 'application/vnd.ms-excel') {
          let s = this;
          const reader = new FileReader();
          reader.readAsText(this.selectedFile);
          reader.onloadend = e => {
            const lines = e.target.result.split(/\n/);
            if (lines[0] !== s.storeTemplate) {
              s.dropZoneError = this.$t('latestTemplateMsg');
            }
          };
        }
        if (file.name.length > 252) {
          this.dropZoneError = this.$t('fileNameExceedsMsg');
        }
      }
    },
    onFileDropped () {
      this.dropZoneError = '';
      this.$refs.myVueDropzone.removeAllFiles();
    },
    confirmDelete () {
      this.dropZoneError = '';
      this.$refs.myVueDropzone.removeAllFiles();
      this.selectedFile = '';
      this.isUploaded = false;
    },
    onUploadError (file, message) {
      this.dropZoneError = message.replace(/MiB/g, 'MB');
    },
    importFile () {
      let formData = new FormData();
      formData.append(
        'programId',
        this.$root.GlobalStoreEventStore.state.program.programId
      );
      formData.append(
        'programName',
        this.$root.GlobalStoreEventStore.state.program.name
      );
      formData.append('serviceId', 2);
      formData.append('serviceName', 'Stores');
      formData.append('file', this.selectedFile);
      formData.append(
        'businessEntityId',
        this.selectedBusinessEntity.businessEntityId
      );
      formData.append(
        'businessEntityName',
        this.selectedBusinessEntity.businessEntityName
      );
      this.loading = true;
      this.$store.dispatch('storeModule/uploadStore', formData);
    },
    async downloadTemplate () {
      const res = await api.downloadStoreTemplateAsync();
      const blob = new Blob([res.data], { type: res.headers['content-type'] });
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = this.$t('store_csv');
      link.click();
    }
  },
  computed: {
    ...mapState('storeModule', [
      'uploadStoreStatus',
      'storeTemplate',
      'selectedBusinessEntity'
    ]),
    disableImport () {
      return !this.selectedFile || this.dropZoneError !== '' || this.loading;
    },
    customAlertType () {
      if (this.dropZoneError.includes('You can\'t upload files of this type.')) {
        return this.$t('fileFormatType');
      }
      if (this.dropZoneError.includes('File is too big')) {
        return this.$t('fileExceedsType');
      }
      return '';
    },
    customAlertBody () {
      if (this.dropZoneError.includes('You can\'t upload files of this type.')) {
        return this.$t('fileFormatMsg');
      }
      if (this.dropZoneError.includes('File is too big')) {
        return this.$t('fileExceedsMsg');
      }
      if (this.dropZoneError === this.$t('fileNameExceedsMsg')) {
        return this.$t('fileNameExceedsMsg');
      }
      return this.$t('latestTemplateMsg');
    }
  },
  watch: {
    uploadStoreStatus (val) {
      if (val) {
        this.confirmDelete();
      }
    }
  }
};
</script>
<style lang="scss">
.store-upload__browse {
  .dz-preview {
    display: none !important;
  }
  .upload-image {
    max-width: 100%;
    width: 100%;
  }
  &--close {
    position: relative;
    width: 54px;
    margin: auto;
    padding: 4px;
    margin-top: 8px;
    .v-icon {
      margin: 0 auto !important;
      cursor: pointer;
    }
    &:hover {
      background: rgba(0, 0, 0, 0.4);
      border-radius: 4px;
      .store-upload__browse--close-icon {
        opacity: 1 !important;
      }
    }
  }
  .dropzone-container {
    .store-upload__browse--close-icon {
      font-size: 18px !important;
      font-weight: bold;
      opacity: 0;
      position: absolute;
      left: 0;
      right: 0;
      color: #fff;
      top: 15px;
      cursor: pointer;
    }
  }
}
</style>
