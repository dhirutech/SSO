<template>
  <brierley-dialogbox
    :dialog="dialog"
    @closeMe="close"
    customDialog="custom-dialog"
    cardStyle="gen2-dialogbox"
    cardStyleContent=""
  >
    <template v-slot:dialog-header>
      <v-card-title class="gen2-dialog-title text-uppercase">
        {{ $t("header") }}
      </v-card-title>
    </template>
    <template v-slot:dialog-body-alert>
      <v-row no-gutters>
        <v-col md="12">
          <p>{{ $t("title") }}</p>
        </v-col>
        <v-col md="12">
          <p class="fbold text-uppercase bmt1">
            {{ $t("selectEntity") }}
          </p>
        </v-col>
        <v-col md="5" class="bmb9">
          <v-select
            :label="label"
            v-model="entityId"
            :items="entities"
            item-text="name"
            item-value="businessEntityId"
            class="gen2select gen2select__dark"
            append-icon="expand_more"
            :disabled="!entities || !entities.length"
            filled
            attach
          ></v-select>
        </v-col>
      </v-row>
    </template>
    <template v-slot:dialog-footer>
      <v-row no-gutters>
        <v-col md="12" class="d-flex justify-end align-center">
          <v-btn
            data-qe-id="choose_entity_cancel-btn"
            text
            class="cancel no-ripple"
            @click="close"
          >
            {{ $t("cancel") }}
          </v-btn>
          <v-btn
            class="primaryctabtn"
            data-qe-id="choose_entity_continue-btn"
            :title="$t('continue')"
            :disabled="disabled"
            @click="setEntity"
          >
            {{ $t("continue") }}
          </v-btn>
        </v-col>
      </v-row>
    </template>
  </brierley-dialogbox>
</template>

<script>
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { programEntityDialogObj } from '../../../i18n/language';

export default {
  components: {
    BrierleyDialogbox
  },
  data () {
    return {
      entityId: null
    };
  },
  computed: {
    disabled () {
      return !this.entities.length || !this.entityId;
    },
    label () {
      if (!this.entities.length) return this.$t('noEntities');

      return this.$t('selectEntity');
    }
  },
  methods: {
    setEntity () {
      if (this.entityId) {
        const entityName = this.entities.filter(
          x => x.businessEntityId === this.entityId
        )[0].name;
        this.$emit('entity-selected', {
          entityId: this.entityId,
          entityName: entityName
        });
      }
    },
    close () {
      this.entityId = null;
      this.$emit('close');
    }
  },
  i18n: programEntityDialogObj,
  props: {
    entities: {
      type: Array,
      default: () => []
    },
    dialog: {
      type: Boolean,
      default: () => false
    }
  }
};
</script>
