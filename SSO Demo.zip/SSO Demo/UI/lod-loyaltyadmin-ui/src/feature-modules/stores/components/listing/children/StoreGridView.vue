<template>
  <v-row class="d-flex flex-column" no-gutters>
    <v-col
      cols="12"
      class="grid-margin"
      v-for="store in storeList"
      :key="store.storeId"
    >
      <brierley-grid-card>
        <template v-slot:grid-card-body>
          <v-col sm="3" xs="12">
            <v-row>
              <v-col md="12" class="bpt0 bpb0">
                <v-card-title
                  :title="store.storeName"
                  class="elipsis-fullwidth"
                >
                  {{ store.storeName }}
                </v-card-title>
              </v-col>
            </v-row>
            <v-row>
              <v-col md="12" class="bpt0 bpb0">
                <p class="elipsis-twoline">
                  <strong>{{ $t("message.storeCode") + ":" }}</strong>
                  {{ store.externalStoreCode }}
                </p>
                <p>
                  <strong>{{ $t("message.programEntity") + ":" }}</strong>
                  {{ getEntityName(store.businessEntityId) }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col sm="4" xs="12">
            <v-row no-gutters>
              <v-col md="12" class="bpt0 bpb0">
                <p class="bmt0">
                  <strong>{{ $t("message.address") + ":" }}</strong>
                </p>
                <p>
                  {{ store.addressLineOne + " " + store.addressLineTwo }}
                </p>
                <p class="bmt0">
                  {{
                    store.city +
                      " " +
                      store.stateOrProvince +
                      " " +
                      store.zipOrPostalCode
                  }}
                </p>
                <p class="bmt0">
                  {{ getCountryName(store.countryCode) }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col sm="3" xs="12">
            <v-row no-gutters class="pr-3 mb-4">
              <v-col class="text-xs-left max-width-100">
                <p class="bmt0">
                  <strong>{{ $t("message.openDate") + ":" }}</strong>
                </p>
              </v-col>
              <v-col class="text-xs-right">
                <div v-if="store.openDate">
                  <div>{{ formatDate(store.openDate) }}</div>
                  <div>
                    {{ formatTime(store.openDate) + "" + timezoneName }}
                  </div>
                </div>
              </v-col>
            </v-row>
            <v-row no-gutters class="pr-3">
              <v-col class="text-xs-left max-width-100">
                <p>
                  <strong>{{ $t("message.closeDate") + ":" }}</strong>
                </p>
              </v-col>
              <v-col class="text-xs-right">
                <div class="bmt1" v-if="store.closeDate">
                  <div>{{ formatDate(store.closeDate) }}</div>
                  <div>
                    {{ formatTime(store.closeDate) + "" + timezoneName }}
                  </div>
                </div>
              </v-col>
            </v-row>
          </v-col>
          <v-col sm="2" xs="12">
            <v-row no-gutters>
              <v-col md="12" class="bpt0 bpb0">
                <p class="bmt0">
                  <strong>{{ $t("message.status") + ":" }}</strong>
                </p>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col sm="12">
                <brierley-status
                  :status="getStatus(store.status)"
                ></brierley-status>
              </v-col>
            </v-row>
          </v-col>
          <v-col>
            <brierleyCardIcons>
              <template v-slot:action-icons>
                <span class="active" @click="viewDetails(store.id)">
                  <v-icon :title="$t('message.viewText')">fe-eye</v-icon>
                  <span class="viewdetails-icon">{{
                    $t("message.viewText")
                  }}</span>
                </span>
                <span>
                  <v-icon :title="$t('message.editText')">fe-edit</v-icon>
                  <span class="edit-icon">{{ $t("message.editText") }}</span>
                </span>
                <span>
                  <v-icon :title="$t('message.copyText')">fe-copy</v-icon>
                  <span class="copy-icon">{{ $t("message.copyText") }}</span>
                </span>
                <span>
                  <v-icon :title="$t('message.deleteText')">fe-trash-2</v-icon>
                  <span class="delete-icon">{{
                    $t("message.deleteText")
                  }}</span>
                </span>
              </template>
            </brierleyCardIcons>
          </v-col>
        </template>
      </brierley-grid-card>
    </v-col>
  </v-row>
</template>
<script>
import {
  BrierleyGridCard,
  BrierleyStatus,
  BrierleyCardIcons
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { storeListsObj } from '../../../../../i18n/language.js';
import moment from 'moment';
import helper from '../../../utilities/stores-helper';

export default {
  i18n: storeListsObj,
  components: {
    BrierleyCardIcons,
    BrierleyGridCard,
    BrierleyStatus
  },
  props: {
    actions: {
      type: Array
    },
    language: {
      type: String,
      default: () => 'en'
    },
    filterResult: {
      type: Array,
      default: () => 0
    }
  },
  data () {
    return {
      isHidden: false
    };
  },
  computed: {
    ...mapState({
      stores: state => state.storeModule.stores,
      businessEntityNode: state =>
        state.storeDefinitionModule.businessEntityNode
    }),
    timezoneName () {
      return helper.getTimezoneName();
    },
    storeList: {
      get () {
        return this.filterResult
          ? this.filterResult
          : this.stores.filter(item => {
            return item.status === true;
          });
      }
    }
  },
  mounted () {
    window.scrollTo(0, 0);
  },
  methods: {
    getActions (store) {
      let self = this;
      return self.actions.map(action => {
        switch (action.id) {
        case 1000:
          return {
            ...action,
            ...{
              click: { name: 'viewStore', params: { id: store.storeId } }
            }
          };
        case 1001:
          return {
            ...action,
            ...{
              click: { name: 'editStore', params: { id: store.storeId } }
            }
          };
        case 1002:
          return {
            ...action,
            ...{
              click: { name: 'cloneStore', params: { id: store.storeId } }
            }
          };
        case 1003:
          return {
            ...action,
            ...{
              click: { name: 'deleteStore', params: { id: store.storeId } }
            }
          };
        }
        return action;
      });
    },
    getStatus (status) {
      if (status) {
        return 'Active';
      }
      return 'Inactive';
    },
    getCountryName () {
      return '';
    },
    formatDate (value) {
      return moment(value).format('MMM Do YYYY');
    },
    formatTime (value) {
      return moment(value).format('hh:mm A zz');
    },
    getEntityName (id) {
      return helper.entityLookUp(id, this.businessEntityNode);
    },
    viewDetails (id) {
      let content = document.querySelector('html');
      content.classList.add('overflow-y-hidden');
      this.$emit('showStoreDetail', id);
    }
  }
};
</script>
<style scoped>
.grid-margin {
  padding-bottom: 4px !important;
}
</style>
