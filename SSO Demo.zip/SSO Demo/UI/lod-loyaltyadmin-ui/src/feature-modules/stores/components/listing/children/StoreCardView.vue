<template>
  <v-row>
    <v-col
      md="6"
      sm="12"
      xs="12"
      v-for="(store, index) in storeList"
      :key="index"
    >
      <brierley-card>
        <template v-slot:header>
          <h2 :title="store.storeName" class="bmt2 bml2">
            {{
              store.storeName.length > 29
                ? store.storeName.substr(0, 29) + '...'
                : store.storeName
            }}
          </h2>
        </template>
        <template v-slot:body>
          <p class="elipsis-twoline text-left bmt3 bml2" :title="store.storeId">
            <strong>{{ $t('message.storeCode') + ': ' }}</strong>
            {{ store.externalStoreCode }}
          </p>
          <p class="text-left bmt3 bml2" :title="store.addressLineOne">
            <strong>{{ $t('message.address') + ':' }}</strong>
          </p>
          <p class="bml2 address-height">{{ getFullAddress(store) }}</p>
          <v-row no-gutters>
            <v-col class="bmt2 bml2">
              <p class="elipsis-twoline text-left" :title="store.openDate">
                <strong>{{ $t('message.openDate') + ':' }}</strong>
              </p>
              <p v-if="store.openDate">
                {{ formatDateTime(store.openDate) + '' + timezoneName }}
              </p>
            </v-col>
            <v-col class="bmt2 bml2">
              <p class="elipsis-twoline text-left" :title="store.closeDate">
                <strong>{{ $t('message.closeDate') + ':' }}</strong>
              </p>
              <p v-if="store.closeDate">
                {{ formatDateTime(store.closeDate) + '' + timezoneName }}
              </p>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="bmb0 bmt3 bml2">
              <p
                class="elipsis-twoline text-left"
                :title="store.businessEntityId"
              >
                <strong>{{ $t('message.programEntity') + ': ' }}</strong>
                {{ getEntityName(store.businessEntityId) }}
              </p>
            </v-col>
            <v-col class="bmb0 bmt3 bml2">
              <p class="elipsis-twoline text-left" :title="store.status">
                <strong>{{ $t('message.status') + ': ' }}</strong>
              </p>
              <p>
                <brierley-status
                  :status="getStatus(store.status)"
                ></brierley-status>
              </p>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="action-margins bml2">
              <brierleyCardIcons>
                <template v-slot:action-icons>
                  <span class="active" @click="viewDetails(store.id)">
                    <v-icon :title="$t('message.viewText')">fe-eye</v-icon>
                    <span class="viewdetails-icon">{{
                      $t('message.viewText')
                    }}</span>
                  </span>
                  <span>
                    <v-icon :title="$t('message.editText')">fe-edit</v-icon>
                    <span class="edit-icon">{{ $t('message.editText') }}</span>
                  </span>
                  <span>
                    <v-icon :title="$t('message.copyText')">fe-copy</v-icon>
                    <span class="copy-icon">{{ $t('message.copyText') }}</span>
                  </span>
                  <span>
                    <v-icon :title="$t('message.deleteText')"
                      >fe-trash-2</v-icon
                    >
                    <span class="delete-icon">{{
                      $t('message.deleteText')
                    }}</span>
                  </span>
                </template>
              </brierleyCardIcons>
            </v-col>
          </v-row>
        </template>
      </brierley-card>
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyCard,
  BrierleyStatus,
  BrierleyCardIcons
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { storeListsObj } from '../../../../../i18n/language.js';
import moment from 'moment';
import helper from '../../../utilities/stores-helper';

export default {
  i18n: storeListsObj,
  components: {
    BrierleyCard,
    BrierleyStatus,
    BrierleyCardIcons
  },
  props: {
    actions: {
      type: Array
    },
    language: {
      type: String,
      default: () => 'en'
    },
    filterResult: {
      type: Array,
      default: () => 0
    }
  },
  computed: {
    ...mapState({
      stores: (state) => state.storeModule.stores,
      businessEntityNode: (state) =>
        state.storeDefinitionModule.businessEntityNode
    }),
    timezoneName () {
      return helper.getTimezoneName();
    },
    storeList: {
      get () {
        return this.filterResult
          ? this.filterResult
          : this.stores.filter((item) => {
            return item.status === true;
          });
      }
    }
  },
  methods: {
    getActions (storeObj) {
      let self = this;
      return self.actions.map((it) => {
        switch (it.referenceId) {
        case 1000:
          return {
            ...it,
            ...{
              click: {
                name: 'viewStore',
                params: { id: storeObj.storeId }
              }
            }
          };
        case 1001:
          return {
            ...it,
            ...{
              click: {
                name: 'editStore',
                params: { id: storeObj.storeId }
              }
            }
          };
        case 1002:
          return {
            ...it,
            ...{
              click: {
                name: 'cloneStore',
                params: { id: storeObj.storeId }
              }
            }
          };
        case 1003:
          return {
            ...it,
            ...{
              click: {
                name: 'deleteStore',
                params: { id: storeObj.storeId }
              }
            }
          };
        }
        return it;
      });
    },
    getEntityName (id) {
      return helper.entityLookUp(id, this.businessEntityNode);
    },
    getStatus (status) {
      if (status) {
        return 'Active';
      }
      return 'Inactive';
    },
    formatDateTime (value) {
      return moment(value).format('MMM Do YYYY hh:mm A zz');
    },
    getFullAddress (store) {
      let fullAddress =
        store.addressLineOne +
        ' ' +
        store.addressLineTwo +
        ' ' +
        store.city +
        ' ' +
        store.stateOrProvince +
        ' ' +
        store.zipOrPostalCode +
        ' ' +
        helper.getCountryName(store.countryCode);

      if (fullAddress.length > 120) {
        return fullAddress.substr(0, 117) + '...';
      }

      return fullAddress;
    },
    viewDetails (id) {
      let content = document.querySelector('html');
      content.classList.add('overflow-y-hidden');
      this.$emit('showStoreDetail', id);
    }
  }
};
</script>

<style scoped>
.text-left {
  text-align: left !important;
}
.action-margins {
  margin-top: 3px;
  margin-bottom: -10px !important;
}
.address-height {
  height: 31px !important;
}
</style>
