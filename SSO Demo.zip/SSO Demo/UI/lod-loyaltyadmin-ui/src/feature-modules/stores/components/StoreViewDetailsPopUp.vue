<template>
  <v-row>
    <v-col sm="12">
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closeDialog()"
        :persistent="false"
        class="custom-dialog__large"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            storeDetailslist.storeName
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-description>
          <v-col cols="12" md="12" class="endless-tailored">
            <v-row no-gutters>
              <v-col cols="12" md="12" class="endless-tailored bmt3 bpr2">
                <span class="endless-tailored__title">
                  {{ $t("storeDetails") }}
                </span>
                <v-flex class="endless-tailored__section">
                  <v-row no-gutters>
                    <v-col md="6">
                      <strong>{{ $t("storeCode") }}</strong>
                      <small>{{ storeDetailslist.storeName }}</small>
                      <strong>{{ $t("brandStoreName") }}</strong>
                      <small>{{ storeDetailslist.brandStoreNumber }}</small>
                    </v-col>
                    <v-col md="6">
                      <strong>{{ $t("phoneNumber") }}</strong>
                      <small>{{ storeDetailslist.phoneNumber }}</small>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col md="12">
                      <strong>{{ $t("storeAddress") }}</strong>
                      <p>
                        <template v-if="storeDetailslist.addressLineOne !== ''">
                          {{ storeDetailslist.addressLineOne }}
                        </template>
                        <template v-if="storeDetailslist.addressLineTwo !== ''">
                          <br />{{ storeDetailslist.addressLineTwo }},
                        </template>
                        <template v-if="storeDetailslist.city !== ''">
                          <br />
                          {{ storeDetailslist.city }}
                        </template>
                        <template
                          v-if="storeDetailslist.stateOrProvince !== ''"
                        >
                          , {{ storeDetailslist.stateOrProvince }}
                        </template>
                        <template
                          v-if="storeDetailslist.zipOrPostalCode !== ''"
                        >
                          , {{ storeDetailslist.zipOrPostalCode }}
                        </template>
                        <template v-if="storeDetailslist.countryCode !== ''">
                          , {{ storeDetailslist.countryCode }}
                        </template>
                      </p>
                    </v-col>
                  </v-row>
                </v-flex>

                <v-flex class="endless-tailored__section">
                  <v-row no-gutters>
                    <v-col md="12">
                      <strong class="link-label">{{
                        $t("storeTiming")
                      }}</strong>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col md="6">
                      <strong>{{ $t("opensAt") }}</strong>
                      <small>{{
                        format_date(storeDetailslist.openDate)
                      }}</small>
                      <strong>{{ $t("storeStatus") }}</strong>
                      <small>{{
                        storeDetailslist.status == true ? "Active" : "InActive"
                      }}</small>
                    </v-col>
                    <v-col md="6">
                      <strong>{{ $t("closesAt") }}</strong>
                      <small>{{
                        format_date(storeDetailslist.closeDate)
                      }}</small>
                    </v-col>
                  </v-row>
                </v-flex>

                <v-flex class="endless-tailored__section">
                  <v-row no-gutters>
                    <v-col md="6">
                      <strong>{{ $t("region") }}</strong>
                      <small>{{ storeDetailslist.region }}</small>
                      <strong>{{ $t("district") }}</strong>
                      <small>{{ storeDetailslist.district }}</small>
                      <strong>{{ $t("zone") }}</strong>
                      <small>{{ storeDetailslist.zone }}</small>
                    </v-col>
                    <v-col md="6">
                      <v-row
                        no-gutters
                        v-for="(value,
                        key,
                        index) in storeDetailslist.extensionProperty"
                        :key="index"
                      >
                        <v-col md="12">
                          <strong>{{ key | uppercase }}</strong>
                          <small>{{ value }}</small>
                        </v-col>
                      </v-row>
                    </v-col>
                  </v-row>
                </v-flex>
              </v-col>
            </v-row>
          </v-col>
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>

<script>
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { storeDetailObj } from '../../../i18n/language.js';
import { mapState } from 'vuex';
import moment from 'moment';

export default {
  components: {
    BrierleyDialogbox
  },
  i18n: storeDetailObj,
  data () {
    return {
      dialog: false
    };
  },
  props: {
    storeId: {
      type: Number,
      default: 0
    }
  },
  filters: {
    uppercase: function (string) {
      return string.charAt(0).toUpperCase() + string.slice(1);
    }
  },
  mounted () {
    this.$store.dispatch('storeModule/storeDetailsAction', this.storeId);
  },
  methods: {
    closeDialog () {
      this.$store.commit('storeModule/getStoreDetailsMutation', {});
      let content = document.querySelector('html');
      content.classList.remove('overflow-y-hidden');
      this.$emit('closeMe', true);
    },
    format_date (value) {
      if (value) {
        return moment(value).format('MM/DD/YYYY');
      }
      return '';
    }
  },
  computed: {
    ...mapState('storeModule', {
      storeDetailslist: state => {
        return state.storeDetailslist.data;
      }
    })
  }
};
</script>

<style lang="scss" scoped>
.link-label {
  color: blue !important;
  font-size: 15px !important;
}
</style>
