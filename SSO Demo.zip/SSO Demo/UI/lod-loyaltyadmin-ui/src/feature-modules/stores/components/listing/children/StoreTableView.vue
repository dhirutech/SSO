<template>
  <v-row class="d-flex flex-column" no-gutter>
    <brierley-table-module v-if="storeList && storeList.length > 0">
      <template v-slot:tablehead>
        <tr class="text-left">
          <th
            v-for="item in header"
            :key="item.name"
            @click="
              sortBy(item)
              arrowToggle()
            "
            :width="item.width"
            class="text-left"
          >{{ item.text }}
            <v-icon
              v-if="item.sort != ''"
              small
              v-bind:class="{
                down: item.sort === 'asc',
                up: item.sort === 'desc'
              }"
              class="arrow uparw primary-text"
              >arrow_drop_up</v-icon
            >
          </th>
        </tr>
      </template>

      <template v-slot:tablebody>
        <tr v-for="store in storeList" :key="store.storeId">
          <td>
            <v-row
              class="d-flex head-name user-display-name text-uppercase"
              :title="store.storeName"
              no-gutters
            >
              <v-col class="text-format elipsis-twoline">{{
                store.storeName
              }}</v-col>
            </v-row>
          </td>
          <td>
            <v-row>
              <v-col class="elipsis-twoline">
                {{ store.externalStoreCode }}
              </v-col>
            </v-row>
          </td>
          <td>
            <v-row
              v-if="store.addressLineTwo"
              :title="
                store.addressLineOne +
                  ', ' +
                  store.addressLineTwo +
                  ', ' +
                  store.city +
                  ', ' +
                  store.stateOrProvince +
                  ', ' +
                  store.zipOrPostalCode +
                  ', ' +
                  getCountryName(store.countryCode)
              "
              no-gutters
            >
              <v-col class="elipsis-twoline">{{
                store.addressLineOne +
                  ', ' +
                  store.addressLineTwo +
                  ', ' +
                  store.city +
                  ', ' +
                  store.stateOrProvince +
                  ', ' +
                  store.zipOrPostalCode +
                  ', ' +
                  getCountryName(store.countryCode)
              }}</v-col>
            </v-row>
            <v-row
              v-else
              :title="
                store.addressLineOne +
                  ', ' +
                  store.city +
                  ', ' +
                  store.stateOrProvince +
                  ', ' +
                  store.zipOrPostalCode +
                  ', ' +
                  getCountryName(store.countryCode)
              "
              no-gutters
            >
              <v-col class="elipsis-twoline">{{
                store.addressLineOne +
                  ', ' +
                  store.city +
                  ', ' +
                  store.stateOrProvince +
                  ', ' +
                  store.zipOrPostalCode +
                  ', ' +
                  getCountryName(store.countryCode)
              }}</v-col>
            </v-row>
          </td>
          <td class="textWrap">
            <div v-if="store.openDate">{{ formatDate(store.openDate) }}</div>
            <div v-if="store.openDate">
              {{ formatTime(store.openDate) + timezoneName }}
            </div>
          </td>
          <td class="textWrap">
            <div v-if="store.closeDate">{{ formatDate(store.closeDate) }}</div>
            <div v-if="store.closeDate">
              {{ formatTime(store.closeDate) + timezoneName }}
            </div>
          </td>
          <td>
            {{ getEntityName(store.businessEntityId) }}
          </td>
          <td>
            <brierley-status
              :status="getStatus(store.status)"
            ></brierley-status>
            <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
              <v-col>
                <brierleyCardIcons>
                  <template v-slot:action-icons>
                    <span class="active" @click="viewDetails(store.id)">
                      <v-icon :title="$t('message.viewText')">fe-eye</v-icon>
                      <span class="viewdetails-icon">{{
                        $t('message.viewText')
                      }}</span>
                    </span>
                    <span>
                      <v-icon :title="$t('message.editText')">fe-edit</v-icon>
                      <span class="edit-icon">{{
                        $t('message.editText')
                      }}</span>
                    </span>
                    <span>
                      <v-icon :title="$t('message.copyText')">fe-copy</v-icon>
                      <span class="copy-icon">{{
                        $t('message.copyText')
                      }}</span>
                    </span>
                    <span>
                      <v-icon :title="$t('message.deleteText')"
                        >fe-trash-2</v-icon
                      >
                      <span class="delete-icon">{{
                        $t('message.deleteText')
                      }}</span>
                    </span>
                  </template>
                </brierleyCardIcons>
              </v-col>
            </v-row>
          </td>
        </tr>
      </template>
    </brierley-table-module>
  </v-row>
</template>
<script>
import {
  BrierleyTableModule,
  BrierleyStatus,
  BrierleyCardIcons
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { storeListsObj } from '../../../../../i18n/language.js';
import moment from 'moment';
import helper from '../../../utilities/stores-helper';

export default {
  i18n: storeListsObj,
  components: {
    BrierleyTableModule,
    BrierleyStatus,
    BrierleyCardIcons
  },
  props: {
    actions: {
      type: Array
    },
    language: {
      type: String,
      default: () => 'en'
    },
    filterResult: {
      type: Array,
      default: () => 0
    },
    searchRequest: {
      searchText: '',
      pageNumber: 0,
      pageSize: 0,
      status: true,
      openDateFrom: null,
      openDateTo: null,
      closeDateFrom: null,
      closeDateTo: null,
      businessEntityId: 0,
      sortColumn: null,
      isDescending: true
    },
    PageSize: {
      type: Number
    },
    pageNumber: {
      type: Number
    }
  },
  data () {
    return {
      sortKey: ['name'],
      sortOrder: ['desc'],
      isToggled: false,
      sortRespone: null,
      header: [
        {
          name: 'StoreName',
          text: this.$t('message.storeName'),
          sort: '',
          width: '215'
        },
        {
          name: 'ExternalStoreCode',
          text: this.$t('message.storeCode'),
          sort: '',
          width: '165'
        },
        {
          name: 'address',
          text: this.$t('message.address'),
          sort: '',
          width: '215'
        },
        {
          name: 'OpenDate',
          text: this.$t('message.openDate'),
          sort: '',
          width: '147'
        },
        {
          name: 'CloseDate',
          text: this.$t('message.closeDate'),
          sort: '',
          width: '147'
        },
        {
          name: 'BusinessEntityId',
          text: this.$t('message.programEntity'),
          sort: '',
          width: '165'
        },
        {
          name: 'Status',
          text: this.$t('message.status'),
          sort: '',
          width: '166'
        }
      ],
      isHidden: false
    };
  },
  computed: {
    ...mapState({
      tableStores: (state) => state.storeModule.tableStores,
      businessEntities: (state) => state.storeModule.businessEntities,
      businessEntityId: (state) => state.storeDefinitionModule.businessEntityId,
      businessEntityNode: (state) =>
        state.storeDefinitionModule.businessEntityNode,
      filterApplied: (state) => state.storeModule.filterApplied,
      sortApplied: (state) => state.storeModule.sortApplied
    }),
    timezoneName () {
      return helper.getTimezoneName();
    },
    storeList: {
      get () {
        if (this.filterApplied === true) {
          return this.filterResult;
        } else if (this.sortApplied === true) {
          return this.sortRespone;
        } else {
          return this.tableStores.filter((item) => {
            return item.status === true;
          });
        }
      }
    }
  },
  mounted () {
    this.scroll();
    window.scrollTo(0, 50);
  },
  methods: {
    sortBy: function (item) {
      let i = this.header.indexOf(item);
      for (let j = 0; j < this.header.length; j++) {
        if (j === i) {
          this.header[j].sort =
            this.header[j].sort === '' || this.header[j].sort === 'desc'
              ? 'asc'
              : 'desc';
        } else {
          this.header[j].sort = '';
        }
      }
      this.sortKey = this.header[i].name;
      this.sortOrder = this.header[i].sort;
      let searchPaginationData = { pageNumber: 1, pageSize: 20 };
      this.sortByKey(searchPaginationData);
    },
    arrowToggle () {
      this.isToggled = !this.isToggled;
    },
    sortByKey (searchPaginationData) {
      this.$store.dispatch('storeModule/isFilterApplied', false);
      this.$store.dispatch('storeModule/isSortApplied', true);
      let s = this;
      let newSortObj = {
        sortColumn: this.sortKey,
        isDescending: this.sortOrder === 'desc' ? true : false
      };
      this.$store.dispatch('storeModule/setSortObj', newSortObj);
      // let searchPaginationData =
      //   { pageNumber: 1,
      //     pageSize: 20 };
      let requestForLazyLoading = {
        ...s.searchRequest,
        ...searchPaginationData,
        ...newSortObj
      };
      this.$store
        .dispatch('storeModule/sortStores', requestForLazyLoading)
        .then((res) => {
          if (res) {
            if (res.stores.length > 0) {
              this.sortRespone = res.stores;
            }
          } else {
            this.sortRespone = [];
          }
        });
    },
    getActions (store) {
      let self = this;
      return self.actions.map((action) => {
        switch (action.id) {
        case 1000:
          return {
            ...action,
            ...{
              click: { name: 'viewStore', params: { id: store.storeId } }
            }
          };
        case 1001:
          return {
            ...action,
            ...{
              click: { name: 'editStore', params: { id: store.storeId } }
            }
          };
        case 1002:
          return {
            ...action,
            ...{
              click: { name: 'cloneStore', params: { id: store.storeId } }
            }
          };
        }
        return action;
      });
    },
    getStatus (status) {
      if (status) {
        return 'Active';
      }
      return 'Inactive';
    },
    getCountryName () {
      return '';
      // return helper.getCountryName(countryCode);
    },
    formatDate (value) {
      return moment(value).format('MMM Do YYYY');
    },
    formatTime (value) {
      return moment(value).format('hh:mm A zz');
    },
    getEntityName (id) {
      return this.entityLookUp(id, this.businessEntityNode);
    },
    entityLookUp (id, node) {
      let s = this;
      if (node.id === id) return node.name;

      if (node.children && node.children.length > 0) {
        for (let i = 0; i < node.children.length; i++) {
          return s.entityLookUp(id, node.children[0]);
        }
      }
    },
    viewDetails (id) {
      let content = document.querySelector('html');
      content.classList.add('overflow-y-hidden');
      this.$emit('showStoreDetail', id);
    },
    scroll () {
      window.onscroll = () => {
        if (
          document.documentElement.scrollHeight ===
            document.documentElement.scrollTop + window.innerHeight &&
          this.loadMore === true &&
          !this.load
        ) {
          this.pageNumber++;
          // this.getProgramsList(this.pageNumber, this.PageSize);
        }
      };
    }
  },
  beforeDestroy () {
    window.onscroll = null;
  }
};
</script>
