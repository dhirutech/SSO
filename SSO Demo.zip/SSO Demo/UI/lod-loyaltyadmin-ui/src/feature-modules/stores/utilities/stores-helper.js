import constants from '../config/constants';

const getTimezoneName = () => {
  const today = new Date();
  const short = today.toLocaleDateString(undefined);
  const full = today.toLocaleDateString(undefined, { timeZoneName: 'short' });

  const shortIndex = full.indexOf(short);
  if (shortIndex >= 0) {
    const trimmed = full.substring(0, shortIndex) + full.substring(shortIndex + short.length);
    return trimmed.replace(/^[\s,.\-:;]+|[\s,.\-:;]+$/g, '');
  } else {
    return full;
  }
};

const entityLookUp = (id, node) => {
  if (node.id === id)
    return node.name;

  if (node.children && node.children.length > 0) {
    for (let i = 0; i < node.children.length; i++) {
      return entityLookUp(id, node.children[0]);
    }
  }
};

const getCountryName = (countryCode) => {
  if (countryCode.length > 0) {
    let countries = constants.COUNTRIES
      .filter(c => c.code === countryCode);
    if (countries.length > 0)
      return countries[0].name;
  }
};

export default {
  getTimezoneName,
  entityLookUp,
  getCountryName
};
