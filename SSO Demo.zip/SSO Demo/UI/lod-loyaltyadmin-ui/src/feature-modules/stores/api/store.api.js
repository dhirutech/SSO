import Vue from 'vue';
import constants from '../config/constants';

const uploadStoreAsync = async request => {
  return await Vue.prototype.$http.post(
    '/contentservice/api/upload/files',
    request
  );
};

const postFilterStoresAsync = async searchRequest => {
  return await Vue.prototype.$http
    .post(constants.STORE_V1 + '/filter', searchRequest)
    .then(res => {
      return res.data.data;
    });
};

const getBusinessEntitiesByProgramIdAsync = async programId => {
  return await Vue.prototype.$http
    .get(constants.STORE_DEFINITION_V1 + '/businessentities/' + programId)
    .then(res => {
      return res.data.data;
    });
};

const downloadStoreTemplateAsync = async () => {
  return await Vue.prototype.$http
    .get('/contentservice/api/batchImport/templateLayout?serviceName=Stores')
    .then(response => {
      return response;
    })
    .catch(err => {
      throw err;
    });
};

const getStoreDetails = payload => {
  return Vue.prototype.$http.get('product/api/v1/stores/' + payload);
};
const getFilterData = async filterRequest => {
  return await Vue.prototype.$http
    .post(constants.STORE_V1 + '/filter', filterRequest)
    .then(res => {
      return res.data.data;
    });
};
export {
  uploadStoreAsync,
  postFilterStoresAsync,
  getBusinessEntitiesByProgramIdAsync,
  downloadStoreTemplateAsync,
  getStoreDetails,
  getFilterData
};
