const STORE_V1 = '/product/api/v1/stores';
const STORE_DEFINITION_V1 = '/product/api/v1/storedefinitions';

const ACTIONS = {
  en: [
    {
      id: 1000,
      name: 'View',
      value: 'view details',
      referenceId: 1000,
      icon: 'fe-eye',
      disable: false
    },
    {
      id: 1001,
      name: 'Edit',
      value: 'edit',
      referenceId: 1001,
      icon: 'fe-edit',
      disable: false
    },
    {
      id: 1002,
      name: 'Clone',
      value: 'clone',
      referenceId: 1002,
      icon: 'fe-copy',
      disable: false
    },
    {
      id: 1003,
      name: 'Delete',
      value: 'delete',
      referenceId: 1003,
      icon: 'fe-trash-2',
      disable: false
    }
  ],
  ja: [
    {
      id: 1010,
      name: 'View',
      value: '詳細',
      referenceId: 1000,
      icon: 'fe-eye',
      disable: false
    },
    {
      id: 1011,
      name: 'Edit',
      value: '編集',
      referenceId: 1001,
      icon: 'fe-edit',
      disable: false
    },
    {
      id: 1012,
      name: 'Clone',
      value: 'コピー',
      referenceId: 1002,
      icon: 'fe-copy',
      disable: false
    },
    {
      id: 1013,
      name: 'Delete',
      value: '削除',
      referenceId: 1003,
      icon: 'fe-trash-2',
      disable: false
    }
  ]
};

const COUNTRIES = [
  {
    id: 1,
    code: 'USA',
    name: 'United States'
  },
  {
    id: 2,
    code: 'JAP',
    name: 'Japan'
  },
  {
    id: 3,
    code: 'CAN',
    name: 'Canada'
  }
];

export default {
  STORE_V1,
  STORE_DEFINITION_V1,
  ACTIONS,
  COUNTRIES
};
