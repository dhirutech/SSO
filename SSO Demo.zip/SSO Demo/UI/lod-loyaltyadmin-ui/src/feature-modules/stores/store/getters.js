const getUploadStoreStatus = state => state.uploadStoreStatus;
const getStores = state => state.stores;
const getBusinessEntities = state => state.businessEntities;
const businessEntityId = state => state.businessEntityId;
const getCurrentView = state => state.currentView;
const getStoreTemplate = state => state.storeTemplate;

export default {
  getUploadStoreStatus,
  getStores,
  getBusinessEntities,
  businessEntityId,
  getCurrentView,
  getStoreTemplate
};
