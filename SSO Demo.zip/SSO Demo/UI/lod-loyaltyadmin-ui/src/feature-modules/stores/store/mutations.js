const uploadStoreStatus = (state, payload) => {
  state.uploadStoreStatus = payload;
};

const setStores = (state, payload) => {
  if (payload !== undefined) {
    state.stores = payload.stores;
    state.storesCount = payload.totalCount;
  } else {
    state.stores = [];
    state.storesCount = 0;
  }
};

const setTableStores = (state, payload) => {
  if (payload !== undefined) {
    state.tableStores = payload.stores;
    state.storesCount = payload.totalCount;
  } else {
    state.tableStores = [];
    state.storesCount = 0;
  }
};

const setCurrentView = (state, payload) => {
  state.currentView = payload;
};

const setSortObj = (state, payload) => {
  state.sortObj = payload;
};

const setSearchRequest = (state, payload) => {
  state.searchRequest = payload;
};

const setBusinessEntities = (state, payload) => {
  state.businessEntities = payload;
};

const setBusinessEntityId = (state, payload) => {
  state.businessEntityId = payload;
};

const setStoreTemplate = (state, payload) => {
  state.storeTemplate = payload;
};

const setSelectedBusinessEntity = (state, payload) => {
  state.selectedBusinessEntity = payload;
};

const setStoresSearched = (state, payload) => {
  if (!payload) {
    state.stores = [];
    state.storesCount = 0;
  } else {
    state.stores = payload.stores;
    state.storesCount = payload.totalCount;
  }
};

const getStoreDetailsMutation = (state, payload) => {
  state.storeDetailslist = payload;
};
const setFilterStatus = (state, payload) => {
  state.filterApplied = payload;
};
const setSortStatus = (state, payload) => {
  state.sortApplied = payload;
};

export default {
  uploadStoreStatus,
  setCurrentView,
  setSortObj,
  setSearchRequest,
  setStores,
  setBusinessEntities,
  setBusinessEntityId,
  setStoreTemplate,
  setSelectedBusinessEntity,
  setStoresSearched,
  getStoreDetailsMutation,
  setTableStores,
  setFilterStatus,
  setSortStatus
};
