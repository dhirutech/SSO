export default {
  uploadStoreStatus: '',
  sortApplied: false,
  filterApplied: false,
  store: {
    Id: '',
    storeId: 0,
    name: '',
    description: ''
  },
  stores: [],
  tableStores: [],
  storesCount: 0,
  currentView: 'grid_view',
  sortObj: {
    sortBy: 'CreatedDate',
    isDesc: true
  },
  businessEntities: [],
  businessEntityId: 0,
  storeTemplate: '',
  selectedBusinessEntity: {
    businessEntityId: 0,
    businessEntityName: ''
  },
  storeDetailslist: []
};
