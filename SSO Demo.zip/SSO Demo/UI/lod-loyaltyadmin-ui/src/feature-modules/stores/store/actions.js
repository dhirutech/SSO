import * as api from '../api/store.api';

const uploadStore = async ({ commit }, payload) => {
  await api
    .uploadStoreAsync(payload)
    .then(() => {
      commit('uploadStoreStatus', 'Success');
    })
    .catch(() => {
      commit('uploadStoreStatus', 'Error');
    });
};
const setBusinessEntities = async ({ commit }, programId) => {
  let response = await api.getBusinessEntitiesByProgramIdAsync(programId);
  commit('setBusinessEntities', response);
};

const setBusinessEntityId = async ({ commit }, businessEntityId) => {
  commit('setBusinessEntityId', businessEntityId);
};

const setCurrentView = ({ commit }, value) => {
  commit('setCurrentView', value);
};

const setSortObj = ({ commit }, value) => {
  commit('setSortObj', value);
};

const setSearchRequest = ({ commit }, value) => {
  commit('setSearchRequest', value);
};

const downloadStoreTemplate = async ({ commit }, request) => {
  let response = await api.downloadStoreTemplateAsync(request);
  commit('setStoreTemplate', response.data);
};

const searchStores = async ({ commit }, request) => {
  let response = await api.postFilterStoresAsync(request);
  commit('setStoresSearched', response);
};
const filterStores = async ({ commit }, request) => {
  let response = await api.postFilterStoresAsync(request);
  commit('setStores', response);
};
const sortStores = async ({ commit }, request) => {
  let response = await api.postFilterStoresAsync(request);
  commit('setTableStores', response);
  return response;
};

const getFilterActions = async (context, filterRequest) => {
  return await api.getFilterData(filterRequest);
};
const storeDetailsAction = async ({ commit }, payload) => {
  await api
    .getStoreDetails(payload)
    .then(res => {
      commit('getStoreDetailsMutation', res.data);
    })
    .catch(() => {
      commit('getStoreDetailsMutation', 'Error');
    });
};
const isFilterApplied = ({ commit }, value) => {
  commit('setFilterStatus', value);
};
const isSortApplied = ({ commit }, value) => {
  commit('setSortStatus', value);
};
export default {
  uploadStore,
  filterStores,
  setCurrentView,
  setBusinessEntities,
  setBusinessEntityId,
  setSortObj,
  setSearchRequest,
  downloadStoreTemplate,
  searchStores,
  sortStores,
  storeDetailsAction,
  getFilterActions,
  isFilterApplied,
  isSortApplied
};
