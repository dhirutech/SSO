import StoreUpload from './components/StoreUpload';
import StoreLists from './components/listing/StoreLists';

const storesRoutes = [
  {
    path: '/loyaltyadmin/stores/upload',
    name: 'StoreUpload',
    component: StoreUpload,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/store',
    name: 'storeLists',
    component: StoreLists,
    meta: {
      showNavigation: true
    }
  }
];

export default storesRoutes;
