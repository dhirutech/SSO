<template>
  <span @mouseleave="updateActionOnHoverLeave">
    <brierleyCardIcons>
        <template v-slot:action-icons>
            <brierley-control-icon
                v-for="action in actions"
                :key="action.value"
                :defaultIconValue="actions[0].referenceId"
                :icon="action.icon"
                :label="action.value"
                :title="action.value"
                :referenceId="action.referenceId"
                :id="'row_' + action.id"
                :isHovered="isHovered"
                :language="language"
                :disable="action.disable"
                :selectedHover="selectedHover"
                @iconClicked="actionClicked(action)"
                @iconHoveredEnter="updateActionOnHoverEnter">
            </brierley-control-icon>
        </template>
    </brierleyCardIcons>
  </span>
</template>

<script>
import { BrierleyCardIcons } from '@brierley/SharedComponents';
import BrierleyControlIcon from './BrierleyControlIcon';

export default {
  name: 'BrierleyTableRow',
  components: {
    BrierleyControlIcon,
    BrierleyCardIcons
  },
  props: {
    actions: {
      type: Array
    },
    language: {
      type: String,
      default: () => 'en'
    }
  },
  data: function () {
    return {
      isHovered: true,
      selectedHover: 0
    };
  },
  methods: {
    actionClicked: function (action) {
      if (action.disable === true) return;

      if (action.referenceId !== 1003)
        this.$router.push(action.click);
      else {
        this.changeDialog(action.click.id, action.click.name, action.click.dialog);
      }
    },
    changeDialog (id, name, dialog) {
      const self = this;
      self.$store.dispatch('roleModule/setDialogStatus', !dialog);
      self.$store.dispatch('roleModule/setSelectedRole', { id, name });
    },
    updateActionOnHoverEnter: function (selectedIconValue, disable) {
      if (disable === true) {
        this.selectedHover = this.actions[0].referenceId;
        this.isHovered = true;
      } else {
        this.selectedHover = selectedIconValue;

        if (this.actions[0].referenceId === selectedIconValue) {
          this.isHovered = true;
        } else {
          this.isHovered = false;
        }
      }
    },
    updateActionOnHoverLeave: function () {
      this.selectedHover = this.actions[0].referenceId;
      this.isHovered = true;
    }
  }
};
</script>
