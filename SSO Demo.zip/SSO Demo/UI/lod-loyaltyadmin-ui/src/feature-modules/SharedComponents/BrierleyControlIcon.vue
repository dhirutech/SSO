<template no-gutters>
    <span no-gutters
        :id="`button${id}`"
        v-on:click="$emit('iconClicked')"
        @mouseover="$emit('iconHoveredEnter', referenceId, disable)"
    >
        <v-icon
            :title="title"
            class="role-icon-size"
            v-bind:class="[
                `${this.defaultIconValue === this.referenceId && isHovered ? 'icon-active' : this.disable === true ? 'icon-disable' :  'icon-inactive'}`,
                `${this.defaultIconValue !== this.referenceId && selectedHover === this.referenceId ? 'icon-active' : this.disable === true ? 'icon-disable' :  'icon-inactive'}`
            ]"
        >
            {{ icon }}
        </v-icon>
        <span no-gutters
            :id="`span${id}`"
            v-bind:class="[
                `${this.defaultIconValue === this.referenceId && isHovered && this.disable === false ? this.class(referenceId) : this.disable === true ? 'icon-width-zero' : ''}`,
                `${this.defaultIconValue !== this.referenceId && selectedHover === this.referenceId && this.disable === false ? this.class(referenceId) : this.disable === true ? 'icon-width-zero' : ''}`
            ]"
            >
            {{ this.label }}
        </span>
    </span>
</template>

<script>
export default {
  name: 'BrierleyCardIcon',
  props: {
    icon: {
      type: String,
      default: () => 'visibility'
    },
    label: {
      type: String,
      default: () => 'View Details'
    },
    title: {
      type: String,
      default: () => 'View Details'
    },
    id: {
      type: String,
      default: () => 'details'
    },
    defaultIconValue: {
      type: Number
    },
    isHovered: {
      type: Boolean,
      default: () => false
    },
    selectedHover: {
      type: Number,
      default: () => ''
    },
    referenceId: {
      type: Number,
      default: 0
    },
    language: {
      type: String,
      default: () => 'en'
    },
    disable: {
      type: Boolean,
      default: () => true
    }
  },
  methods: {
    class (actionReferenceId) {
      switch (actionReferenceId) {
      case 1000:
        if (this.language === 'en')
          return 'icon-width-view';
        else
          return 'icon-width-view-ja';
      case 1001:
        if (this.language === 'en')
          return 'icon-width-edit';
        else
          return 'icon-width-edit-ja';
      case 1002:
        if (this.language === 'en')
          return 'icon-width-clone';
        else
          return 'icon-width-clone-ja';
      case 1003:
        if (this.language === 'en')
          return 'icon-width-delete';
        else
          return 'icon-width-delete-ja';
      case '':
        return '';
      }
    }
  }
};
</script>

<style>
    div.gen2-card-btm-icons span i.v-icon.role-icon-size{
        font-size:20px !important;
    }
    div.gen2-card-btm-icons span i.v-icon.role-icon-size:before{
        font-size:20px !important;
    }
</style>

<style scoped>
    .icon-width-zero{
        min-width: 0px !important;
        border-bottom: solid 2px #0628b1;
    }
    .icon-width-view{
        min-width: 85px !important;
        border-bottom: solid 2px #0628b1;
    }
    .icon-width-view-ja{
        min-width: 30px !important;
        border-bottom: solid 2px #0628b1;
    }
    .icon-width-edit{
        min-width: 32px !important;
        border-bottom: solid 2px #0628b1;
    }

    .icon-width-edit-ja{
        min-width: 25px !important;
        border-bottom: solid 2px #0628b1;
    }
    .icon-width-clone{
        min-width: 43px !important;
        border-bottom: solid 2px #0628b1;
    }
    .icon-width-clone-ja{
        min-width: 35px !important;
        border-bottom: solid 2px #0628b1;
    }
    .icon-width-delete{
        min-width: 45px !important;
        border-bottom: solid 2px #0628b1;
    }
    .icon-width-delete-ja{
        min-width: 27px !important;
        border-bottom: solid 2px #0628b1;
    }
    .icon-no-width{
        min-width: 0px !important;
        border-bottom: solid 2px #0628b1;
    }
    .icon-active{
        color: #0628b1 !important;
    }
    .icon-inactive{
        color: #000 !important;
    }
    .icon-disable{
        color: #bdbdbd;
    }
</style>
