<template>
  <v-row class="row-margin-10 mtn-12 bmb2">
    <v-col
      md="6"
      sm="12"
      xs="12"
      v-for="(product, index) in productdefinitionlistdata"
      :key="index"
    >
      <v-card class="gen2-card gen2-typo3 each-productdefination-card">
        <v-row no-gutters>
          <v-col md="12" sm="12" xs="12" class="bpa4">
            <v-card-title
              data-qe-id="productdefinition_name"
              class="elipsis-fullwidth"
              >&nbsp;
              {{ product.name === '' ? 'N/A' : product.name }}</v-card-title
            >
            <div class="gen2-card-copy bpt4">
              <p class="elipsis-fullwidth" data-qe-id="productdefinition_gap">
                <strong data-qe-id="productdefinition_gap_title">{{
                  $t('descriptionLabel')
                }}</strong>
                <br />
                {{ product.description }}
              </p>
            </div>
            <div class="gen2-card-copy bpt4">
              <p id="productdefinition_programentity">
                <strong data-qe-id="productdefinition_program_title">{{
                  $t('programEntityLabel')
                }}</strong>
                &nbsp;
                <span v-if="product.businessEntity !== null">{{
                  product.businessEntity.name
                }}</span>
              </p>
            </div>
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span :title="$t('viewDetails')" class="active">
                  <v-icon
                    data-qe-id="loyaltyadmin_productdefinition_viewicon"
                    class="blackicon cursor-p"
                    @click="
                      $router.push({
                        name: 'productDefinitionView',
                        query: { id: product.productDefinitionId }
                      })
                    "
                    >fe-eye</v-icon
                  >
                  <span
                    class="viewdetails-icon"
                    data-qe-id="loyaltyadmin_productdefinition_viewname"
                    @click="
                      $router.push({
                        name: 'productDefinitionView',
                        query: { id: product.productDefinitionId }
                      })
                    "
                    >{{ $t('viewDetails') }}
                  </span>
                </span>
                <span title="Edit">
                  <v-icon data-qe-id="productdefinition_edit" class="blackicon"
                    >fe fe-edit</v-icon
                  >
                  <span
                    class="edit-icon"
                    @click="
                      $router.push({
                        name: 'editProductDefinition',
                        query: { id: product.productDefinitionId }
                      })
                    "
                    >{{ $t('editLabel') }}</span
                  >
                </span>
                <span title="Copy">
                  <v-icon
                    data-qe-id="productdefinition_copy"
                    class="blackicon cursor-p"
                    @click="
                      $router.push({
                        name: 'cloneProductDefinition',
                        query: { id: product.productDefinitionId }
                      })
                    "
                    >fe fe-copy</v-icon
                  >
                  <span
                    class="copy-icon"
                    @click="
                      $router.push({
                        name: 'cloneProductDefinition',
                        query: { id: product.productDefinitionId }
                      })
                    "
                    >{{ $t('copyLabel') }}</span
                  >
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
        </v-row>
      </v-card>
    </v-col>
  </v-row>
</template>

<script>
import { BrierleyCardIcons } from '@brierley/SharedComponents';
import { productDefinitionCardViewObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyCardIcons
  },
  i18n: productDefinitionCardViewObj,
  props: {
    productdefinitionlistdata: {
      type: Array
    }
  }
};
</script>
<style lang="scss">
.each-productdefination-card {
  border-bottom: solid 1px #777777 !important;
  min-height: 336px;
}
</style>
