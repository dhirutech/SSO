<template>
  <v-row class="no-gutters">
    <brierley-dialogbox
      class="custom-dialog__large custom-large"
      :width="1200"
      :dialog="true"
      @closeMe="CloseDialogNo"
      :content-class="customLarge"
    >
      <template v-slot:dialog-header>
        <v-card-title class="gen2-dialog-title text-uppercase">
          {{ $t('programHierarchy') }}
        </v-card-title>
      </template>
      <template v-slot:dialog-body-description>
        <v-col>
          <template>
            <div class="chart-container loyalty-org" v-if="orgProductData">
              <div class="orgchart-container bpb6">
                <div class="orgchart bmb6 bpb6">
                  <organization-product-chart-node
                    :datasource="orgProductData"
                  ></organization-product-chart-node>
                </div>
              </div>
            </div>
          </template>
        </v-col>
      </template>
      <template v-slot:dialog-footer>
        <v-btn
          title="No"
          text
          class="cancel no-ripple bmb3"
          @click="CloseDialogNo"
        ></v-btn>
        <v-btn text class="cancel no-ripple " @click="CloseDialogNo">
          {{ $t('noBtnText') }}
        </v-btn>
        <v-btn
          class="primaryctabtn btn-close long-width-btn "
          title="Default"
          @click="CloseDialogYes"
          :disabled="selectedOrgProductDataBasedOnYesOrNo.length === 0"
          >{{ $t('doneBtnText') }}</v-btn
        >
      </template>
    </brierley-dialogbox>
  </v-row>
</template>
<script>
import OrganizationProductChartNode from './OrganizationProductChartNode.vue';
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { getJsonData } from './../helper/orgProductData-helper.js';
import { programHierarchyLanguageObj } from '../../../i18n/language.js';
export default {
  name: 'parent',
  components: {
    BrierleyDialogbox,
    OrganizationProductChartNode
  },
  computed: {
    ...mapState('productdefinitionModule', {
      orgProductData: (state) => {
        return getJsonData(state.orgProductData);
      },
      openProgramHierarchy: (state) => {
        return state.openProgramHierarchy;
      }
    }),
    ...mapState('productdefinitionModule', [
      'selectedOrgProductDataBasedOnYesOrNo'
    ])
  },
  created () {
    this.$store.dispatch(
      'productdefinitionModule/getProductOrganizationDataAction'
    );
  },
  mounted () {
    this.$store.dispatch(
      'productdefinitionModule/updateSelectedProductDataToImplitDataAction'
    );
    this.orgChatOnload();
  },
  methods: {
    CloseDialogNo () {
      this.$store.dispatch(
        'productdefinitionModule/updateSelectedProductDataNoAction'
      );
      this.CloseDialog();
    },
    CloseDialogYes () {
      this.$store.dispatch(
        'productdefinitionModule/updateSelectedProductDataYesAction'
      );
      this.CloseDialog();
    },
    CloseDialog () {
      this.$store.dispatch(
        'productdefinitionModule/setDialogOpenAndCloseAction'
      );
    },
    orgChatOnload () {
      let content = document.querySelector('.orgchart-container');
      let calcx = document.querySelector('.orgchart > table .topTR > td .node');
      content.scrollLeft = calcx.offsetLeft - 300;
    }
  },
  i18n: programHierarchyLanguageObj
};
</script>
