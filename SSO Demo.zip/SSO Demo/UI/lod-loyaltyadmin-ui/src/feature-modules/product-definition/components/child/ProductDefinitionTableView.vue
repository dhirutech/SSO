<template>
  <v-row class="flex-column bmb3 pb-1" no-gutters>
    <v-col>
      <brierley-table-module
        v-if="productdefinitionlistdata.length > 0"
        class="no-gutters"
      >
        <template v-slot:tablehead>
          <tr class="text-left">
            <th
              data-qe-id="productdefinition_header"
              v-for="item in header"
              :key="item.name"
              class="text-left"
              :width="item.width"
            >{{ item.text }}</th>
          </tr>
        </template>
        <template v-slot:tablebody>
          <tr v-for="item in productdefinitionlistdata" :key="item.name">
            <td>
              <v-row class="d-flex head-name user-display-name" no-gutters>
                <v-col
                  class="elipsis-twoline"
                  data-qe-id="productdefinition_name"
                  >{{ item.name }}</v-col
                >
              </v-row>
            </td>
            <td>
              <v-row class="d-flex" no-gutters>
                <v-col
                  class="elipsis-twoline"
                  data-qe-id="productdefinition_description"
                  >{{ item.description }}</v-col
                >
              </v-row>
            </td>
            <td>
              <v-row class="d-flex" no-gutters>
                <v-col
                  v-if="item.businessEntity !== null"
                  class="elipsis-twoline"
                  data-qe-id="productdefinition_program_name"
                  >{{ item.businessEntity.name }}</v-col
                >
              </v-row>
              <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
                <v-col>
                  <brierleyCardIcons>
                    <template v-slot:action-icons>
                      <span :title="$t('viewDetails')" class="active">
                        <v-icon
                          data-qe-id="loyaltyadmin_productdefinition_viewicon"
                          @click="
                            $router.push({
                              name: 'productDefinitionView',
                              query: { id: item.productDefinitionId }
                            })
                          "
                          >fe-eye</v-icon
                        >
                        <span
                          class="viewdetails-icon"
                          data-qe-id="loyaltyadmin_productdefinition_viewname"
                          @click="
                            $router.push({
                              name: 'productDefinitionView',
                              query: { id: item.productDefinitionId }
                            })
                          "
                          >{{ $t('viewDetails') }}</span
                        >
                      </span>
                      <span title="Edit">
                        <v-icon
                          data-qe-id="productdefinition_edit"
                          class="blackicon"
                          >fe fe-edit</v-icon
                        >
                        <span
                          class="edit-icon"
                          @click="
                            $router.push({
                              name: 'editProductDefinition',
                              query: { id: item.productDefinitionId }
                            })
                          "
                          >{{ $t('editLabel') }}</span
                        >
                      </span>
                      <span title="Copy">
                        <v-icon
                          data-qe-id="productdefinition_copy"
                          class="blackicon cursor-p"
                          @click="
                            $router.push({
                              name: 'cloneProductDefinition',
                              query: { id: item.productDefinitionId }
                            })
                          "
                          >feather-icon fe fe-copy</v-icon
                        >
                        <span
                          class="copy-icon"
                          @click="
                            $router.push({
                              name: 'cloneProductDefinition',
                              query: { id: item.productDefinitionId }
                            })
                          "
                          >{{ $t('copyLabel') }}</span
                        >
                      </span>
                    </template>
                  </brierleyCardIcons>
                </v-col>
              </v-row>
            </td>
          </tr>
        </template>
      </brierley-table-module>
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyCardIcons,
  BrierleyTableModule
} from '@brierley/SharedComponents';
import { productDefinitionTableViewObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyCardIcons,
    BrierleyTableModule
  },

  data () {
    return {
      sortKey: ['name'],
      sortOrder: ['asc'],
      isToggled: false,
      changeColor: false,
      btext: '',
      msg: '',
      headertext: '',
      header: [
        { name: 'name', text: this.$t('defNameText'), sort: 'asc' },
        { name: 'description', text: this.$t('descriptionText'), sort: '' },
        { name: 'externalid', text: this.$t('programEntityText'), sort: '' }
      ]
    };
  },
  i18n: productDefinitionTableViewObj,
  props: {
    productdefinitionlistdata: {
      type: Array
    }
  }
};
</script>
