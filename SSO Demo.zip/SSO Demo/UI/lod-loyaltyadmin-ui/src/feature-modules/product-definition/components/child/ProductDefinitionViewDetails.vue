<template>
  <brierley-inner-view class="gen2-container-py0">
    <template v-slot:header>
      <span class="inner-head">{{ $t('productDefinitionLabel') }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>{{ $t('closeBtnText') }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row class="flex-column bpt5" no-gutters>
        <v-col>
          <brierley-form-title
            :formTitle="$t('productDefinitionLabel')"
            :infoText="$t('productDefInfoText')"
          />
        </v-col>
      </v-row>
      <keep-alive>
        <v-form>
          <v-row no-gutters class="bpt5">
            <v-col class="gen2-forms form-light-bg" xs="12" sm="7">
              <p class="label-text">{{ $t('basicDetailsText') }}</p>
              <v-col sm="8" xs="12" class="bpa0">
                <v-text-field
                  autocomplete="off"
                  :label="$t('productSetNameLabel')"
                  id="loyaltyadmin_productDefinition_basic_name"
                  :disabled="true"
                  :readonly="true"
                  filled
                  required
                  v-model="productDefinitionData.name"
                ></v-text-field>
              </v-col>
              <v-col sm="10" xs="12" class="bpa0">
                <v-textarea
                  id="loyaltyadmin_productdefinition_description"
                  :label="$t('productSetDescriptionLabel')"
                  :disabled="true"
                  :readonly="true"
                  filled
                  auto-grow
                  v-model="productDefinitionData.description"
                ></v-textarea>
              </v-col>
            </v-col>
            <v-col xs="12" sm="5">
              <brierley-info-side>
                <template v-slot:info-side-header>
                  <div class="info_title">
                    <v-icon>info</v-icon>{{ $t('infoText') }}
                  </div>
                </template>
                <template v-slot:info-side-body>
                  <div>
                    {{ $t('infoPassage') }}
                  </div>
                </template>
              </brierley-info-side>
            </v-col>
          </v-row>
        </v-form>
      </keep-alive>
      <v-expansion-panels
        class="role-assignment-expansions bpt3 bpb5"
        accordion
        v-model="panel"
        :disabled="disabled"
        multiple
      >
        <v-expansion-panel>
          <v-expansion-panel-header>{{
            $t('productAttributesLabel')
          }}</v-expansion-panel-header>
          <v-expansion-panel-content>
            <v-row class="gen2-scroll-table" no-gutters>
              <v-col>
                <v-row class="table_container d-flex" no-gutters>
                  <v-col
                    class="table-center sticky-data-table gen2-forms form-light-bg"
                  >
                    <v-flex class="sticky-data-table__scroll">
                      <v-simple-table class="sticky-data-table__table">
                        <thead>
                          <tr>
                            <th
                              class="sticky-first"
                              data-qe-id="loyaltyadmin_viewproductdefinition_attributename"
                            >
                              {{ $t('attributeNameLabel') }}
                            </th>
                            <th
                              class="largecol"
                              data-qe-id="loyaltyadmin_viewproductdefinition_datatype"
                            >
                              {{ $t('dataTypeLabel') }}
                            </th>
                            <th
                              data-qe-id="loyaltyadmin_viewproductdefinition_maxlength"
                            >
                              {{ $t('maxLengthLabel') }}
                              <v-icon
                                :title="$t('maxLengthTitle')"
                                class="cursor-p"
                                >mdi-information-outline</v-icon
                              >
                            </th>
                            <th
                              class="largecol"
                              data-qe-id="loyaltyadmin_viewproductdefinition_required"
                            >
                              {{ $t('requireLabel') }}
                            </th>
                            <th
                              class="largecol"
                              data-qe-id="loyaltyadmin_viewproductdefinition_unique"
                            >
                              {{ $t('uniqueLabel') }}
                            </th>
                            <th
                              data-qe-id="loyaltyadmin_viewproductdefinition_uniques"
                            >
                              {{ $t('descriptionLabel') }}
                            </th>
                            <th
                              data-qe-id="loyaltyadmin_viewproductdefinition_defaultvalue"
                            >
                              {{ $t('defaultValueLabel') }}
                              <v-icon
                                :title="$t('attributeTitle')"
                                class="cursor-p"
                                >mdi-information-outline</v-icon
                              >
                            </th>
                            <th
                              data-qe-id="loyaltyadmin_viewproductdefinition_displayname"
                            >
                              {{ $t('displayNameLabel') }}
                            </th>
                            <th
                              class="sticky-last"
                              data-qe-id="viewproductdefinition-actions"
                            >
                              {{ $t('actionsLabel') }}
                            </th>
                          </tr>
                        </thead>
                        <tbody
                          v-if="
                            productDefinitionData.productCoreAttributes != null
                          "
                        >
                          <tr
                            v-for="(items,
                            j) in productDefinitionData.productCoreAttributes"
                            :key="j"
                          >
                            <td
                              class="sticky-first"
                              data-qe-id="productdefinition-attributename-res"
                            >
                              <v-row class="content-info" no-gutters>
                                <v-col
                                  data-qe-id="loyaltyadmin_viewproductdefinition_attributename_value"
                                  >{{ items.attributeName }}</v-col
                                >
                                <v-col
                                  md="auto"
                                  class="align-self-center"
                                  data-qe-id="productdefinition-lock"
                                >
                                  <v-icon>lock</v-icon>
                                </v-col>
                              </v-row>
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_viewproductdefinition_datatype_value"
                                >{{ items.dataType }}</span
                              >
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_viewproductdefinition_maxlength_value"
                                >{{ items.maxlength }}</span
                              >
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_viewproductdefinition_required_value"
                                >{{ items.require }}</span
                              >
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_viewproductdefinition_unique_value"
                                >{{ items.unique }}</span
                              >
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_viewproductdefinition_description"
                                >{{ items.description }}</span
                              >
                            </td>

                            <td>
                              <span
                                data-qe-id="loyaltyadmin_viewproductdefinition_defaultvalue"
                              ></span>
                            </td>

                            <td>
                              <span
                                data-qe-id="loyaltyadmin_viewproductdefinition_displayname"
                              ></span>
                            </td>
                            <td class="sticky-last">
                              <span>
                                <v-icon
                                  id="productdefinition-edit"
                                  data-qe-id="loyaltyadmin_viewproductdefinition_edit"
                                  :disabled="true"
                                  >edit</v-icon
                                >
                              </span>
                              <v-icon
                                id="productdefinition-delete"
                                data-qe-id="loyaltyadmin_viewproductdefinition_delete"
                                :disabled="true"
                                >delete</v-icon
                              >
                            </td>
                          </tr>
                        </tbody>
                        <tbody>
                          <tr
                            v-for="(attribute,
                            j) in productDefinitionData.productExtendedAttributes"
                            :key="j"
                          >
                            <td
                              class="sticky-first"
                              data-qe-id="productdefinition-attributename-res"
                            >
                              <v-row class="content-info" no-gutters>
                                <v-col
                                  data-qe-id="loyaltyadmin_viewproductdefinition_attributename_value"
                                  >{{ attribute.columnName }}</v-col
                                >
                                <v-col
                                  md="auto"
                                  class="align-self-center"
                                  data-qe-id="productdefinition-lock"
                                >
                                </v-col>
                              </v-row>
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_extndproductdefinition_dataType"
                                >{{ attribute.dataType }}</span
                              >
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_extndproductdefinition_maxlength"
                                >{{ attribute.stringMax }}</span
                              >
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_extndproductdefinition_require"
                              ></span>
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_extndproductdefinition_unique"
                              ></span>
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_extndproductdefinition_description"
                                >{{ attribute.description }}</span
                              >
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_extndproductdefinition_defaultValue"
                                >{{ attribute.defaultValue }}</span
                              >
                            </td>
                            <td>
                              <span
                                data-qe-id="loyaltyadmin_extndproductdefinition_displayText"
                                >{{ attribute.displayText }}</span
                              >
                            </td>
                            <td class="sticky-last">
                              <span>
                                <v-icon
                                  id="productdefinition-edit"
                                  data-qe-id="loyaltyadmin_extndproductdefinition_edit"
                                  :disabled="true"
                                  >edit</v-icon
                                >
                              </span>
                              <v-icon
                                id="productdefinition-delete"
                                data-qe-id="loyaltyadmin_extndproductdefinition_delete"
                                :disabled="true"
                                >delete</v-icon
                              >
                            </td>
                          </tr>
                        </tbody>
                      </v-simple-table>
                    </v-flex>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
          </v-expansion-panel-content>
        </v-expansion-panel>
        <v-expansion-panel>
          <v-expansion-panel-header class="fbold">{{
            $t('programEntityLabel')
          }}</v-expansion-panel-header>
          <v-expansion-panel-content>
            <v-col class="programEntity">
              <v-col class="pt-0">
                <h2 class="label-text bmt1">{{ $t('programEntitiesText') }}</h2>
                <v-row
                  no-gutters
                  v-if="productDefinitionData.businessEntity == null"
                >
                  <v-col class="gen2-forms form-light-bg" xs="12" sm="7">
                    <v-col sm="8" xs="12" class="bpa0">
                      <v-text-field
                        autocomplete="off"
                        disabled
                        :label="$t('noProgramEntitySelectedText')"
                        data-qe-id="loyaltyadmin_entity_name"
                        id="productView_entity_name"
                        filled
                        required
                      ></v-text-field>
                    </v-col>
                  </v-col>
                </v-row>
                <v-row
                  no-gutters
                  v-if="productDefinitionData.businessEntity != null"
                >
                  <v-col sm="6">
                    <v-row class="flex-column block-with-chips" no-gutters>
                      <v-col class="block-with-chips__label">
                        <template>
                          <span class="req-label">{{
                            $t('selectedProgramEntitiesLabel')
                          }}</span>
                        </template>
                      </v-col>
                      <v-col class="block-with-chips__body">
                        <template>
                          <v-chip
                            :readonly="true"
                            close-icon="close"
                            data-qe-id="loyaltyadmin_entity_businessentityname"
                            >{{
                              productDefinitionData.businessEntity.name
                            }}</v-chip
                          >
                        </template>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </v-col>
            </v-col>
          </v-expansion-panel-content>
        </v-expansion-panel>
      </v-expansion-panels>
    </template>
    <template v-slot:footer>
      <v-btn
        class="primaryctabtn bmt2 bml2"
        data-qe-id="loyaltyadmin_productdefinition_close"
        @click.native="$router.push({ name: 'productdefinition' })"
        >{{ $t('closeBtnText') }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyInnerView,
  BrierleyFormTitle,
  BrierleyInfoSide
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { productDefinitionViewDetailsObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyInnerView,
    BrierleyFormTitle,
    BrierleyInfoSide
  },
  data () {
    return {
      panel: [0, 1],
      disabled: false
    };
  },
  i18n: productDefinitionViewDetailsObj,
  created () {
    this.$store.dispatch(
      'productdefinitionModule/getProductDefinitionByIdAction',
      this.$route.query.id
    );
  },
  computed: {
    ...mapState('productdefinitionModule', {
      productDefinitionData: (state) => {
        return state.productDefinitionByIdData.data;
      }
    })
  }
};
</script>
<style lang="scss" scoped>
.errclass {
  p {
    color: red;
  }
}
.programEntity {
  background: #fff;
}
</style>
