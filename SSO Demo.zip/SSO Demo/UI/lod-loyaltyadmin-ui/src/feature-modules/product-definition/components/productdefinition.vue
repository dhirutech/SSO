<template>
  <brierley-inner-view class="gen2-container-py0">
    <template v-slot:header>
      <span class="inner-head bpl1" style="position:relative; right:5px">{{
        $t("productDefInfoText")
      }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        data-qe-id="productdefinition_btn_close"
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>{{ $t("closeBtnText") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row class="flex-column loyalty-users-common bpt5" no-gutters>
        <v-col>
          <brierley-form-title
            data-qe-id="productdefinition_title"
            :formTitle="$t('productDefinitionFormTitle')"
            :infoText="$t('productDefinitionInfoText')"
          >
            <template v-slot:list-count>
              <span class="list-count" data-qe-id="productdefinition_count"
                >({{ productDefinitionsCount }}
                {{ $t("viewNoOfProductsText") }})</span
              >
            </template>
          </brierley-form-title>
        </v-col>
        <v-col class="bmb2">
          <v-row class="gen2-search-filter grid-search bpt2" no-gutters>
            <v-col class="text-left" cols="6">
              <v-text-field
                autocomplete="off"
                class="search-field"
                id="productdefinition_serch"
                :label="$t('searchProdDefText')"
                prepend-inner-icon="mdi-magnify"
                v-model="searchText"
                @input="isTyping = true"
              ></v-text-field>
            </v-col>
            <v-col cols="6" class="text-right align-self-center">
              <div class="bmr1 d-inline-block">
                <brierley-view-option
                  id="viewproductdefinition_viewoptions"
                  :viewList="cardlist"
                  @viewOptionClicked="clearFilter()"
                  @viewChanged="viewType = $event"
                ></brierley-view-option>
              </div>
              <brierley-icon-with-head
                class="loyalty-users-common__create-user"
                @click.native="$router.push('/loyaltyadmin/product/create')"
                :iconTitle="$t('createNewDefTitle')"
                :iconName="'add_circle'"
                title="Create a New Definition"
                id="viewproductdefinition_btn_createProductDefinition"
              ></brierley-icon-with-head>
            </v-col>
          </v-row>
        </v-col>
        <v-col v-if="viewType === 'card_view'">
          <product-definition-card-view
            :productdefinitionlistdata="productDefinitionlist"
            data-qe-id="productdefinition_card_view"
          />
        </v-col>
        <v-col v-if="viewType === 'grid_view'">
          <product-definition-grid-view
            data-qe-id="productdefinition_grid_view"
            :productdefinitionlistdata="productDefinitionlist"
          />
        </v-col>
        <v-col v-if="viewType === 'table_view'">
          <product-definition-table-view
            data-qe-id="productdefinition_table_view"
            :productdefinitionlistdata="productDefinitionlist"
          />
        </v-col>
        <v-col v-if="productDefinitionlist.length === 0 && !loadmore">
          <brierley-no-result
            data-qe-id="productdefinition_no_results"
            :noResultMessage="noRecordsFound"
          ></brierley-no-result>
        </v-col>
      </v-row>
      <v-col align="center" v-if="loadmore">
        <loadmore loadingText="loading" class="margin-auto" />
      </v-col>
    </template>
    <template v-slot:footer>
      <v-btn
        title="Close"
        data-qe-id="productdefinition_btn_getting_started"
        text
        class="primaryctabtn no-ripple"
        @click.native="$router.push('/gettingstarted')"
        >{{ $t("closeBtnLabel") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyFormTitle,
  BrierleyInnerView,
  BrierleyIconWithHead,
  BrierleyViewOption,
  BrierleyNoResult,
  Loadmore
} from '@brierley/SharedComponents';
import ProductDefinitionCardView from './child/ProductDefinitionCardView';
import ProductDefinitionGridView from './child/ProductDefinitionGidView';
import ProductDefinitionTableView from './child/ProductDefinitionTableView';
import { mapState } from 'vuex';
import _ from 'lodash';
import { productDefinitionObj } from '../../../i18n/language.js';
export default {
  components: {
    BrierleyFormTitle,
    ProductDefinitionCardView,
    ProductDefinitionGridView,
    BrierleyInnerView,
    BrierleyIconWithHead,
    BrierleyViewOption,
    Loadmore,
    ProductDefinitionTableView,
    BrierleyNoResult
  },
  data () {
    return {
      noRecordsFound:
        'No Product definitions have been created for this Program entity. Please use the link on the top right corner of this page to create one',
      isHidden: false,
      searchText: '',
      isTyping: false,
      loadmore: true,
      showPopUp: false,
      viewType: 'grid_view',
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('gridViewText')
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('tableViewText')
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('cardViewText')
        }
      ]
    };
  },
  i18n: productDefinitionObj,
  methods: {
    searchInit (searchText) {
      this.params.searchText =
        searchText === '' || searchText === undefined ? '' : searchText.trim();
      this.params.pageNumber = 1;
      this.$store.dispatch(
        'productdefinitionModule/getProductDefinitionListAction',
        this.params
      );
    },
    getProductDefinitionListData () {
      this.loadmore = true;
      if (
        this.params.pageNumber * this.params.pageSize <
        this.productDefinitionsCount + 12
      ) {
        this.$store.dispatch(
          'productdefinitionModule/getProductDefinitionListAction',
          this.params
        );
      } else {
        this.loadmore = false;
      }
    },

    onScroll () {
      window.onscroll = () => {
        if (
          document.documentElement.scrollHeight ===
          document.documentElement.scrollTop + window.innerHeight
        ) {
          this.params.pageNumber += 1;
          this.getProductDefinitionListData();
        }
      };
    },
    clearFilter () {
      this.isHidden = false;
    }
  },
  watch: {
    productDefinitionlist () {
      if (
        this.productDefinitionsCount <
        this.params.pageNumber * this.params.pageSize
      ) {
        this.loadmore = false;
      }
      this.loadmore = false;
    },
    searchText: function () {
      const self = this;
      _.debounce(function () {
        self.isTyping = false;
        self.params.pageNumber = 1;
      }, 3000)();
    },
    isTyping: function (value) {
      if (this.searchText === '') {
        this.params.searchText = '';
      }
      if (!value) {
        this.searchInit(this.searchText);
      }
    }
  },
  mounted () {
    this.params.searchText = '';
    this.getProductDefinitionListData();
    window.addEventListener('scroll', this.onScroll);
  },
  beforeDestroy () {
    window.removeEventListener('scroll', this.onScroll);
  },
  computed: {
    ...mapState('productdefinitionModule', [
      'productDefinitionlist',
      'params',
      'productDefinitionsCount'
    ])
  }
};
</script>
<style scoped></style>
