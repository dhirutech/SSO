<template>
  <v-row no-gutters class="bpt5">
    <v-col class="gen2-forms form-light-bg" xs="12" sm="7">
      <p class="label-text">{{ $t("basicDetailsText") }}</p>
      <v-col sm="8" xs="12" class="bpa0">
        <validation-provider
          id="Product_Set_Name"
          rules="required"
          v-slot="{ errors }"
        >
          <v-text-field
            autocomplete="off"
            :label="$t('productSetNameLabel')"
            id="product_basic_name"
            filled
            required
            v-model="ProductSetName"
          ></v-text-field>
          <p
            class="custom-error-msg"
            v-if="
              errors[0] != undefined &&
                errors[0].length > 0 &&
                errors[0] === 'This field is required'
            "
          >
            {{ $t("productSetNameError") }}
          </p>
          <p
            class="custom-error-msg"
            v-else-if="errors[0] != undefined && errors[0].length > 0"
          >
           {{ $t("productSetNameAlphabeticError") }}
          </p>
        </validation-provider>
      </v-col>
      <v-col sm="10" xs="12" class="bpa0">
        <v-textarea
          :label="$t('productSetDescriptionLabel')"
          filled
          auto-grow
        ></v-textarea>
      </v-col>
    </v-col>
    <v-col xs="12" sm="5">
      <brierley-info-side>
        <template v-slot:info-side-header>
          <div class="info_title"><v-icon>info</v-icon>{{ $t("infoText") }}</div>
        </template>
        <template v-slot:info-side-body>
          <div>
          {{ $t("infoPassage") }}
          </div>
        </template>
      </brierley-info-side>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyInfoSide } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { productInfoObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyInfoSide
  },
  computed: {
    ...mapState('signUpModule', ['getUserData'])
  },
  i18n: productInfoObj,
  props: {},
  data () {
    return {
      nameRules: [
        (v) => !!v || this.$t('message.nameIsRequired'),
        (v) => v && v.length <= 50 || this.$t('message.nameLengthExceeded')
      ],
    };
  }
};
</script>

<style lang="scss" scoped>
.errclass {
  p {
    color: red;
  }
}
</style>
