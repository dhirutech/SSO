<template>
  <table>
    <tbody>
      <tr class="topTR">
        <td
          :colspan="
            datasource.children && datasource.children.length
              ? datasource.children.length * 2
              : null
          "
        >
          <v-menu open-on-hover bottom attach offset-y>
            <template v-slot:activator="{ on, attrs }">
              <div
                class="node"
                :id="datasource.id"
                @click="selectProgram(datasource)"
                v-bind="attrs"
                v-on="on"
              >
                <slot :node-data="datasource">
                  <div
                    class="nodeItem prod"
                    :class="[
                      constructClass,
                      datasource.isAssinedToProductDefinition ? 'nodeItem4' : ''
                    ]"
                  >
                    <v-row no-gutters class="pa-1 pr-2 nodeRow">
                      <v-list-item class="px-0">
                        <v-list-item-avatar style="margin-right:0px">
                          <v-icon
                            large
                            v-if="datasource.isAssinedToProductDefinition"
                            color="#A9A9A9"
                            >{{ datasource.icon }}</v-icon
                          >
                          <v-icon large v-else color="#000">{{
                            datasource.icon
                          }}</v-icon>
                        </v-list-item-avatar>

                        <v-list-item-title
                          class="nodeTitle elipsis-fullwidth max-width-80p"
                          :title="datasource.name"
                        >
                          {{ datasource.name }}
                        </v-list-item-title>

                        <v-row align="center" justify="end">
                          <v-icon
                            v-if="
                              isCheck || datasource.isAssinedToProductDefinition
                            "
                            >check_circle</v-icon
                          >
                        </v-row>
                      </v-list-item>
                    </v-row>
                  </div>
                </slot>
              </div>
            </template>
            <v-row
              class="table-custom-tooltip max-width-600 flex-column customPopup"
              no-gutters
              v-if="datasource.isAssinedToProductDefinition"
            >
              <v-col class="table-custom-tooltip__head">
                <v-icon class="font24 bmr1">info</v-icon
                >{{ $t("tooltipLabel") }}
              </v-col>
              <v-col class="table-custom-tooltip__content bmb0">{{
                $t('tooltipText')
              }}</v-col>
            </v-row>
          </v-menu>
        </td>
      </tr>
      <template v-if="datasource.children && datasource.children.length">
        <tr class="lines">
          <td :colspan="datasource.children.length * 2">
            <div
              :class="{
                downLine: datasource.children.length > 2,
                downLine1: datasource.children.length == 2,
                downLine2: datasource.children.length == 1
              }"
            ></div>
          </td>
        </tr>
        <tr class="lines">
          <td class="rightLine"></td>
          <template v-for="n in datasource.children.length - 1">
            <td class="leftLine topLine" :key="`leftLine-${n}`"></td>
            <td class="rightLine topLine" :key="`rightLine-${n}`"></td>
          </template>
          <td class="leftLine"></td>
        </tr>
        <tr class="nodes">
          <td colspan="2" v-for="child in datasource.children" :key="child.id">
            <node :datasource="child" :handle-click="handleClick"></node>
          </td>
        </tr>
      </template>
    </tbody>
  </table>
</template>

<script>
import { mapState } from 'vuex';
import { orgProductChartNodeLanguageObj } from '../../../i18n/language.js';
export default {
  name: 'node',
  props: {
    datasource: Object,
    handleClick: Function
  },
  computed: {
    ...mapState('productdefinitionModule', [
      'IsSelectedProductExists',
      'selectedOrgProductDataBasedOnYesOrNo'
    ]),
    isCheck () {
      if (this.selectedOrgProductDataBasedOnYesOrNo.length === 0) {
        return false;
      }
      return (
        this.IsSelectedProductExists &&
        this.datasource.id ===
          this.selectedOrgProductDataBasedOnYesOrNo[0].id &&
        this.datasource.parentEntityId ===
          this.selectedOrgProductDataBasedOnYesOrNo[0].parentEntityId
      );
    },
    constructClass () {
      if (this.datasource.parentEntityId === null) {
        return 'company-node';
      } else {
        let getClass = '';
        switch (this.datasource.icon) {
        case 'business':
          getClass = 'company-node';
          break;
        case 'domain':
          getClass = 'nodeItem';
          break;
        case 'language':
          getClass = 'nodeItem1';
          break;
        case 'store':
          getClass = 'nodeItem2';
          break;
        case 'location_city':
          getClass = 'nodeItem3';
          break;
        default:
          getClass = 'nodeItem';
          break;
        }
        return !this.datasource.isAssinedToProductDefinition ? getClass : '';
      }
    }
  },
  methods: {
    myIconColor (icon) {
      switch (icon) {
      case 'business':
        return '0E1E61';
      case 'domain':
        return '0E1E61';
      case 'language':
        return '5BB9BC';
      case 'store':
        return '60BFFE';
      case 'location_city':
        return 'A154F2';
      default:
        return '000';
      }
    },
    selectProgram (datasource) {
      if (!datasource.isAssinedToProductDefinition) {
        if (!this.isCheck) {
          this.$store.dispatch(
            'productdefinitionModule/setSelectedProductDataAction',
            {
              id: datasource.id,
              name: datasource.name,
              parentEntityId: datasource.parentEntityId
            }
          );
        } else {
          this.$store.dispatch(
            'productdefinitionModule/removeSelectedProductDataAction',
            {
              id: datasource.id,
              name: datasource.name,
              parentEntityId: datasource.parentEntityId
            }
          );
        }
      }
    }
  },
  i18n: orgProductChartNodeLanguageObj
};
</script>

<style lang="scss" scoped>
.nodeTitle {
  text-align: left;
  width: 35px;
  height: 14px;
  font-family: OpenSans;
  font-size: 10px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #000000;
}
.nodeRow {
  margin: 0;
  position: relative;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
  padding: 10px;
}
.nodeItem4 {
  margin: 0 24px;
  font-family: "Open Sans", sans-serif;
  text-align: center;
  font-size: 10px;
  font-weight: bold;
  width: 240px;
  height: 50px;
  line-height: 35px;
  text-overflow: ellipsis;
  white-space: nowrap;
  border-radius: 0;
  padding-right: 16px;
  border: 2px solid #999999 !important;
  background-color: #f5f5f5 !important;
  color: #666666 !important;
  opacity: 0.6;
  cursor: not-allowed;
}
.customPopup {
  box-shadow: 2px#f5f5f5;
  text-align: left;
}
.nodeItem.prod {
  width: 220px !important;
}
</style>
