<template>
  <v-row no-gutters class="mb-3">
    <v-col
      cols="12"
      v-for="(product, index) in productdefinitionlistdata"
      :key="index"
      class="bmb2"
    >
      <v-card class="gen2-card gen2-typo3">
        <v-row no-gutters>
          <v-col sm="4" xs="12">
            <v-card-title
              data-qe-id="productdefinition_product_name"
              class="elipsis-fullwidth"
              >&nbsp;
              {{ product.name === '' ? 'N/A' : product.name }}</v-card-title
            >
          </v-col>
          <v-col sm="4" xs="12" class="pr-5">
            <p data-qe-id="productdefinition_gap_title" class="bmt0">
              <strong>{{ $t('descriptionLabel') }}</strong>
            </p>
            <span
              data-qe-id="productdefinition_description"
              class="elipsis-twoline"
              >{{ product.description }}</span
            >
          </v-col>
          <v-col md="4" sm="12" xs="12" class="pr-5">
            <p class="bmt0">
              <strong data-qe-id="productdefinition_program_title">{{
                $t('programEntityLabel')
              }}</strong>
            </p>
            <span
              v-if="product.businessEntity !== null"
              data-qe-id="productdefinition_program_name"
              class="elipsis-twoline"
              >{{ product.businessEntity.name }}</span
            >
          </v-col>
          <v-col sm="12">
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span :title="$t('viewDetails')" class="active">
                  <v-icon
                    data-qe-id="loyaltyadmin_productdefinition_viewicon"
                    class="blackicon"
                    @click="
                      $router.push({
                        name: 'productDefinitionView',
                        query: { id: product.productDefinitionId }
                      })
                    "
                    >fe fe-eye</v-icon
                  >
                  <span
                    class="viewdetails-icon"
                    data-qe-id="loyaltyadmin_productdefinition_viewname"
                    @click="
                      $router.push({
                        name: 'productDefinitionView',
                        query: { id: product.productDefinitionId }
                      })
                    "
                    >{{ $t('viewDetails') }}</span
                  >
                </span>
                <span title="Edit">
                  <v-icon data-qe-id="productdefinition_edit" class="blackicon"
                    >fe fe-edit</v-icon
                  >
                  <span
                    class="edit-icon"
                    @click="
                      $router.push({
                        name: 'editProductDefinition',
                        query: { id: product.productDefinitionId }
                      })
                    "
                    >{{ $t('editLabel') }}</span
                  >
                </span>
                <span title="Copy">
                  <v-icon
                    data-qe-id="productdefinition_copy"
                    class="blackicon cursor-p"
                    @click="
                      $router.push({
                        name: 'cloneProductDefinition',
                        query: { id: product.productDefinitionId }
                      })
                    "
                    >feather-icon fe fe-copy</v-icon
                  >
                  <span
                    class="copy-icon"
                    @click="
                      $router.push({
                        name: 'cloneProductDefinition',
                        query: { id: product.productDefinitionId }
                      })
                    "
                    >{{ $t('copyLabel') }}</span
                  >
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
        </v-row>
      </v-card>
    </v-col>
  </v-row>
</template>

<script>
import { BrierleyCardIcons } from '@brierley/SharedComponents';
import { productDefinitionGridViewObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyCardIcons
  },
  i18n: productDefinitionGridViewObj,
  props: {
    productdefinitionlistdata: {
      type: Array,
      defualt: []
    }
  }
};
</script>
