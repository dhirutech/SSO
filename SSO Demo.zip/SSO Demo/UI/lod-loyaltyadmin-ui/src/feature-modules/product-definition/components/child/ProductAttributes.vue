<template>
  <v-row class="gen2-scroll-table mb-0" no-gutters>
    <v-col>
      <Validation-Observer
        ref="observer2"
        v-slot="{ onSubmit }"
        tag="form"
        @submit.prevent="submit()"
      >
        <v-form
          id="product_definition_form2"
          @submit.prevent="submit(onSubmit)"
        >
          <v-row class="table_container d-flex" no-gutters>
            <v-col
              class="table-center sticky-data-table gen2-forms form-light-bg"
            >
              <v-flex class="sticky-data-table__scroll">
                <v-simple-table class="sticky-data-table__table">
                  <thead>
                    <tr>
                      <th
                        class="sticky-first"
                        data-qe-id="loyaltyadmin_productdefinition_attributename"
                      >
                        {{ $t('attributeNameLabel') }}
                      </th>
                      <th
                        class="largecol"
                        data-qe-id="loyaltyadmin_productdefinition_datatype"
                      >
                        {{ $t('dataTypeLabel') }}
                      </th>
                      <th
                        class="largecol"
                        data-qe-id="loyaltyadmin_productdefinition_maxlength"
                      >
                        {{ $t('maxLengthLabel') }}
                        <v-icon
                          :title="$t('maxLengthTitle')"
                          class="primary-text cursor-p"
                          >mdi-information-outline</v-icon
                        >
                      </th>
                      <th data-qe-id="loyaltyadmin_productdefinition_required">
                        {{ $t('requireLabel') }}
                      </th>
                      <th data-qe-id="loyaltyadmin_productdefinition_uniques">
                        {{ $t('uniqueLabel') }}
                      </th>
                      <th
                        class="largecol"
                        data-qe-id="loyaltyadmin_productdefinition_description"
                      >
                        {{ $t('descriptionLabel') }}
                      </th>
                      <th
                        class="largecol"
                        data-qe-id="loyaltyadmin_productdefinition_defaultvalue"
                      >
                        {{ $t('defaultValueLabel') }}
                        <v-icon
                          :title="$t('attributeTitle')"
                          class="cursor-p primary-text"
                          >mdi-information-outline</v-icon
                        >
                      </th>
                      <th
                        class="largecol"
                        data-qe-id="loyaltyadmin_productdefinition_displayText"
                      >
                        {{ $t('displayNameLabel') }}
                      </th>
                      <th
                        class="sticky-last"
                        data-qe-id="loyaltyadmin_productdefinition_actions"
                      >
                        {{ $t('actionsLabel') }}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(items, j) in productAttributesData" :key="j">
                      <td
                        class="sticky-first"
                        data-qe-id="loyaltyadmin_productdefinition_res"
                      >
                        <v-row class="content-info" no-gutters>
                          <v-col>{{ items.attributeName }}</v-col>
                          <v-col
                            md="auto"
                            class="align-self-center"
                            data-qe-id="loyaltyadmin_productdefinition_lock"
                          >
                            <v-icon>lock</v-icon>
                          </v-col>
                        </v-row>
                      </td>
                      <td
                        class="position-relative"
                        data-qe-id="loyaltyadmin_productdefinition_datatype"
                      >
                        {{ items.dataType }}
                      </td>
                      <td data-qe-id="loyaltyadmin_productdefinition_maxlength">
                        {{ items.maxlength }}
                      </td>
                      <td
                        data-qe-id="loyaltyadmin_productdefinition_require_value"
                      >
                        {{ items.require }}
                      </td>
                      <td
                        data-qe-id="loyaltyadmin_productdefinition_unique_value"
                      >
                        {{ items.unique }}
                      </td>
                      <td
                        data-qe-id="loyaltyadmin_productdefinition_description_value"
                      >
                        {{ items.description }}
                      </td>
                      <td
                        data-qe-id="loyaltyadmin_productdefinition_description_Field"
                      >
                        {{ items.defaultField }}
                      </td>
                      <td
                        data-qe-id="loyaltyadmin_productdefinition_description_value"
                      >
                        {{ items.displayText }}
                      </td>
                      <td class="sticky-last">
                        <v-icon
                          data-qe-id="loyaltyadmin_productdefinition_require_edit"
                          >edit</v-icon
                        >
                        <v-icon
                          data-qe-id="loyaltyadmin_productdefinition_require_delete"
                          >delete</v-icon
                        >
                      </td>
                    </tr>
                  </tbody>
                  <tbody v-if="newObj !== []">
                    <tr
                      v-for="(items, j) in newObj"
                      :key="j"
                      class="gen2-forms form-light-bg"
                    >
                      <td
                        class="sticky-first border-t0"
                        data-qe-id="loyaltyadmin_productdefinition_res"
                      >
                        <v-row class="content-info" no-gutters>
                          <v-col
                            data-qe-id="loyaltyadmin_productdefinition_attributename"
                            v-if="selectedAttribute !== j"
                            >{{ items.columnName }}</v-col
                          >
                          <v-col v-if="selectedAttribute === j">
                            <v-menu open-on-hover bottom offset-y>
                              <template v-slot:activator="{ on, attrs }">
                                <div
                                  v-bind="attrs"
                                  v-on="on"
                                  class="gen2-forms form-light-bg"
                                >
                                  <validation-provider
                                    id="product_definition_form2"
                                    rules="required"
                                    v-slot="{ errors }"
                                  >
                                    <!-- @focus="attributeNameVal(errors)" -->
                                    <v-text-field
                                      autocomplete="off"
                                      filled
                                      id="loyaltyadmin_productdefinition_attributename"
                                      v-bind:class="[
                                        errors[0] ===
                                          'This field is required' ||
                                        duplicateAttributeName
                                          ? ' error--text'
                                          : ''
                                      ]"
                                      class="mini-field bmt-2"
                                      ref="columnName"
                                      :disabled="attributeNameNonEditable"
                                      v-model="items.columnName"
                                      required
                                      maxlength="63"
                                      :label="$t('attributeNameLabel')"
                                      @input="attributeField()"
                                      @paste.prevent
                                    ></v-text-field>
                                  </validation-provider>
                                </div>
                              </template>
                              <!-- <p
                                class="custom-table-error"
                                v-if="attributeNameHover === true"
                              >
                                <v-row class="flex-column " no-gutters>
                                  <v-col class="custom-table-error__head">
                                    <v-icon>info</v-icon
                                    >{{ $t('attributeNameText') }}
                                  </v-col>
                                  <v-col
                                    class="custom-table-error__disc"
                                    v-if="!duplicateAttributeName"
                                  >
                                    {{ $t('attributeNameErrorLabel') }}
                                  </v-col>
                                  <v-col
                                    class="custom-table-error__disc"
                                    v-if="duplicateAttributeName"
                                  >
                                    {{ $t('attributeNameExistenceError') }}
                                  </v-col>
                                </v-row>
                              </p> -->
                            </v-menu>
                          </v-col>
                        </v-row>
                      </td>
                      <td class="date-type-attribute">
                        <span
                          v-if="selectedAttribute !== j"
                          data-qe-id="loyaltyadmin_productdefinition_datatype"
                          >{{ items.dataType }}</span
                        >
                        <span v-if="selectedAttribute === j">
                          <validation-provider
                            id="product_definition_form2"
                            rules="required"
                            v-slot="{ errors }"
                          >
                            <!-- @focus="attributeNameVal(errors)" -->
                            <v-select
                              id="loyaltyadmin_productdefinition_datatype"
                              :disabled="dataTypeNonEditable"
                              :items="allDataTypes"
                              maxlength="25"
                              filled
                              v-bind:class="[
                                errors[0] === 'This field is required'
                                  ? ' error--text'
                                  : ''
                              ]"
                              @change="setDataType(items.dataType)"
                              :label="$t('typeLabel')"
                              offset-y
                              required
                              class="gen2select gen2select__dark mini-field"
                              ref="items.dataType"
                              v-model="items.dataType"
                              append-icon="expand_more"
                              @paste.prevent
                            ></v-select>
                            <v-menu
                              open-on-hover
                              offset-y
                              :close-on-click="true"
                              :close-on-content-click="true"
                              v-if="
                                errors[0] != undefined &&
                                  errors[0].length > 0 &&
                                  errors[0] === 'This field is required'
                              "
                            >
                              <template v-slot:activator="{ on, attrs }">
                                <div
                                  v-bind="attrs"
                                  v-on="on"
                                  @mouseover="greet"
                                  class="great-content"
                                ></div>
                              </template>
                              <p class="custom-table-error">
                                <v-row class="flex-column " no-gutters>
                                  <v-col class="custom-table-error__head">
                                    <v-icon>info</v-icon
                                    >{{ $t('dataTypeText') }}
                                  </v-col>
                                  <v-col class="custom-table-error__disc">
                                    {{ $t('dataTypeErrorLabel') }}
                                  </v-col>
                                </v-row>
                              </p>
                            </v-menu>
                          </validation-provider>
                        </span>
                      </td>
                      <td>
                        <span
                          v-if="
                            selectedAttribute !== j &&
                              items.dataType === 'String'
                          "
                          data-qe-id="loyaltyadmin_productdefinition_maxlength"
                          >{{ items.stringMax }}</span
                        >
                        <v-menu
                          open-on-hover
                          bottom
                          offset-y
                          v-if="
                            selectedAttribute === j &&
                              items.dataType === 'String'
                          "
                        >
                          <template v-slot:activator="{ on, attrs }">
                            <div
                              v-bind="attrs"
                              v-on="on"
                              class="gen2-forms form-light-bg"
                            >
                              <validation-provider
                                id="product_definition_form2"
                                rules="required"
                                v-if="
                                  selectedAttribute === j &&
                                    items.dataType === 'String' &&
                                    j + 1 <= addNewAtt
                                "
                                v-slot="{ errors }"
                              >
                                <!-- @focus="maxLengthVal(errors, j, items)" -->
                                <v-text-field
                                  id="loyaltyadmin_productdefinition_maxlength"
                                  v-if="
                                    selectedAttribute === j &&
                                      items.dataType === 'String' &&
                                      j + 1 <= addNewAtt
                                  "
                                  class="mini-field"
                                  :label="$t('maxLengthLabel')"
                                  onkeypress="allowNumbersOnly(event)"
                                  v-model="items.stringMax"
                                  type="number"
                                  filled
                                  required
                                  v-bind:class="[
                                    errors[0] === 'This field is required'
                                      ? ' error--text'
                                      : ''
                                  ]"
                                  @paste.prevent
                                  @input="defaultEditMaxField(items.stringMax)"
                                ></v-text-field>
                              </validation-provider>
                              <validation-provider
                                id="product_definition_form2"
                                rules="required"
                                v-if="
                                  selectedAttribute === j &&
                                    items.dataType === 'String' &&
                                    j + 1 > addNewAtt
                                "
                                v-slot="{ errors }"
                              >
                                <!-- @focus="maxLengthVal(errors, j, items)" -->
                                <v-text-field
                                  autocomplete="off"
                                  v-if="
                                    selectedAttribute === j &&
                                      items.dataType === 'String' &&
                                      j + 1 > addNewAtt
                                  "
                                  id="loyaltyadmin_productdefinition_maxLength"
                                  class="mini-field bmt-2"
                                  ref="items.stringMax"
                                  v-model="items.stringMax"
                                  type="number"
                                  filled
                                  :label="$t('maxLengthLabel')"
                                  v-bind:class="[
                                    errors[0] === 'This field is required'
                                      ? ' error--text'
                                      : ''
                                  ]"
                                  @input="defaultMaxField(items.stringMax)"
                                  @paste.prevent
                                ></v-text-field>
                              </validation-provider>
                            </div>
                          </template>
                          <!-- <p
                            class="custom-table-error"
                            v-if="
                              maxLengthHover === true ||
                                errors[0] === 'This field is required'
                            "
                          >
                            <v-row class="flex-column " no-gutters>
                              <v-col class="custom-table-error__head">
                                <v-icon>info</v-icon>{{ $t('maxLengthText') }}
                              </v-col>
                              <v-col class="custom-table-error__disc">
                                {{ $t('maxLengthError') }}
                              </v-col>
                              <v-col
                                class="custom-table-error__disc"
                                v-if="
                                  j + 1 <= addNewAtt &&
                                    !$route.name.includes('clone')
                                "
                              >
                                {{ $t('maxLengthErrorText') }}
                              </v-col>
                            </v-row>
                          </p> -->
                        </v-menu>
                      </td>
                      <td
                        data-qe-id="loyaltyadmin_productdefinition_require_value"
                      >
                        {{ items.require }}
                      </td>
                      <td
                        data-qe-id="loyaltyadmin_productdefinition_unique_value"
                      >
                        {{ items.unique }}
                      </td>
                      <td>
                        <span
                          v-if="selectedAttribute !== j"
                          data-qe-id="loyaltyadmin_productdefinition_description_value"
                          >{{ items.description }}</span
                        >
                        <v-text-field
                          autocomplete="off"
                          v-if="selectedAttribute === j"
                          id="loyaltyadmin_productdefinition_description"
                          class="mini-field bmt-2"
                          ref="items.description"
                          v-model="items.description"
                          maxlength="250"
                          filled
                          :label="$t('descriptionLabel')"
                          @paste.prevent
                        ></v-text-field>
                      </td>
                      <td
                        data-qe-id="loyaltyadmin_productdefinition_defaultValue"
                      >
                        <span
                          v-if="selectedAttribute !== j"
                          data-qe-id="loyaltyadmin_productdefinition_defaultValue"
                          >{{ items.defaultValue }}</span
                        >
                        <v-menu
                          open-on-hover
                          bottom
                          offset-y
                          v-if="selectedAttribute === j"
                        >
                          <template v-slot:activator="{ on, attrs }">
                            <div
                              v-bind="attrs"
                              v-on="on"
                              class="gen2-forms form-light-bg"
                            >
                              <validation-provider
                                id="product_definition_form2"
                                rules="required"
                                v-slot="{ errors }"
                              >
                                <!-- @focus="defaultValueVal(errors)" -->
                                <v-text-field
                                  filled
                                  v-if="selectedAttribute === j"
                                  id="loyaltyadmin_productdefinition_defaultValue"
                                  class="mini-field bmt-2"
                                  ref="items.defaultValue"
                                  v-model="items.defaultValue"
                                  maxlength="50"
                                  :label="$t('defaultValueLabel')"
                                  v-bind:class="[
                                    errors[0] === 'This field is required'
                                      ? ' error--text'
                                      : ''
                                  ]"
                                  @input="defaultField()"
                                  @paste.prevent
                                ></v-text-field>
                              </validation-provider>
                            </div>
                          </template>
                          <!-- <p
                            class="custom-table-error"
                            v-if="defaultValueHover === true"
                          >
                            <v-row class="flex-column " no-gutters>
                              <v-col class="custom-table-error__head">
                                <v-icon>info</v-icon
                                >{{ $t('defaultValueText') }}
                              </v-col>
                              <v-col class="custom-table-error__disc">
                                {{ $t('defaultValueError') }}
                              </v-col>
                            </v-row>
                          </p> -->
                        </v-menu>
                      </td>
                      <td
                        data-qe-id="loyaltyadmin_productdefinition_displayText"
                      >
                        <span
                          v-if="selectedAttribute !== j"
                          data-qe-id="loyaltyadmin_productdefinition_displayTexte"
                          >{{ items.displayText }}</span
                        >
                        <v-menu
                          open-on-hover
                          bottom
                          offset-y
                          v-if="selectedAttribute === j"
                        >
                          <template v-slot:activator="{ on, attrs }">
                            <div
                              v-bind="attrs"
                              v-on="on"
                              class="gen2-forms form-light-bg"
                            >
                              <validation-provider
                                id="product_definition_form2"
                                rules="required"
                                v-slot="{ errors }"
                              >
                                <!-- @focus="displayNameVal(errors)" -->
                                <v-text-field
                                  v-if="selectedAttribute === j"
                                  id="loyaltyadmin_productdefinition_displayText"
                                  class="mini-field bmt-2"
                                  ref="items.displayText"
                                  v-model="items.displayText"
                                  filled
                                  maxlength="63"
                                  :label="$t('displayNameLabel')"
                                  v-bind:class="[
                                    errors[0] === 'This field is required'
                                      ? ' error--text'
                                      : ''
                                  ]"
                                  @input="displayField()"
                                  @paste.prevent
                                ></v-text-field>
                              </validation-provider>
                            </div>
                          </template>
                          <!-- <p
                            class="custom-table-error"
                            v-if="displayNameHover === true"
                          >
                            <v-row class="flex-column " no-gutters>
                              <v-col class="custom-table-error__head">
                                <v-icon>info</v-icon>{{ $t('displayNameText') }}
                              </v-col>
                              <v-col class="custom-table-error__disc">
                                {{ $t('displayNameError') }}
                              </v-col>
                            </v-row>
                          </p> -->
                        </v-menu>
                      </td>
                      <td class="sticky-last border-t0">
                        <span
                          title="Edit"
                          class="material-icons icon-font20 pl-2"
                          data-qe-id="loyaltyadmin_productdefinition_require_edit"
                          v-if="selectedAttribute !== j"
                          @click="editAttribute(items, j)"
                          >edit
                        </span>
                        <span v-if="selectedAttribute === j">
                          <v-icon
                            title="Save"
                            data-qe-id="loyaltyadmin_productdefinition_require_save"
                            class="primary-text"
                            @click="submit(items, j)"
                            type="submit"
                            form="product_definition_form2"
                            >save</v-icon
                          >
                        </span>
                        <span
                          title="Delete"
                          v-if="
                            $route.name.includes('edit') &&
                              j < addNewAtt &&
                              selectedAttribute !== j
                          "
                        >
                          <v-icon
                            data-qe-id="loyaltyadmin_productdefinition_require_delete"
                            >delete</v-icon
                          >
                        </span>
                        <span
                          title="Delete"
                          v-else-if="selectedAttribute !== j"
                          class="material-icons icon-font20 pl-2"
                          data-qe-id="loyaltyadmin_productdefinition_require_delete"
                          @click="deleteAttribute(items, j)"
                          >delete
                        </span>
                        <span
                          title="Cancel"
                          data-qe-id="loyaltyadmin_productdefinition_require_delete"
                          @click="cancleAttribute(items, j)"
                          v-if="selectedAttribute === j"
                          class="material-icons icon-font20 pl-2"
                          >cancel
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </v-simple-table>
              </v-flex>
            </v-col>
          </v-row>
          <v-row
            no-gutters
            v-if="
              errorMessages.length > 0 && errorMessages.length !== undefined && !attrNotSaved">
            <v-col>
              <v-alert
                class="b-alert-error max-width-full bmt2"
                type="error"
                :dismissible="false"
              >
                <v-row class="alert-block align-center havebtn" no-gutters>
                  <v-col class="alert-block__body">
                    <h3>Error</h3>
                    <p v-for="error in errorMessages" :key="error">
                      {{ error }}
                    </p>
                  </v-col>
                </v-row>
              </v-alert>
            </v-col>
          </v-row>
        <v-row
            no-gutters
            v-if="attrNotSaved">
            <v-col>
              <v-alert
                class="b-alert-error max-width-full bmt2"
                type="error"
                :dismissible="false"
              >
                <v-row class="alert-block align-center havebtn" no-gutters>
                  <v-col class="alert-block__body">
                    <h3>Error</h3>
                    <p>
                     {{ $t('alertPopUpMessage') }}
                    </p>
                  </v-col>
                </v-row>
              </v-alert>
            </v-col>
          </v-row>
        </v-form>
      </Validation-Observer>
      <v-row no-gutters class="d-inline-flex icon-with-head align-center bmt1">
        <v-col>
          <span
            title="Add New Attribute"
            class="fbold text-uppercase assign primary-text cursor-p"
            v-if="$route.name.includes('create')"
            data-qe-id="loyaltyadmin_productdefinition_new_attribute"
            @click="addNewAttribute()"
          >
            <v-icon
              data-qe-id="loyaltyadmin_productdefinition_add"
              class="pr-1 primary-text"
              >add_circle_outline</v-icon
            >
            {{ $t('addNewAttributeLabel') }}
          </span>
          <span
            class="fbold text-uppercase assign primary-text cursor-p"
            v-if="$route.name.includes('edit')"
            data-qe-id="loyaltyadmin_productdefinition_new_attribute"
            @click="addNewAttributeInEdit()"
          >
            <v-icon
              data-qe-id="loyaltyadmin_productdefinition_add"
              class="pr-3 primary-text"
              >add_circle_outline</v-icon
            >{{ $t('addNewAttributeLabel') }}
          </span>
          <span
            class="fbold text-uppercase assign primary-text cursor-p"
            v-if="$route.name.includes('clone')"
            data-qe-id="loyaltyadmin_productdefinition_new_attribute"
            @click="addNewAttributeInClone()"
          >
            <v-icon
              data-qe-id="loyaltyadmin_productdefinition_add"
              class="pr-3 primary-text"
              >add_circle_outline</v-icon
            >{{ $t('addNewAttributeLabel') }}
          </span>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import { mapState } from 'vuex';
import { productAttributesObj } from '../../../../i18n/language.js';
export default {
  data () {
    return {
      maxLengthEdit: null,
      errorMessages: [],
      coreAttributes: [],
      newExtensionAttribute: [],
      attributeNameHover: false,
      maxLengthHover: false,
      defaultValueHover: false,
      displayNameHover: false,
      editClick: false,
      errors: [],
      attrVal: false,
      duplicateAttributeName: false,
      attributeNameValidation: [],
      newAttributeNameValidation: [],
      newAttributeNameValidationOldValues: [],
      extendedAttributeNameValidation: [],
      newAttributeNameValidationEdit: [],
      newObj: [],
      stringObj: [],
      errorAttribute: false,
      attributeNameNonEditable: false,
      dataTypeNonEditable: false,
      errorData: false,
      errorDataType: '',
      errorAttributeName: '',
      newAttribute: false,
      colomnError: false,
      dataTypeError: false,
      defaultValueError: false,
      displayTextError: false,
      editFlag: true,
      selectedAttribute: null,
      allDataTypes: ['String', 'Number', 'Date', 'Boolean'],
      addAttributeInEdit: false,
      addAttributeInClone: false,
      addNewAtt: '',
      flag: false,
      deleteAttributeNew: false,
      strValidation: '',
      rules: {
        RuleCharacters: (value) => {
          if (value) {
            if (
              value < this.strValidation &&
              this.$route.name.includes('edit')
            ) {
              return 'Should be greater';
            }
          }
          return true;
        }
      }
    };
  },
  i18n: productAttributesObj,
  created () {
    if (this.$route.name.includes('edit')) {
      if (this.extensionAttributesData) {
        this.noOfExtensionAttributes = true;
        this.addNewAtt = this.extensionAttributesData.productCoreAttributes.length;
        if (this.extensionAttributesData.productCoreAttributes.length > 0) {
          this.newObj = this.extensionAttributesData.productCoreAttributes;
        }
        for (
          let i = 0;
          i < this.extensionAttributesData.productCoreAttributes.length;
          i++
        ) {
          this.stringObj.push(
            this.extensionAttributesData.productCoreAttributes[i].stringMax
          );
        }
        this.$emit('saveNewAttributes', this.newObj);
        this.$emit('attributeSaveValidation', true);
      }
      localStorage.setItem('editObj', JSON.stringify(this.newObj));
    } else if (this.$route.name.includes('clone')) {
      if (this.extensionAttributesData) {
        this.addNewAtt = this.extensionAttributesData.productCoreAttributes.length;
        if (this.extensionAttributesData.productCoreAttributes.length > 0) {
          this.newObj = this.extensionAttributesData.productCoreAttributes;
        }
        this.$emit('saveNewAttributes', this.newObj);
      }
      localStorage.setItem('oldObj', JSON.stringify(this.newObj));
    }
  },
  computed: {
    ...mapState('productdefinitionModule', {
      productAttributesData: (state) => {
        return state.productAttributesData;
      },
      extensionAttributesData: (state) => {
        return state.extensionAttributesData;
      },
      attrNotSaved: (state) => {
        return state.attrNotSaved;
      },
    })
  },
  methods: {
    async submit (item, j) {
      let self = this;
      this.$store.commit('productdefinitionModule/attributeNotSavedMutation', false);
      if (item.columnName === '') {
        if (!this.errorMessages.includes(self.$t('attributeNameErrorLabel'))) {
          this.errorMessages.push(self.$t('attributeNameErrorLabel'));
        }
      } else {
        const changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('attributeNameErrorLabel');
        });
        this.errorMessages = changedArray;
      }

      if (item.displayText === '') {
        if (!this.errorMessages.includes(self.$t('displayRequired'))) {
          this.errorMessages.push(self.$t('displayRequired'));
        }
      } else {
        const changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('displayRequired');
        });
        this.errorMessages = changedArray;
      }

      if (item.defaultValue === '') {
        if (!this.errorMessages.includes(self.$t('defaultValueError'))) {
          this.errorMessages.push(self.$t('defaultValueError'));
        }
      } else {
        const changedArray = this.errorMessages.filter(function (value) {
          return value !==  self.$t('defaultValueError');
        });
        this.errorMessages = changedArray;
      }

      if (item.dataType === null) {
        if (!this.errorMessages.includes(self.$t('dataTypeErrorLabel'))) {
          this.errorMessages.push(self.$t('dataTypeErrorLabel'));
        }
      } else {
        const changedArray = this.errorMessages.filter(function (value) {
          return value !==  self.$t('dataTypeErrorLabel');
        });
        this.errorMessages = changedArray;
      }
      if (item.stringMax === '' || item.stringMax === 0) {
        if (item.dataType === 'String') {
          if (!this.errorMessages.includes(self.$t('maxLengthError'))) {
            this.errorMessages.push(self.$t('maxLengthError'));
          }
        }
      } else {
        const changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('maxLengthError');
        });
        this.errorMessages = changedArray;
      }

      // this.errorMessages = msgArray;
      const isValid = await this.$refs.observer2.validate();
      if (!isValid) {
        return;
      } else {
        this.coreAttributes = [];
        let localAttribute = [];
        this.newExtensionAttribute = [];
        if (!this.$route.name.includes('edit')) {
          localAttribute = localStorage.getItem('oldObj');
        } else if (this.$route.name.includes('edit')) {
          localAttribute = localStorage.getItem('editObj');
        }
        localAttribute = JSON.parse(localAttribute);
        if (this.productAttributesData) {
          this.coreAttributes = this.productAttributesData.filter(
            (res) =>
              res.attributeName.toUpperCase() === item.columnName.toUpperCase()
          );
        }
        if (localAttribute) {
          this.newExtensionAttribute = localAttribute.filter(
            (res) =>
              res.columnName.toUpperCase() === item.columnName.toUpperCase()
          );
        }
        if (this.editClick === true && parseInt(item.stringMax) >= 0) {
          if (localAttribute[j].columnName === item.columnName) {
            if (!this.$route.name.includes('edit')) {
              this.saveAttr(item, j);
            } else if (this.$route.name.includes('edit')) {
              this.updateAttr(item, j);
            }
          } else {
            if (
              this.newExtensionAttribute.length === 0 &&
              this.coreAttributes.length === 0
            ) {
              if (!this.$route.name.includes('edit')) {
                this.saveAttr(item, j);
              } else if (this.$route.name.includes('edit')) {
                this.updateAttr(item, j);
              }
            } else {
              this.duplicateAttributeName = true;
              if (!this.errorMessages.includes(self.$t('attributeNameExistenceError'))) {
                this.errorMessages.push(self.$t('attributeNameExistenceError'));
              }
              this.attributeNameHover = true;
            }
          }
        } else if (parseInt(item.stringMax) >= 0) {
          if (
            this.newExtensionAttribute.length === 0 &&
            this.coreAttributes.length === 0
          ) {
            if (!this.$route.name.includes('edit')) {
              this.saveAttr(item, j);
            } else if (this.$route.name.includes('edit')) {
              this.updateAttr(item, j);
            }
          } else {
            this.duplicateAttributeName = true;
            if (!this.errorMessages.includes(self.$t('attributeNameExistenceError'))) {
              this.errorMessages.push(self.$t('attributeNameExistenceError'));
            }
            this.attributeNameHover = true;
          }
        } else {
          this.maxLengthHover = true;
        }
      }
    },
    attributeNameVal (errors) {
      if (errors.length > 0) {
        this.attributeNameHover = true;
      } else {
        this.attributeNameHover = false;
      }
    },
    maxLengthVal (errors, j, items) {
      if (
        errors.length > 0 &&
        !this.$route.name.includes('editProductDefinition')
      ) {
        this.maxLengthHover = true;
      } else {
        this.maxLengthHover = false;
      }
      if (errors[j] === 'This field is required') {
        this.maxLengthHover = true;
      }
      if (errors.length === 0) {
        this.maxLengthHover = false;
      }
      if (this.$route.name.includes('editProductDefinition')) {
        if (items.stringMax >= this.stringMax[j] || errors.length > 0) {
          this.maxLengthHover = true;
        } else {
          this.maxLengthHover = false;
        }
      }
    },
    defaultValueVal (errors) {
      if (errors.length > 0) {
        this.defaultValueHover = true;
      } else {
        this.defaultValueHover = false;
      }
    },
    displayNameVal (errors) {
      if (errors.length > 0) {
        this.displayNameHover = true;
      } else {
        this.displayNameHover = false;
      }
    },
    greet: function () {
      setTimeout(function () {
        document.querySelector('.great-content').style.display = 'none';
      }, 1500);
    },
    greetleave: function () {
      document.querySelector('.great-content').style.display = 'block';
    },
    greetextra: function () {
      document.querySelector('.great-content').style.display = 'none';
    },
    defaultMaxField (x) {
      let max = parseInt(x);
      let self = this;
      this.$store.commit('productdefinitionModule/attributeNotSavedMutation', false);
      if (max !== '') {
        const changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('maxLengthError');
        });
        this.errorMessages = changedArray;
      } else {
        if (max !== 0)
          if (!this.errorMessages.includes(self.$t('maxLengthError'))) {
            this.errorMessages.push(self.$t('maxLengthError'));
          }
      }
    },
    defaultEditMaxField (x) {
      let max = parseInt(x);
      let self = this;
      this.$store.commit('productdefinitionModule/attributeNotSavedMutation', false);
      let changedArray;
      if (max !== '') {
        changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('maxLengthError');
        });
        this.errorMessages = changedArray;
      }
      if (max >= this.maxLengthEdit) {
        changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('maxLengthErrorText');
        });
        this.errorMessages = changedArray;
      }
      if (max < this.maxLengthEdit) {
        if (!this.$route.path.includes('/loyaltyadmin/product/clone')) {
          const changedArray = this.errorMessages.filter(function (value) {
            return value !== self.$t('maxLengthErrorText');
          });
          this.errorMessages = changedArray;
          this.errorMessages.push(
            self.$t('maxLengthErrorText')
          );
        }
      }
      if (max === '') {
        let changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('maxLengthError');
        });
        changedArray = this.errorMessages.filter(function (value) {
          return value !==  self.$t('maxLengthErrorText');
        });
        this.errorMessages = changedArray;
        this.errorMessages.push(self.$t('maxLengthError'));
      }
      // else {
      //   const changedArray = this.errorMessages.filter(function (value) {
      //     return value !== 'Max length should be greater than current length.';
      //   });
      //   this.errorMessages = changedArray;
      //   if (max < this.maxLengthEdit) {
      //     this.errorMessages.push('Max length should be greater than current length.');
      //   }
      //   if (max !== 0 && max > this.maxLengthEdit) this.errorMessages.push('Max Length Required');
      // }
    },
    attributeField () {
      let self = this;
      this.$store.commit('productdefinitionModule/attributeNotSavedMutation', false);
      if (this.newObj[0].columnName !== '') {
        const changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('attributeNameErrorLabel');
        });
        this.errorMessages = changedArray;
      } else {
        this.errorMessages.push(self.$t('attributeNameErrorLabel'));
      }
      this.duplicateAttributeName = false;
      const changedAttrArray = this.errorMessages.filter(function (value) {
        return value !== self.$t('attributeNameErrorLabel');
      });
      this.errorMessages = changedAttrArray;
    },
    defaultField () {
      let self = this;
      this.$store.commit('productdefinitionModule/attributeNotSavedMutation', false);
      if (this.newObj[0].defaultValue !== '') {
        const changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('defaultValueError');
        });
        this.errorMessages = changedArray;
      } else {
        this.errorMessages.push(self.$t('defaultValueError'));
      }
    },
    displayField () {
      let self = this;
      this.$store.commit('productdefinitionModule/attributeNotSavedMutation', false);
      if (this.newObj[0].displayText !== '') {
        const changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('displayRequired');
        });
        this.errorMessages = changedArray;
      } else {
        this.errorMessages.push(self.$t('displayRequired'));
      }
    },
    setDataType (dataType) {
      let self= this;
      this.$store.commit('productdefinitionModule/attributeNotSavedMutation', false);
      if (dataType !== null) {
        if (this.newObj[this.newObj.length-1].stringMax === '' || this.newObj[this.newObj.length-1].stringMax === 0 && this.newObj[this.newObj.length-1].dataType==='String') {
          // if (!this.errorMessages.includes('Max Length Required')) {
          //   this.errorMessages.push('Max Length Required');
          // }
        }
        const changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('dataTypeErrorLabel');
        });
        this.errorMessages = changedArray;
      } else {
        if (!this.errorMessages.includes(self.$t('dataTypeErrorLabel'))) {
          this.errorMessages.push(self.$t('dataTypeErrorLabel'));
        }
      }
      if (dataType !== 'String') {
        const changedArray = this.errorMessages.filter(function (value) {
          return value !== self.$t('maxLengthError');
        });
        this.errorMessages = changedArray;
      }

      // if (this.newObj[this.newObj.length-1].columnName === '') {
      //   if (!this.errorMessages.includes('Attribute Name is Required')) {
      //     this.errorMessages.push('Attribute Name is Required');
      //   }
      // } else {
      //   const changedArray = this.errorMessages.filter(function (value) {
      //     return value !== 'Attribute Name is Required';
      //   });
      //   this.errorMessages = changedArray;
      // }

      // if (this.newObj[this.newObj.length-1].defaultValue === '') {
      //   if (!this.errorMessages.includes('Default Value is Required')) {
      //     this.errorMessages.push('Default Value is Required');
      //   }
      // } else {
      //   const changedArray = this.errorMessages.filter(function (value) {
      //     return value !== 'Default Value is Required';
      //   });
      //   this.errorMessages = changedArray;
      // }

      // if (this.newObj[this.newObj.length-1].displayText === '') {
      //   if (!this.errorMessages.includes('Display Text is Required')) {
      //     this.errorMessages.push('Display Text is Required');
      //   }
      // } else {
      //   const changedArray = this.errorMessages.filter(function (value) {
      //     return value !== 'Display Text is Required';
      //   });
      //   this.errorMessages = changedArray;
      // }
    },
    editAttribute (data, index) {
      this.maxLengthEdit = data.stringMax;
      this.editClick = true;
      if (this.newAttribute === true && this.$route.name.includes('create')) {
        this.selectedAttribute = index;
        this.newAttribute = false;
      } else if (
        this.$route.name.includes('edit') &&
        this.editFlag === true &&
        index >= 0 &&
        !(index >= this.addNewAtt)
      ) {
        this.selectedAttribute = index;
        this.editFlag = false;
        this.dataTypeNonEditable = true;
        this.attributeNameNonEditable = true;
        this.addAttributeInEdit = true;
        this.strValidation = this.stringObj[index];
      } else if (
        this.$route.name.includes('edit') &&
        this.newObj.length > parseInt(this.addNewAtt) &&
        index >= this.addNewAtt &&
        this.editFlag === true
      ) {
        this.selectedAttribute = index;
        this.editFlag = false;
        this.dataTypeNonEditable = false;
        this.addAttributeInEdit = true;
        this.attributeNameNonEditable = false;
      } else if (
        this.$route.name.includes('clone') &&
        this.editFlag === true &&
        index >= 0
      ) {
        this.selectedAttribute = index;
        this.editFlag = false;
        this.addAttributeInClone = true;
      }
    },
    saveAttr (item, i) {
      if (item.stringMax !== 0 && item.stringMax !== '') {
        this.editClick = false;
        localStorage.removeItem('oldObj');
        this.newObj[i].status = true;
        this.selectedAttribute = null;
        this.editFlag = true;
        this.addAttributeInClone = false;
        this.newAttribute = true;
        localStorage.setItem('oldObj', JSON.stringify(this.newObj));
        this.$emit('saveNewAttributes', this.newObj);
        this.$emit('attributeSaveValidation', true);
      }
      if (item.dataType !== null && item.dataType !== 'String') {
        this.editClick = false;
        localStorage.removeItem('oldObj');
        this.newObj[i].status = true;
        this.selectedAttribute = null;
        this.editFlag = true;
        this.addAttributeInClone = false;
        this.newAttribute = true;
        localStorage.setItem('oldObj', JSON.stringify(this.newObj));
        this.$emit('saveNewAttributes', this.newObj);
        this.$emit('attributeSaveValidation', true);
      }
    },
    updateAttr (item, i) {
      this.editClick = false;
      if (item.dataType !== 'String') {
        this.newObj[i].status = true;
        this.selectedAttribute = null;
        this.editFlag = true;
        this.oldData = true;
        this.addAttributeInEdit = false;
        this.newAttribute = true;
        localStorage.setItem('editObj', JSON.stringify(this.newObj));
        localStorage.setItem('oldObj', JSON.stringify(this.newObj));
        this.$emit('saveNewAttributes', this.newObj);
        this.$emit('attributeSaveValidation', true);
      } else if (item.dataType === 'String' && parseInt(item.stringMax) >= 0) {
        if (i + 1 <= this.addNewAtt) {
          if (item.stringMax >= this.stringObj[i]) {
            this.newObj[i].status = true;
            this.selectedAttribute = null;
            this.editFlag = true;
            this.oldData = true;
            this.addAttributeInEdit = false;
            this.newAttribute = true;
            localStorage.setItem('editObj', JSON.stringify(this.newObj));
            localStorage.setItem('oldObj', JSON.stringify(this.newObj));
            this.$emit('saveNewAttributes', this.newObj);
            this.$emit('attributeSaveValidation', true);
          } else {
            this.editClick = true;
            this.maxLengthHover = true;
          }
        }
        if (i + 1 > this.addNewAtt) {
          this.newObj[i].status = true;
          this.selectedAttribute = null;
          this.editFlag = true;
          this.addAttributeInEdit = false;
          this.newAttribute = true;
          localStorage.setItem('editObj', JSON.stringify(this.newObj));
          localStorage.setItem('oldObj', JSON.stringify(this.newObj));
          this.$emit('saveNewAttributes', this.newObj);
          this.$emit('attributeSaveValidation', true);
        }
      } else {
        this.editClick = true;
      }
    },
    deleteAttribute (items, index) {
      if (this.newAttribute === true && this.$route.name.includes('create')) {
        this.newObj = this.newObj.filter((item) => item !== items);
        this.newAttribute = true;
        localStorage.setItem('oldObj', JSON.stringify(this.newObj));
      } else if (
        this.$route.name.includes('edit') &&
        this.newObj.length > parseInt(this.addNewAtt) &&
        index >= this.addNewAtt &&
        this.editFlag
      ) {
        this.newObj = this.newObj.filter(
          (item) => item.columnName !== items.columnName
        );
        this.editFlag = true;
        this.addAttributeInEdit = false;
        localStorage.setItem('editObj', JSON.stringify(this.newObj));
      } else if (
        this.$route.name.includes('clone') &&
        index >= 0 &&
        this.editFlag
      ) {
        this.newObj = this.newObj.filter(
          (item) => item.columnName !== items.columnName
        );
        this.editFlag = true;
        this.addAttributeInClone = false;
        localStorage.setItem('oldObj', JSON.stringify(this.newObj));
      }
      this.$emit('saveNewAttributes', this.newObj);
      this.$emit('attributeSaveValidation', true);
    },
    cancleAttribute (items, i) {
      this.errorMessages = [];
      if (this.$route.name.includes('create')) {
        if (this.newObj[i].status === false) {
          this.newObj.pop();
          this.errorData = false;
          this.errorAttribute = false;
        } else {
          let oldObj = [];
          oldObj = localStorage.getItem('oldObj');
          this.newObj = JSON.parse(oldObj);
          this.selectedAttribute = null;
        }
      }
      if (this.$route.name.includes('clone')) {
        if (
          this.$route.name.includes('clone') &&
          this.newObj[i] &&
          this.newObj.length > parseInt(this.addNewAtt) &&
          this.newObj[i].status === false
        ) {
          this.newObj.pop();
          this.errorData = false;
          this.errorAttribute = false;
          this.addAttributeInClone = false;
        } else {
          let oldObj = [];
          oldObj = localStorage.getItem('oldObj');
          this.newObj = [];
          this.newObj = JSON.parse(oldObj);
          this.selectedAttribute = null;
        }
      }
      if (this.$route.name.includes('edit')) {
        if (
          this.$route.name.includes('edit') &&
          this.newObj[i] &&
          this.newObj.length > parseInt(this.addNewAtt) &&
          this.newObj[i].status === false
        ) {
          this.newObj.pop();
          this.errorData = false;
          this.errorAttribute = false;
          this.addAttributeInEdit = false;
        } else {
          let oldObj = [];
          oldObj = localStorage.getItem('editObj');
          this.newObj = [];
          this.newObj = JSON.parse(oldObj);
          this.selectedAttribute = null;
        }
      }
      this.editFlag = true;
      this.addAttributeInEdit = false;
      this.addAttributeInClone = false;
      this.newAttribute = true;
      this.$emit('saveNewAttributes', this.newObj);
      this.$emit('attributeSaveValidation', true);
    },
    addNewAttribute () {
      if (this.newObj.length === 0) {
        localStorage.removeItem('oldObj');
        localStorage.removeItem('editObj');
      }
      if (this.newAttribute === true || this.newObj.length === 0) {
        this.newObj.push({
          columnName: '',
          dataType: null,
          stringMax: 0,
          require: '',
          unique: '',
          encryption: 'string',
          predefinedValues: null,
          example: '',
          description: '',
          status: false,
          defaultValue: '',
          displayText: '',
          programId: -1,
          isDsar: true,
          isRtbf: true,
          isActive: true
        });
        this.selectedAttribute = this.newObj.length - 1;
        this.newAttribute = false;
        this.$emit('attributeSaveValidation', false);
        this.editFlag = false;
      }
    },
    addNewAttributeInEdit () {
      if (this.newObj.length === 0) {
        localStorage.removeItem('oldObj');
        localStorage.removeItem('editObj');
      }
      if (
        this.$route.name.includes('edit') &&
        this.addAttributeInEdit === false
      ) {
        this.newObj.push({
          columnName: '',
          dataType: null,
          stringMax: 0,
          require: '',
          unique: '',
          encryption: 'string',
          predefinedValues: null,
          example: '',
          description: '',
          status: false,
          defaultValue: '',
          displayText: '',
          programId: -1,
          isDsar: true,
          isRtbf: true,
          isActive: true
        });
        this.attributeNameNonEditable = false;
        this.dataTypeNonEditable = false;
        this.selectedAttribute = this.newObj.length - 1;
        this.addAttributeInEdit = true;
        this.editFlag = false;
        this.$emit('attributeSaveValidation', false);
      }
    },
    addNewAttributeInClone () {
      if (this.newObj.length === 0) {
        localStorage.removeItem('oldObj');
        localStorage.removeItem('editObj');
      }
      if (
        this.$route.name.includes('clone') &&
        this.addAttributeInClone === false
      ) {
        this.newObj.push({
          columnName: '',
          dataType: null,
          stringMax: 0,
          require: '',
          unique: '',
          encryption: 'string',
          predefinedValues: null,
          example: '',
          description: '',
          status: false,
          defaultValue: '',
          displayText: '',
          programId: -1,
          isDsar: true,
          isRtbf: true,
          isActive: true
        });
        this.selectedAttribute = this.newObj.length - 1;
        this.addAttributeInClone = true;
        this.editFlag = false;
        this.$emit('attributeSaveValidation', false);
      }
    }
  }
};
</script>

<style scoped lang="scss">
.sticky-data-table {
  overflow-y: hidden;
}
.erroe-popup {
  position: absolute;
  top: 34px;
  padding-top: 8px;
  height: 100%;
  small {
    color: #cc0000;
    display: block;
    font-weight: 600;
    font-size: 12px !important;
    line-height: normal;
  }
  span {
    display: flex;
    font-size: 13px !important;
    .v-icon {
      color: #cc0000 !important;
      font-size: 15px !important;
      padding-right: 3px;
      line-height: normal;
    }
  }
}
.relstive-position {
  position: relative;
}
.icon-font20 {
  font-size: 20px !important;
  cursor: pointer;
}
.custom-table-error {
  //box-shadow: 10px 10px 15px 0 rgba(0, 0, 0, 0.1);
  background-color: rgba(255, 255, 255, 0.98);
  width: 500px;
  //position: absolute;
  margin-bottom: 0;
  padding: 32px;
  &__disc {
    padding-left: 32px;
    line-height: 24px;
    color: black;
    font-size: 15px !important;
  }
  &__head {
    font-size: 24px !important;
    font-weight: normal;
    margin-bottom: 16px;
    .v-icon {
      color: #00295f;
      font-size: 24px !important;
      margin-right: 8px;
    }
  }
}
.great-content {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 55px;
  //background: red;
  opacity: 0.2;
}
td.border-t0 {
  border-top: 0 !important;
}
</style>
