<template>
  <brierley-inner-view class="gen2-container-py0">
    <template v-slot:header>
      <template v-if="openProgramHierarchy">
        <program-hierarchy></program-hierarchy>
      </template>
      <span class="inner-head">{{ title }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>{{ $t("closeBtnText") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row
        class="flex-column bpt5"
        no-gutters
        v-if="productCurrentStep === 1"
      >
        <v-col>
          <brierley-form-title
            :formTitle="formTitle"
            :infoText="$t('productDefInfoText')"
          />
        </v-col>
      </v-row>
      <v-row
        class="flex-column bpt5"
        no-gutters
        v-if="productCurrentStep === 2"
      >
        <v-col>
          <brierley-form-title
            :formTitle="$t('successFormTitle')"
            :infoText="$t('successInfoText')"
          />
        </v-col>
      </v-row>
      <template v-if="productCurrentStep === 1">
        <Validation-Observer
          ref="observer"
          v-slot="{ invalid }"
          tag="form"
          @submit.prevent="submit()"
        >
          <v-form
            id="product_definition_form"
            @submit.prevent="submit(invalid)"
          >
            <keep-alive>
              <v-row no-gutters class="bpt5">
                <v-col class="gen2-forms form-light-bg" xs="12" sm="7">
                  <p class="label-text">{{ $t("basicDetailsText") }}</p>
                  <v-col sm="8" xs="12" class="bpa0">
                    <validation-provider
                      id="product_definition_form"
                      rules="required"
                      v-slot="{ errors }"
                    >
                      <v-text-field
                        autocomplete="off"
                        :label="$t('productSetNameLabel')"
                        id="product_basic_name"
                        filled
                        required
                        :disabled="productNameNonEditable"
                        v-model="productInformation.name"
                        @input="productField()"
                        v-bind:class="[
                          errors[0] === 'This field is required'
                            ? ' error--text'
                            : ''
                        ]"
                      ></v-text-field>
                      <p
                        class="custom-error-msg"
                        v-if="duplicateName && errors.length === 0"
                      >
                       {{productNameErrorText}}
                      </p>
                      <p
                        class="custom-error-msg"
                        v-if="
                          errors[0] != undefined &&
                            errors[0].length > 0 &&
                            errors[0] === 'This field is required'
                        "
                      >
                        {{ $t("productSetNameError") }}
                      </p>
                      <p
                        class="custom-error-msg"
                        v-else-if="
                          errors[0] != undefined && errors[0].length > 0
                        "
                      >
                        {{ $t("productSetNameAlphabeticError") }}
                      </p>
                    </validation-provider>
                  </v-col>
                  <v-col sm="10" xs="12" class="bpa0">
                    <v-textarea
                      :label="$t('productSetDescriptionLabel')"
                      filled
                      auto-grow
                      v-model="productInformation.description"
                    ></v-textarea>
                  </v-col>
                </v-col>
                <v-col xs="12" sm="5">
                  <brierley-info-side>
                    <template v-slot:info-side-header>
                      <div class="info_title">
                        <v-icon>info</v-icon>{{ $t("infoText") }}
                      </div>
                    </template>
                    <template v-slot:info-side-body>
                      <div>
                        {{ $t("infoPassage") }}
                      </div>
                    </template>
                  </brierley-info-side>
                </v-col>
              </v-row>
            </keep-alive>
            <v-expansion-panels
              class="role-assignment-expansions bpb28 bpt3"
              accordion
              v-model="panel"
              multiple
            >
              <v-expansion-panel>
                <v-expansion-panel-header>{{
                  $t("productAttributesLabel")
                }}</v-expansion-panel-header>
                <v-expansion-panel-content>
                  <ProductAttribute
                    v-on:saveNewAttributes="saveNewAttributes"
                    v-on:attributeSaveValidation="attributeSaveValidation"
                    v-on:saveAttributeClick="saveAttributeClick"
                  />
                </v-expansion-panel-content>
              </v-expansion-panel>
              <v-expansion-panel>
                <v-expansion-panel-header class="fbold">{{
                  $t("programEntityMappingLabel")
                }}</v-expansion-panel-header>
                <v-expansion-panel-content>
                  <v-col class="programEntity">
                    <v-col class="pb-0">
                      <p data-qe-id="product_definition_paragraph">
                        {{ $t("programEntityPassage") }}
                      </p>
                    </v-col>
                    <v-col class="pt-0">
                      <h2 class="label-text">
                        {{ $t("programEntityText") }}
                      </h2>
                      <v-row
                        no-gutters
                        v-if="selectedOrgProductData.length == 0"
                      >
                        <v-col class="gen2-forms form-light-bg" xs="12" sm="7">
                          <v-col sm="8" xs="12" class="bpa0">
                            <validation-provider
                              id="product_definition_form"
                              rules="required"
                              v-slot="{ errors }"
                            >
                              <v-text-field
                                autocomplete="off"
                                disabled
                                :label="$t('noProgramEntitySelectedText')"
                                id="product_entity_name"
                                filled
                                required
                                v-model="selectedEntity"
                                v-bind:class="[
                                  errors[0] === 'This field is required'
                                    ? ' error--text'
                                    : ''
                                ]"
                              ></v-text-field>
                              <p
                                class="custom-error-msg"
                                v-if="
                                  errors[0] != undefined &&
                                    errors[0].length > 0 &&
                                    errors[0] === 'This field is required'
                                "
                              >
                                {{ $t("programEntityError") }}
                              </p>
                            </validation-provider>
                          </v-col>
                        </v-col>
                      </v-row>
                      <v-row
                        no-gutters
                        v-if="selectedOrgProductData.length > 0"
                      >
                        <v-col sm="6">
                          <v-row
                            class="flex-column block-with-chips"
                            no-gutters
                          >
                            <v-col class="block-with-chips__label">
                              <template>
                                <span class="req-label">{{
                                  $t("selectedProgramEntitiesLabel")
                                }}</span>
                              </template>
                            </v-col>
                            <v-col class="block-with-chips__body">
                              <template>
                                <v-chip
                                  close
                                  close-icon="close"
                                  v-for="item in selectedOrgProductData"
                                  :key="item.name"
                                  :disabled="chipNonEditable"
                                  data-qe-id="product_productlaoyout_selectorgProductData"
                                  @click:close="removeSelectedChip(item)"
                                  >{{ item.name }}</v-chip
                                >
                              </template>
                            </v-col>
                          </v-row>
                        </v-col>
                      </v-row>
                      <v-row
                        class="mt-2 ml-1"
                        v-if="disableInEdit"
                        @click="openProgramHierarchyPopUp()"
                        data-qe-id="product_productlaoyout_selectprograHirerachyPopUp"
                      >
                        <p
                          title="Click Here To Select"
                          class="primary-text fbold text-right text-uppercase font15 selectText bmb0"
                          data-qe-id="product_productlaoyout_pragaraph_click"
                        >
                          {{ $t("selectHereLabel") }}
                        </p>
                      </v-row>
                    </v-col>
                  </v-col>
                </v-expansion-panel-content>
              </v-expansion-panel>
            </v-expansion-panels>
          </v-form>
        </Validation-Observer>
      </template>
      <template v-if="productCurrentStep === 2">
        <v-row class="flex-column" no-gutters>
          <v-col class="bmt5 bmb2">
            <brierley-alert
              :isSiteLevel="true"
              alertType="success"
              :alertBody="alertMessage"
              :alertHeader="$t('successAlert')"
              icon="done"
            ></brierley-alert>
          </v-col>
        </v-row>
      </template>
      <brierley-dialogbox :dialog="dialog" @closeMe="dialog = $event">
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            $t("unsavedChangesLabel")
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <brierley-alert
                  alertType="error"
                  :alertBody="$t('errorMsgText')"
                ></brierley-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="org_btn_cancelDeleteDialog"
            text
            class="cancel no-ripple"
            @click="gotoProductsClick()"
            >{{ $t("noBtnText") }}</v-btn
          >
          <v-btn
            id="org_btn_deleteDeleteDialog"
            class="primaryctabtn text-uppercase"
            title
            @click="save()"
            type="invalid"
            form="product_definition_form"
            >{{ $t("yesBtnText") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
      <brierley-dialogbox :dialog="alertDialog" @closeMe="alertDialog = $event">
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            $t("alertText")
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <brierley-alert
                  alertType="error"
                  :alertBody="$t('alertPopUpMessage')"
                ></brierley-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="org_btn_cancelDeleteDialog"
            text
            class="primaryctabtn text-uppercase"
            @click="alertDialog = false"
            >{{ $t("closePopUp") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </template>
    <template v-slot:footer v-if="productCurrentStep == 1">
      <v-btn
        title="Cancel"
        text
        class="cancel no-ripple bmt2 bmr5"
        @click="showPopUp()"
        >{{ $t("cancelBtnText") }}</v-btn
      >
      <v-btn
        title="Save And Continue"
        class="primaryctabtn bmt2 bml2"
        type="invalid"
        form="product_definition_form"
        @click="saveProductDefinition()"
        >{{ $t("saveContinueBtnText") }}</v-btn
      >
    </template>
    <template v-slot:footer-redirect v-if="productCurrentStep == 2">
      <v-btn
        title="Go To Product Definitions"
        id="user_btn_goToUsers"
        class="primaryctabtn bmt2"
        @click="gotoProductsClick()"
        >{{ $t("goToProductDefText") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import ProgramHierarchy from './programHierarchy.vue';
import {
  BrierleyInnerView,
  BrierleyFormTitle,
  BrierleyInfoSide,
  brierleyAlert,
  BrierleyDialogbox
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import ProductAttribute from './child/ProductAttributes';
import { productLayoutObj } from '../../../i18n/language.js';
export default {
  components: {
    BrierleyInnerView,
    BrierleyFormTitle,
    ProgramHierarchy,
    ProductAttribute,
    BrierleyInfoSide,
    brierleyAlert,
    BrierleyDialogbox
  },
  data () {
    return {
      title: this.$t('headerText'),
      panel: [],
      ProductSetNameRes: '',
      ProductDesctiptionRes: '',
      selectedOrgProductDataRes: '',
      newCreatedAttributesRes: '',
      newCreatedAttributes: '',
      newProductInformation: '',
      productNameNonEditable: false,
      chipNonEditable: false,
      disableInEdit: false,
      ProductSetName: null,
      ProductDesctiption: '',
      saveDefinition: [],
      productCurrentStep: 1,
      dialog: false,
      validation: false,
      nameRules: [
        v => !!v || this.$t('message.nameIsRequired'),
        v => v && v.length <= 50 || this.$t('message.nameLengthExceeded')
      ],
      saveCall: false,
      duplicateName: false,
      productNameErrorText: '',
      attrRes: Boolean,
      selectedEntity: null,
      alertDialog: false,
      saveAttribute: false
    };
  },
  i18n: productLayoutObj,
  created () {
    localStorage.removeItem('editObj');
    localStorage.removeItem('oldObj');
    this.$store.dispatch('productdefinitionModule/getProductAttributesAction');
    if (this.$route.name.includes('edit')) {
      this.$store.dispatch(
        'productdefinitionModule/editProductDefinitionByIdAction',
        this.$route.query.id
      );
    } else if (this.$route.name.includes('clone')) {
      this.$store.dispatch(
        'productdefinitionModule/cloneProductDefinitionByIdAction',
        this.$route.query.id
      );
    }
    this.$store.commit(
      'productdefinitionModule/productInformationDataMutation',
      {
        name: '',
        description: '',
        productDefinitionId: ''
      }
    );
    this.$store.commit(
      'productdefinitionModule/extensionPropertyDataMutation',
      {
        extensionAttributesData: []
      }
    );
    this.$store.commit(
      'productdefinitionModule/updateSelectedProductDataYesMutation',
      {
        id: '',
        name: '',
        parentEntityId: ''
      }
    );
  },
  computed: {
    ...mapState('productdefinitionModule', {
      selectedOrgProductData: state => {
        return state.selectedOrgProductData;
      },
      openProgramHierarchy: state => {
        return state.openProgramHierarchy;
      },
      attrNotSaved: state => {
        return state.attrNotSaved;
      },
      productAttributesData: state => {
        return state.productAttributesData;
      },
      productInformation: state => {
        return state.productInformation;
      }
    }),
    alertMessage () {
      return (
        this.$t('productDefText') +
        `${this.productInformation.name.bold()}` +
        this.$t('saveSuccesfulText')
      );
    },
    formTitle () {
      if (this.$route.name.includes('edit')) {
        return this.$t('editFormTitle');
      } else {
        return this.$t('newFormTitle');
      }
    }
  },
  mounted () {
    if (this.$route.name.includes('edit')) {
      this.title = this.$t('editProductDefinition');
      this.chipNonEditable = true;
      this.disableInEdit = false;
      this.productNameNonEditable = true;
    } else {
      this.chipNonEditable = false;
      this.disableInEdit = true;
      this.productNameNonEditable = false;
      this.$store.dispatch(
        'productdefinitionModule/getProductOrganizationDataAction'
      );
    }
  },
  methods: {
    productField () {
      this.duplicateName = false;
    },
    showPopUp () {
      this.dialog = true;
    },
    gotoProductsClick () {
      this.$router.push({ name: 'productdefinition' });
    },
    openProgramHierarchyPopUp () {
      let content = document.querySelector('html');
      content.classList.add('overflow-y-hidden');
      if (!this.$route.name.includes('edit')) {
        this.$store.dispatch(
          'productdefinitionModule/setDialogOpenAndCloseAction'
        );
      }
    },
    removeSelectedChip (selctedItem) {
      this.$store.dispatch(
        'productdefinitionModule/removeSelectedProductDataMainAction',
        {
          ...selctedItem
        }
      );
    },
    save () {
      this.dialog = false;
      this.saveProductDefinition();
    },
    async submit () {
      this.validation = false;
      const isValid = await this.$refs.observer.validate();
      if (!isValid) {
        this.validation = false;
        if (
          this.selectedOrgProductData.length === 0 &&
          this.attrRes === false
        ) {
          this.panel = [0, 1];
        } else if (
          this.attrRes === false &&
          this.selectedOrgProductData.length > 0
        ) {
          this.panel = [0];
          if (!this.saveAttribute && this.saveCall) {
            // this.alertDialog = true;
            this.$store.commit(
              'productdefinitionModule/attributeNotSavedMutation',
              true
            );
          }
        } else if (this.selectedOrgProductData.length === 0) {
          this.panel = [1];
        }
        return;
      } else {
        if (this.attrRes === false) {
          this.panel = [0];
          // this.alertDialog = true;
          this.$store.commit(
            'productdefinitionModule/attributeNotSavedMutation',
            true
          );
        } else {
          if (this.saveCall === true) {
            this.validation = true;
            this.saveProductDefinition();
          }
        }
      }
    },
    saveProductDefinition () {
      this.panel = [0, 1];
      this.saveCall = true;
      this.saveAttribute = false;
      if (this.validation === true) {
        if (this.productInformation.productDefinitionId === '') {
          let res = {
            name: this.productInformation.name,
            description: this.productInformation.description,
            programEntityId: this.selectedOrgProductData[0].id,
            extensionProperties: this.newCreatedAttributes
          };
          this.$store
            .dispatch('productdefinitionModule/saveProductDefinition', res)
            .then(res => {
              if (res.status === 201 || res.status === 200) {
                this.productCurrentStep = 2;
              }
            })
            .catch(err => {
              if (err.response.status === 400) {
                this.duplicateName = true;
                this.productNameErrorText = err.response.data.userMessage;
                this.panel = [];
                this.validation = false;
              }
            });
        } else {
          let res = {
            productDefinitionId: this.productInformation.productDefinitionId,
            name: this.productInformation.name,
            description: this.productInformation.description,
            programEntityId: this.selectedOrgProductData[0].id,
            extensionProperties: this.newCreatedAttributes
          };
          this.$store
            .dispatch('productdefinitionModule/saveProductDefinition', res)
            .then(res => {
              if (res.status === 201 || res.status === 200) {
                this.productCurrentStep = 2;
              }
            })
            .catch(err => {
              if (err.response.status === 400) {
                this.duplicateName = true;
                this.productNameErrorText = err.response.data.userMessage;
                this.panel = [];
                this.validation = false;
              }
            });
        }
      }
    },
    saveNewAttributes (value) {
      this.newCreatedAttributes = value;
    },
    attributeSaveValidation (value) {
      this.attrRes = value;
    },
    saveAttributeClick (value) {
      this.saveAttribute = value;
    }
  }
};
</script>
<style lang="scss" scoped>
.errclass {
  p {
    color: red;
  }
}
.programEntity {
  background: #fff;
}
.selectText {
  cursor: pointer;
}
.bpb28 {
  padding-bottom: 28px;
}
</style>
