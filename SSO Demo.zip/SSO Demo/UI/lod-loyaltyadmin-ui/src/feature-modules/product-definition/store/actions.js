import {
  getUsersSearch,
  getProductOrgData,
  getProducts,
  getProductDefinitionById,
  postProductDefinition
} from '../api/productdefinition-api';
import Vue from 'vue';

const saveProductDefinition = (context, payload) => {
  return new Promise((resolve, reject) => {
    postProductDefinition(payload)
      .then(res => {
        if (res.data) {
          Vue.prototype.$http.patch(
            '/loyaltyconfiguration/api/v1/businessEntities/productdefinition?businessEntityId=' +
              res.data.data.programEntityId +
              '&productDefinitionId=' +
              res.data.data.productDefinitionId
          );
        }
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getProductDefinitionListAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getUsersSearch(payload)
      .then(result => {
        resolve(result);
        context.commit('userSearchListMutation', result.data);
      })
      .catch(err => {
        reject(err);
        if (err.response.status === 400 || err.response.status === 404) {
          context.commit('userSearchListMutation', err.response.data);
        }
      });
  });
};

const getProductAttributes = context => {
  getProducts().then(productDataRes => {
    context.commit('getProductDataMutation', productDataRes.data);
  });
};

const getProductAttributesAction = context => {
  context.dispatch('getProductAttributes');
};

const getProductOrgDataAction = context => {
  getProductOrgData().then(orgProductDataRes => {
    context.commit(
      'getProductOrganizationDataMutation',
      orgProductDataRes.data
    );
  });
};

const getProductOrganizationDataAction = context => {
  context.dispatch('getProductOrgDataAction');
};

const setSelectedProductDataAction = (context, payloadForOrgData) => {
  context.commit('setSelectedProductDataMutation', payloadForOrgData);
};

const removeSelectedProductDataAction = (context, payloadForOrgData) => {
  context.commit('removeSelectedProductDataMutation', payloadForOrgData);
};

const setDialogOpenAndCloseAction = context => {
  context.commit('setDialogOpenAndCloseMutation');
};

const updateSelectedProductDataYesAction = context => {
  context.commit('updateSelectedProductDataYesMutation');
};

const updateSelectedProductDataNoAction = context => {
  context.commit('updateSelectedProductDataNoMutation');
};

const removeSelectedProductDataMainAction = (context, payloadForOrgData) => {
  context.commit('removeSelectedProductDataMainMutation', payloadForOrgData);
};

const updateSelectedProductDataToImplitDataAction = context => {
  context.commit('updateSelectedProductDataToImplitDataMutation');
};
const getProductDefinitionByIdAction = (context, payload) => {
  getProductDefinitionById(payload).then(productDefinitionRes => {
    context.commit(
      'getProductDefinitionByIdMutation',
      productDefinitionRes.data
    );
  });
};
const editProductDefinitionByIdAction = (context, payload) => {
  getProductDefinitionById(payload).then(productDefinitionRes => {
    let productAttributes = {};
    let productInformation = {};
    let businessEntity = {};
    productAttributes = {
      productCoreAttributes:
        productDefinitionRes.data.data.productExtendedAttributes
    };
    productInformation = {
      name: productDefinitionRes.data.data.name,
      description: productDefinitionRes.data.data.description,
      productDefinitionId: productDefinitionRes.data.data.productDefinitionId
    };
    if (productDefinitionRes.data.data.businessEntity !== null) {
      businessEntity = [
        {
          id: productDefinitionRes.data.data.businessEntity.businessEntityId,
          name: productDefinitionRes.data.data.businessEntity.name
        }
      ];
    }
    context.commit('programEntityDataMutation', businessEntity);
    context.commit('productInformationDataMutation', productInformation);
    context.commit('extensionPropertyDataMutation', productAttributes);
  });
};

const cloneProductDefinitionByIdAction = (context, payload)=> {
  getProductDefinitionById(payload).then(res=>{
    let productAttributes = {};
    let productInformation = {};
    productInformation = {
      name: `copy of ${res.data.data.name}`,
      description: '',
      productDefinitionId: ''
    };
    productAttributes = {
      productCoreAttributes:
        res.data.data.productExtendedAttributes
    };
    context.commit('productInformationDataMutation', productInformation);
    context.commit('extensionPropertyDataMutation', productAttributes);
  });
};

export default {
  getProductDefinitionListAction,
  getProductAttributesAction,
  getProductAttributes,
  cloneProductDefinitionByIdAction,
  getProductOrganizationDataAction,
  getProductOrgDataAction,
  setSelectedProductDataAction,
  editProductDefinitionByIdAction,
  removeSelectedProductDataAction,
  setDialogOpenAndCloseAction,
  updateSelectedProductDataYesAction,
  updateSelectedProductDataNoAction,
  removeSelectedProductDataMainAction,
  updateSelectedProductDataToImplitDataAction,
  getProductDefinitionByIdAction,
  saveProductDefinition
};
