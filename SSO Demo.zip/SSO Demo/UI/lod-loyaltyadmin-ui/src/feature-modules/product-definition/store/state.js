export default {
  moduleVar: 'I am Module',
  dashboard: {},
  productInformation: {
    name: '',
    description: '',
    productDefinitionId: ''
  },
  productDefinitionlist: [],
  productDefinitionsCount: 0,
  params: {
    searchText: '',
    pageSize: 10,
    pageNumber: 1
  },
  productAttributesData: [],
  orgProductData: [],
  selectedOrgProductData: [],
  selectedOrgProductDataBasedOnYesOrNo: [],
  openProgramHierarchy: false,
  IsSelectedProductExists: false,
  productDefinitionByIdData: [],
  attrNotSaved: false
};
