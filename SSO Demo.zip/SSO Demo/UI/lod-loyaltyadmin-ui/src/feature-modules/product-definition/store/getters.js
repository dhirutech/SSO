const getProductDefinitionList = state => state.productDefinitionlist;
const getListOfSelectedOrgProducts = state => state.selectedOrgProductData;
const getIsSelectedProductExists =  state => state.selectedOrgProductData;

export default { getProductDefinitionList, getListOfSelectedOrgProducts, getIsSelectedProductExists };
