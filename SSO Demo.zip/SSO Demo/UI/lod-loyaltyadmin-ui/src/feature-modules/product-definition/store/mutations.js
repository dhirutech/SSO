// import state from './state';

const userSearchListMutation = (state, payload) => {
  state.productDefinitionlist = payload.data.productDefinitions;
  state.productDefinitionsCount = payload.data.productDefinitionsCount;
};

const getLoadState = (state, payload) => {
  state.load = payload;
};

const getProductDataMutation = (state, payload) => {
  state.productAttributesData = payload.data.coreData;
};

const getProductOrganizationDataMutation = (state, payload) => {
  state.orgProductData = payload;
};

const setSelectedProductDataMutation = (state, payload) => {
  const getCurrentObject = [
    {
      id: payload.id,
      parentEntityId: payload.parentEntityId,
      name: payload.name
    }
  ];
  state.selectedOrgProductDataBasedOnYesOrNo = getCurrentObject;
  state.IsSelectedProductExists = true;
};

const removeSelectedProductDataMutation = state => {
  state.selectedOrgProductDataBasedOnYesOrNo = [];
  state.IsSelectedProductExists = false;
};

const updateSelectedProductDataYesMutation = state => {
  state.selectedOrgProductData = state.selectedOrgProductDataBasedOnYesOrNo;
  state.IsSelectedProductExists = true;
  state.selectedOrgProductDataBasedOnYesOrNo = [];
};

const updateSelectedProductDataNoMutation = state => {
  state.selectedOrgProductDataBasedOnYesOrNo = [];
  state.IsSelectedProductExists = state.IsSelectedProductExists.length > 0;
};

const removeSelectedProductDataMainMutation = state => {
  state.IsSelectedProductExists = false;
  state.selectedOrgProductData = [];
};

const updateSelectedProductDataToImplitDataMutation = state => {
  state.selectedOrgProductDataBasedOnYesOrNo = state.selectedOrgProductData;
  state.IsSelectedProductExists = state.selectedOrgProductData.length > 0;
};

const setDialogOpenAndCloseMutation = state => {
  state.openProgramHierarchy = !state.openProgramHierarchy;
};

const getProductDefinitionByIdMutation = (state, payload) => {
  state.productDefinitionByIdData = payload;
};

const extensionPropertyDataMutation = (state, payload) => {
  state.extensionAttributesData = payload;
};
const productInformationDataMutation = (state, payload) => {
  state.productInformation = payload;
};

const programEntityDataMutation = (state, payload) => {
  if (payload.length > 0) {
    state.selectedOrgProductData = payload;
  }
};

const attributeNotSavedMutation = (state, payload) => {
  state.attrNotSaved = payload;
};
export default {
  attributeNotSavedMutation,
  userSearchListMutation,
  getLoadState,
  extensionPropertyDataMutation,
  productInformationDataMutation,
  programEntityDataMutation,
  getProductDataMutation,
  getProductOrganizationDataMutation,
  setSelectedProductDataMutation,
  removeSelectedProductDataMutation,
  setDialogOpenAndCloseMutation,
  updateSelectedProductDataYesMutation,
  updateSelectedProductDataNoMutation,
  removeSelectedProductDataMainMutation,
  updateSelectedProductDataToImplitDataMutation,
  getProductDefinitionByIdMutation
};
