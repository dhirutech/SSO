import productdefinition from './components/productdefinition.vue';
import ProductLayout from './components/ProductLayout';
import ProductDefinitionViewDetails from './components/child/ProductDefinitionViewDetails.vue';
const productdefinitionRoutes = [
  {
    path: '/loyaltyadmin/productdefinition',
    name: 'productdefinition',
    component: productdefinition,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/product/create',
    name: 'createProduct',
    component: ProductLayout,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/product/edit',
    name: 'editProductDefinition',
    component: ProductLayout,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/product/clone',
    name: 'cloneProductDefinition',
    component: ProductLayout,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/product/view',
    name: 'productDefinitionView',
    component: ProductDefinitionViewDetails,
    meta: {
      showNavigation: false
    }
  }
];

export default productdefinitionRoutes;
