import Vue from 'vue';
const getUsersSearch = parameters => {
  return Vue.prototype.$http.get(
    '/product/api/v1/productdefinitions?SearchText=' +
     encodeURIComponent(parameters.searchText) +
      '&PageSize=' +
      parameters.pageSize +
      '&PageNumber=' +
      parameters.pageNumber
  );
};

const getProducts = () => {
  return Vue.prototype.$http.get(
    '/product/api/v1/productdefinitions/GetProductCoreAttributes'
  );
};

const getProductOrgData = () => {
  return Vue.prototype.$http.get(
    '/loyaltyconfiguration/api/v1/businessEntities/structure'
  );
};
const getProductDefinitionById = id => {
  return Vue.prototype.$http.get(
    '/product/api/v1/productdefinitions/getproductdefinitionbyid?productDefinitionId=' +
      id
  );
};

const postProductDefinition = ProductDefinition => {
  if (ProductDefinition.productDefinitionId) {
    return Vue.prototype.$http.put(
      'product/api/v1/productdefinitions',
      ProductDefinition
    );
  } else {
    return Vue.prototype.$http.post(
      'product/api/v1/productdefinitions',
      ProductDefinition
    );
  }
};

export {
  getUsersSearch,
  getProducts,
  getProductOrgData,
  getProductDefinitionById,
  postProductDefinition
};
