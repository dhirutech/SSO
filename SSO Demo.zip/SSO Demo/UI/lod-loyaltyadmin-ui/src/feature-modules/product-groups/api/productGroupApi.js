import Vue from 'vue';

const getProductGroupList = async payload => {
  let sortCol =
    payload.sortCol && payload.sortCol !== '' ? payload.sortCol : 'CreatedDate';
  let sortType =
    typeof payload.sortType === 'boolean' ? payload.sortType : true;
  // return await Vue.prototype.$http.get(
  //   'product/api/v1/productgroup/getall?ProgramId=' +
  //     payload.programId +
  //     '&PageSize=' +
  //     payload.pageSize +
  //     '&PageNumber=' +
  //     payload.pageNumber +
  //     '&SortColumn=' +
  //     sortCol +
  //     '&IsDescending=' +
  //     sortType
  // );
  // console.log(payload)
  // eslint-disable-next-line eqeqeq
  if (payload.searchText === '' && !payload.filter) {
    return await Vue.prototype.$http.get(
      'product/api/v1/productgroup/getall?ProgramId=' +
      payload.programId +
      '&PageSize=' +
      payload.pageSize +
      '&PageNumber=' +
      payload.pageNumber +
      '&SortColumn=' +
      sortCol +
      '&IsDescending=' +
      sortType
    );
  } else if(payload.searchText !== '' || payload.filter) {
    let searchData =
    payload.searchText !== ''
      ? '&SearchText=' + payload.searchText
      : '';
      let ToDate =
    payload.toDate !== ''
      ? '&ToDate=' + payload.toDate
      : '';
      let FromDate =
    payload.fromDate !== ''
      ? '&FromDate=' + payload.fromDate
      : '';
      let programEntityId =
    payload.programEntityId !== ''
      ? '&programEntityId=' + payload.programEntityId
      : '';
    return await Vue.prototype.$http
      .get(
        'product/api/v1/productgroup/getall?ProgramId=' +
          payload.programId +
          searchData +
          '&PageSize=' +
          payload.pageSize +
          '&PageNumber=' +
          payload.pageNumber +
          ToDate+
          FromDate+
          programEntityId
      )
      .then(res => {
        return res;
      });
  } 
  //else if(payload.searchText == '' && payload.filter) {
  //   console.log(payload)
  //   let searchData =
  // payload.searchText !== ''
  //   ? '&SearchText=' + payload.searchText
  //   : '';
  //   return await Vue.prototype.$http
  //     .get(
  //       'product/api/v1/productgroup/getall?ProgramId=' +
  //     payload.programId +
  //     '&ToDate=' +
  //     payload.toDate +
  //     '&FromDate=' +
  //     payload.fromDate +
  //     '&programEntityId=' +
  //     payload.programEntityId +
  //     '&PageSize=' +
  //     payload.pageSize +
  //     '&PageNumber=' +
  //     payload.pageNumber+
  //     searchData
  //     )
  //     .then(res => {
  //       console.log('>>>>>Filterres',res)
  //       return res;
  //     });
  // }

};

const getProductBusinessEntity = payload => {
  return Vue.prototype.$http.get(
    '/product/api/v1/productdefinitions/businessentities/' + payload
  );
};
const deleteProductGroup = payload => {
  return Vue.prototype.$http.delete(
    'product/api/v1/productgroup/delete/' + payload
  );
};

const getExtensionProperties = payload => {
  return Vue.prototype.$http.get(
    '/product/api/v2/extensionProperties/products?brandIds=' + payload
  );
};

const getValueProperties = payload => {
  return Vue.prototype.$http.get(
    '/product/api/v2/extensionProperties/products/values?ExtensionPropertyId=' +
      payload.extensionPropertyId +
      '&ColumnName=' +
      payload.columnName +
      '&IsExtendedAttribute=' +
      payload.isExtendedAttribute
    // '&ProgramEntityId=' +
    // payload.programEntityId
  );
};
const createOrEditProductGroups = payload => {
  return Vue.prototype.$http.post('/product/api/v1/productgroup', payload);
};

const getProductGroupsById = payload => {
  return Vue.prototype.$http.get('/product/api/v1/productgroup/'+payload);
};
const checkForDuplicateProductGroup = payload => {
  let { productGroupName, productGroupId, programId } = payload;
  let url = '/product/api/v1/productgroup/isUnique';
  return Vue.prototype.$http.post(url, {
    name: productGroupName,
    productGroupId,
    programId
  });
};
const getProductDetailsRes = payload => {
  return Vue.prototype.$http.post(
    'product/api/v1/productgroup/previewproduct',
    payload[0]
  );
};
export {
  getProductBusinessEntity,
  getProductGroupList,
  getExtensionProperties,
  getValueProperties,
  createOrEditProductGroups,
  getProductGroupsById,
  checkForDuplicateProductGroup,
  getProductDetailsRes,
  deleteProductGroup,
};
