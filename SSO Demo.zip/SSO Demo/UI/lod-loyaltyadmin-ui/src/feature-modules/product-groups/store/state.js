export default {
  viewName: '',
  isDuplicateExist: false,
  isLoading: false,
  isCreateSuccess: true,
  productGroupDetails: {
    productGroupName: '',
    productGroupDescription: '',
    productGroupCreatedBy: '',
    productGroupStepper: 1,
    showCancelPopup: false,
    showCreateEntityPopup: false,
    showDuplicateProductPopup: false
  },
  productGroupId: null,
  params: {
    searchText: '',
    pageSize: 10,
    pageNumber: 1,
    businessEntityId: 0,
    fromDate: '',
    toDate: '',
    programEntityId: '',
    filter: false
  },
  getProductGroupListMutations: [],
  getProductGroupCount: 0,
  preiewProduct: [],
  getProductGroupProducts: [],
  getProductGroupProductsCount: 0,
  previewPopupValues: [],
  paramsTable: {
    searchText: '',
    pageSize: 10,
    pageNumber: 1,
    businessEntityId: 0,
    fromDate: '',
    toDate: '',
    programEntityId: '',
    filter: false
  },
  getProductGroupListMutationsTable: [],
  getProductGroupCountTable: 0,

  loadmore: true,
  getFilterResponse: [],
  productBusinessEntity: [],
  productGroupAttributeArray: [],
  programEntity: [],
  showPreviewPopup: false,
  productGroupEntityArray: [
    {
      productGroupDefaultCondition: 'AND',
      productGroupAndToggled: true,
      productGroupOrToggle: false,
      productGroupBusinessEntity: [],
      selectedBusinessEntity: '',
      deleteProductGroupObj: {},
      deleteProductGroupName: '',
      entityErrorExists: false,
      productGroupAttibuteOperatorArray: [
        {
          productGroupAttributeArray: [],
          selectedGroupAttribute: '',
          attributeErrorExists: false,
          productGroupOperatorArray: [],
          selectedGroupOperator: '',
          operatorErrorExists: false,
          productGroupValueArray: [],
          selectedGroupValue: '',
          valueErrorExists: false,
          valueName: ''
        }
      ]
    }
  ]
};
