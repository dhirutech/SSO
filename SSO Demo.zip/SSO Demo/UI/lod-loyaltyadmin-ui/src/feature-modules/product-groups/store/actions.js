import * as api from '../api/productGroupApi.js';
import {
  getProductBusinessEntity,
  getExtensionProperties,
  getValueProperties,
  getProductGroupsById,
  checkForDuplicateProductGroup,
  deleteProductGroup,
  getProductDetailsRes
} from '../api/productGroupApi.js';

const getProductGroupListActions = async ({ commit }, payload) => {
  // commit('setLoadMoreMutations', true);
  // await api
  //   .getProductGroupList(payload)
  //   .then(res => {
  //     commit('getProductGroupListMutations', res.data.data.productGroups);
  //     commit('getProductGroupCount', res.data.data.productGroupsCount);
  //   })
  //   .catch(() => {
  //     commit('getProductGroupCount', 0);
  //     commit('getProductGroupListMutations', []);
  //   });
  commit('setLoadMoreMutations', true);
  // eslint-disable-next-line eqeqeq
  if (payload.searchText === '' && !payload.filter) {
    await api

      .getProductGroupList(payload)
      .then(res => {
        commit('getProductGroupCount', res.data.data.productGroupsCount);
        return res.data.data;
      })
      .catch(() => {
        commit('getProductGroupCount', 0);
        commit('getProductGroupListMutations', []);
      });
  } else if (payload.searchText !== '' || payload.filter) {
    return await api.getProductGroupList(payload)
      .then(response => {
        commit('getProductGroupCount', response.data.data.productGroupsCount);
        return response.data.data;
      })
      .catch(() => {
        commit('getProductGroupListMutations', []);
        commit('setLoadMoreMutations', false);
        commit('getProductGroupCount', 0);
       
      });
  } 
  // else if (payload.searchText == '' && payload.filter ) {
  //   return await api.getProductGroupList(payload)
  //     .then(response=>{
        
  //        //commit('setProductGroupFilter', response.data.data.productGroups);
  //       commit('getProductGroupCount', response.data.data.productGroupsCount);
  //       return response.data.data;
  //     })
  //     .catch((err) => {
  //       console.log(err)
  //       commit('setLoadMoreMutations', false);
  //       commit('getProductGroupCount', 0);
  //       commit('getProductGroupListMutations', []);
  //     });
  // }
};

const getProductGroupTableListActions = async ({ commit }, payload) => {
  commit('setLoadMoreMutations', true);
  await api
    .getProductGroupList(payload)
    .then(res => {
      commit('getProductGroupListMutationsTable', res.data.data.productGroups);
      commit('getProductGroupCountTable', res.data.data.productGroupsCount);
    })
    .catch(() => {
      commit('getProductGroupCountTable', 0);
      commit('getProductGroupListMutationsTable', []);
    });
};

const getProductBusinessEntityAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getProductBusinessEntity(payload)
      .then(res => {
        context.commit('productBusinessEntityMutation', res.data.data);
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const createOrEditProductGroup = async ({ commit }, payload) => {
  commit('setLoadMoreMutations', true);
  commit('setLoading', true);
  return await api.createOrEditProductGroups(payload);
};

const getExtensionPropertyValueAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getExtensionProperties(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getValuePropertyAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getValueProperties(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getProductGroupsByIdAction = ({ commit }, payload) => {
  getProductGroupsById(payload)
    .then(res => {
      let data = res.data.data;
      commit('setProdGrpEditMutation', data);
    });
};
const getProductDetails = async ({ commit }, payload) => {
  getProductDetailsRes(payload)
    .then(res => {
      commit('getProductsGroupProductMutations', res.data.data.products);
      commit('getProductGroupProductCountMutations', res.data.data.totalCount);
    })
    .catch(() => {
      commit('getProductsGroupProductMutations', []);
      commit('getProductGroupProductCountMutations', 0);
    });
};

const checkForDuplicateProductGroupAction = ({ commit }, payload) => {
  commit('setLoading', true);
  return new Promise((resolve, reject) => {
    checkForDuplicateProductGroup(payload)
      .then(res => {
        commit('setLoading', false);
        commit('isDuplicateExistMutation', false);
        resolve(false);
      })
      .catch(() => {
        commit('setLoading', false);
        reject(true);
      });
  });

};
const deleteProductGroupActions = (context, payload) => {
  return new Promise((resolve, reject) => {
    deleteProductGroup(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export default {
  getValuePropertyAction,
  getProductGroupListActions,
  getProductGroupTableListActions,
  getProductBusinessEntityAction,
  getExtensionPropertyValueAction,
  createOrEditProductGroup,
  getProductGroupsByIdAction,
  checkForDuplicateProductGroupAction,
  getProductDetails,
  deleteProductGroupActions,
};
