const updateProductGroupStepperMutation = (state, payload) => {
  state.productGroupDetails.productGroupStepper = payload;
};

const updateCreatedByNameMutation = (state, payload) => {
  state.productGroupDetails.productGroupCreatedBy = payload;
};

const closePopupMutation = (state, payload) => {
  state.productGroupDetails.showCancelPopup = payload;
};

const previewPopupMutation = (state, payload) => {
  state.showPreviewPopup = payload;
};

const getProductGroupListMutations = (state, payload) => {
  state.getProductGroupListMutations = payload;
  state.loadmore = false;
};

const getProductGroupListMutationsTable = (state, payload) => {
  state.getProductGroupListMutationsTable = payload;
  state.loadmore = false;
};

const getProductGroupCount = (state, payload) => {
  state.getProductGroupCount = payload;
};

const getProductGroupCountTable = (state, payload) => {
  state.getProductGroupCountTable = payload;
};

const closeCreateEntityPopupMutation = (state, payload) => {
  state.productGroupDetails.showCreateEntityPopup = payload;
};

const productBusinessEntityMutation = (state, payload) => {
  state.productBusinessEntity = payload;
  state.productGroupEntityArray[0].productGroupBusinessEntity = payload;
};

const selectedProgramEntityMutation = (state, payload) => {
  state.programEntity = payload;
};

const clearproductGroupDetailsMutation = (state, payload) => {
  state.productGroupDetails = payload;
};

const updateproductGroupAttributeArrayMutation = (state, payload) => {
  state.productGroupEntityArray[
    payload.index
  ].productGroupAttibuteOperatorArray[0].productGroupAttributeArray =
    payload.attributeArray;
  state.productGroupEntityArray[
    payload.index
  ].productGroupAttibuteOperatorArray[0].selectedGroupAttribute =
    payload.attributeArray[0].extensionPropertyId;
};

const updateproductGroupAttibuteOperatorArrayMutation = (state, payload) => {
  state.productGroupEntityArray[
    payload.index
  ].productGroupAttibuteOperatorArray.push(payload);
};

const updateproductAttibuteOperatorArrayMutation = (state, payload) => {
  state.productGroupEntityArray[
    payload.index
  ].productGroupAttibuteOperatorArray = payload.attrArr;
};

const addMoreCriteriaMutation = (state, payload) => {
  state.productGroupEntityArray.push(payload);
};

const updateproductGroupDefaultConditionMutation = (state, payload) => {
  state.productGroupEntityArray[payload.index].productGroupDefaultCondition =
    payload.operator;
  if (payload.toggled === 'productGroupAndToggled') {
    state.productGroupEntityArray[payload.index].productGroupAndToggled = true;
    state.productGroupEntityArray[payload.index].productGroupOrToggled = false;
  }
  if (payload.toggled === 'productGroupOrToggled') {
    state.productGroupEntityArray[payload.index].productGroupAndToggled = false;
    state.productGroupEntityArray[payload.index].productGroupOrToggled = true;
  }
};

const updateproductGroupEntityArrayMutation = (state, payload) => {
  state.productGroupEntityArray = payload;
};

const updateproductGroupValueArrayMutation = (state, payload) => {
  state.productGroupEntityArray[
    payload.entityIndex
  ].productGroupAttibuteOperatorArray[
    payload.valueIndex
  ].productGroupValueArray = payload.valueArray;
};

const updateValueNameMutation = (state, payload) => {
  state.productGroupEntityArray[
    payload.entityIndex
  ].productGroupAttibuteOperatorArray[payload.valueIndex].valueName =
    payload.valueName;
};

const updateproductGroupValueMutation = (state, payload) => {
  state.productGroupEntityArray[
    payload
  ].productGroupAttibuteOperatorArray[0].productGroupValueArray = '';
};

const updateAttibuteOperatorArrayMutation = (state, payload) => {
  let arr = [];
  arr.push(payload.operator);
  state.productGroupEntityArray[
    payload.index
  ].productGroupAttibuteOperatorArray = arr;
};

const updateErrorsMutation = (state, payload) => {
  state.productGroupEntityArray[payload].entityErrorExists = false;
  state.productGroupEntityArray[
    payload
  ].productGroupAttibuteOperatorArray[0].attributeErrorExists = false;
  state.productGroupEntityArray[
    payload
  ].productGroupAttibuteOperatorArray[0].operatorErrorExists = false;
  state.productGroupEntityArray[
    payload
  ].productGroupAttibuteOperatorArray[0].valueErrorExists = false;
};

const updateOperatorErrorMutation = (state, payload) => {
  state.productGroupEntityArray[
    payload.entityIndex
  ].productGroupAttibuteOperatorArray[
    payload.valueIndex
  ].attributeErrorExists = false;
  state.productGroupEntityArray[
    payload.entityIndex
  ].productGroupAttibuteOperatorArray[
    payload.valueIndex
  ].operatorErrorExists = false;
  state.productGroupEntityArray[
    payload.entityIndex
  ].productGroupAttibuteOperatorArray[
    payload.valueIndex
  ].valueErrorExists = false;
};

const updateproductGroupOperatorArrayMutation = (state, payload) => {
  state.productGroupEntityArray[
    payload.entityIndex
  ].productGroupAttibuteOperatorArray[
    payload.valueIndex
  ].productGroupOperatorArray = payload.valueArray;
  state.productGroupEntityArray[
    payload.entityIndex
  ].productGroupAttibuteOperatorArray[
    payload.valueIndex
  ].selectedGroupOperator =
    state.productGroupEntityArray[
      payload.entityIndex
    ].productGroupAttibuteOperatorArray[
      payload.valueIndex
    ].productGroupOperatorArray[0].name;
};

const setLoadMoreMutations = (state, payload) => {
  state.loadmore = payload;
};

const isDuplicateExistMutation = (state, payload) => {
  state.isDuplicateExist = payload;
};

const setLoading = (state, payload) => {
  state.isLoading = payload;
};
const updateSuccess = (state, payload) => {
  state.isCreateSuccess = payload;
};
const clearProductGroupEntityArray = (state, payload) => {
  let productGroupBusinessEntity = JSON.parse(JSON.stringify(state.productGroupEntityArray[0].productGroupBusinessEntity));
  state.productGroupId = null;
  state.productGroupEntityArray = [];
  state.productGroupEntityArray = [
    {
      productGroupDefaultCondition: 'AND',
      productGroupAndToggled: true,
      productGroupOrToggle: false,
      productGroupBusinessEntity: productGroupBusinessEntity,
      selectedBusinessEntity: '',
      entityErrorExists: false,
      productGroupAttibuteOperatorArray: [
        {
          productGroupAttributeArray: [],
          selectedGroupAttribute: '',
          attributeErrorExists: false,
          productGroupOperatorArray: [],
          selectedGroupOperator: '',
          operatorErrorExists: false,
          productGroupValueArray: [],
          selectedGroupValue: '',
          valueErrorExists: false,
          valueName: ''
        }
      ]
    }
  ];
};

const setProductGroupId = (state, payload) => {
  state.productGroupId = payload;
};

const showDuplicateProductPopupMutation = (state, payload) => {
  state.productGroupDetails.showDuplicateProductPopup = payload;
};

const setProdGrpEditMutation = (state, payload) => {
  let programEntity = state.productBusinessEntity.filter(
    x => x.businessEntityId === payload.businessEntityId
  );
  state.programEntity = programEntity;
  if (state.viewName === 'edit') {
    state.productGroupId = payload.productGroupId;
  }
  state.productGroupDetails.productGroupName =
    state.viewName === 'clone' ? 'Copy of ' + payload.name : payload.name;
  state.productGroupDetails.productGroupDescription = payload.description;
  if (payload.criteria !== '') {
    state.productGroupEntityArray = JSON.parse(payload.criteria);
  }
};

const setViewName = (state, payload) => {
  state.viewName = payload;
};

const setProductGroupSearched = (state, payload) => {
  state.loadmore = false;
  if (!payload) {
    state.getProductGroupListMutations = [];
  } else {
    state.getProductGroupListMutations = payload;
  }
};
const setProductGroupFilter = (state, payload) => {
  state.loadmore = false;
  if (!payload) {
    state.getFilterResponse = [];
  } else {
    state.getFilterResponse = payload;
  }
};


const getProductsGroupProductMutations = (state, payload) => {
  state.getProductGroupProducts = payload;
};
const getProductGroupProductCountMutations = (state, payload) => {
  state.getProductGroupProductsCount = payload;
};
const previewPopupValuesMutations = (state, payload) => {
  state.previewPopupValues = payload;
};
const preiewProduct = (state, payload) => {
  state.preiewProduct = payload;
};
const deleteProductGroupIdMutation = (state, payload) => {
  state.deleteProductGroupObj = payload;
};
export default {
  updateproductGroupOperatorArrayMutation,
  updateOperatorErrorMutation,
  updateErrorsMutation,
  updateAttibuteOperatorArrayMutation,
  updateproductGroupValueMutation,
  updateValueNameMutation,
  updateproductGroupValueArrayMutation,
  updateproductGroupEntityArrayMutation,
  addMoreCriteriaMutation,
  updateproductGroupDefaultConditionMutation,
  updateproductAttibuteOperatorArrayMutation,
  updateproductGroupAttibuteOperatorArrayMutation,
  updateproductGroupAttributeArrayMutation,
  previewPopupMutation,
  updateProductGroupStepperMutation,
  updateCreatedByNameMutation,
  closePopupMutation,
  getProductGroupListMutations,
  getProductGroupListMutationsTable,
  getProductGroupCount,
  getProductGroupCountTable,
  closeCreateEntityPopupMutation,
  productBusinessEntityMutation,
  selectedProgramEntityMutation,
  clearproductGroupDetailsMutation,
  setLoadMoreMutations,
  isDuplicateExistMutation,
  setLoading,
  updateSuccess,
  clearProductGroupEntityArray,
  setProductGroupId,
  showDuplicateProductPopupMutation,
  setProdGrpEditMutation,
  setViewName,
  setProductGroupSearched,
  setProductGroupFilter,
  getProductsGroupProductMutations,
  getProductGroupProductCountMutations,
  previewPopupValuesMutations,
  preiewProduct,
  deleteProductGroupIdMutation,

};
