<template>
  <v-row class="flex-column" no-gutter>
    <brierley-table-module v-if="productGroupList.length > 0">
      <template v-slot:tablehead>
        <tr class="text-left">
          <th
            v-for="item in header"
            :key="item.name"
            @click="
              sortBy(item);
              arrowToggle();
            "
            class="text-left"
            :width="item.width"
          >
            {{ item.text }}

            <v-icon
              v-if="
                item.isIconRequired &&
                  (item.sort === 'asc' || item.sort === 'desc')
              "
              small
              v-bind:class="{
                down: item.sort === 'asc',
                up: item.sort === 'desc'
              }"
              class="arrow uparw primary-text"
              >arrow_drop_up</v-icon
            >
          </th>
        </tr>
      </template>
      <template v-slot:tablebody>
        <tr v-for="(item, i) in productGroupList" :key="i">
          <td>
            <h4
              class="primary-text font15 text-uppercase fbold elipsis-fullwidth"
            >
              {{ item.name }}
            </h4>
          </td>
          <td>{{ item.description }}</td>
          <td>{{ format_date(item.createdDate) }} {{ localTimeZone }}</td>
          <td>
            {{ item.programEntityName }}
          </td>
          <td>
            <brierley-status status="Active"></brierley-status>
            <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
              <v-col>
                <brierleyCardIcons>
                  <template v-slot:action-icons>
                    <span :title="$t('viewDetails')" class="active">
                      <v-icon>fe fe-eye</v-icon>
                      <span class="viewdetails-icon">{{
                        $t("viewDetails")
                      }}</span>
                    </span>
                    <span
                      @click="$router.push(`/loyaltyadmin/productGroupPage/${item.productGroupId}`)"
                      :title="$t('editLabel')" data-qe-id="edit_btn">
                      <v-icon id="viewuser_edit-icon" class="blackicon"
                        >fe fe-edit</v-icon
                      >
                      <span class="edit-icon" id="viewuser-edit">{{
                        $t("editLabel")
                      }}</span>
                    </span>
                    <span
                      @click="$router.push(`/loyaltyadmin/productGroupPage/${item.productGroupId}/clone`)"
                      :title="$t('cloneLabel')">
                      <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                        >feather-icon fe fe-copy</v-icon
                      >
                      <span class="clone-icon">
                        {{ $t("cloneLabel") }}
                      </span>
                    </span>
                    <span
                      :title="$t('deleteText')"
                      data-qe-id="delete_btn"
                      @click="openPopup(item)"
                    >
                      <v-icon class="blackicon cursor-p">fe fe-trash-2</v-icon>
                      <span class="delete-icon">{{ $t("deleteText") }}</span>
                    </span>
                  </template>
                </brierleyCardIcons>
              </v-col>
            </v-row>
          </td>
        </tr>
      </template>
    </brierley-table-module>
     <brierley-dialogbox
      :dialog="dialogPopup"
      @closeMe="dialogPopup = $event"
      :persistent="false"
    >
      <template v-slot:dialog-header>
        <v-card-title class="gen2-dialog-title text-uppercase">{{
          $t("deletepGroupText")
        }}</v-card-title>
      </template>
      <template v-slot:dialog-body-alert>
        <v-alert class="b-alert-error" type="error" :dismissible="false">
          <v-row class="alert-block align-center havebtn" no-gutters>
            <v-col class="alert-block__body">
              {{ $t("areYouSureText") }} {{ pGroupData.name }} ?
            </v-col>
          </v-row>
        </v-alert>
      </template>
      <!-- <template v-slot:dialog-body-description>
              <v-col>
                <p>Are you sure you want to publish this Promotion?</p>
              </v-col>
            </template> -->
      <template v-slot:dialog-footer>
        <v-btn text class="cancel no-ripple" @click="closePopup()">{{
          $t("noBtnText")
        }}</v-btn>
        <v-btn
          class="primaryctabtn"
          title="Default"
          @click="deleteProductGroup()"
          >{{ $t("yesBtnText") }}</v-btn
        >
      </template>
    </brierley-dialogbox>
  </v-row>
</template>

<script>
import { mapState } from 'vuex';
import {
  BrierleyCardIcons,
  BrierleyTableModule,
  BrierleyStatus,
  BrierleyDialogbox
} from '@brierley/SharedComponents';
import { productGroupListObj } from './../../../../i18n/language.js';
import moment from 'moment-timezone';
export default {
  data () {
    return {
      localTimeZone: '',
      sortKey: '',
      sortOrder: '',
      isToggled: false,
      changeColor: false,
      dialogPopup: false,
      pGroupData: null,
      header: [
        {
          name: 'Name',
          text: this.$t('productGroupNameLabel'),
          sort: '',
          isSortRequired: false,
          isIconRequired: true
        },
        {
          name: 'Description',
          text: this.$t('productGroupDescription'),
          sort: '',
          width: '',
          isSortRequired: false,
          isIconRequired: true
        },
        {
          name: 'CreatedDate',
          text: this.$t('createdOnText'),
          sort: '',
          width: '',
          isSortRequired: false,
          isIconRequired: true
        },
        {
          name: 'ProgramEntityName',
          text: this.$t('programEntityLabel'),
          sort: '',
          width: '200',
          isSortRequired: false,
          isIconRequired: true
        },
        {
          name: 'Status',
          text: this.$t('statusLabel'),
          sort: '',
          width: '180',
          isSortRequired: false,
          isIconRequired: true
        }
      ]
    };
  },
  computed: {
    ...mapState('productGroupModule', ['paramsTable']),
    ...mapState('productGroupModule', {
      // productGroupList: state => {
      //   return state.getProductGroupListMutationsTable;
      // },
      productGroupCount: state => {
        return state.getProductGroupCountTable;
      }
    }),
    productGroupList: {
      get () {
        return this.filterResult
          ? this.filterResult
          : this.productGroupListData;
      }
    }
  },
  props: {
    productGroupListData: {
      type: Array,
      defualt: []
    },
    filterResult: {
      type: Array,
      defualt: []
    },
  },
  components: {
    BrierleyCardIcons,
    BrierleyTableModule,
    BrierleyStatus,
    BrierleyDialogbox
  },
  i18n: productGroupListObj,
  methods: {
    sortBy: function (item) {
      let i = this.header.indexOf(item);
      for (let j = 0; j < this.header.length; j++) {
        if (j === i) {
          this.header[j].sort =
            this.header[j].sort === '' || this.header[j].sort === 'desc'
              ? 'asc'
              : 'desc';
        } else {
          this.header[j].sort = '';
        }
      }
      this.sortKey = this.header[i].name;
      this.sortOrder = this.header[i].sort;
      this.productGroups(true);
    },
    arrowToggle () {
      this.isToggled = !this.isToggled;
    },
    editNav (encryptionItem) {
      this.$store.dispatch(
        'batchImportModule/getEncryptionKey',
        encryptionItem
      );
      this.$router.push('/loyaltyadmin/editEncryption');
    },
    format_date (value) {
      if (value) {
        let localZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        this.localTimeZone = moment()
          .tz(localZone)
          .zoneAbbr();
        return moment(String(value)).format('MMM Do YYYY, h:mm A');
      }
    },

    productGroups (isSortApplied = false) {
      if (
        !isSortApplied &&
        this.productGroupCount > 0 &&
          this.productGroupCount === this.productGroupList.length
      )
        return false;

      if (this.sortOrder !== '' && this.sortKey !== '') {
        this.paramsTable.sortCol = this.sortKey;
        this.paramsTable.sortType = this.sortOrder === 'desc' ? true : false;
      }
      // this.loadmore = true;
      this.paramsTable.programId = localStorage.getItem('programId');
      if (this.paramsTable.programId !== null) {
        this.$store.dispatch(
          'productGroupModule/getProductGroupTableListActions',
          this.paramsTable
        );
      } else {
        this.$store.commit('productGroupModule/getProductGroupCountTable', 0);
      }
      if (
        this.paramsTable.pageNumber * this.paramsTable.pageSize <
        this.productGroupCount + 12
      ) {
        this.$store.dispatch(
          'productGroupModule/getProductGroupTableListActions',
          this.paramsTable
        );
      } else {
        // this.loadmore = false;
      }
    },
    openPopup (item) {
      this.pGroupData = item;
      this.dialogPopup = true;
    },
    closePopup () {
      this.dialogPopup = false;
    },
    deleteProductGroup () {
      this.dialogPopup = false;
      let params = {
        pName: this.pGroupData.name,
        pId: this.pGroupData.productGroupId,
      };
      this.$store
        .dispatch('productGroupModule/deleteProductGroupActions', params.pId)
        .then((res) => {
          if (res.status === 201 || res.status === 200) {
            this.$store.commit(
              'productGroupModule/showDeletePopUpDialogueMutation',
              false
            );
            let params = {
              programId: localStorage.getItem('programId'),
              pageNumber: 1,
              pageSize: 10,
              searchText: ''
            };
            this.$store.dispatch(
              'productGroupModule/getProductGroupListActions',
              params
            );
          }
        });
    },


  },
  mounted () {
    this.productGroups();
    if (this.paramsTable.sortCol !== '') {
      let headerIndex = this.header.findIndex(
        item => item.name === this.paramsTable.sortCol
      );
      if (headerIndex >= 0) {
        this.header[headerIndex].sort = this.paramsTable.sortType
          ? 'desc'
          : 'asc';
      }
    }
  },
};
</script>
