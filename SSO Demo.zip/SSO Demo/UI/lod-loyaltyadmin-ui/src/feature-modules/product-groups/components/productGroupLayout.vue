<template>
  <brierley-inner-view>
    <template v-slot:header>
      <v-flex class="toggle-menu-custom">
        <v-btn class="no-ripple iconbtn" text>
          <v-icon> fe-menu </v-icon>
        </v-btn>
      </v-flex>
      <span class="inner-head">
        {{ getViewTitle() }}
        {{
          programEntity.length > 0 ? programEntity[0].name.toUpperCase() : ""
        }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        data-qe-id="commmsgdetails_routerpush"
        text
        @click.native="openDialog()"
      >
        <v-icon>mdi-close</v-icon>{{ $t("closeTxt") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <product-popup v-if="productGroupDetails.showDuplicateProductPopup" />
      <cancel-popup
        v-if="productGroupDetails.showCancelPopup"
        @clickedYes="clickedYes"
      />
      <brierley-primary-stepper
        :currentStep="productGroupDetails.productGroupStepper"
        :stepperSize="3"
        class="mt-1"
      >
        <template v-slot:stepper-steps>
          <v-stepper-step step="1">{{ $t("basicInfo") }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="2">{{ $t("criteriaTxt") }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="3">{{ $t("reviewTxt") }}</v-stepper-step>
        </template>
        <template slot="stepper-content">
          <v-stepper-items>
            <v-stepper-content step="1">
              <Validation-Observer
                v-slot="{ handleSubmit }"
                ref="basicInfoForm"
              >
                <form id="basic_form" @submit.prevent="handleSubmit(onsubmit)">
                  <basic-info
                    v-if="productGroupDetails.productGroupStepper === 1"
                  />
                </form>
              </Validation-Observer>
            </v-stepper-content>
            <v-stepper-content step="2">
              <criteria-creation />
            </v-stepper-content>
            <v-stepper-content step="3">
              <product-review
                :success="success"
                :createSuccess="createSuccess"
              />
            </v-stepper-content>
          </v-stepper-items>
        </template>
      </brierley-primary-stepper>
    </template>
    <!-- <template v-slot:footer-previous>
      <v-btn
        id="user_btn_previous"
        text
        class="mr-5 cancel no-ripple"
        data-qe-id="commmsgdetails_gotoprevious"
        @click="goToPrevious()"
      >
        <v-icon class="bpr1">arrow_back</v-icon>previous
      </v-btn>
    </template> -->
    <template v-if="success === false || createSuccess === false" v-slot:footer>
      <v-btn
        id="user_btn_cancel"
        text
        class="cancel no-ripple bmt2 bmr5"
        data-qe-id="commmsgdetails_cancelmsg"
        @click="openDialog()"
        >{{ $t("cancelTxt") }}</v-btn
      >
      <v-btn
        form="basic_form"
        type="submit"
        class="primaryctabtn bmt2 bml2"
        v-if="productGroupDetails.productGroupStepper === 1"
        data-qe-id="commmsgdetails_nextdeliverybtn"
        :loading="isLoading"
        >{{ $t("nextCriteriaBtn") }}</v-btn
      >
      <v-btn
        class="primaryctabtn bmt2 bml2"
        v-if="productGroupDetails.productGroupStepper === 2"
        @click="goToReview()"
      >
        {{ $t("nxtReviewBtn") }}
      </v-btn>
      <v-btn
        form="basic_form"
        type="submit"
        class="primaryctabtn bmt2 bml2"
        :loading="isLoading"
        @click="checkDuplicateProdGro()"
        v-if="productGroupDetails.productGroupStepper === 3"
      >
        <template v-if="$route.name === 'ProductreGroupPageUpdate'">{{
          $t("udpateGroupBtn")
        }}</template>
        <template v-else>{{ $t("saveGroupBtn") }}</template>
      </v-btn>
    </template>
  </brierley-inner-view>
</template>
<script>
import { mapState } from 'vuex';
import BasicInfo from './child/basicInfo.vue';
import CriteriaCreation from './child/criteriaCreation.vue';
import ProductReview from './child/productReview';
import cancelPopup from './child/cancelPopUp.vue';
import ProductPopup from './child/ProductPopup.vue';
import { productGroupLayoutObj } from '../../../i18n/language.js';
import {
  BrierleyInnerView,
  BrierleyPrimaryStepper
} from '@brierley/SharedComponents';
export default {
  components: {
    BrierleyInnerView,
    BrierleyPrimaryStepper,
    BasicInfo,
    CriteriaCreation,
    ProductReview,
    cancelPopup,
    ProductPopup
  },
  computed: {
    ...mapState('productGroupModule', {
      productGroupDetails: state => {
        return state.productGroupDetails;
      },
      productGroupEntityArray: state => {
        return state.productGroupEntityArray;
      },
      isLoading: state => {
        return state.isLoading;
      },
      productGroupId: state => {
        return state.productGroupId;
      },
      isDuplicateExist: state => {
        return state.isDuplicateExist;
      },
      businessEntityId () {
        return this.programEntity[0].businessEntityId;
      },
      programEntity: state => {
        return state.programEntity;
      },
      productGroupName () {
        return (
          this.$t('newProductStoreGroup') +
          ' ' +
          this.programEntity[0].name.toUpperCase()
        );
      },
      createSuccess: state => {
        return state.isCreateSuccess;
      }
    })
  },
  i18n: productGroupLayoutObj,
  created () {
    this.productGroupId = null;
    this.$store.commit(
      'productGroupModule/updateProductGroupStepperMutation',
      1
    );
    this.$store.commit('productGroupModule/setProductGroupId', null);
    this.$store.commit('productGroupModule/closePopupMutation', false);
    this.$store.commit(
      'productGroupModule/showDuplicateProductPopupMutation',
      false
    );
    this.$store.commit('productGroupModule/previewPopupMutation', false);
    this.$store.commit('productGroupModule/clearproductGroupDetailsMutation', {
      productGroupName: '',
      productGroupDescription: '',
      productGroupCreatedBy: '',
      productGroupStepper: 1,
      showCancelPopup: false,
      showCreateEntityPopup: false,
      showDuplicateProductPopup: false
    });

    this.$store.commit(
      'productGroupModule/isDuplicateExistMutation',
      false
    );
    this.$store.commit(
      'productGroupModule/setProductGroupId',
      null
    );

    document.onkeypress = (evt) => {
      evt = evt ? evt : event ? event : null;
      let node = evt.target ? evt.target : evt.srcElement ? evt.srcElement : null;
      if (evt.keyCode === 13 && node.type === 'text')  {
        return false;
      }
    };
  },
  beforeDestroy () {
    document.onkeypress = '';
  },
  mounted () {
    this.$store.commit(
      'productGroupModule/updateCreatedByNameMutation',
      this.$root.GlobalStoreEventStore.state.intialUserProfileDetails
        .firstName +
        ' ' +
        this.$root.GlobalStoreEventStore.state.intialUserProfileDetails.lastName
    );
    if (
      this.$route.name === 'ProductreGroupPageUpdate' ||
      this.$route.name === 'ProductreGroupPageClone'
    ) {
      let programId = localStorage.getItem('programId');
      this.$store
        .dispatch(
          'productGroupModule/getProductBusinessEntityAction',
          programId
        )
        .then(() => {
          this.showPageTitle = true;
          this.$store.dispatch(
            'productGroupModule/getProductGroupsByIdAction',
            this.$route.params.id
          );
        });
      if (this.$route.name === 'ProductreGroupPageUpdate') {
        this.$store.commit('productGroupModule/setViewName', 'edit');
      } else {
        this.$store.commit('productGroupModule/setViewName', 'clone');
      }
    } else {
      this.$store.commit('productGroupModule/setViewName', 'create');
    }
  },
  data () {
    return {
      success: false,
      isEditCancelProccess: false
    };
  },
  methods: {
    goToReview (saveAndExit = false) {
      let errorCount = 0;
      let extensionArray = this.productGroupEntityArray.filter(obj => {
        if (
          obj.selectedBusinessEntity === null ||
          obj.selectedBusinessEntity === '' ||
          obj.selectedBusinessEntity === undefined
        ) {
          obj.entityErrorExists = true;
          errorCount++;
        } else {
          obj.entityErrorExists = false;
        }
        let attributeArray = obj.productGroupAttibuteOperatorArray.filter(
          item => {
            if (
              item.selectedGroupAttribute === null ||
              item.selectedGroupAttribute === '' ||
              item.selectedGroupAttribute === undefined
            ) {
              item.attributeErrorExists = true;
              errorCount++;
            } else {
              item.attributeErrorExists = false;
            }
            if (
              item.selectedGroupOperator === null ||
              item.selectedGroupOperator === '' ||
              item.selectedGroupOperator === undefined
            ) {
              item.operatorErrorExists = true;
              errorCount++;
            } else {
              item.operatorErrorExists = false;
            }
            if (
              item.selectedGroupValue === null ||
              item.selectedGroupValue === '' ||
              item.selectedGroupValue === undefined
            ) {
              item.valueErrorExists = true;
              errorCount++;
            } else {
              item.valueErrorExists = false;
            }
          }
        );
      });
      if (errorCount === 0) {
        if (saveAndExit) {
          this.isEditCancelProccess = true;
          this.createOrEditProductGroup();
        } else {
          this.$store.commit(
            'productGroupModule/updateProductGroupStepperMutation',
            this.productGroupDetails.productGroupStepper += 1
          );
        }
      }
    },
    onsubmit () {
      if (this.productGroupDetails.productGroupStepper === 1) {
        this.checkDuplicateProdGro();
      } else if (this.productGroupDetails.productGroupStepper === 2) {
        this.$store.commit(
          'productGroupModule/updateProductGroupStepperMutation',
          this.productGroupDetails.productGroupStepper += 1
        );
      }
    },
    openDialog () {
      if (
        this.productGroupDetails.productGroupStepper === 3 &&
        this.success === true
      ) {
        this.$router.push('/loyaltyadmin/productGroupList');
      } else {
        this.$store.commit('productGroupModule/closePopupMutation', true);
      }
    },
    createOrEditProductGroup (isFromStep3) {
      // Setting Request Body
      let payload = {
        name: this.productGroupDetails.productGroupName,
        criteria: '',
        description: this.productGroupDetails.productGroupDescription,
        businessEntityId: this.businessEntityId,
        programId: localStorage.getItem('programId')
      };
      if (this.productGroupId) {
        payload['productGroupId'] = this.productGroupId;
      }
      if (this.productGroupEntityArray) {
        let criteria = JSON.stringify(this.productGroupEntityArray);
        payload['criteria'] = criteria;
      }
      // Setting Request Body

      // Setting Button Loader true
      this.$store.commit('productGroupModule/setLoading', true);

      // Calling API
      this.$store
        .dispatch('productGroupModule/createOrEditProductGroup', payload)
        .then(res => {
          this.$store.commit('productGroupModule/setLoading', false);
          if (res.status === 201) {
            this.$store.commit(
              'productGroupModule/setProductGroupId',
              res.data.data.productGroupId
            );
          }

          if (isFromStep3) {
            this.$store.commit('productGroupModule/updateSuccess', true);
            this.success = true;
            this.createSuccess = true;
          } else {
            if (!this.isDuplicateExist && !this.isEditCancelProccess) {
              this.$store.commit(
                'productGroupModule/updateProductGroupStepperMutation',
                this.productGroupDetails.productGroupStepper += 1
              );
            }
            if (this.isEditCancelProccess) {
              this.$router.push('/loyaltyadmin/productGroupList');
            }
            this.isEditCancelProccess = false;
          }
        })
        .catch(err => {
          this.$store.commit('productGroupModule/setLoading', false);
          this.$store.commit(
            'productGroupModule/isDuplicateExistMutation',
            true
          );
          if (isFromStep3) {
            // Show Popup mutation
            this.$store.commit(
              'productGroupModule/showDuplicateProductPopupMutation',
              true
            );
          }
        });
    },
    checkDuplicateProdGro () {
      let payload = {
        productGroupName: this.productGroupDetails.productGroupName,
        productGroupId: this.productGroupId > 0 ? this.productGroupId : 0,
        programId: localStorage.getItem('programId')
      };
      this.$store.dispatch('productGroupModule/checkForDuplicateProductGroupAction', payload)
        .then(res => {
          if (res === false) {
            if (this.productGroupDetails.productGroupStepper === 3) {
              this.createOrEditProductGroup(true);
            }
            if (this.productGroupDetails.productGroupStepper === 1) {
              this.$store.commit(
                'productGroupModule/updateProductGroupStepperMutation',
                this.productGroupDetails.productGroupStepper += 1
              );
            }
          }
        })
        .catch((err) => {
          if (this.productGroupDetails.productGroupStepper === 1) {
            this.$store.commit(
              'productGroupModule/isDuplicateExistMutation',
              true
            );
          } else if (this.productGroupDetails.productGroupStepper === 3) {
            this.$store.commit(
              'productGroupModule/showDuplicateProductPopupMutation',
              true
            );
          }
        });
    },
    getViewTitle () {
      if (this.$route.name === 'ProductreGroupPageUpdate') {
        return this.$t('editProductGroup');
      } else if (this.$route.name === 'ProductreGroupPageClone') {
        return this.$t('cloneProductGroup');
      } else {
        return this.$t('newProductStoreGroup');
      }
    },
    clickedYes () {
      if (this.productGroupDetails.productGroupStepper === 1) {
        this.$refs.basicInfoForm.validate().then(res => {
          if (res) {
            this.isEditCancelProccess = true;
            this.createOrEditProductGroup();
          }
        });
      } else if (
        this.productGroupDetails.productGroupStepper === 2
          || this.productGroupDetails.productGroupStepper === 3
      ) {
        let payload = {
          productGroupName: this.productGroupDetails.productGroupName,
          productGroupId: this.productGroupId > 0 ? this.productGroupId : 0,
          programId: localStorage.getItem('programId')
        };
        this.$store.dispatch('productGroupModule/checkForDuplicateProductGroupAction', payload)
          .then(res => {
            if (this.productGroupDetails.productGroupStepper === 2) {
              this.goToReview(true);
            } else {
              this.isEditCancelProccess = true;
              this.createOrEditProductGroup();
            }
          })
          .catch((err) => {
            this.$store.commit(
              'productGroupModule/showDuplicateProductPopupMutation',
              true
            );
          });
      }
    }
  }
};
</script>
