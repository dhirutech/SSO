<template>
  <v-col>
    <v-row class="bmt4 bmb5 promotion-details" no-gutters>
      <v-col cols="11">
        <brierley-page-headings
          pageHeading="Product GROUP details"
          pageSubHeading="Product GROUP NAME"
        ></brierley-page-headings>
      </v-col>
      <v-col cols="1" class="ml-n3">
        <v-btn class="no-ripple btn-hover-none" href target="_blank" text large>
          <v-icon class="close-icon">close</v-icon>
          <strong class="font18">CLOSE</strong>
        </v-btn>
      </v-col>
      <v-col cols="12">
        <brierley-module-detail class="productGroupDetail no-gutters bmt4">
          <template v-slot:detail-side-links>
            <p class="label-text bmb0">Status</p>
            <brierleyStatus status="Active"></brierleyStatus>
            <v-divider class="dashed bmy5"></v-divider>
            <div class="quicklinks-title text-uppercase">
              <v-icon title="Title Here">insert_link</v-icon>Quick Links
            </div>
            <div class="quicklinks-text">
              <div>
                <router-link to="/">Edit Program</router-link>
              </div>
              <div>
                <router-link to="/">Make Inactive</router-link>
              </div>
              <div>
                <router-link to="/">Delete</router-link>
              </div>
            </div>
          </template>
          <template v-slot:detail-header>
            <h2 class="gen2-mreward-title">Product GROUP NAME</h2>
            <p><strong>Product Group Code:</strong> 9929292</p>
            <p class="bmb0">
              <strong>Product Group Description:</strong>
            </p>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
            </p>
            <v-divider class="dashed bmt4 bmb4"></v-divider>
            <v-row no-gutters>
              <v-col cols="6">
                <p><strong>No.of Products: </strong> 50490</p>
                <p><strong>Created By: </strong> Jakob Herwitz</p>
              </v-col>
              <v-col cols="6">
                <p><strong>Program Entity: </strong> PVH</p>
                <p>
                  <strong>Created Date: </strong> Apr 30th 2020 12:00 AM EST
                </p>
              </v-col>
            </v-row>
          </template>
        </brierley-module-detail>
      </v-col>
      <v-col cols="12">
        <v-divider class="dashed bmy5"></v-divider>
      </v-col>
      <v-col cols="12">
        <h3>Products criteria Details</h3>
        <v-divider class="bmb3 bmt3"></v-divider>
      </v-col>
      <v-col cols="12">
        <v-row no-gutters>
          <v-col cols="6">
            <v-row>
              <v-col>
                <strong>Entity</strong> <br />
                Gap
              </v-col>
              <v-col>
                <strong>Division</strong> <br />
                Men, Women
              </v-col>
              <v-col cols="12">
                <strong>Department</strong> <br />
                Denim Jeans, Women Tees
              </v-col>
            </v-row>
          </v-col>
          <v-col>
            <!--Charge-->
          </v-col>
        </v-row>
      </v-col>
      <v-col cols="12">
        <v-divider class="bmt6 bmb4"></v-divider>
        <h2 class="bmb1 fbold">products details</h2>
      </v-col>
      <v-col cols="12">
        <brierley-table-module>
          <template v-slot:tablehead>
            <tr class="text-left">
              <th
                v-for="item in header"
                :key="item.name"
                @click="
                  sortBy(item)
                  arrowToggle()
                "
                class="text-left"
                :width="item.width"
              >
                {{ item.text
                }}<v-icon
                  v-if="item.sort != ''"
                  small
                  v-bind:class="{
                    down: item.sort === 'asc',
                    up: item.sort === 'desc'
                  }"
                  class="arrow uparw"
                  >arrow_upward</v-icon
                >
              </th>
            </tr>
          </template>
          <template v-slot:tablebody>
            <tr v-for="item in campaigns" :key="item.name">
              <td>
                <!-- <v-row class="d-flex head-name" :title="item.name" no-gutters>
                  <v-col>
                    <v-icon title="bookmark">mdi-bookmark</v-icon>
                  </v-col>
                  <v-col class="elipsis-twoline">{{ item.name }}</v-col>
                </v-row> -->
                Denim Jeans
              </td>
              <td>{{ item.id }}</td>
              <td>
                <div :title="item.description" class="elipsis-description">
                  {{ item.description }}
                </div>
              </td>
              <td class="text-nowrap">{{ item.startdate }}</td>
              <td>
                <brierleyStatus status="Active"></brierleyStatus>
                <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
                  <v-col>
                    <brierleyCardIcons>
                      <template v-slot:action-icons>
                        <span>
                          <v-icon title="View Details">visibility</v-icon>
                          <span>View Details</span>
                        </span>
                        <span>
                          <v-icon title="View Details"
                            >mdi-pencil-box-outline</v-icon
                          >
                          <span>View Details</span>
                        </span>
                        <span>
                          <v-icon title="View Details">mdi-content-copy</v-icon>
                          <span>View Details</span>
                        </span>
                        <span>
                          <v-icon title="View Details">mdi-pause</v-icon>
                          <span>View Details</span>
                        </span>
                        <span>
                          <v-icon title="View Details">mdi-delete</v-icon>
                          <span>View Details</span>
                        </span>
                      </template>
                    </brierleyCardIcons>
                  </v-col>
                </v-row>
              </td>
            </tr>
          </template>
        </brierley-table-module>
      </v-col>
    </v-row>
  </v-col>
</template>
<script>
import {
  BrierleyPageHeadings,
  brierleyModuleDetail,
  BrierleyStatus,
  BrierleyTableModule,
  BrierleyCardIcons
} from '@brierley/SharedComponents';
export default {
  components: {
    BrierleyPageHeadings,
    brierleyModuleDetail,
    BrierleyStatus,
    BrierleyTableModule,
    BrierleyCardIcons
  },
  data () {
    return {
      sortKey: ['name'],
      sortOrder: ['asc'],
      header: [
        { name: 'name', text: 'Product Name', sort: 'asc' },
        { name: 'id', text: 'Product Code', sort: '' },
        {
          name: 'description',
          text: 'Product Description',
          sort: '',
          width: '215'
        },
        { name: 'startdate', text: 'Division/Department', sort: '' },
        { name: 'enddate', text: 'Status', sort: '', width: '180' }
      ],
      campaigns: [
        {
          name: 'Earn 2x points on sale items',
          id: '25OYPSUM2K19',
          description: 'Get $5 off on your next order- FREE SHIPPING...',
          startdate: 'Dec 31st 2019',
          enddate: 'Dec 31st 2020',
          lastdate: 'Feb 31st 2020',
          status: 'active'
        },
        {
          name: 'Deserunt mollit',
          id: '26OYPSUM2K19',
          description: 'The purpose of lorem ipsum',
          startdate: 'Aug 31st 2019',
          enddate: 'Dec 31st 2020',
          lastdate: 'Dec 31st 2020',
          status: 'active'
        },
        {
          name: 'Excepteur sint',
          id: '27OYPSUM2K19',
          description: 'looking ',
          startdate: 'Sep 31st 2019',
          enddate: 'Dec 31st 2020',
          lastdate: 'Jan 31st 2020',
          status: 'active'
        },
        {
          name: 'Laboris nisi',
          id: '28OYPSUM2K19',
          description: 'block of text (sentence, paragraph, page, etc.) ',
          startdate: 'Dec 31st 2019',
          enddate: 'Oct 31st 2020',
          lastdate: 'Mar 31st 2020',
          status: 'active'
        },
        {
          name: 'Voluptate velit',
          id: '29OYPSUM2K19',
          description: 'distract from the layout.',
          startdate: 'Nov 31st 2019',
          enddate: 'Dec 31st 2020',
          lastdate: 'Apr 31st 2020',
          status: 'active'
        },
        {
          name: 'Duis aute irure dolor',
          id: '30OYPSUM2K19',
          description: 'A practice not without',
          startdate: 'Dec 31st 2019',
          enddate: 'Dec 31st 2020',
          lastdate: 'May 31st 2020',
          status: 'active'
        },
        {
          name: 'Tempor incididunt',
          id: '31OYPSUM2K19',
          description: 'controversy, laying out pages',
          startdate: 'Dec 31st 2019',
          enddate: 'Dec 31st 2020',
          lastdate: 'Jun 31st 2020',
          status: 'active'
        },
        {
          name: 'Frozen Yogurt',
          id: '32OYPSUM2K19',
          description: 'filler text ',
          startdate: 'Dec 31st 2019',
          enddate: 'Dec 31st 2020',
          lastdate: 'Jul 31st 2020',
          status: 'active'
        },

        {
          name: 'Dollar sit',
          id: '33OYPSUM2K19',
          description: 'can be very useful ',
          startdate: 'Dec 31st 2019',
          enddate: 'jan 31st 2020',
          lastdate: 'Aug 31st 2020',
          status: 'active'
        },
        {
          name: 'Eiusmod tempor',
          id: '34OYPSUM2K19',
          description: 'when the focus.',
          startdate: 'Feb 31st 2019',
          enddate: 'Dec 31st 2020',
          lastdate: 'Nov 31st 2020',
          status: 'active'
        },
        {
          name: 'Frozen',
          id: '35OYPSUM2K19',
          description: 'meant to be on design',
          startdate: 'Dec 31st 2019',
          enddate: 'Dec 31st 2020',
          lastdate: 'Jan 31st 2020',
          status: 'active'
        },
        {
          name: 'Yogurt',
          id: '36OYPSUM2K19',
          description: 'not content.',
          startdate: 'Apr 31st 2019',
          enddate: 'Feb 31st 2020',
          lastdate: 'Mar 31st 2020',
          status: 'active'
        }
      ]
    };
  }
};
</script>

<style lang="scss" scoped>
.close-icon {
  font-size: 35px !important;
}
</style>
<style lang="scss">
.productGroupDetail {
  .detail-image,
  .bpb3.horizontal-line {
    display: none !important;
  }
  .mreward-side-quicklinks {
    margin-top: 0;
  }
}
</style>
