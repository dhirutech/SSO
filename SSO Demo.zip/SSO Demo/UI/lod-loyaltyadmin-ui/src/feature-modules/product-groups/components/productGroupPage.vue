<template>
  <ProductGroupLayout />
</template>
<script>
import ProductGroupLayout from './productGroupLayout.vue';
export default {
  components: {
    ProductGroupLayout
  }
};
</script>
