<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox :dialog="true" persistent @closeMe="closePopup()">
        <template v-slot:dialog-header>
          <v-card-title
            class="gen2-dialog-title text-uppercase"
            data-qe-id="org_addEntity_cardTitle"
            >{{ $t("pgmEntity") }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <p class="line-height-normal">
              {{ $t("bodyDes") }}
            </p>
            <v-row
              no-gutters
              class="flex-column gen2-forms form-light-bg min-height-240 overflow-y-hidden"
            >
              <v-col class="bmt2" sm="4" xs="12" md="6">
                <p class="label-text line-height-normal">
                  {{ $t("pgmEntity") }}
                </p>
                <v-select
                  :items="productBusinessEntity"
                  item-text="name"
                  item-value="businessEntityId"
                  v-model="select"
                  :disabled="disableBtn"
                  filled
                  attach
                  offset-y
                  @change="
                    selectedProgram => selectBusinessEntity(selectedProgram)
                  "
                  class="gen2select gen2select__dark mini-list"
                  :label="alertMessage"
                  append-icon="expand_more"
                ></v-select>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            text
            class="cancel no-ripple cursor-p btn-hover-none"
            @click="closeDeleteEntityPopupWhenClickNo()"
            >{{ $t("cancelTxt") }}</v-btn
          >
          <v-btn
            class="primaryctabtn text-uppercase cursor-p"
            @click="navigateToBasicInfo()"
            :disabled="select !== '' ? false : true"
            >{{ $t("continueTxt") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { createProductEntityObj } from '../../../../i18n/language.js';
export default {
  data () {
    return {
      select: '',
      disableBtn: false
    };
  },
  computed: {
    ...mapState(
      'productGroupModule',
      {
        productBusinessEntity: state => {
          return state.productBusinessEntity;
        },
        alertMessage () {
          if (this.productBusinessEntity.length === 0) {
            this.disableBtn = true;
            return this.$t('noPgmEntity');
          } else {
            this.disableBtn = false;
            return this.$t('selectEntity');
          }
        }
      },

      ['productGroupDetails']
    )
  },
  i18n: createProductEntityObj,
  components: {
    BrierleyDialogbox
  },
  methods: {
    selectBusinessEntity (val) {
      let programEntity = this.productBusinessEntity.filter(
        x => x.businessEntityId === val
      );
      this.$store.commit(
        'productGroupModule/selectedProgramEntityMutation',
        programEntity
      );
    },
    closePopup () {
      this.$store.commit(
        'productGroupModule/closeCreateEntityPopupMutation',
        false
      );
    },
    navigateToBasicInfo () {
      this.$router.push('/loyaltyadmin/productGroupPage');
      if (this.$route.name === 'ProductreGroupPage') {
        this.$store.commit('productGroupModule/updateSuccess', false);
        this.$store.commit(
          'productGroupModule/updateProductGroupStepperMutation',
          1
        );
        this.$store.commit(
          'productGroupModule/clearproductGroupDetailsMutation',
          {
            productGroupName: '',
            productGroupDescription: '',
            productGroupCreatedBy: '',
            productGroupStepper: 1,
            showCancelPopup: false,
            showCreateEntityPopup: false
          }
        );
        this.$store.commit('productGroupModule/clearProductGroupEntityArray', {
          selectedBusinessEntity: '',
          selectedGroupAttribute: '',
          selectedGroupOperator: '',
          selectedGroupValue: ''
        });
      }
    },
    closeDeleteEntityPopupWhenClickNo () {
      this.closePopup();
    }
  }
};
</script>
