<template>
  <v-col>
    <v-row class="flex-column" no-gutters>
      <v-col class="loyalty-users-common">
        <v-row class="flex-column bpt4" no-gutters>
          <v-col v-if="productGroupFilterList && productGroupFilterList.length">
            <brierley-page-headings
              pageSubHeading="PRODUCT GROUPS"
              :pageSecondaryHeading="
                `(${productGroupCount} ${$t('productGroups')})`
              "
            ></brierley-page-headings>
          </v-col>
        </v-row>
      </v-col>
      <v-col>
        <v-row class="gen2-search-filter bpt3" no-gutters>
          <v-col class="text-left" cols="5">
            <v-text-field
              autocomplete="off"
              class="search-field bmb0"
              :label="$t('searchProductGroup')"
              prepend-inner-icon="mdi-magnify"
              v-model="searchQuery"
              @input="isTyping = true"
            ></v-text-field>
          </v-col>
          <v-col cols="7" class="text-right align-self-center">
            <brierley-filter
              v-on:click.native="isHidden = !isHidden"
            ></brierley-filter>
            <div class="bmr1 d-inline-block">
              <brierley-view-option
                :viewList="cardlist"
                @viewChanged="viewType = $event"
              ></brierley-view-option>
            </div>
            <v-btn text class="primaryctabtn no-ripple" @click="openDialog()">{{
              $t("createProductGroup")
            }}</v-btn>
          </v-col>
          <v-col cols="12" class="filter-dropdown bmt1"> </v-col>
        </v-row>
      </v-col>
      <v-col cols="12" class="filter-dropdown">
        <brierley-filter-result v-if="isHidden">
          <template v-slot:body-content>
            <v-row no-gutters class="bmb6">
              <v-col cols="3" class="bmr6">
                <h3>{{ $t("datRange") }}</h3>
                <v-row class="main-wrapper__header">
                  <v-col cols="12" class="todate">
                    <v-menu
                      id="prom_promotions_startDatePopup"
                      ref="fromDateMenu"
                      v-model="fromDateMenu"
                      :close-on-content-click="false"
                      :return-value.sync="searchRequest.fromDate"
                      transition="scale-transition"
                      offset-y
                      min-width="290px"
                    >
                      <template v-slot:activator="{ on }">
                        <v-text-field
                          id="prom_promotioins_filterStartRangeFormated"
                          readonly
                          v-model="searchRequest.fromDate"
                          :label="$t('fromlabelTxt')"
                          append-icon="mdi-calendar-range"
                          v-on="on"
                          class="darktxtfield__light"
                          filled
                        ></v-text-field>
                      </template>
                      <v-date-picker
                        id="prom_promotions_filterStartRange"
                        v-model="searchRequest.fromDate"
                        no-title
                        scrollable
                      >
                        <v-spacer></v-spacer>
                        <v-btn
                          id="prom_promotions_btnCancel"
                          text
                          color="primary"
                          @click="fromDateMenu = false"
                          >{{ $t("cancelText") }}</v-btn
                        >
                        <v-btn
                          text
                          id="prom_promotions_btnOk"
                          color="primary"
                          @click="fromDateSubmit()"
                          >{{ $t("okText") }}</v-btn
                        >
                      </v-date-picker>
                    </v-menu>
                  </v-col>
                  <v-col cols="12" class="todate">
                    <v-menu
                      id="prom_promotions_endDatePopup"
                      ref="toDateMenu"
                      v-model="toDateMenu"
                      :close-on-content-click="false"
                      :return-value.sync="searchRequest.toDate"
                      transition="scale-transition"
                      offset-y
                      min-width="290px"
                    >
                      <template v-slot:activator="{ on }">
                        <v-text-field
                          id="prom_promotioins_filterEndRangeFormated"
                          readonly
                          v-model="searchRequest.toDate"
                          :label="$t('tolabelTxt')"
                          append-icon="mdi-calendar-range"
                          v-on="on"
                          class="darktxtfield__light"
                          filled
                        ></v-text-field>
                      </template>
                      <v-date-picker
                        id="prom_promotioins_filterEndRange"
                        v-model="searchRequest.toDate"
                        no-title
                        scrollable
                      >
                        <v-spacer></v-spacer>
                        <v-btn
                          text
                          color="primary"
                          @click="toDateMenu = false"
                          >{{ $t("cancelText") }}</v-btn
                        >
                        <v-btn
                          text
                          id="prom_promotions_endDateSave"
                          color="primary"
                          @click="toDateSubmit()"
                          >{{ $t("okText") }}</v-btn
                        >
                      </v-date-picker>
                    </v-menu>
                  </v-col>
                  <span class="custom-error-msg" v-if="dateErrorMsg">{{
                    $t("dateValidationErrMsg")
                  }}</span>
                </v-row>
              </v-col>
              <v-col cols="3" class="bml6">
                <h3>by program entity</h3>
                <v-row no-gutters>
                  <v-col cols="12 pt-0">
                    <v-select
                      :items="productBusinessEntity"
                      item-text="name"
                      item-value="businessEntityId"
                      v-model="searchRequest.entityId"
                      :label="$t('selectProgramlabelTxt')"
                      filled
                      attach
                      offset-y
                      class="gen2select gen2select__light"
                      append-icon="expand_more"
                    ></v-select>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
          </template>
          <template v-slot:footer>
            <v-btn text class="mr-5 cancel bmt3" @click="resetFilter()">
              Reset
            </v-btn>
            <v-btn
              depressed
              class="next bmt3 primaryctabtn"
              id="prom_promotions_btnFilterPromotion"
              @click="submitProductGroupFilter()"
              >{{ $t("applyFilterBtn") }}</v-btn
            >
          </template>
        </brierley-filter-result>
      </v-col>
      <v-col v-if="productGroupDetails.showCreateEntityPopup">
        <create-entity-popup />
      </v-col>
      <v-col v-if="viewType == 'card_view'">
        <productgroup-card-view
          :productGroupListData="productGroupFilterList"
          :filterResult="filterRespone"
        />
      </v-col>
      <v-col v-if="viewType == 'grid_view'">
        <productgroup-grid-view
          :productGroupListData="productGroupFilterList"
          :filterResult="filterRespone"
        />
      </v-col>
      <v-col v-if="viewType == 'table_view'">
        <productgroup-table-view
          ref="tableView"
          :productGroupListData="productGroupFilterList"
          :filterResult="filterRespone"
        />
      </v-col>
      <v-col>
        <brierley-no-result
          v-if="productGroupFilterList.length === 0"
          :noRecordFoundHeader="$t('noRecordFoundHeader')"
          :noResultMessage="$t('noResultMessage')"
        ></brierley-no-result>
      </v-col>
      <v-col align="center" class="bpb4">
        <loadmore
          loadingText="loading"
          v-if="loadmore"
          id="viewuser_loadmore"
          class="margin-auto"
        />
      </v-col>
    </v-row>
  </v-col>
</template>
<script>
import {
  BrierleyFilter,
  BrierleyViewOption,
  BrierleyPageHeadings,
  BrierleyNoResult,
  BrierleyFilterResult,
  Loadmore
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import ProductgroupCardView from '../components/child/ProductgroupCardView';
import ProductgroupGridView from '../components/child/ProductgroupGridView';
import ProductgroupTableView from '../components/child/ProductgroupTableView';
import { productGroupListObj } from '../../../i18n/language.js';
import createEntityPopup from '../components/child/createEntityPopup';
import _ from 'lodash';
export default {
  components: {
    BrierleyFilter,
    BrierleyViewOption,
    ProductgroupCardView,
    ProductgroupGridView,
    ProductgroupTableView,
    BrierleyPageHeadings,
    BrierleyNoResult,
    createEntityPopup,
    BrierleyFilterResult,
    Loadmore
  },
  data () {
    return {
      viewType: 'grid_view',
      businessEntities: '',
      businessEntity: '',
      isHidden: false,
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('gridViewText')
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('tableViewText')
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('cardViewText')
        }
      ],
      dateErrorMsg: false,
      fromDateMenu: false,
      toDateMenu: false,
      isTyping: false,
      searchRequest: {
        searchText: null,
        pageNumber: 1,
        pageSize: 10,
        fromDate: null,
        toDate: null,
        entityId: 0,
        select: ''
      },
      filterRespone: null,
      searchQuery: ''
    };
  },
  mounted () {
    this.productGroups();
    window.addEventListener('scroll', this.onScroll);
  },
  i18n: productGroupListObj,
  computed: {
    ...mapState('productGroupModule', {
      productGroupDetails: state => {
        return state.productGroupDetails;
      },
      productBusinessEntity: state => {
        return state.productBusinessEntity;
      }
      // productTableList: state => {
      //   return state.getProductGroupListMutationsTable;
      // },
    }),
    ...mapState('productGroupModule', ['params', 'paramsTable', 'loadmore']),
    ...mapState('productGroupModule', {
      productGroupList: state => {
        return state.getProductGroupListMutations;
      },
      productGroupCount: state => {
        return state.getProductGroupCount;
      }
    }),
    productGroupFilterList: {
      get () {
        // if (this.viewType === 'table_view') {
        //   return this.productTableList;
        // } else {
        //   return this.filterRespone
        //     ? this.filterRespone
        //     : this.productGroupList;
        // }
        return this.filterRespone ? this.filterRespone : this.productGroupList;
      }
    }
  },
  watch: {
    '$root.GlobalStoreEventStore.state.programList' () {
      this.params.pageNumber = 1;
      this.params.pageSize = 10;
      this.paramsTable.pageNumber = 1;
      this.paramsTable.pageSize = 10;
      this.$store.commit('productGroupModule/getProductGroupListMutations', []);
      this.$store.commit(
        'productGroupModule/getProductGroupListMutationsTable',
        []
      );
      this.productGroups(true);
    },
    searchQuery: _.debounce(function () {
      this.isTyping = false; // eslint-disable-line no-invalid-this
      this.searchRequest.PageNumber = 1; // eslint-disable-line no-invalid-this
    }, 1000),
    isTyping: function (value) {
      if (this.searchQuery === '') {
        this.searchRequest.searchText = '';
      }
      if (!value) {
        this.searchProductGroup();
      }
    }
  },
  methods: {
    openDialog () {
      let programId = localStorage.getItem('programId');
      this.$store.dispatch(
        'productGroupModule/getProductBusinessEntityAction',
        programId
      );
      this.$store.commit(
        'productGroupModule/closeCreateEntityPopupMutation',
        true
      );
      this.$store.commit('productGroupModule/setProductGroupId', null);
    },
    productGroups (loadAll = false) {
      if (
        loadAll ||
        this.viewType === 'card_view' ||
        this.viewType === 'grid_view' ||
        this.viewType === 'table_view'
      ) {
        this.params.programId = localStorage.getItem('programId');
        if (this.params.programId !== null) {
          this.$store.dispatch(
            'productGroupModule/getProductGroupListActions',
            this.params
          );
        } else {
          this.$store.commit('productGroupModule/getProductGroupCount', 0);
        }
        if (
          this.params.pageNumber * this.params.pageSize <
          this.productGroupCount + 12
        ) {
          this.$store.dispatch(
            'productGroupModule/getProductGroupListActions',
            this.params
          )
          .then(res=>{
            this.$store.commit(
                'productGroupModule/getProductGroupListMutations',
                res.productGroups
              )
          })
        }
      }
      // if (loadAll || this.viewType === 'table_view') {
      //   {
      //     this.$store.dispatch(
      //       'productGroupModule/getProductGroupTableListActions',
      //       this.params
      //     );
      //   }
      // }
    },
    onScroll () {
      window.onscroll = () => {
        if (this.loadmore === true) {
          return false;
        }
        if (
          this.viewType === 'card_view' ||
          this.viewType === 'grid_view' ||
          this.viewType === 'table_view'
        ) {
          if (this.productGroupCount === this.productGroupFilterList.length){
            return false;
            }
        }
        if (
          document.documentElement.scrollHeight ===
          document.documentElement.scrollTop + window.innerHeight
        ) {
          if (this.viewType === 'table_view') {
            this.params.pageSize += 10;
            // this.paramsTable.pageSize += 10;
          } else {
            this.params.pageSize += 10;
          }
          window.scrollTo(0, document.documentElement.scrollTop - 120);
          if (this.searchQuery === ' ' && !this.params.filter) {
               this.productGroups();
          } else if (this.searchQuery !== ' ' && !this.params.filter) { 
            this.searchProductGroup(true);
          } else if (this.params.filter) {
            this.submitProductGroupFilter(true);
          }
          
        }
      };
    },
    searchProductGroup (loadAll = false) {
      this.params.searchText = this.searchQuery;
      if (!loadAll) {
        this.params.pageSize = 10;
        this.params.pageNumber = 1;
      }
      if (
        loadAll ||
        this.viewType === 'card_view' ||
        this.viewType === 'grid_view' ||
        this.viewType === 'table_view'
      ) {
        this.$store
          .dispatch(
            'productGroupModule/getProductGroupListActions',
            this.params
          )
          .then(res=>{
            this.$store.commit(
                'productGroupModule/getProductGroupListMutations',
                res.productGroups
              )
            if(res){
              if (res.productGroups.length > 0) {
                this.filterRespone = res.productGroups;
                this.isHidden = false;
              } else {
                this.filterRespone = [];
                this.isHidden = false;
              }
            }
            
          })
          
          .catch(error => {
            if (error.response.status === 404) {
              this.isHidden = false;
              this.filterRespone = [];
            }
          });
      }
    },
    fromDateSubmit () {
      if (this.searchRequest.fromDate) {
        let fromDate = this.searchRequest.fromDate;
        this.$refs.fromDateMenu.save(fromDate);
      }
      if (this.searchRequest.toDate) {
        let toDate = this.searchRequest.toDate;
        if (this.searchRequest.fromDate <= toDate) {
          let toDate = this.searchRequest.toDate;
          this.$refs.toDateMenu.save(toDate);
          this.dateErrorMsg = false;
        } else {
          if (this.searchRequest.fromDate > toDate) {
            let toDate = this.searchRequest.toDate;
            this.$refs.toDateMenu.save(toDate);
            this.dateErrorMsg = true;
          }
        }
      }
    },
    toDateSubmit () {
      if (this.searchRequest.toDate) {
        let toDate = this.searchRequest.toDate;
        this.$refs.toDateMenu.save(toDate);
      }
      if (this.searchRequest.fromDate) {
        let fromDate = this.searchRequest.fromDate;
        if (this.searchRequest.toDate < fromDate) {
          let toDate = this.searchRequest.toDate;
          this.$refs.toDateMenu.save(toDate);
          this.dateErrorMsg = true;
        } else {
          if (this.searchRequest.toDate >= fromDate) {
            let toDate = this.searchRequest.toDate;
            this.$refs.toDateMenu.save(toDate);
            this.dateErrorMsg = false;
          }
        }
      }
    },
    resetFilter () {
      this.searchRequest.searchText = '';
      this.searchRequest.fromDate = null;
      this.searchRequest.toDate = null;
      this.searchRequest.entityId = 0;
      this.dateErrorMsg = false;
    },
    submitProductGroupFilter (loadAll = false) {
      if (this.dateErrorMsg) {
        return true;
      }
      let programId = this.params.programId;
      this.params.searchText = this.searchQuery;
      this.params.fromDate = this.searchRequest.fromDate
        ? this.searchRequest.fromDate
        : '';
      this.params.toDate = this.searchRequest.toDate
        ? this.searchRequest.toDate
        : '';
      this.params.programEntityId = this.searchRequest.entityId;
      this.params.filter = true;
      if (!loadAll) {
        this.params.pageSize = 10;
        this.params.pageNumber = 1;
      }
      if (
        loadAll ||
        this.viewType === 'card_view' ||
        this.viewType === 'grid_view' ||
        this.viewType === 'table_view'
      ) {
        this.$store
          .dispatch(
            'productGroupModule/getProductGroupListActions',
            this.params
          )
          .then((res) => {
            if (res) {
              if (res.productGroups.length > 0) {
                this.filterRespone = res.productGroups;
                this.isHidden = false;
              } else {
                this.filterRespone = [];
                this.isHidden = false;
              }
            }
            else{
              this.filterRespone = [];
                this.isHidden = false;
            }
          })
          .catch(error => {
            if (error.response.status === 404) {
              this.isHidden = false;
              this.filterRespone = [];
            }
          });
      }
    }
  },
  created () {
    this.$store.commit(
      'productGroupModule/closeCreateEntityPopupMutation',
      false
    );

    let programId = localStorage.getItem('programId');
    this.$store.dispatch(
      'productGroupModule/getProductBusinessEntityAction',
      programId
    );
    this.$store.commit('productGroupModule/isDuplicateExistMutation', false);
    this.$store.commit('productGroupModule/setProductGroupId', null);
  }
};
</script>
