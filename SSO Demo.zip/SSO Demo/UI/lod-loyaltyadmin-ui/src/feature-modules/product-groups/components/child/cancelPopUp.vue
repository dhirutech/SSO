<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closePopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ ($route.name !== 'ProductreGroupPageUpdate') ? $t("cardTitle") : $t("editCardTitle") }}
          </v-card-title>
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <brierley-alert
                  alertType="error"
                  icon="warning"
                  :alertBody="($route.name !== 'ProductreGroupPageUpdate') ? $t('alertMsg') : $t('editAlertMsg') "
                ></brierley-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="org_btn_cancelDeleteDialog"
            data-qe-id="communicationManagement_no_btn"
            text
            class="cancel no-ripple"
            @click="closeDeleteEntityPopupWhenClickNo()"
            >{{ $t("noBtnText") }}</v-btn
          >
          <v-btn
            id="org_btn_deleteDeleteDialog"
            class="primaryctabtn text-uppercase"
            data-qe-id="communicationManagement_yes_btn"
            title
            @click="navigateToList()"
            >{{ $t("yesBtnText") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox, brierleyAlert } from '@brierley/SharedComponents';
import { productCancelPopUpObject } from '../../../../i18n/language.js';
export default {
  data () {
    return {
      dialog: false
    };
  },
  components: {
    BrierleyDialogbox,
    brierleyAlert
  },
  i18n: productCancelPopUpObject,
  methods: {
    closePopup () {
      this.$store.commit('productGroupModule/closePopupMutation', false);
    },
    navigateToList () {
      if (this.$route.name === 'ProductreGroupPageUpdate') {
        this.$store.commit('productGroupModule/closePopupMutation', false);
        this.$emit('clickedYes', true);
      } else {
        this.$router.push('/loyaltyadmin/productGroupList');
      }
    },
    closeDeleteEntityPopupWhenClickNo () {
      if (this.$route.name === 'ProductreGroupPageUpdate') {
        this.$router.push('/loyaltyadmin/productGroupList');
      } else {
        this.closePopup();
      }
    }
  }
};
</script>
