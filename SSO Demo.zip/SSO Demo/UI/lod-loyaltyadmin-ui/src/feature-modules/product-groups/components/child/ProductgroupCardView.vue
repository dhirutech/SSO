<template>
  <v-row>
    <v-col
      md="6"
      sm="12"
      xs="12"
     v-for="(item, i) in productGroupList"
      :key="i"
    >
      <brierley-card>
        <template v-slot:header>
          <h2>
            <!-- <v-icon class="mtn-6 primary-text icon-btn-hover-none"
              >mdi-bookmark</v-icon
            > -->
           {{ item.name }}
          </h2>
        </template>

        <template v-slot:footer>
          <!-- <v-col sm="7">
            <p>
              <strong> {{ $t('storeGroupCreatedBy') }}: </strong><br />
              <span>{{ item.authorFullName }}</span>
              <strong>{{ $t("ProductGroupCode") }}: </strong>
              <span>3294058</span>
            </p>
          </v-col>
          <v-col sm="5">
            <p>
              <strong> {{ $t("productsCount") }}: </strong><br />
              <span>3500</span>
            </p>
          </v-col> -->
          <v-col sm="12" class="bmb3 minheight52">
            <p>
              <strong> {{ $t('productGroupDescription') }}:</strong> <br />
              {{ item.description }}
            </p>
          </v-col>
          <v-col sm="7" class="bpr2">
            <p>
              <!-- <strong> {{ $t('storeGroupCreatedBy') }}: </strong><br />
              <span>{{ item.authorFullName }}</span> -->
              <strong>{{ $t('programEntityLabel') }}: </strong>
              <span class="word-break">{{ item.programEntityName }}</span>
            </p>
          </v-col>
          <v-col sm="5">
            <p>
              <strong> {{ $t('createdOnText') }}: </strong><br />
              <span
                >{{ format_date(item.createdDate) }} {{ localTimeZone }}</span
              >
            </p>
          </v-col>
          <v-col sm="7" class="bmy3">
            <!-- <p>
              <strong>{{ $t('programEntityLabel') }}: </strong>
              <span>{{ item.programEntityName }}</span>
            </p> -->
          </v-col>
          <v-col sm="5" class="bmy3">
            <p>
              <strong> {{ $t('statusLabel') }}: </strong><br />
            </p>
            <brierley-status
              v-if="item.status === true"
              status="Active"
            ></brierley-status>
          </v-col>
          <v-col sm="12">
            <brierleyCardIcons>
              <template v-slot:action-icons>
                <span :title="$t('viewDetails')" class="active">
                  <v-icon>fe fe-eye</v-icon>
                  <span class="viewdetails-icon">{{ $t('viewDetails') }}</span>
                </span>
                <span
                  @click="$router.push(`/loyaltyadmin/productGroupPage/${item.productGroupId}`)"
                  :title="$t('editLabel')" data-qe-id="edit_btn">
                  <v-icon id="viewuser_edit-icon" class="blackicon"
                    >fe fe-edit
                  </v-icon>
                  <span class="edit-icon" id="viewuser-edit">{{
                    $t('editLabel')
                  }}</span>
                </span>
                <span
                  @click="$router.push(`/loyaltyadmin/productGroupPage/${item.productGroupId}/clone`)"
                  :title="$t('cloneLabel')">
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >feather-icon fe fe-copy</v-icon
                  >
                  <span class="clone-icon">
                    {{ $t('cloneLabel') }}
                  </span>
                </span>
                <span :title="$t('deleteText')"
                data-qe-id="delete_btn"
                @click="openPopup(item)">
                  <v-icon class="blackicon cursor-p">fe fe-trash-2</v-icon>
                  <span class="delete-icon"> {{ $t('deleteText') }}</span>
                </span>
              </template>
            </brierleyCardIcons>
          </v-col>
        </template>
      </brierley-card>
    </v-col>
    <brierley-dialogbox
      :dialog="dialogPopup"
      @closeMe="dialogPopup = $event"
      :persistent="false"
    >
      <template v-slot:dialog-header>
        <v-card-title class="gen2-dialog-title text-uppercase">{{
          $t("deletepGroupText")
        }}</v-card-title>
      </template>
      <template v-slot:dialog-body-alert>
        <v-alert class="b-alert-error" type="error" :dismissible="false">
          <v-row class="alert-block align-center havebtn" no-gutters>
            <v-col class="alert-block__body">
              {{ $t("areYouSureText") }} {{ pGroupData.name }} ?
            </v-col>
          </v-row>
        </v-alert>
      </template>
      <!-- <template v-slot:dialog-body-description>
              <v-col>
                <p>Are you sure you want to publish this Promotion?</p>
              </v-col>
            </template> -->
      <template v-slot:dialog-footer>
        <v-btn text class="cancel no-ripple" @click="closePopup()">{{
          $t("noBtnText")
        }}</v-btn>
        <v-btn
          class="primaryctabtn"
          title="Default"
          @click="deleteProductGroup()"
          >{{ $t("yesBtnText") }}</v-btn
        >
      </template>
    </brierley-dialogbox>
  </v-row>
</template>

<script>
import {
  BrierleyCardIcons,
  BrierleyCard,
  BrierleyStatus,
  BrierleyDialogbox
} from '@brierley/SharedComponents';
import { productGroupListObj } from './../../../../i18n/language.js';
import moment from 'moment-timezone';
export default {
  components: {
    BrierleyCardIcons,
    BrierleyCard,
    BrierleyStatus,
    BrierleyDialogbox
  },
  data () {
    return {
      localTimeZone: '',
      dialogPopup: false,
      pGroupData: null,
    };
  },
  i18n: productGroupListObj,
  computed: {
    productGroupList: {
      get () {
        return this.filterResult
          ? this.filterResult
          : this.productGroupListData;
      }
    }
  },
  props: {
    productGroupListData: {
      type: Array,
      defualt: []
    },
    filterResult: {
      type: Array,
      defualt: []
    },
  },
  methods: {
    format_date (value) {
      if (value) {
        let localZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        this.localTimeZone = moment()
          .tz(localZone)
          .zoneAbbr();
        return moment(String(value)).format('MMM Do YYYY, h:mm A');
      }
    },
    openPopup (item) {
      this.pGroupData = item;
      this.dialogPopup = true;
    },
    closePopup () {
      this.dialogPopup = false;
    },
    deleteProductGroup () {
      this.dialogPopup = false;
      let params = {
        pName: this.pGroupData.name,
        pId: this.pGroupData.productGroupId,
      };
      this.$store
        .dispatch('productGroupModule/deleteProductGroupActions', params.pId)
        .then((res) => {
          if (res.status === 201 || res.status === 200) {
            this.$store.commit(
              'productGroupModule/showDeletePopUpDialogueMutation',
              false
            );
            let params = {
              programId: localStorage.getItem('programId'),
              pageNumber: 1,
              pageSize: 20,
              searchText: ''
            };
            this.$store.dispatch(
              'productGroupModule/getProductGroupListActions',
              params
            );
          }
        });
    },
  }
};
</script>
<style lang="scss" scoped>
.mtn-6 {
  margin-top: -6px !important;
}
.minheight52{
  min-height: 52px;
}
.word-break{
  word-break: break-word !important;
  white-space: normal !important;
}
</style>
