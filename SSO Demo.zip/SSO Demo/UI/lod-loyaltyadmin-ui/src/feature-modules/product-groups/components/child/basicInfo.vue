<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <brierley-form-title
        :formTitle="$t('formTitle')"
        :currentStep="1"
        :totalStep="3"
        :infoText="$t('infoText')"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <v-col>
      <v-row no-gutters class="bmt5">
        <v-col sm="7" class="gen2-forms form-light-bg">
          <v-row class="flex-column " no-gutters>
            <v-col class="label-text">{{ $t("productGroupDetails") }}</v-col>
            <v-col sm="7">
              <validation-provider
                id="user_v_email"
                rules="required"
                v-slot="{ errors }"
              >
                <v-text-field
                  autocomplete="off"
                  data-qe-id="productGroupName"
                  :label="$t('productGroupName')"
                  class="isrequired"
                  v-model="productGroupDetails.productGroupName"
                  maxLength="50"
                  @input="nameField()"
                  @blur="
                    productGroupDetails.productGroupName = removeSpaces(
                      productGroupDetails.productGroupName
                    )
                  "
                  filled
                ></v-text-field>
                <v-layout
                  class="custom-error-msg"
                  v-if="
                    productGroupDetails.productGroupName.length != 0 &&
                      isDuplicateExist
                  "
                  >{{ $t("nameError") }}
                </v-layout>
                <p
                  class="custom-error-msg"
                  v-if="
                    errors[0] != undefined &&
                      errors[0].length > 0 &&
                      errors[0] == 'This field is required'
                  "
                >
                  {{ $t("commNameRequired") }}
                </p>
              </validation-provider>
            </v-col>
            <v-col sm="9">
              <v-textarea
                :label="$t('productGroupDes')"
                data-qe-id="productGroupDes"
                v-model="productGroupDetails.productGroupDescription"
                maxLength="1000"
                auto-grow
                filled
              ></v-textarea>
            </v-col>
            <!-- <v-col sm="7">
              <v-text-field
                autocomplete="off"
                data-qe-id="productCreatedBy"
                :label="$t('productGroupCreatedBy')"
                disabled
                v-model="productGroupDetails.productGroupCreatedBy"
                filled
              ></v-text-field>
            </v-col> -->
          </v-row>
        </v-col>
        <v-col sm="5">
          <brierley-info-side>
            <template v-slot:info-side-header>
              <div class="info_title">
                <v-icon>info</v-icon>{{ $t("productGroupInfo") }}
              </div>
            </template>
            <template v-slot:info-side-body>
              <div>
                {{ $t("productGroupInfoText") }}
              </div>
            </template>
          </brierley-info-side>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import { mapState } from 'vuex';
import {
  BrierleyInfoSide,
  BrierleyFormTitle
} from '@brierley/SharedComponents';
import { productGroupBasicInfoObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyInfoSide,
    BrierleyFormTitle
  },
  i18n: productGroupBasicInfoObj,
  computed: {
    ...mapState('productGroupModule', {
      productGroupDetails: state => {
        return state.productGroupDetails;
      },
      programEntity: state => {
        return state.programEntity;
      },
      isDuplicateExist: state => {
        return state.isDuplicateExist;
      },
      isLoading: state => {
        return state.isLoading;
      },
      businessEntityId () {
        return this.programEntity[0].businessEntityId;
      }
    })
  },
  methods: {
    removeSpaces (string) {
      return string.trim();
    },
    nameField () {
      this.$store.commit('productGroupModule/isDuplicateExistMutation', false);
    }
  }
};
</script>
