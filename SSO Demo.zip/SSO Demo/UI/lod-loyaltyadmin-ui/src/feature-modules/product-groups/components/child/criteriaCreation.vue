<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <brierley-form-title
        :formTitle="$t('formTitle')"
        :currentStep="2"
        :totalStep="3"
        :infoText="$t('infoText')"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <v-col class="bmt5 bpt4 gray-bg">
      <v-row
        no-gutters
        v-for="(item, index) in productGroupEntityArray"
        :key="index"
        class="flex-column bpx4"
      >
        <v-col class="bpx3 bpy2" v-if="index >= 1">
          <v-btn
            depressed
            :class="[
              item.productGroupAndToggled ? 'green-btn bmr1' : 'white-btn'
            ]"
            @click="andOperator(item, index)"
            >AND</v-btn
          >
          <v-btn
            depressed
            :class="[
              item.productGroupOrToggled ? 'green-btn bmr1' : 'white-btn'
            ]"
            @click="orOperator(item, index)"
            >OR</v-btn
          >
        </v-col>
        <v-col>
          <v-row
            class="white-bg flex-column bpx4 bpy3 gen2-forms form-light-bg"
            no-gutters
          >
            <v-col class="label-text bmb1">{{ $t("chooseProductGrp") }}</v-col>
            <v-col>
              <v-row>
                <v-col class="max-width-290">
                  <v-select
                    :label="$t('selectEntity')"
                    :items="item.productGroupBusinessEntity"
                    item-text="name"
                    item-value="businessEntityId"
                    v-model="item.selectedBusinessEntity"
                    filled
                    attach
                    offset-y
                    @change="
                      selectedProgram =>
                        selectBusinessEntity(selectedProgram, index)
                    "
                    class="gen2select gen2select__dark mini-list"
                    append-icon="expand_more"
                  ></v-select>
                  <p class="custom-error-msg" v-if="item.entityErrorExists">
                    {{ $t("errorText") }}
                  </p>
                </v-col>
              </v-row>
            </v-col>
            <v-col><v-divider class="dashed bmt2 bmb4"></v-divider></v-col>
            <v-col
              v-if="
                productGroupEntityArray[index]
                  .productGroupAttibuteOperatorArray[0]
                  .productGroupAttributeArray.length > 0
              "
            >
              <v-row
                v-for="(entity, j) in item.productGroupAttibuteOperatorArray"
                :key="j"
              >
                <v-col class="bpb0">
                  <v-select
                    filled
                    :items="entity.productGroupAttributeArray"
                    item-text="columnName"
                    item-value="extensionPropertyId"
                    v-model="entity.selectedGroupAttribute"
                    :label="$t('selectProductGrpAttr')"
                    @change="
                      selectedAttribute(
                        item.productGroupAttibuteOperatorArray[j],
                        index,
                        j
                      )
                    "
                    attach
                    offset-y
                    class="gen2select gen2select__dark mini-list"
                    append-icon="expand_more"
                  ></v-select>
                  <p
                    class="custom-error-msg"
                    v-if="entity.attributeErrorExists"
                  >
                    {{ $t("errorText") }}
                  </p>
                </v-col>
                <v-col class="bpb0">
                  <v-select
                    filled
                    :label="$t('selectOper')"
                    :items="entity.productGroupOperatorArray"
                    v-model="entity.selectedGroupOperator"
                    @change="
                      selectedOperator(
                        item.productGroupAttibuteOperatorArray[j],
                        j
                      )
                    "
                    item-text="name"
                    item-value="name"
                    attach
                    offset-y
                    class="gen2select gen2select__dark mini-list"
                    append-icon="expand_more"
                  ></v-select>
                  <p class="custom-error-msg" v-if="entity.operatorErrorExists">
                    {{ $t("errorText") }}
                  </p>
                </v-col>
                <v-col class="bpb0 max-width-290">
                  <v-select
                    filled
                    :items="entity.productGroupValueArray"
                    v-model="entity.selectedGroupValue"
                    @change="
                      selectedValue(
                        item.productGroupAttibuteOperatorArray[j],
                        j
                      )
                    "
                    item-text="extensionPropertyValue"
                    item-value="extensionPropertyValue"
                    :label="getLabel(index, j)"
                    :disabled="entity.valueName === 'No options available'"
                    attach
                    offset-y
                    class="gen2select gen2select__dark mini-list"
                    append-icon="expand_more"
                  ></v-select>
                  <p class="custom-error-msg" v-if="entity.valueErrorExists">
                    {{ $t("errorText") }}
                  </p>
                </v-col>
                <v-col class="btn-ic-width text-right bpl6 bpb0">
                  <v-btn
                    depressed
                    class="blue-icon-btn"
                    @click="
                      addProductGroupAttibuteOperatorRow(entity, index, j)
                    "
                  >
                    <v-icon>add_circle_outline</v-icon>
                  </v-btn>
                  <v-btn
                    depressed
                    class="blue-icon-btn bml2"
                    :disabled="
                      productGroupEntityArray.length === 1 &&
                        item.productGroupAttibuteOperatorArray.length === 1
                    "
                    @click="
                      removeProductGroupAttibuteOperatorRow(entity, index, j)
                    "
                  >
                    <v-icon>remove_circle_outline</v-icon>
                  </v-btn>
                </v-col>
              </v-row>
            </v-col>
            <v-col>
              <v-row class="d-inline-flex icon-with-head align-center">
                <v-col>
                  <v-icon class="bmr1">playlist_add_check</v-icon>
                </v-col>
                <v-col @click="ShowSinglePreviewPopup(index)"> {{ $t("previewText") }}</v-col>
              </v-row>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </v-col>
    <v-col class="gray-bg bpx4 bpb3">
      <v-row
        class="d-inline-flex icon-with-head align-center bmr3"
        @click="addMoreCriteria(productGroupEntityArray)"
      >
        <v-col>
          <v-icon class="bmr1">add_circle_outline</v-icon>
        </v-col>
        <v-col class="text-uppercase">{{ $t("addQualifying") }}</v-col>
      </v-row>
      <v-row class="d-inline-flex icon-with-head align-center">
        <v-col>
          <v-icon class="bmr1">playlist_add_check</v-icon>
        </v-col>
        <v-col @click="ShowPreviewPopup()"> {{ $t("previewText") }} </v-col>
      </v-row>
    </v-col>
    <v-col>
      <preview-popup v-if="showPreviewPopup" />
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyFormTitle } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import PreviewPopup from './PreviewPopup';
import { productGroupCriteriaObj } from '../../../../i18n/language.js';
export default {
  data () {
    return {
      select: '',
      operatorArray: []
    };
  },
  i18n: productGroupCriteriaObj,
  components: {
    BrierleyFormTitle,
    PreviewPopup
  },
  methods: {
    andOperator (item, index) {
      let operatorPayload = {
        operator: 'AND',
        index: index,
        toggled: 'productGroupAndToggled'
      };
      this.$store.commit(
        'productGroupModule/updateproductGroupDefaultConditionMutation',
        operatorPayload
      );
    },
    orOperator (item, index) {
      let operatorPayload = {
        operator: 'OR',
        index: index,
        toggled: 'productGroupOrToggled'
      };
      this.$store.commit(
        'productGroupModule/updateproductGroupDefaultConditionMutation',
        operatorPayload
      );
    },
    addMoreCriteria (productGroupEntityArray) {
      let entityResult = productGroupEntityArray.filter(obj => {
        return (
          obj.selectedBusinessEntity === '' ||
          obj.selectedBusinessEntity === undefined
        );
      });
      let obj = {
        productGroupDefaultCondition: 'AND',
        productGroupAndToggled: true,
        productGroupOrToggle: false,
        productGroupBusinessEntity: this.productBusinessEntity,
        selectedBusinessEntity: '',
        entityErrorExists: false,
        productGroupAttibuteOperatorArray: [
          {
            productGroupAttributeArray: [],
            selectedGroupAttribute: '',
            attributeErrorExists: false,
            productGroupOperatorArray: [],
            selectedGroupOperator: '',
            operatorErrorExists: false,
            productGroupValueArray: [],
            selectedGroupValue: '',
            valueErrorExists: false,
            valueName: ''
          }
        ]
      };
      if (entityResult.length === 0) {
        this.$store.commit('productGroupModule/addMoreCriteriaMutation', obj);
      }
    },
    getLabel (a, b) {
      if (
        this.productGroupEntityArray[a].productGroupAttibuteOperatorArray[b]
          .valueName === 'No options available'
      ) {
        return 'No options available';
      } else {
        if (
          this.productGroupEntityArray[a].productGroupAttibuteOperatorArray[b]
            .valueName
        ) {
          return (
            this.$t('select') +
            ' ' +
            this.productGroupEntityArray[a].productGroupAttibuteOperatorArray[b]
              .valueName
          );
        } else {
          return this.$t('select');
        }
      }
    },
    removeProductGroupAttibuteOperatorRow (entity, a, b) {
      if (
        this.productGroupEntityArray[a].productGroupAttibuteOperatorArray
          .length === 1
      ) {
        this.productGroupEntityArray.splice(a, 1);
      } else {
        this.productGroupEntityArray[
          a
        ].productGroupAttibuteOperatorArray.splice(b, 1);
        let obj = {
          index: a,
          attrArr: this.productGroupEntityArray[a]
            .productGroupAttibuteOperatorArray
        };
        this.$store.commit(
          'productGroupModule/updateproductAttibuteOperatorArrayMutation',
          obj
        );
      }
    },
    addProductGroupAttibuteOperatorRow (entity, a, b) {
      if (
        entity.selectedGroupAttribute === undefined ||
        entity.selectedGroupAttribute === ''
      ) {
        entity.attributeErrorExists = true;
      } else {
        entity.attributeErrorExists = false;
      }
      if (
        entity.selectedGroupOperator === undefined ||
        entity.selectedGroupOperator === ''
      ) {
        entity.operatorErrorExists = true;
      } else {
        entity.operatorErrorExists = false;
      }
      if (
        entity.selectedGroupValue === undefined ||
        entity.selectedGroupValue === ''
      ) {
        entity.valueErrorExists = true;
      } else {
        entity.valueErrorExists = false;
      }
      // if (entity.valueName === 'No options available') {
      //   entity.valueErrorExists = false;
      // }
      if (
        entity.selectedGroupAttribute &&
        entity.selectedGroupOperator &&
        entity.selectedGroupValue
      ) {
        let obj = {
          index: a,
          productGroupAttributeArray: this.productGroupEntityArray[a]
            .productGroupAttibuteOperatorArray[b].productGroupAttributeArray,
          selectedGroupAttribute: '',
          attributeErrorExists: false,
          productGroupOperatorArray: [],
          selectedGroupOperator: '',
          operatorErrorExists: false,
          productGroupValueArray: [],
          selectedGroupValue: '',
          valueErrorExists: false
        };
        this.$store.commit(
          'productGroupModule/updateproductGroupAttibuteOperatorArrayMutation',
          obj
        );
      }
    },
    selectBusinessEntity (val, a) {
      this.$store
        .dispatch('productGroupModule/getExtensionPropertyValueAction', val)
        .then(res => {
          let obj = {
            index: a,
            attributeArray: res.data.data
          };
          this.$store.commit(
            'productGroupModule/updateproductGroupAttributeArrayMutation',
            obj
          );
          let attributeResult = res.data.data.filter(obj => {
            return (
              obj.extensionPropertyId ===
              this.productGroupEntityArray[a]
                .productGroupAttibuteOperatorArray[0].selectedGroupAttribute
            );
          });
          if (attributeResult[0].dataType === 'String') {
            this.operatorArray = [
              { name: 'Matches Exactly', value: 8 },
              { name: 'Contains', value: 9 },
              { name: 'Starts With', value: 10 }
            ];
          } else if (attributeResult[0].dataType === 'Boolean') {
            this.operatorArray = [
              { name: 'Is', value: 6 },
              { name: 'Is Not', value: 7 }
            ];
          } else if (
            attributeResult[0].dataType === 'DateTime' ||
            attributeResult[0].dataType === 'Number'
          ) {
            this.operatorArray = [
              { name: 'Equals', value: 0 },
              { name: 'Less Than', value: 1 },
              { name: 'Less Than or Equals', value: 2 },
              { name: 'Greater Than', value: 3 },
              {
                name: 'Greater Than or Equals',
                value: 4
              },
              { name: 'Does Not Equal', value: 5 }
            ];
          }
          let stringObj = {
            entityIndex: a,
            valueIndex: 0,
            valueArray: this.operatorArray
          };
          this.$store.commit(
            'productGroupModule/updateproductGroupOperatorArrayMutation',
            stringObj
          );
          this.$store
            .dispatch(
              'productGroupModule/getValuePropertyAction',
              attributeResult[0]
            )
            .then(res => {
              this.$store.commit(
                'productGroupModule/updateproductGroupValueMutation',
                a
              );
              const dataresult = [...new Set(res.data.data)];
              let extensionArray = dataresult.map((item, index) => {
                const extensionObj = {
                  index: index,
                  extensionPropertyValue: item
                };
                return extensionObj;
              });
              extensionArray = extensionArray.filter(obj => {
                if (obj.extensionPropertyValue !== null) {
                  return obj;
                }
              });
              let obj = {
                entityIndex: a,
                valueIndex: 0,
                valueArray: extensionArray
              };
              this.$store.commit(
                'productGroupModule/updateproductGroupValueArrayMutation',
                obj
              );
              if (res.data.data === undefined) {
                let valueNameObj = {
                  entityIndex: a,
                  valueIndex: 0,
                  valueName: 'No options available'
                };
                this.$store.commit(
                  'productGroupModule/updateValueNameMutation',
                  valueNameObj
                );
              } else {
                let valueNameObj = {
                  entityIndex: a,
                  valueIndex: 0,
                  valueName: attributeResult[0].columnName
                };
                this.$store.commit(
                  'productGroupModule/updateValueNameMutation',
                  valueNameObj
                );
              }
              let productObj = {
                index: a,
                operator: this.productGroupEntityArray[a]
                  .productGroupAttibuteOperatorArray[0]
              };
              this.$store.commit(
                'productGroupModule/updateAttibuteOperatorArrayMutation',
                productObj
              );
            });
        });
      this.$store.commit('productGroupModule/updateErrorsMutation', a);
    },

    ShowSinglePreviewPopup (i) {
      let previewProduct = [];
      let criteria = [];
      this.productGroupEntityArray.forEach((val, i) => {
        let andOrCondition = 0;
        criteria[i] = {
          operator: andOrCondition,
          programEntityId: val.selectedBusinessEntity,
          criteriaList: []
        };
        val.productGroupAttibuteOperatorArray.forEach((arr, j) => {
          let attributeValue = arr.productGroupAttributeArray.filter(
            x => x.extensionPropertyId === arr.selectedGroupAttribute
          );
          let operatorValue = arr.productGroupOperatorArray.filter(
            x => x.name === arr.selectedGroupOperator
          );

          criteria[i].criteriaList[j] = {
            criteriaType: attributeValue[0].columnName,
            operator: operatorValue[0].value,
            criteriaValue: arr.selectedGroupValue,
            isExtensionProperty: attributeValue[0].isExtendedAttribute
          };
        });
      });
      previewProduct.pageSize = 10;
      previewProduct.pageNumber = 1;
      previewProduct.productGroupCrieterias = [{ ...criteria[i] }];
      previewProduct = [{ ...previewProduct }];
      this.$store.commit('productGroupModule/preiewProduct', previewProduct);
      this.$store.dispatch('productGroupModule/getProductDetails', previewProduct);
      this.$store.commit('productGroupModule/previewPopupValuesMutations', [
        { ...criteria[i] }
      ]);
      this.$store.commit('productGroupModule/previewPopupMutation', true);
    },

    ShowPreviewPopup () {
      let previewProduct = [];
      let criteria = [];
      this.productGroupEntityArray.forEach((val, i) => {
        let andOrCondition = 0;
        if (i === this.productGroupEntityArray.length - 1) {
          criteria[i] = {
            operator: andOrCondition,
            programEntityId: val.selectedBusinessEntity,
            criteriaList: []
          };
        } else if (i < this.productGroupEntityArray.length) {
          criteria[i] = {
            operator: val.productGroupDefaultCondition === 'AND' ? 1 : 2,
            programEntityId: val.selectedBusinessEntity,
            criteriaList: []
          };
        }
        val.productGroupAttibuteOperatorArray.forEach((arr, j) => {
          let attributeValue = arr.productGroupAttributeArray.filter(
            x => x.extensionPropertyId === arr.selectedGroupAttribute
          );
          let operatorValue = arr.productGroupOperatorArray.filter(
            x => x.name === arr.selectedGroupOperator
          );
          criteria[i].criteriaList[j] = {
            criteriaType: attributeValue[0].columnName,
            operator: operatorValue[0].value,
            criteriaValue: arr.selectedGroupValue,
            isExtensionProperty: attributeValue[0].isExtendedAttribute
          };
        });
      });
      previewProduct.pageSize = 10;
      previewProduct.pageNumber = 1;
      previewProduct.productGroupCrieterias = criteria;
      previewProduct = [{ ...previewProduct }];
      this.$store.commit('productGroupModule/preiewProduct', previewProduct);
      this.$store.dispatch('productGroupModule/getProductDetails', previewProduct);
      this.$store.commit(
        'productGroupModule/previewPopupValuesMutations',
        criteria
      );
      this.$store.commit('productGroupModule/previewPopupMutation', true);
    },

    selectedOperator (val) {
      if (
        val.selectedGroupOperator === undefined ||
        val.selectedGroupOperator === ''
      ) {
        val.operatorErrorExists = true;
      } else {
        val.operatorErrorExists = false;
      }
    },
    selectedValue (val) {
      if (
        val.selectedGroupValue === undefined ||
        val.selectedGroupValue === ''
      ) {
        val.valueErrorExists = true;
      } else {
        val.valueErrorExists = false;
      }
    },
    selectedAttribute (val, a, b) {
      let attributeResult = val.productGroupAttributeArray.filter(obj => {
        return obj.extensionPropertyId === val.selectedGroupAttribute;
      });
      if (attributeResult[0].dataType === 'String') {
        this.operatorArray = [
          { name: 'Matches Exactly', value: '8' },
          { name: 'Contains', value: '9' },
          { name: 'Starts With', value: '10' }
        ];
      } else if (attributeResult[0].dataType === 'Boolean') {
        this.operatorArray = [
          { name: 'Is', value: '6' },
          { name: 'Is Not', value: '7' }
        ];
      } else if (
        attributeResult[0].dataType === 'DateTime' ||
        attributeResult[0].dataType === 'Number'
      ) {
        this.operatorArray = [
          { name: 'Equals', value: '0' },
          { name: 'Less Than', value: '1' },
          { name: 'Less Than or Equals', value: '2' },
          { name: 'Greater Than', value: '3' },
          {
            name: '4'
          },
          { name: 'Does Not Equal', value: '5' }
        ];
      }
      let stringObj = {
        entityIndex: a,
        valueIndex: b,
        valueArray: this.operatorArray
      };
      this.$store.commit(
        'productGroupModule/updateproductGroupOperatorArrayMutation',
        stringObj
      );
      this.$store
        .dispatch(
          'productGroupModule/getValuePropertyAction',
          attributeResult[0]
        )
        .then(res => {
          val.selectedGroupValue = '';
          const dataresult = [...new Set(res.data.data)];
          let extensionArray = dataresult.map((item, index) => {
            const extensionObj = { index: index, extensionPropertyValue: item };
            return extensionObj;
          });
          extensionArray = extensionArray.filter(obj => {
            if (obj.extensionPropertyValue !== null) {
              return obj;
            }
          });
          let obj = {
            entityIndex: a,
            valueIndex: b,
            valueArray: extensionArray
          };
          this.$store.commit(
            'productGroupModule/updateproductGroupValueArrayMutation',
            obj
          );
          if (res.data.data === undefined) {
            let valueNameObj = {
              entityIndex: a,
              valueIndex: b,
              valueName: 'No options available'
            };
            this.$store.commit(
              'productGroupModule/updateValueNameMutation',
              valueNameObj
            );
          } else {
            let valueNameObj = {
              entityIndex: a,
              valueIndex: b,
              valueName: attributeResult[0].columnName
            };
            this.$store.commit(
              'productGroupModule/updateValueNameMutation',
              valueNameObj
            );
          }
        });
      let indexObj = {
        entityIndex: a,
        valueIndex: b
      };
      this.$store.commit(
        'productGroupModule/updateOperatorErrorMutation',
        indexObj
      );
    }
  },
  created () {
    let arr = [
      {
        productGroupDefaultCondition: 'AND',
        productGroupAndToggled: true,
        productGroupOrToggle: false,
        productGroupBusinessEntity: this.productBusinessEntity,
        selectedBusinessEntity: '',
        entityErrorExists: false,
        productGroupAttibuteOperatorArray: [
          {
            productGroupAttributeArray: [],
            selectedGroupAttribute: '',
            attributeErrorExists: false,
            productGroupOperatorArray: [],
            selectedGroupOperator: '',
            operatorErrorExists: false,
            productGroupValueArray: [],
            selectedGroupValue: '',
            valueErrorExists: false,
            valueName: ''
          }
        ]
      }
    ];
    this.$store.commit(
      'productGroupModule/updateproductGroupEntityArrayMutation',
      arr
    );
  },
  computed: {
    ...mapState('productGroupModule', {
      productGroupDetails: state => {
        return state.productGroupDetails;
      },
      productBusinessEntity: state => {
        return state.productBusinessEntity;
      },
      showPreviewPopup: state => {
        return state.showPreviewPopup;
      },
      productGroupAttributeArray: state => {
        return state.productGroupAttributeArray;
      },
      productGroupEntityArray: state => {
        return state.productGroupEntityArray;
      },
      getProductGroupProducts: state => {
        return state.getProductGroupProducts;
      }

    })
  }
};
</script>
<style lang="scss" scoped>
.max-width-290 {
  max-width: 290px !important;
}
</style>
