<template>
  <v-row>
    <v-col cols="12" v-for="(item, i) in productGroupList" :key="i">
      <v-card class="gen2-card gen2-typo3">
        <v-row no-gutters>
          <v-col md="3" sm="12" xs="12">
            <v-card-title class="elipsis-fullwidth">
              {{ item.name }}
            </v-card-title>
            <div class="gen2-card-copy">
              <!-- <p>
                <strong>{{ $t('productGroupCode') }}: </strong>
                3294058
              </p>
              <p>
                <strong>{{ $t('productsCount') }}: </strong>
                3500
              </p> -->
              <p>
                <strong>{{ $t("programEntityLabel") }}: </strong>
                {{ item.programEntityName }}
              </p>
            </div>
          </v-col>
          <v-col md="3" sm="12" xs="12" class="bpx4">
            <v-row no-gutters class="flex-column">
              <v-col>
                <p class="bmt0">
                  <strong>{{ $t("productGroupDescription") }}:</strong>
                </p>
              </v-col>
              <v-col>
                <p class="elipsis-twoline bmt0" :title="item.description">
                  {{ item.description }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col md="4" sm="12" xs="12" class="bpr6 bpl6">
            <v-row no-gutters class="pr-3">
              <v-col class="text-xs-left">
                <p class="bmt0">
                  <strong>{{ $t("createdOnText") }}:</strong>
                </p>
              </v-col>
              <v-col class="text-xs-right bpr3 bpl3">
                <p class="bmt0">
                  {{ format_date(item.createdDate) }} {{ localTimeZone }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col sm="2">
            <v-row no-gutters>
              <v-col md="12" class="bpt0 bpb0">
                <p class="bmt0">
                  <strong>{{ $t("statusLabel") }}</strong>
                </p>
              </v-col>
              <v-col sm="12">
                <brierley-status
                  v-if="item.status === true"
                  status="Active"
                ></brierley-status>
              </v-col>
            </v-row>
          </v-col>
          <v-col sm="12" class="bmt1">
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span :title="$t('viewDetails')" class="active">
                  <v-icon>fe fe-eye</v-icon>
                  <span class="viewdetails-icon">{{ $t("viewDetails") }}</span>
                </span>
                <span
                  @click="
                    $router.push(
                      `/loyaltyadmin/productGroupPage/${item.productGroupId}`
                    )
                  "
                  :title="$t('editLabel')"
                  data-qe-id="edit_btn"
                >
                  <v-icon id="viewuser_edit-icon" class="blackicon"
                    >fe fe-edit</v-icon
                  >
                  <span class="edit-icon" id="viewuser-edit">{{
                    $t("editLabel")
                  }}</span>
                </span>
                <span
                  @click="
                    $router.push(
                      `/loyaltyadmin/productGroupPage/${item.productGroupId}/clone`
                    )
                  "
                  :title="$t('cloneLabel')"
                >
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >feather-icon fe fe-copy</v-icon
                  >
                  <span class="clone-icon">
                    {{ $t("cloneLabel") }}
                  </span>
                </span>
                <span :title="$t('deleteText')" @click="openPopup(item)">
                  <v-icon class="blackicon cursor-p">fe-trash-2</v-icon>
                  <span class="delete-icon">{{ $t("deleteText") }}</span>
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
        </v-row>
      </v-card>
    </v-col>
    <brierley-dialogbox
      :dialog="dialogPopup"
      @closeMe="dialogPopup = $event"
      :persistent="false"
    >
      <template v-slot:dialog-header>
        <v-card-title class="gen2-dialog-title text-uppercase">{{
          $t("deletepGroupText")
        }}</v-card-title>
      </template>
      <template v-slot:dialog-body-alert>
        <v-alert class="b-alert-error" type="error" :dismissible="false">
          <v-row class="alert-block align-center havebtn" no-gutters>
            <v-col class="alert-block__body">
              {{ $t("areYouSureText") }} {{ pGroupData.name }} ?
            </v-col>
          </v-row>
        </v-alert>
      </template>
      <!-- <template v-slot:dialog-body-description>
              <v-col>
                <p>Are you sure you want to publish this Promotion?</p>
              </v-col>
            </template> -->
      <template v-slot:dialog-footer>
        <v-btn text class="cancel no-ripple" @click="closePopup()">{{
          $t("noBtnText")
        }}</v-btn>
        <v-btn
          class="primaryctabtn"
          title="Default"
          @click="deleteProductGroup()"
          >{{  $t("yesBtnText")}}</v-btn
        >
      </template>
    </brierley-dialogbox>
  </v-row>
</template>
<script>
import {
  BrierleyCardIcons,
  BrierleyStatus,
  BrierleyDialogbox,
} from '@brierley/SharedComponents';
import { productGroupListObj } from './../../../../i18n/language.js';
import moment from 'moment-timezone';
export default {
  components: {
    BrierleyCardIcons,
    BrierleyStatus,
    BrierleyDialogbox,
  },
  data () {
    return {
      localTimeZone: '',
      dialogPopup: false,
      pGroupData: null,
    };
  },
  i18n: productGroupListObj,
  computed: {
    productGroupList: {
      get () {
        return this.filterResult
          ? this.filterResult
          : this.productGroupListData;
      }
    }
  },
  props: {
    productGroupListData: {
      type: Array,
      defualt: [],
    },
    filterResult: {
      type: Array,
      defualt: [],
    },
  },
  methods: {
    format_date (value) {
      if (value) {
        let localZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        this.localTimeZone = moment().tz(localZone).zoneAbbr();
        return moment(String(value)).format('MMM Do YYYY, h:mm A');
      }
    },
    openPopup (item) {
      this.pGroupData = item;
      this.dialogPopup = true;
    },
    closePopup () {
      this.dialogPopup = false;
    },
    deleteProductGroup () {
      this.dialogPopup = false;
      let params = {
        pName: this.pGroupData.name,
        pId: this.pGroupData.productGroupId,
      };
      this.$store
        .dispatch('productGroupModule/deleteProductGroupActions', params.pId)
        .then((res) => {
          if (res.status === 201 || res.status === 200) {
            this.$store.commit(
              'productGroupModule/showDeletePopUpDialogueMutation',
              false
            );
            let params = {
              programId: localStorage.getItem('programId'),
              pageNumber: 1,
              pageSize: 20,
              searchText: ''
            };
            this.$store.dispatch(
              'productGroupModule/getProductGroupListActions',
              params
            );
          }
        });
    },
  },
};
</script>
