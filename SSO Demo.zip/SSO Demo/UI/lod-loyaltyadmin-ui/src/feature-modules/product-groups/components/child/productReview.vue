<template>
  <v-row no-gutters>
    <v-col>
      <v-row v-if="!success || !createSuccess" class="flex-column" no-gutters>
        <v-col>
          <brierley-form-title
            formTitle="Review"
            :currentStep="3"
            :totalStep="3"
            :infoText="$t('infoText')"
            :showSteps="true"
          ></brierley-form-title>
        </v-col>
        <v-col class="bmt5" style="padding-left: 2px;">
          <v-row no-gutters>
            <v-col cols="12">
              <v-row no-gutters class="sub-section_title">
                <v-col xs="12" sm="9" md="9">
                  <!-- Sub Header Start-->
                  <p class="fbold text-left text-uppercase">
                    {{ $t("basicInfo") }}
                  </p>
                  <!-- Sub Header End-->
                </v-col>
                <v-col xs="12" sm="3" md="3" class="hoverEdit">
                  <!-- Edit Button Start -->
                  <p class="text-right text-uppercase">
                    <span
                      class="cursor-p primary-text fbold"
                      @click="goToStep(1)"
                      ><v-icon class="bpr1" color="#000">create</v-icon
                      >Edit</span
                    >
                  </p>
                  <!-- Edit Button End-->
                </v-col>
              </v-row>
              <v-divider class="bmt0 bmb2"></v-divider>
              <v-row no-gutters class="sub-section_descripition">
                <v-col>
                  <p>
                    <strong>{{ $t("productGrpName") }}</strong>
                    {{ productGroupDetails.productGroupName }}
                  </p>
                  <p>
                    <strong>{{ $t("productGrpDesc") }}</strong>
                    {{ productGroupDetails.productGroupDescription }}
                  </p>
                </v-col>
              </v-row>
            </v-col>
            <v-col cols="12" class="bmt5 bmb2">
              <v-row no-gutters class="sub-section_title">
                <v-col xs="12" sm="9" md="9">
                  <!-- Sub Header Start-->
                  <p class="fbold text-left text-uppercase">
                    {{ $t("rules") }}
                  </p>
                  <!-- Sub Header End-->
                </v-col>
                <v-col xs="12" sm="3" md="3" class="hoverEdit">
                  <!-- Edit Button Start -->
                  <p class="text-right text-uppercase">
                    <span
                      class="cursor-p primary-text fbold"
                      @click="goToStep(2)"
                      ><v-icon class="bpr1" color="#000">create</v-icon
                      >Edit</span
                    >
                  </p>
                  <!-- Edit Button End-->
                </v-col>
              </v-row>
              <v-divider class="bmt0 bmb2"></v-divider>
              <div
                v-for="(productGroup, j) in productGroupEntityArray"
                :key="j"
              >
                <v-row no-gutters class="sub-section_descripition">
                  <v-col>
                    <p>
                      <strong>{{ $t("entity") }}</strong>
                      {{ getEntityName(productGroup) }}
                    </p>
                    <p>
                      <strong>{{ $t("criteria") }}</strong>
                      <span
                        style="display: block"
                        v-for="(product,
                        i) in productGroup.productGroupAttibuteOperatorArray"
                        :key="i"
                      >
                        {{ product.valueName }}
                        {{ product.selectedGroupOperator }}
                        "{{ product.selectedGroupValue }}"<template
                          v-if="
                            i <
                              productGroup.productGroupAttibuteOperatorArray
                                .length -
                                1
                          "
                          >,</template
                        >
                      </span>
                    </p>
                  </v-col>
                </v-row>
                <v-divider
                  v-if="j < productGroupEntityArray.length - 1"
                  class="dashed-border"
                  bmy4
                ></v-divider>
              </div>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
      <v-row class="store-review-success flex-column" no-gutters v-else>
        <v-col>
          <v-row no-gutters>
            <v-col>
              <brierley-form-title
                :formTitle="$t('successFormTitle')"
                :infoIcon="false"
              ></brierley-form-title>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col md="12" class="store-review-success__alert">
              <v-alert
                class="b-alert-success"
                type="success"
                :dismissible="false"
                infoText="Success"
                style="min-width: 100%"
                icon="done"
              >
                <v-row class="alert-block align-center" no-gutters>
                  <v-col class="alert-block__body">
                    <h3>{{ $t("successAlertHeader") }}</h3>
                    <p v-if="$route.name === 'ProductreGroupPageUpdate'">
                      {{
                        $t("editStore", {
                          productGroupName: `${productGroupDetails.productGroupName}`
                        })
                      }}
                    </p>
                    <p v-else>
                      {{
                        $t("newProductGroupText", {
                          productGroupName: `${productGroupDetails.productGroupName}`
                        })
                      }}
                    </p>
                  </v-col>
                </v-row>
              </v-alert>
            </v-col>
            <v-col
              md="12"
              class="store-review-success__actions gen2-frm-footer-previous"
            >
              <v-btn
                form="basic_form"
                type="submit"
                class="primaryctabtn bmt2 bml2 large ml-0"
                id="success-close-btn"
                @click.native="nav()"
              >
                {{ $t("closeText") }}
              </v-btn>
              <p class="mt-8">
                <strong>{{ $t("anotherProductGroup") }}</strong> <br />
                <span>
                  {{ $t("productGroup")
                  }}<v-btn
                    text
                    class="no-ripple cancel store-review-success__actions--click-here"
                    @click="openDialog()"
                  >
                    {{ $t("clickHere") }}
                  </v-btn></span
                >
                <v-col v-if="productGroupDetails.showCreateEntityPopup">
                  <create-entity-popup />
                </v-col>
              </p>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyFormTitle } from '@brierley/SharedComponents';
import { productReviewSuccessObj } from '../../../../i18n/language';
import { mapState } from 'vuex';
import createEntityPopup from '../child/createEntityPopup';
export default {
  i18n: productReviewSuccessObj,
  //  data(){
  //   return {
  //     openPopUp: false
  //   }
  // },
  components: {
    BrierleyFormTitle,
    createEntityPopup
  },
  alertMessage () {
    if (this.$route.path.includes('/loyaltyadmin/productgrouplist/edit')) {
      return this.$t('editStore');
    } else {
      return this.$t('$t("newProductGroupText")');
    }
  },
  props: {
    success: {
      type: Boolean,
      default: false
    },
    createSuccess: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    ...mapState('productGroupModule', [
      'productGroupEntityArray',
      'productGroupDetails'
    ])
  },
  methods: {
    openDialog () {
      let programId = localStorage.getItem('programId');
      this.$store.dispatch(
        'productGroupModule/getProductBusinessEntityAction',
        programId
      );
      this.$store.commit(
        'productGroupModule/closeCreateEntityPopupMutation',
        true
      );
    },
    nav () {
      this.$router.push('/loyaltyadmin/productgrouplist');
    },
    goToStep (step) {
      this.$store.commit(
        'productGroupModule/updateProductGroupStepperMutation',
        step
      );
    },
    getEntityName (criteria) {
      let entity = criteria.productGroupBusinessEntity.find(item => {
        return item.businessEntityId === criteria.selectedBusinessEntity;
      });
      return entity && entity.name ? entity.name : '';
    }
  }
};
</script>
<style lang="scss" scoped>
.sub-section_descripition {
  p {
    margin-bottom: 0;
    line-height: 32px;
  }
}
</style>
