<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        class="custom-dialog__large custom-large"
        :dialog="true"
        @closeMe="closePopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ $t("productlistText") }}
          </v-card-title>
        </template>
        <template v-slot:dialog-body-description>
          <v-col class="preview-stores-list">
            <v-row no-gutters>
              <v-col class="preview-stores-list__criteria" cols="12">
                <v-row no-gutters v-for="details in previewPopupRes"
                        :key="details.programEntityId">
                  <v-col md="12" class="mt-5"
                    ><h3 class="preview-stores-list__title">
                       {{ $t("productCriteriaText") }}
                    </h3></v-col
                  >
                  <v-col md="6" class="mt-7" >
                    <v-row no-gutters>
                      <v-col md="6">
                      <p><strong> {{ $t("entityText" ) }} </strong>
                      <span> {{ getEntityName(details) }}</span>
                      </p>
                      <p><strong>{{ $t("criteria" ) }}</strong>
                      <span v-for="(detailsRes,index) in details.criteriaList"
                        :key="index"> {{ getCriteria(index) }}</span>
                      </p>
                      </v-col>
                    </v-row>
                      <v-divider
                      v-if="j < details.criteriaList.length - 1"
                      class="dashed-border"
                      bmy4
                    ></v-divider>
                    <!-- <v-row no-gutters class="mt-3">
                      <v-col md="6">
                        <strong>{{ $t("department") }}</strong>
                        <span>TX</span>
                      </v-col>
                    </v-row> -->
                  </v-col>
                </v-row>
              </v-col>
              <v-row no-gutters class="mt-7 px-0">
                <v-col md="12"
                  ><h3 class="preview-stores-list__title">
                    {{ $t("productDetailsText") }} <small>({{ getProductGroupProductsCountRes }} Products)</small>
                  </h3></v-col
                >
                <v-col md="12" class="mt-7">
                  <v-simple-table class="gen2-sample-table" v-if="getProductGroupProductsCountRes > 0">
                    <thead>
                      <tr>
                        <th>{{ $t("productnameText") }}</th>
                        <th>{{ $t("productcodeText") }}</th>
                        <th>{{ $t("productDescriptionText") }}</th>
                        <th>{{ $t("divisionOrDepartment") }}</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="item in getProductGroupProductsRes"
                        :key="item.name">
                        <td>{{ item.name }}</td>
                        <td>{{ item.externalId }}</td>
                        <td>{{ item.description }}</td>
                        <td >
                          {{ item.extensionProperty.division }} / {{ item.extensionProperty.department }}
                        </td>
                      </tr>
                    </tbody>
                  </v-simple-table>
                  <brierley-no-result
                    v-if="getProductGroupProductsRes === 0"
                    :noRecordFoundHeader="$t('noRecordFoundHeader')"
                    :noResultMessage="$t('noResultMessage')"
                  >
                </brierley-no-result>
                </v-col>
              </v-row>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer v-if="getProductGroupProductsRes > 0 && loadmore === true">
          <v-col md="12" class="text-center">
            <v-row
              class="d-flex d-inline-flex flex-column load-more-listing text-center"
              no-gutters
            >
              <v-col class="bpa2">
                <v-progress-circular
                  :width="3"
                  indeterminate
                  color="brown"
                ></v-progress-circular>
              </v-col>
              <v-col>LOAD MORE</v-col>
            </v-row>
          </v-col>
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox, BrierleyNoResult } from '@brierley/SharedComponents';
// import { productCancelPopUpObject } from '../../../../i18n/language.js';
import { productPreviewPopUpObject } from '../../../../i18n/language.js';

import { mapState } from 'vuex';
export default {
  data () {
    return {
      dialog: false,
      loadmore: true
    };
  },
  components: {
    BrierleyDialogbox,
    BrierleyNoResult
  },
  i18n: productPreviewPopUpObject,
  methods: {
    closePopup () {
      this.$store.commit('productGroupModule/previewPopupMutation', false);
    },
    getEntityName (criteria) {
      let entity = this.productGroupEntityArray[0].productGroupBusinessEntity.find(item => {
        return item.businessEntityId === criteria.programEntityId;
      });
      return entity && entity.name ? entity.name : '';
    },
    getCriteria (index) {
      let data = this.productGroupEntityArray[0].productGroupAttibuteOperatorArray[index];
      let critera = data.valueName + ' ' + data.selectedGroupOperator + ' ' + '"' + data.selectedGroupValue + '"';
      return critera;
    },
    onScroll () {
      window.onscroll = () => {
        if (
          document.documentElement.scrollHeight ===
          document.documentElement.scrollTop + window.innerHeight
        ) {
          this.preiewStore.pageSize += 10;
          this.$store.dispatch('productGroupModule/getProductDetails', this.preiewProduct);
          this.loadmore = false;
        }
      };
    },
  },
  computed: {
    ...mapState('productGroupModule', [
      'productGroupEntityArray'
    ]),
    ...mapState('productGroupModule', {
      previewPopupRes: (state) => {
        return state.previewPopupValues;
      },
      getProductGroupProductsRes: (state) => {
        return state.getProductGroupProducts;
      },
      getProductGroupProductsCountRes: (state) => {
        return state.getProductGroupProductsCount;
      },
      preiewProduct: (state) => {
        return state.preiewProduct;
      },
    })
  },
  watch: {
    getProductGroupProductsRes () {
      this.loadmore = false;
    }
  }
};
</script>
