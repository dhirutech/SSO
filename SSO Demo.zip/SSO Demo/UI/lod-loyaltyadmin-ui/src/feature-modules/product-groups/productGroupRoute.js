import ProductGroupPage from './components/productGroupPage.vue';
import ProductGroupLayout from './components/productGroupLayout.vue';
import ProductGroupList from './components/ProductGroupList.vue';
import ProductGroupDetail from './components/ProductGroupDetail';

const productGroupRoutes = [
  {
    path: '/loyaltyadmin/productGroupPage',
    name: 'ProductreGroupPage',
    component: ProductGroupPage,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/productGroupPage/:id',
    name: 'ProductreGroupPageUpdate',
    component: ProductGroupPage,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/productGroupDetail/:id',
    name: 'ProductGroupDetail',
    component: ProductGroupDetail,
    meta: {
      showNavigation: true
    }
  },
  {
    path: '/loyaltyadmin/productGroupPage/:id/clone',
    name: 'ProductreGroupPageClone',
    component: ProductGroupPage,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/productGroupLayout',
    name: 'ProductGroupLayout',
    component: ProductGroupLayout,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/productGroupList',
    name: 'ProductreGroupList',
    component: ProductGroupList,
    meta: {
      showNavigation: true
    }
  }
];

export default productGroupRoutes;
