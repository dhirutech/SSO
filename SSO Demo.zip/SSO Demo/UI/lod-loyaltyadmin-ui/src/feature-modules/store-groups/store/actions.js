import * as api from '../api/storeGroupApi.js';
import {
  getStoreBusinessEntity,
  getExtensionProperties,
  getValueProperties,
  saveStoreGroupData,
  deleteStoreGroup,
  editStoreGroup,
  storeGroupNameExistsOrNot
} from '../api/storeGroupApi.js';

const getStoreGroupListActions = async ({ commit }, payload) => {
  await api
    .getStoreGroupList(payload)
    .then((res) => {
      commit('getStoreGroupListMutations', res.data.data.storeGroups);
      commit('getStoreGroupCount', res.data.data.storeGroupsCount);
    })
    .catch(() => {
      commit('getStoreGroupCount', 0);
      commit('getStoreGroupListMutations', []);
    });
};

const deleteStoreGroupActions = (context, payload) => {
  return new Promise((resolve, reject) => {
    deleteStoreGroup(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const storeGroupNameExistsOrNotAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    storeGroupNameExistsOrNot(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getStoreBusinessEntityAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getStoreBusinessEntity(payload)
      .then((res) => {
        context.commit('storeBusinessEntityMutation', res.data.data);
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const editStoreGroupAction = async (context, payload) => {
  return new Promise((resolve, reject) => {
    editStoreGroup(payload)
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const getExtensionPropertyValueAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getExtensionProperties(payload)
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const getValuePropertyAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getValueProperties(payload)
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};
const getStoreGroupFilterActions = async (context, filterRequest) => {
  return await api.getStoreGroupFilterData(filterRequest);
};
const storeGroupSearch = async ({ commit }, request) => {
  let response = await api.getFilterSearchAsync(request);
  commit('setStoresGroupSearched', response);
};

const saveStoreGroupDataAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    saveStoreGroupData(payload)
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const getStoreDetails = async ({ commit }, payload) => {
  await api
    .getStoreDetailsRes(payload)
    .then(res => {
      commit('getStoreGroupStoresMutations', res.data.data.stores);
      commit('getStoreGroupStoresCountMutations', res.data.data.totalCount);
    })
    .catch(() => {
      commit('getStoreGroupStoresMutations', []);
      commit('getStoreGroupStoresCountMutations', 0);
    });
};

export default {
  storeGroupNameExistsOrNotAction,
  editStoreGroupAction,
  getValuePropertyAction,
  getStoreGroupListActions,
  getStoreBusinessEntityAction,
  getExtensionPropertyValueAction,
  storeGroupSearch,
  getStoreGroupFilterActions,
  saveStoreGroupDataAction,
  deleteStoreGroupActions,
  getStoreDetails
};
