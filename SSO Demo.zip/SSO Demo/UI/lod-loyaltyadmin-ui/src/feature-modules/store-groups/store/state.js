export default {
  storeGroupDetails: {
    storeGroupId: 0,
    storeGroupName: '',
    storeGroupDescription: '',
    storeGroupCreatedBy: '',
    storeGroupStepper: 1,
    showCancelPopup: false,
    showCreateEntityPopup: false,
  },
  params: {
    searchText: '',
    pageSize: 10,
    pageNumber: 1,
    businessEntityId: 0,
    SortBy: '',
    isDesc: ''
  },
  storeGroupNameExists: false,
  getStoreGroupListMutations: [],
  getStoreGroupCount: 0,
  storeBusinessEntity: [],
  storeGroupAttributeArray: [],
  programEntity: [],
  preiewStore: [],
  showPreviewPopup: false,
  reviewData: {},
  deleteStoreGroupObj: {},
  showDeletePopUp: false,
  showNamePopUp: false,
  deleteStoreGroupName: '',
  previewPopupValues: [],
  getStoreGroupStores: [],
  getStoreGroupStoresCount: 0,

  storeGroupEntityArray: [
    {
      storeGroupDefaultCondition: 'AND',
      storeGroupAndToggled: true,
      storeGroupOrToggled: false,
      storeGroupBusinessEntity: [],
      selectedBusinessEntity: '',
      entityErrorExists: false,
      storeGroupAttibuteOperatorArray: [
        {
          storeGroupAttributeArray: [],
          selectedGroupAttribute: '',
          attributeErrorExists: false,
          storeGroupOperatorArray: [],
          selectedGroupOperator: '',
          operatorErrorExists: false,
          storeGroupValueArray: [],
          selectedGroupValue: '',
          valueErrorExists: false,
          valueName: ''
        }
      ]
    }
  ]
};
