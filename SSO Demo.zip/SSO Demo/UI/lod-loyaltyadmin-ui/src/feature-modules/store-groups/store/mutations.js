const updateStoreGroupStepperMutation = (state, payload) => {
  state.storeGroupDetails.storeGroupStepper = payload;
};

const updateCreatedByNameMutation = (state, payload) => {
  state.storeGroupDetails.storeGroupCreatedBy = payload;
};

const closePopupMutation = (state, payload) => {
  state.storeGroupDetails.showCancelPopup = payload;
};

const previewPopupMutation = (state, payload) => {
  state.showPreviewPopup = payload;
};

const previewPopupValuesMutations = (state, payload) => {
  state.previewPopupValues = payload;
};

const preiewStore = (state, payload) => {
  state.preiewStore = payload;
};

const getStoreGroupStoresMutations = (state, payload) => {
  state.getStoreGroupStores = payload;
};

const getStoreGroupStoresCountMutations = (state, payload) => {
  state.getStoreGroupStoresCount = payload;
};

const getStoreGroupListMutations = (state, payload) => {
  state.getStoreGroupListMutations = payload;
};

const getStoreGroupCount = (state, payload) => {
  state.getStoreGroupCount = payload;
};

const showDeletePopUpDialogueMutation = (state, payload) => {
  state.showDeletePopUp = payload;
};

const showStoreGroupNamePopupMutation = (state, payload) => {
  state.showNamePopUp = payload;
};

const deleteStoreGroupIdMutation = (state, payload) => {
  state.deleteStoreGroupObj = payload;
};

const closeCreateEntityPopupMutation = (state, payload) => {
  state.storeGroupDetails.showCreateEntityPopup = payload;
};

const storeBusinessEntityMutation = (state, payload) => {
  state.storeBusinessEntity = payload;
  state.storeGroupEntityArray[0].storeGroupBusinessEntity = payload;
};

const selectedProgramEntityMutation = (state, payload) => {
  state.programEntity = payload;
};

const clearstoreGroupDetailsMutation = (state, payload) => {
  state.storeGroupDetails = payload;
};

const updatestoreGroupAttributeArrayMutation = (state, payload) => {
  state.storeGroupEntityArray[
    payload.index
  ].storeGroupAttibuteOperatorArray[0].storeGroupAttributeArray =
    payload.attributeArray;
  state.storeGroupEntityArray[
    payload.index
  ].storeGroupAttibuteOperatorArray[0].selectedGroupAttribute =
    payload.attributeArray[0].extensionPropertyId;
};

const updatestoreGroupAttibuteOperatorArrayMutation = (state, payload) => {
  state.storeGroupEntityArray[
    payload.index
  ].storeGroupAttibuteOperatorArray.push(payload);
};

const updatestoreAttibuteOperatorArrayMutation = (state, payload) => {
  state.storeGroupEntityArray[payload.index].storeGroupAttibuteOperatorArray =
    payload.attrArr;
};

const addMoreCriteriaMutation = (state, payload) => {
  state.storeGroupEntityArray.push(payload);
};

const updatestoreGroupDefaultConditionMutation = (state, payload) => {
  state.storeGroupEntityArray[payload.index].storeGroupDefaultCondition =
    payload.operator;
  if (payload.toggled === 'storeGroupAndToggled') {
    state.storeGroupEntityArray[payload.index].storeGroupAndToggled = true;
    state.storeGroupEntityArray[payload.index].storeGroupOrToggled = false;
  }
  if (payload.toggled === 'storeGroupOrToggled') {
    state.storeGroupEntityArray[payload.index].storeGroupAndToggled = false;
    state.storeGroupEntityArray[payload.index].storeGroupOrToggled = true;
  }
};

const updatestoreGroupEntityArrayMutation = (state, payload) => {
  state.storeGroupEntityArray = payload;
};

const updatestoreGroupValueArrayMutation = (state, payload) => {
  state.storeGroupEntityArray[
    payload.entityIndex
  ].storeGroupAttibuteOperatorArray[payload.valueIndex].storeGroupValueArray =
    payload.valueArray;
};

const updateValueNameMutation = (state, payload) => {
  state.storeGroupEntityArray[
    payload.entityIndex
  ].storeGroupAttibuteOperatorArray[payload.valueIndex].valueName =
    payload.valueName;
};

const updatestoreGroupValueMutation = (state, payload) => {
  state.storeGroupEntityArray[
    payload
  ].storeGroupAttibuteOperatorArray[0].storeGroupValueArray = '';
};

const updateAttibuteOperatorArrayMutation = (state, payload) => {
  let arr = [];
  arr.push(payload.operator);
  state.storeGroupEntityArray[
    payload.index
  ].storeGroupAttibuteOperatorArray = arr;
};

const updateErrorsMutation = (state, payload) => {
  state.storeGroupEntityArray[payload].entityErrorExists = false;
  state.storeGroupEntityArray[
    payload
  ].storeGroupAttibuteOperatorArray[0].attributeErrorExists = false;
  state.storeGroupEntityArray[
    payload
  ].storeGroupAttibuteOperatorArray[0].operatorErrorExists = false;
  state.storeGroupEntityArray[
    payload
  ].storeGroupAttibuteOperatorArray[0].valueErrorExists = false;
};

const updateOperatorErrorMutation = (state, payload) => {
  state.storeGroupEntityArray[
    payload.entityIndex
  ].storeGroupAttibuteOperatorArray[
    payload.valueIndex
  ].attributeErrorExists = false;
  state.storeGroupEntityArray[
    payload.entityIndex
  ].storeGroupAttibuteOperatorArray[
    payload.valueIndex
  ].operatorErrorExists = false;
  state.storeGroupEntityArray[
    payload.entityIndex
  ].storeGroupAttibuteOperatorArray[
    payload.valueIndex
  ].valueErrorExists = false;
};

const updatestoreGroupOperatorArrayMutation = (state, payload) => {
  state.storeGroupEntityArray[
    payload.entityIndex
  ].storeGroupAttibuteOperatorArray[
    payload.valueIndex
  ].storeGroupOperatorArray = payload.valueArray;
  state.storeGroupEntityArray[
    payload.entityIndex
  ].storeGroupAttibuteOperatorArray[payload.valueIndex].selectedGroupOperator =
    state.storeGroupEntityArray[
      payload.entityIndex
    ].storeGroupAttibuteOperatorArray[
      payload.valueIndex
    ].storeGroupOperatorArray[0].name;
};
const setStoresGroupSearched = (state, payload) => {
  if (!payload) {
    state.getStoreGroupListMutations = [];
  } else {
    state.getStoreGroupListMutations = payload;
  }
};

const reviewDataMutation = (state, payload) => {
  state.reviewData = payload;
};

const editStoreGroupMutation = (state, payload) => {
  state.storeGroupDetails.storeGroupId = payload.storeGroupDetails.storeGroupId;
  state.storeGroupDetails.storeGroupName =
    payload.storeGroupDetails.storeGroupName;
  state.storeGroupDetails.storeGroupDescription =
    payload.storeGroupDetails.storeGroupDescription;
  state.storeGroupDetails.storeGroupStepper = 1;
  state.storeGroupDetails.showCancelPopup = false;
  state.storeGroupDetails.showCreateEntityPopup = false;
  state.storeGroupEntityArray = payload.storeGroupEntityArray;
};

const editUpdatestoreGroupValueArrayMutation = (state, payload) => {
  state.storeGroupEntityArray[
    payload.entityIndex
  ].storeGroupAttibuteOperatorArray[payload.valueIndex].storeGroupValueArray =
    payload.valueArray;
};

const storeGroupNameExistsMutation = (state, payload) => {
  state.storeGroupNameExists = payload;
};

export default {
  showStoreGroupNamePopupMutation,
  storeGroupNameExistsMutation,
  editUpdatestoreGroupValueArrayMutation,
  editStoreGroupMutation,
  reviewDataMutation,
  updatestoreGroupOperatorArrayMutation,
  updateOperatorErrorMutation,
  updateErrorsMutation,
  updateAttibuteOperatorArrayMutation,
  updatestoreGroupValueMutation,
  updateValueNameMutation,
  updatestoreGroupValueArrayMutation,
  updatestoreGroupEntityArrayMutation,
  addMoreCriteriaMutation,
  updatestoreGroupDefaultConditionMutation,
  updatestoreAttibuteOperatorArrayMutation,
  updatestoreGroupAttibuteOperatorArrayMutation,
  updatestoreGroupAttributeArrayMutation,
  previewPopupMutation,
  updateStoreGroupStepperMutation,
  updateCreatedByNameMutation,
  closePopupMutation,
  getStoreGroupListMutations,
  getStoreGroupCount,
  closeCreateEntityPopupMutation,
  storeBusinessEntityMutation,
  selectedProgramEntityMutation,
  clearstoreGroupDetailsMutation,
  setStoresGroupSearched,
  showDeletePopUpDialogueMutation,
  deleteStoreGroupIdMutation,
  previewPopupValuesMutations,
  getStoreGroupStoresMutations,
  getStoreGroupStoresCountMutations,
  preiewStore
};
