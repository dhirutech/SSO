import Vue from 'vue';

const getStoreGroupList = async payload => {
  let queryString =
  '?ProgramId=' +
  payload.programId +
  '&PageSize=' +
  payload.pageSize +
  '&PageNumber=' +
  payload.pageNumber;
  if (payload.SortBy)
    queryString =
      queryString +
      '&SortColumn=' +
      payload.SortBy +
      '&IsDescending=' +
      (payload.isDesc === true ? 'true' : 'false');
  return await Vue.prototype.$http.get(
    'product/api/v1/storegroup/getall' + queryString
  );
};

const deleteStoreGroup = payload => {
  return Vue.prototype.$http.delete(
    'product/api/v1/storegroup/delete/' + payload
  );
};

const getStoreBusinessEntity = payload => {
  return Vue.prototype.$http.get(
    '/product/api/v1/storedefinitions/businessentities/' + payload
  );
};

const getExtensionProperties = payload => {
  return Vue.prototype.$http.get(
    '/product/api/v2/extensionProperties/stores?brandIds=' + payload
  );
};

const getValueProperties = payload => {
  return Vue.prototype.$http.get(
    '/product/api/v2/extensionProperties/stores/values?ExtensionPropertyId=' +
      payload.extensionPropertyId +
      '&ColumnName=' +
      payload.columnName +
      '&IsExtendedAttribute=' +
      payload.isExtendedAttribute
    // '&ProgramEntityId=' +
    // payload.programEntityId
  );
};
const getStoreGroupFilterData = async FilterGroupRequest => {
  let searchData =
    FilterGroupRequest.searchText !== ''
      ? '&SearchText=' + FilterGroupRequest.searchText
      : '';
  return await Vue.prototype.$http
    .get(
      '/product/api/v1/storegroup/getall?ProgramId=' +
        FilterGroupRequest.programId +
        '&ToDate=' +
        FilterGroupRequest.toDate +
        searchData +
        '&FromDate=' +
        FilterGroupRequest.fromDate +
        '&programEntityId=' +
        FilterGroupRequest.programEntityId +
        '&PageSize=' +
        FilterGroupRequest.pageSize +
        '&PageNumber=' +
        FilterGroupRequest.pageNumber
    )
    .then(res => {
      return res.data.data;
    });
};

const getFilterSearchAsync = async searchGroupRequest => {
  return await Vue.prototype.$http
    .get(
      '/product/api/v1/storegroup/getall?ProgramId=' +
        searchGroupRequest.programId +
        '&searchText=' +
        searchGroupRequest.searchText +
        '&PageSize=' +
        searchGroupRequest.pageSize +
        '&PageNumber=' +
        searchGroupRequest.pageNumber
    )
    .then(res => {
      return res.data.data.storeGroups;
    });
};

const saveStoreGroupData = payload => {
  return Vue.prototype.$http.post(
    'product/api/v1/storegroup',
    payload
  );
};

const editStoreGroup = id => {
  return Vue.prototype.$http.get('product/api/v1/storegroup/' + id);
};

const getStoreDetailsRes = payload => {
  return Vue.prototype.$http.post(
    'product/api/v1/storegroup/previewstore',
    payload[0]
  );
};

const storeGroupNameExistsOrNot = payload => {
  return Vue.prototype.$http.get(
    'product/api/v1/storegroup/' + payload.name + '/' + payload.programId + '/' + payload.storeGroupId
  );
};

export {
  storeGroupNameExistsOrNot,
  editStoreGroup,
  getStoreBusinessEntity,
  saveStoreGroupData,
  getStoreGroupList,
  getExtensionProperties,
  getValueProperties,
  getFilterSearchAsync,
  getStoreGroupFilterData,
  deleteStoreGroup,
  getStoreDetailsRes
};
