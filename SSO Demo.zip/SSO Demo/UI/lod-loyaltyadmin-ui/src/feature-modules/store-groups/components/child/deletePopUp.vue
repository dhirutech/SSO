<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closePopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ $t("cardTitle") }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <v-alert
                  class="b-alert-error"
                  type="error"
                  :dismissible="false"
                >
                  <v-row class="alert-block align-center havebtn" no-gutters>
                    <v-col class="alert-block__body">
                      {{ $t("alertMsg") }} {{ deleteStoreGroupObj.name }}?
                    </v-col>
                  </v-row>
                </v-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="org_btn_cancelDeleteDialog"
            data-qe-id="communicationManagement_no_btn"
            text
            class="cancel no-ripple"
            @click="closeDeleteEntityPopupWhenClickNo()"
            >{{ $t("noBtnTextPopUp") }}</v-btn
          >
          <v-btn
            id="org_btn_deleteDeleteDialog"
            data-qe-id="communicationManagement_yes_btn"
            class="primaryctabtn text-uppercase"
            title
            @click="navigateToList()"
            >{{ $t("yesBtnTextPopUp") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { storeGroupListObj } from '../../../../i18n/language.js';
import { mapState } from 'vuex';
export default {
  data () {
    return {
      dialog: false
    };
  },
  props: {
    params: {
      type: Array,
      defualt: []
    },
    storeGroupListData: {
      type: Array,
      defualt: []
    }
  },
  components: {
    BrierleyDialogbox
  },
  i18n: storeGroupListObj,
  methods: {
    closePopup () {
      this.$store.commit(
        'storeGroupModule/showDeletePopUpDialogueMutation',
        false
      );
    },
    navigateToList () {
      this.$store
        .dispatch(
          'storeGroupModule/deleteStoreGroupActions',
          this.deleteStoreGroupObj.id
        )
        .then(res => {
          if (res.status === 201 || res.status === 200) {
            this.$store.commit(
              'storeGroupModule/showDeletePopUpDialogueMutation',
              false
            );
            // let programIdParams = this.$root.GlobalStoreEventStore.getters
            //  .getProgram.programId;
            //   this.params.programId = this.$root.GlobalStoreEventStore.getters.getProgram.programId;
            this.params.programId = localStorage.getItem('programId');
            this.$store.dispatch(
              'storeGroupModule/getStoreGroupListActions',
              this.params
            );
          }
        });
    },
    closeDeleteEntityPopupWhenClickNo () {
      this.closePopup();
    }
  },
  computed: {
    ...mapState('storeGroupModule', ['deleteStoreGroupObj'])
  }
};
</script>
