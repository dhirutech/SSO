<template>
  <v-row class="flex-column" no-gutter>
    <brierley-table-module v-if="storeGroupList.length > 0">
      <template v-slot:tablehead>
        <tr class="text-left">
          <th
            v-for="item in header"
            :key="item.CreatedDate"
            @click="
              item.name == 'Name' ||
              item.name == 'Description' ||
              item.name == 'CreatedDate' ||
              item.name == 'ProgramEntityName'
                ? sortBy(item)
                : null
            "
            class="text-left"
            :width="item.width"
          >
            {{ item.text }}
            <v-icon
              v-if="item.sort != ''"
              small
              v-bind:class="{
                down: item.sort === 'asc',
                up: item.sort === 'desc'
              }"
              class="arrow uparw"
              >arrow_upward</v-icon
            >
          </th>
        </tr>
      </template>
      <template v-slot:tablebody>
        <tr v-for="(item, i) in storeGroupListData" :key="i">
          <td>
            <h4
              class="primary-text font15 text-uppercase fbold elipsis-fullwidth"
            >
              {{ item.name }}
            </h4>
            <!-- <v-row class="head-name user-display-name" no-gutters>
              <v-col>
                <v-row no-gutters>
                  <v-col class="max-width-40"> -->
            <!-- <v-icon id="prom_table_bookmark_true" class="cursor-p"
                      >bookmark</v-icon
                    > -->
            <!-- <v-icon
                      id="prom_table_bookmark_false"
                      class="cursor-p"
                      v-else
                      >bookmark_border</v-icon
                    > -->
            <!-- </v-col>
                  <v-col class="elipsis-twoline text-uppercase">
                    {{ item.name }}
                  </v-col>
                </v-row>
              </v-col>
            </v-row> -->
          </td>
          <!-- <td>
            {{ item.storeGroupId }}
          </td> -->
          <!-- <td>{{ item.storesCount }}</td> -->
          <td>{{ item.description }}</td>
          <!-- <td>
            <div :title="item.description" class="elipsis-description">
              {{ item.authorFullName }}
            </div>
          </td> -->
          <td>{{ format_date(item.createdDate) }} {{ localTimeZone }}</td>
          <td>
            {{ item.programEntityName }}
          </td>
          <td>
            <brierley-status status="Active"></brierley-status>
            <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
              <v-col>
                <brierleyCardIcons>
                  <template v-slot:action-icons>
                    <span :title="$t('viewDetails')" class="active">
                      <v-icon>fe fe-eye</v-icon>
                      <span class="viewdetails-icon">{{
                        $t("viewDetails")
                      }}</span>
                    </span>
                    <span
                      :title="$t('editLabel')"
                      data-qe-id="edit_btn"
                      @click="editStoreGroup(item)"
                    >
                      <v-icon id="viewuser_edit-icon" class="blackicon"
                        >fe fe-edit</v-icon
                      >
                      <span class="edit-icon" id="viewuser-edit">{{
                        $t("editLabel")
                      }}</span>
                    </span>
                    <span
                      :title="$t('cloneLabel')"
                      @click="cloneStoreGroup(item)"
                    >
                      <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                        >feather-icon fe fe-copy</v-icon
                      >
                      <span class="clone-icon">
                        {{ $t("cloneLabel") }}
                      </span>
                    </span>
                    <span
                      :title="$t('deleteText')"
                      data-qe-id="delete_btn"
                      @click="deleteStoreGroup(item)"
                    >
                      <v-icon class="blackicon cursor-p">fe fe-trash-2</v-icon>
                      <span class="delete-icon">{{ $t("deleteText") }}</span>
                    </span>
                  </template>
                </brierleyCardIcons>
              </v-col>
            </v-row>
          </td>
        </tr>
      </template>
    </brierley-table-module>
  </v-row>
</template>

<script>
import _ from 'lodash';
import {
  BrierleyCardIcons,
  BrierleyTableModule,
  BrierleyStatus
} from '@brierley/SharedComponents';
import { storeGroupListObj } from './../../../../i18n/language.js';
import moment from 'moment-timezone';
import { mapState } from 'vuex';
export default {
  data () {
    return {
      localTimeZone: '',
      sortKey: ['CreatedDate'],
      sortOrder: ['desc'],
      isToggled: false,
      changeColor: false,
      newSortObj: null,
      header: [
        { name: 'Name', text: this.$t('storeGroupNameLabel'), sort: '' },
        // { name: 'batchTemplate', text: this.$t('storeGroupCode'), sort: '', width: '' },
        // {
        //   name: 'encryptionKey',
        //   text: this.$t('storesCount'),
        //   sort: '',
        //   width: ''
        // },
        {
          name: 'Description',
          text: this.$t('storeGroupDescription'),
          sort: '',
          width: ''
        },
        {
          name: 'CreatedDate',
          text: this.$t('createdOnText'),
          sort: 'desc',
          width: ''
        },
        {
          name: 'ProgramEntityName',
          text: this.$t('programEntityLabel'),
          sort: ''
        },
        { name: 'status', text: this.$t('statusLabel'), sort: '' }
      ],
      campaignslist: [
        {
          name: 'Encryption1',
          batchTemplate: 'Product',
          encryptionKey: 'Encryption 1',
          location: 'Location 1',
          description: 'Lorem Ipsum is simply dummy tex...',
          createdDate: 'Jan 31st 2019  12:00 AM EST',
          editedDate: 'DEC 31st 2019  12:00 AM EST'
        },
        {
          name: 'PRODUCTS',
          batchTemplate: 'Member',
          encryptionKey: 'Encryption 1',
          location: 'Location 1',
          description: 'Lorem Ipsum is simply dummy tex...',
          createdDate: 'Jan 31st 2019  12:00 AM EST',
          editedDate: 'DEC 31st 2019  12:00 AM EST'
        }
      ]
    };
  },
  components: {
    BrierleyCardIcons,
    BrierleyTableModule,
    BrierleyStatus
  },
  i18n: storeGroupListObj,
  props: {
    storeGroupListData: {
      type: Array,
      defualt: []
    },
    filterResult: {
      type: Array,
      default: () => 0
    }
  },
  mounted  () {
    let sortBy = localStorage.getItem('sortBy');
    let order = localStorage.getItem('order');
    if (sortBy !== null) {
      this.header.forEach(x => {
        if (x.name === sortBy) {
          x.sort = order;
        } else {
          x.sort = '';
        }
      });
    } else {
      this.header[2].sort = 'desc';
    }
  },
  methods: {
    editStoreGroup (val) {
      let programId = localStorage.getItem('programId');
      this.$store
        .dispatch('storeGroupModule/getStoreBusinessEntityAction', programId)
        .then(() => {
          let obj = [
            {
              name: val.programEntityName,
              businessEntityId: val.programEntityId
            }
          ];
          this.$store.commit(
            'storeGroupModule/selectedProgramEntityMutation',
            obj
          );
          this.$router.push({
            name: 'StoreGroupPageEdit',
            query: { res: val.storeGroupId }
          });
        });
    },
    cloneStoreGroup (val) {
      let programId = localStorage.getItem('programId');
      this.$store
        .dispatch('storeGroupModule/getStoreBusinessEntityAction', programId)
        .then(() => {
          let obj = [
            {
              name: val.programEntityName,
              businessEntityId: val.programEntityId
            }
          ];
          this.$store.commit(
            'storeGroupModule/selectedProgramEntityMutation',
            obj
          );
          this.$router.push({
            name: 'StoreGroupPageClone',
            query: { res: val.storeGroupId }
          });
        });
    },
    sortBy: function (item) {
      let i = this.header.indexOf(item);
      for (let j = 0; j < this.header.length; j++) {
        if (j === i) {
          this.header[j].sort =
            this.header[j].sort === '' || this.header[j].sort === 'desc'
              ? 'asc'
              : 'desc';
        } else {
          this.header[j].sort = '';
        }
      }
      this.sortKey = this.header[i].name;
      this.sortOrder = this.header[i].sort;
      this.arrowToggle();
      this.newSortObj = {
        SortBy: this.header[i].name,
        isDesc: this.header[i].sort === 'desc' ? true : false
      };
      this.params.programId = localStorage.getItem('programId');
      this.params.SortBy = this.newSortObj.SortBy;
      this.params.isDesc = this.newSortObj.isDesc;
      localStorage.setItem('sortBy', this.newSortObj.SortBy);
      localStorage.setItem('order', this.newSortObj.isDesc);
      let requestForLazyLoading = { ...this.params };
      this.$store.dispatch(
        'storeGroupModule/getStoreGroupListActions',
        requestForLazyLoading
      );
    },
    arrowToggle () {
      this.isToggled = !this.isToggled;
    },
    deleteKey (index) {
      this.campaignslist.splice(index, 1);
    },
    editNav (encryptionItem) {
      this.$store.dispatch(
        'batchImportModule/getEncryptionKey',
        encryptionItem
      );
      this.$router.push('/loyaltyadmin/editEncryption');
    },
    format_date (value) {
      if (value) {
        let localZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        this.localTimeZone = moment()
          .tz(localZone)
          .zoneAbbr();
        return moment(String(value)).format('MMM Do YYYY, h:mm A');
      }
    },
    deleteStoreGroup (val) {
      this.$store.commit(
        'storeGroupModule/showDeletePopUpDialogueMutation',
        true
      );
      let deleteStoreGroupObj = {
        id: val.storeGroupId,
        name: val.name
      };
      this.$store.commit(
        'storeGroupModule/deleteStoreGroupIdMutation',
        deleteStoreGroupObj
      );
    }
  },
  computed: {
    ...mapState('storeGroupModule', ['params']),
    storeGroupList: {
      get () {
        return this.filterResult
          ? this.filterResult
          : this.storeGroupListData.filter(item => {
            return item.status === true;
          });
      }
    }
  }
};
</script>
