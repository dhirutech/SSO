<template>
  <brierley-inner-view>
    <template v-slot:header>
      <v-flex class="toggle-menu-custom">
        <v-btn class="no-ripple iconbtn" text>
          <v-icon>
            fe-menu
          </v-icon>
        </v-btn>
      </v-flex>
      <span class="inner-head">{{ storeGroupName }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        data-qe-id="commmsgdetails_routerpush"
        v-if="storeGroupDetails.storeGroupStepper <= 3"
        text
        @click.native="openDialog()"
      >
        <v-icon>mdi-close</v-icon>{{ $t("closeTxt") }}
      </v-btn>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        data-qe-id="commmsgdetails_routerpush"
        v-if="storeGroupDetails.storeGroupStepper === 4"
        text
        @click.native="$router.push('/loyaltyadmin/storeGroupList')"
      >
        <v-icon>mdi-close</v-icon>{{ $t("closeTxt") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <cancel-pop-up-store-group v-if="storeGroupDetails.showCancelPopup" />
        <create-entity-popup v-if="storeGroupDetails.showCreateEntityPopup"/>
      <store-group-name-popup v-if="showNamePopUp"/>
      <brierley-primary-stepper
        :currentStep="storeGroupDetails.storeGroupStepper"
        :stepperSize="4"
        class="mt-1"
      >
        <template v-slot:stepper-steps>
          <v-stepper-step step="1">{{ $t("basicInfo") }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="2">{{ $t("criteriaTxt") }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="3">{{ $t("reviewTxt") }}</v-stepper-step>
        </template>
        <template slot="stepper-content">
          <v-stepper-items>
            <v-stepper-content step="1">
              <Validation-Observer v-slot="{ handleSubmit }">
                <form id="basic_form" @submit.prevent="handleSubmit(onsubmit)">
                  <basic-info
                    v-if="storeGroupDetails.storeGroupStepper === 1"
                  />
                </form>
              </Validation-Observer>
            </v-stepper-content>
            <v-stepper-content step="2">
              <criteria-creation-view
                v-if="storeGroupDetails.storeGroupStepper === 2"
              />
            </v-stepper-content>
            <v-stepper-content step="3">
              <store-review v-if="storeGroupDetails.storeGroupStepper === 3" />
            </v-stepper-content>
            <v-stepper-content step="4">
              <v-row
                class="flex-column"
                no-gutters
                v-if="storeGroupDetails.storeGroupStepper === 4"
              >
                <v-col>
                  <brierley-form-title
                   :formTitle="$t('successTxt')"
                   :infoIcon="false"
                  ></brierley-form-title>
                </v-col>
                <v-col class="bpt5">
                  <brierley-alert
                    :isSiteLevel="true"
                    alertType="success"
                    :alertBody="alertMessage"
                    :alertHeader="$t('successAlert')"
                    icon="done"
                  ></brierley-alert>
                </v-col>
              </v-row>
            </v-stepper-content>
          </v-stepper-items>
        </template>
      </brierley-primary-stepper>
    </template>
    <template v-slot:footer>
      <v-btn
        id="user_btn_cancel"
        text
        v-if="storeGroupDetails.storeGroupStepper <= 3"
        class="cancel no-ripple bmt2 bmr5"
        data-qe-id="commmsgdetails_cancelmsg"
        @click="openDialog()"
        >{{ $t("cancelTxt") }}</v-btn
      >
      <v-btn
        form="basic_form"
        type="submit"
        class="primaryctabtn bmt2 bml2"
        v-if="storeGroupDetails.storeGroupStepper === 1"
        data-qe-id="commmsgdetails_nextdeliverybtn"
        >{{ $t("nextCriteriaBtn") }}</v-btn
      >
      <v-btn
        class="primaryctabtn bmt2 bml2"
        v-if="storeGroupDetails.storeGroupStepper === 2"
        @click="goToReview()"
      >
        {{ $t("nxtReviewBtn") }}
      </v-btn>
      <v-btn
        form="basic_form"
        type="submit"
        class="primaryctabtn bmt2 bml2"
        v-if="storeGroupDetails.storeGroupStepper === 3 && $route.name !== 'StoreGroupPageEdit'"
        @click="saveStoreGroupData()"
      >
        {{ $t("createGroupBtn") }}
      </v-btn>
      <v-btn
        form="basic_form"
        type="submit"
        class="primaryctabtn bmt2 bml2"
        v-if="storeGroupDetails.storeGroupStepper === 3 && $route.name === 'StoreGroupPageEdit'"
        @click="saveStoreGroupData()"
      >
        {{ $t("udpateGroupBtn") }}
      </v-btn>
    </template>
    <template v-slot:footer-redirect v-if="storeGroupDetails.storeGroupStepper === 4">
      <v-btn
      @click.native="$router.push('/loyaltyadmin/storeGroupList')"
        data-qe-id="communication_commlistbtn"
        id="user_btn_goToUsers"
        class="primaryctabtn bmt2"
        >{{ $t('closeTxt') }}</v-btn
      >
    </template>
     <template v-if="storeGroupDetails.storeGroupStepper === 4 && $route.name !== 'StoreGroupPageEdit'" v-slot:footer-notes>
      <div class="bmt7">
        <v-row class="bpt2 bmt2"></v-row>
        <span
          id="LabelNextStepsText"
          class="font15 fbold text-uppercase bpt1"
          >{{ $t('createAnotherStoreGroup') }}</span
        >
      </div>
      <div class="bmt1">
        <span
          id="LabelCreateText"
          data-qe-id="communication_gotosetup"
          class="font15 label-create-txt"
        >
          {{ $t('createStoreGroupText') }}
          <a
            id="BtnCampaigns"
            v-on:click="openDialogClickHere"
            data-qe-id="communication_gotosetupbtn"
          >
            <span id="LabelFooterText" class="font15 fbold primary-text pl-2">{{
              $t('clickHereText')
            }}</span>
          </a>
        </span>
      </div>
    </template>
  </brierley-inner-view>
</template>
<script>
import { mapState } from 'vuex';
import BasicInfo from './child/basicInfo.vue';
import CriteriaCreationView from './child/criteriaCreationView.vue';
import StoreReview from './child/storeGroupReview.vue';
import createEntityPopup from '../components/child/createEntityPopup';
import cancelPopUpStoreGroup from './child/cancelPopUpStoreGroup.vue';
import storeGroupNamePopup from './child/storeGroupNamePopup.vue';
import { storeGroupLayoutObj } from '../../../i18n/language.js';
import Vue from 'vue';
import {
  BrierleyInnerView,
  BrierleyPrimaryStepper,
  BrierleyFormTitle,
  brierleyAlert
} from '@brierley/SharedComponents';
export default {
  components: {
    BrierleyInnerView,
    BrierleyPrimaryStepper,
    BasicInfo,
    CriteriaCreationView,
    StoreReview,
    cancelPopUpStoreGroup,
    BrierleyFormTitle,
    brierleyAlert,
    storeGroupNamePopup,
    createEntityPopup
  },
  computed: {
    ...mapState('storeGroupModule', {
      storeGroupDetails: state => {
        return state.storeGroupDetails;
      },
      reviewData: state => {
        return state.reviewData;
      },
      storeBusinessEntity: state => {
        return state.storeBusinessEntity;
      },
      storeGroupAttributeArray: state => {
        return state.storeGroupAttributeArray;
      },
      storeGroupEntityArray: state => {
        return state.storeGroupEntityArray;
      },
      showNamePopUp: state =>{
        return state.showNamePopUp;
      },
      programEntity: state => {
        return state.programEntity;
      },
      storeGroupName () {
        if (this.$route.name === 'StoreGroupPage') {
          return (
            this.$t('newStoreGroup') +
            ' ' +
            this.programEntity[0].name.toUpperCase()
          );
        } else if (this.$route.name === 'StoreGroupPageEdit') {
          return (
            this.$t('editStoreGroup') +
            ' ' +
            this.programEntity[0].name.toUpperCase()
          );
        } else if (this.$route.name === 'StoreGroupPageClone') {
          return (
            this.$t('cloneStoreGroup') +
            ' ' +
            this.programEntity[0].name.toUpperCase()
          );
        }
      },
      alertMessage () {
        if (this.$route.name === 'StoreGroupPage') {
          return this.$t('textMessgae') + ' '+ this.storeGroupDetails.storeGroupName +' '+ this.$t('createdText');
        } else if (this.$route.name === 'StoreGroupPageEdit') {
          return this.$t('storeGroupEditMessgae') + ' '+ this.storeGroupDetails.storeGroupName +' '+ this.$t('editTextMessage');
        } else if (this.$route.name === 'StoreGroupPageClone') {
          return this.$t('textMessgae') + ' ' +this.storeGroupDetails.storeGroupName + ' '+ this.$t('createdText');

        }
      }
    })
  },
  i18n: storeGroupLayoutObj,
  created () {
    this.$store.commit('storeGroupModule/showStoreGroupNamePopupMutation', false);
    this.$store.commit('storeGroupModule/storeGroupNameExistsMutation', false);
    this.$store.commit(
      'storeGroupModule/closeCreateEntityPopupMutation',
      false
    );
    if (
      this.$route.name === 'StoreGroupPageEdit' ||
      this.$route.name === 'StoreGroupPageClone'
    ) {
      this.$store.commit('storeGroupModule/updateStoreGroupStepperMutation', 1);
      this.$store.commit('storeGroupModule/closePopupMutation', false);
      this.$store.commit('storeGroupModule/previewPopupMutation', false);
      this.$store
        .dispatch(
          'storeGroupModule/editStoreGroupAction',
          this.$route.query.res
        )
        .then(res => {
          let storeGroupDetails = {};
          storeGroupDetails.storeGroupDescription = res.data.data.description,
          storeGroupDetails.storeGroupId = res.data.data.storeGroupId;
          if (this.$route.name === 'StoreGroupPageEdit') {
            storeGroupDetails.storeGroupId = res.data.data.storeGroupId;
            storeGroupDetails.storeGroupName = res.data.data.name;
          } else {
            storeGroupDetails.storeGroupName = `copy of ${res.data.data.name}`;
            storeGroupDetails.storeGroupId = 0;
          }
          let storeGroupEntityArray = [];
          let self = this;
          async function getCriteria () {
            const promises = res.data.data.crieteria.map(async (val, i) => {
              if (i === 0) {
                storeGroupEntityArray[i] = {
                  storeGroupDefaultCondition: val.operator === 0 ? 'AND' : 'OR',
                  storeGroupAndToggled: true,
                  storeGroupOrToggled: false,
                  storeGroupBusinessEntity: self.storeBusinessEntity,
                  selectedBusinessEntity: val.programEntityId,
                  entityErrorExists: false,
                  storeGroupAttibuteOperatorArray: []
                };
              } else if (i >= 1) {
                storeGroupEntityArray[i] = {
                  storeGroupDefaultCondition: val.operator === 1 ? 'AND' : 'OR',
                  storeGroupAndToggled: val.operator === 1 ? true : false,
                  storeGroupOrToggled: val.operator === 2 ? true : false,
                  storeGroupBusinessEntity: self.storeBusinessEntity,
                  selectedBusinessEntity: val.programEntityId,
                  entityErrorExists: false,
                  storeGroupAttibuteOperatorArray: []
                };
              }
              let attributeValues = await Vue.prototype.$http.get(
                `/product/api/v2/extensionProperties/stores?brandIds=${val.programEntityId}`
              );
              val.criteriaList.map(async (arr, j) => {
                let x = attributeValues.data.data.filter(
                  x => x.columnName === arr.criteriaType
                );
                let operatorArray = [];
                if (x[0].dataType === 'String') {
                  operatorArray = [
                    { name: 'Matches Exactly', value: 8 },
                    { name: 'Contains', value: 9 },
                    { name: 'Starts With', value: 10 }
                  ];
                } else if (x[0].dataType === 'Boolean') {
                  operatorArray = [
                    { name: 'Is', value: 6 },
                    { name: 'Is Not', value: 7 }
                  ];
                } else if (
                  x[0].dataType === 'DateTime' ||
                  x[0].dataType === 'Number'
                ) {
                  operatorArray = [
                    { name: 'Equals', value: 0 },
                    { name: 'Less Than', value: 1 },
                    { name: 'Less Than or Equals', value: 2 },
                    { name: 'Greater Than', value: 3 },
                    {
                      name: 'Greater Than or Equals',
                      value: 4
                    },
                    { name: 'Does Not Equal', value: 5 }
                  ];
                }
                let selectedOperator = operatorArray.filter(
                  x => x.value === arr.operator
                );
                storeGroupEntityArray[i].storeGroupAttibuteOperatorArray[j] = {
                  storeGroupAttributeArray: attributeValues.data.data,
                  selectedGroupAttribute: x[0].extensionPropertyId,
                  attributeErrorExists: false,
                  storeGroupOperatorArray: operatorArray,
                  selectedGroupOperator: selectedOperator[0].name,
                  operatorErrorExists: false,
                  storeGroupValueArray: [],
                  selectedGroupValue: arr.criteriaValue,
                  valueErrorExists: false,
                  valueName: ''
                };
              });
            });
            await Promise.all(promises);
            let obj = {
              storeGroupDetails: storeGroupDetails,
              storeGroupEntityArray: storeGroupEntityArray
            };
            self.$store.commit('storeGroupModule/editStoreGroupMutation', obj);
          }
          getCriteria();
        });
    } else if (this.$route.name === 'StoreGroupPage') {
      let arr = [
        {
          storeGroupDefaultCondition: 'AND',
          storeGroupAndToggled: true,
          storeGroupOrToggled: false,
          storeGroupBusinessEntity: this.storeBusinessEntity,
          selectedBusinessEntity: '',
          entityErrorExists: false,
          storeGroupAttibuteOperatorArray: [
            {
              storeGroupAttributeArray: [],
              selectedGroupAttribute: '',
              attributeErrorExists: false,
              storeGroupOperatorArray: [],
              selectedGroupOperator: '',
              operatorErrorExists: false,
              storeGroupValueArray: [],
              selectedGroupValue: '',
              valueErrorExists: false,
              valueName: ''
            }
          ]
        }
      ];
      this.$store.commit(
        'storeGroupModule/updatestoreGroupEntityArrayMutation',
        arr
      );
      this.$store.commit('storeGroupModule/updateStoreGroupStepperMutation', 1);
      this.$store.commit('storeGroupModule/closePopupMutation', false);
      this.$store.commit('storeGroupModule/previewPopupMutation', false);
      this.$store.commit('storeGroupModule/clearstoreGroupDetailsMutation', {
        storeGroupName: '',
        storeGroupDescription: '',
        storeGroupCreatedBy: '',
        storeGroupStepper: 1,
        showCancelPopup: false,
        showCreateEntityPopup: false
      });
    }
  },
  mounted () {
    this.$store.commit(
      'storeGroupModule/updateCreatedByNameMutation',
      this.$root.GlobalStoreEventStore.state.intialUserProfileDetails
        .firstName +
        ' ' +
        this.$root.GlobalStoreEventStore.state.intialUserProfileDetails.lastName
    );
  },
  data () {
    return {
      success: false
    };
  },
  methods: {
    errorCriteria () {
      let errorCount = 0;
      let extensionArray = this.storeGroupEntityArray.filter(obj => {
        if (
          obj.selectedBusinessEntity === null ||
          obj.selectedBusinessEntity === '' ||
          obj.selectedBusinessEntity === undefined
        ) {
          obj.entityErrorExists = true;
          errorCount++;
        } else {
          obj.entityErrorExists = false;
        }
        let attributeArray = obj.storeGroupAttibuteOperatorArray.filter(
          item => {
            if (
              item.selectedGroupAttribute === null ||
              item.selectedGroupAttribute === '' ||
              item.selectedGroupAttribute === undefined
            ) {
              item.attributeErrorExists = true;
              errorCount++;
            } else {
              item.attributeErrorExists = false;
            }
            if (
              item.selectedGroupOperator === null ||
              item.selectedGroupOperator === '' ||
              item.selectedGroupOperator === undefined
            ) {
              item.operatorErrorExists = true;
              errorCount++;
            } else {
              item.operatorErrorExists = false;
            }
            if (
              item.selectedGroupValue === null ||
              item.selectedGroupValue === '' ||
              item.selectedGroupValue === undefined
            ) {
              item.valueErrorExists = true;
              errorCount++;
            } else {
              item.valueErrorExists = false;
            }
          }
        );
      });
      return errorCount;
    },
    goToReview () {
      const count = this.errorCriteria();
      if (count === 0) {
        let storeGroupData = {};
        let criteria = [];
        let programId = localStorage.getItem('programId');
        storeGroupData.storeGroupId = this.storeGroupDetails.storeGroupId
          ? this.storeGroupDetails.storeGroupId
          : 0;
        storeGroupData.name = this.storeGroupDetails.storeGroupName;
        storeGroupData.description = this.storeGroupDetails.storeGroupDescription;
        storeGroupData.businessEntityId = this.programEntity[0].businessEntityId;
        storeGroupData.programId = programId;
        this.storeGroupEntityArray.forEach((val, i) => {
          let andOrCondition = 0;
          if (i === 0) {
            criteria[i] = {
              operator: andOrCondition,
              programEntityId: val.selectedBusinessEntity,
              criteriaList: []
            };
          } else if (i >= 1) {
            criteria[i] = {
              operator: val.storeGroupDefaultCondition === 'AND' ? 1 : 2,
              programEntityId: val.selectedBusinessEntity,
              criteriaList: []
            };
          }
          val.storeGroupAttibuteOperatorArray.forEach((arr, j) => {
            let attributeValue = arr.storeGroupAttributeArray.filter(
              x => x.extensionPropertyId === arr.selectedGroupAttribute
            );
            let operatorValue = arr.storeGroupOperatorArray.filter(
              x => x.name === arr.selectedGroupOperator
            );
            criteria[i].criteriaList[j] = {
              criteriaType: attributeValue[0].columnName,
              operator: operatorValue[0].value,
              criteriaValue: arr.selectedGroupValue,
              isExtensionProperty: attributeValue[0].isExtendedAttribute
            };
          });
        });
        storeGroupData.criteria = [...criteria];
        this.$store.commit(
          'storeGroupModule/reviewDataMutation',
          storeGroupData
        );
        this.$store.commit(
          'storeGroupModule/updateStoreGroupStepperMutation',
          this.storeGroupDetails.storeGroupStepper += 1
        );
      }
    },
    saveStoreGroupData () {
      let programId = localStorage.getItem('programId');
      let obj = {
        name: this.storeGroupDetails.storeGroupName,
        programId: programId,
        storeGroupId: this.storeGroupDetails.storeGroupId ? this.storeGroupDetails.storeGroupId : 0
      };
      this.$store.dispatch('storeGroupModule/storeGroupNameExistsOrNotAction', obj).then((res)=>{
        if (res.status === 200 || res.status === 201) {
          this.$store
            .dispatch('storeGroupModule/saveStoreGroupDataAction', this.reviewData)
            .then(res => {
              if (res.status === 201 || res.status === 200) {
                if (this.storeGroupDetails.storeGroupStepper === 3) {
                  this.$store.commit(
                    'storeGroupModule/updateStoreGroupStepperMutation',
                    this.storeGroupDetails.storeGroupStepper += 1
                  );
                }
              }
            })
            .catch(error => {
              return error.response;
            });
        }
      }).catch((err)=>{
        if (err.response.status === 400) {
          this.$store.commit(
            'storeGroupModule/showStoreGroupNamePopupMutation',
            true
          );
        }
      });
    },
    onsubmit () {
      if (this.storeGroupDetails.storeGroupStepper < 3) {
        let programId = localStorage.getItem('programId');
        let obj = {
          name: this.storeGroupDetails.storeGroupName,
          programId: programId,
          storeGroupId: this.storeGroupDetails.storeGroupId ? this.storeGroupDetails.storeGroupId : 0
        };
        this.$store.dispatch('storeGroupModule/storeGroupNameExistsOrNotAction', obj).then((res)=>{
          if (res.status === 200 || res.status === 201) {
            this.$store.commit(
              'storeGroupModule/updateStoreGroupStepperMutation',
              this.storeGroupDetails.storeGroupStepper += 1
            );
          }
        }).catch((err)=>{
          if (err.response.status === 400) {
            this.$store.commit(
              'storeGroupModule/storeGroupNameExistsMutation',
              true
            );
          }
        });
      } else {
        this.success = true;
      }
    },
    openDialog () {
      this.$store.commit('storeGroupModule/closePopupMutation', true);
    },
    openDialogClickHere () {
      let programId = localStorage.getItem('programId');
      this.$store.dispatch(
        'storeGroupModule/getStoreBusinessEntityAction',
        programId
      );
      this.$store.commit(
        'storeGroupModule/closeCreateEntityPopupMutation',
        true
      );
    },
  }
};
</script>
