<template>
  <v-col>
    <v-row class="flex-column" no-gutters>
      <v-col class="loyalty-users-common">
        <v-row class="flex-column bpt4" no-gutters>
          <v-col>
            <brierley-page-headings
              pageSubHeading="STORE GROUPS"
              :pageSecondaryHeading="
                `(${storeGroupCount} ${$t('storeGroups')})`
              "
            ></brierley-page-headings>
          </v-col>
        </v-row>
      </v-col>
      <v-col>
        <v-row class="gen2-search-filter bpt3" no-gutters>
          <v-col class="text-left" cols="5">
            <v-text-field
              autocomplete="off"
              class="search-field bmb0"
              :label="$t('searchlabelTxt')"
              prepend-inner-icon="mdi-magnify"
              v-model="searchQuery"
              @input="isTyping = true"
            ></v-text-field>
          </v-col>
          <v-col cols="7" class="text-right align-self-center">
            <brierley-filter
              v-on:click.native="isHidden = !isHidden"
            ></brierley-filter>
            <div class="bmr1 d-inline-block">
              <brierley-view-option
                :viewList="cardlist"
                @viewChanged="viewType = $event"
              ></brierley-view-option>
            </div>
            <v-btn text class="primaryctabtn no-ripple" @click="openDialog()">{{
              $t("createStoreGroup")
            }}</v-btn>
          </v-col>
          <v-col cols="12" class="filter-dropdown bmt1">
            <!-- <brierley-filter-result v-if="isHidden">
                <template v-slot:body-content>
                </template>
                <template v-slot:footer>
                  <v-btn
                    text
                    title="Clear & Close"
                    class="mr-5 cancel bmt3"
                    id="viewuser_btn_clear"
                    >{{ $t('clearBtnText') }}</v-btn
                  >
                  <v-btn
                    title="Apply Filters"
                    depressed
                    class="next bmt3 primaryctabtn"
                    >{{ $t('filterBtnText') }}</v-btn
                  >
                </template>
              </brierley-filter-result> -->
          </v-col>
        </v-row>
      </v-col>
      <v-col cols="12" class="filter-dropdown">
        <brierley-filter-result v-if="isHidden">
          <template v-slot:body-content>
            <v-row no-gutters class="bmb6">
              <v-col cols="3" class="bmr6">
                <h3>{{ $t("datRange") }}</h3>
                <v-row class="main-wrapper__header">
                  <v-col cols="12" class="todate">
                    <v-menu
                      id="prom_promotions_startDatePopup"
                      ref="fromDateMenu"
                      v-model="fromDateMenu"
                      :close-on-content-click="false"
                      :return-value.sync="searchRequest.fromDate"
                      transition="scale-transition"
                      offset-y
                      min-width="290px"
                    >
                      <template v-slot:activator="{ on }">
                        <v-text-field
                          id="prom_promotioins_filterStartRangeFormated"
                          readonly
                          v-model="searchRequest.fromDate"
                          :label="$t('fromlabelTxt')"
                          append-icon="mdi-calendar-range"
                          v-on="on"
                          class="darktxtfield__light"
                          filled
                        ></v-text-field>
                      </template>
                      <v-date-picker
                        id="prom_promotions_filterStartRange"
                        v-model="searchRequest.fromDate"
                        no-title
                        scrollable
                      >
                        <v-spacer></v-spacer>
                        <v-btn
                          id="prom_promotions_btnCancel"
                          text
                          color="primary"
                          @click="fromDateMenu = false"
                          >{{ $t("cancelText") }}</v-btn
                        >
                        <v-btn
                          text
                          id="prom_promotions_btnOk"
                          color="primary"
                          @click="fromDateSubmit()"
                          >{{ $t("okText") }}</v-btn
                        >
                      </v-date-picker>
                    </v-menu>
                  </v-col>
                  <v-col cols="12" class="todate">
                    <v-menu
                      id="prom_promotions_endDatePopup"
                      ref="toDateMenu"
                      v-model="toDateMenu"
                      :close-on-content-click="false"
                      :return-value.sync="searchRequest.toDate"
                      transition="scale-transition"
                      offset-y
                      min-width="290px"
                    >
                      <template v-slot:activator="{ on }">
                        <v-text-field
                          id="prom_promotioins_filterEndRangeFormated"
                          readonly
                          v-model="searchRequest.toDate"
                          :label="$t('tolabelTxt')"
                          append-icon="mdi-calendar-range"
                          v-on="on"
                          class="darktxtfield__light"
                          filled
                        ></v-text-field>
                      </template>
                      <v-date-picker
                        id="prom_promotioins_filterEndRange"
                        v-model="searchRequest.toDate"
                        no-title
                        scrollable
                      >
                        <v-spacer></v-spacer>
                        <v-btn
                          text
                          color="primary"
                          @click="toDateMenu = false"
                          >{{ $t("cancelText") }}</v-btn
                        >
                        <v-btn
                          text
                          id="prom_promotions_endDateSave"
                          color="primary"
                          @click="toDateSubmit()"
                          >{{ $t("okText") }}</v-btn
                        >
                      </v-date-picker>
                    </v-menu>
                  </v-col>
                  <span class="custom-error-msg" v-if="dateErrorMsg">{{
                    $t("dateValidationErrMsg")
                  }}</span>
                </v-row>
              </v-col>
              <v-col cols="3" class="bml6">
                <h3>{{ $t("byProgramEntity") }}</h3>
                <v-row no-gutters>
                  <v-col cols="12 pt-0">
                    <v-select
                      :items="businessEntities"
                      item-text="name"
                      item-value="businessEntityId"
                      v-model="searchRequest.entityId"
                      filled
                      attach
                      offset-y
                      :label="$t('selectProgramlabelTxt')"
                      class="gen2select gen2select__light"
                      append-icon="expand_more"
                    >
                    </v-select>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
          </template>
          <template v-slot:footer>
            <v-btn text class="mr-5 cancel bmt3" @click="resetFilter()">{{
              $t("resetBtn")
            }}</v-btn>
            <v-btn
              depressed
              class="next bmt3 primaryctabtn cursor-p"
              id="stores_btnFilterstore"
              @click="submitStoreGroupFilter()"
              >{{ $t("applyFilterBtn") }}</v-btn
            >
          </template>
        </brierley-filter-result>
      </v-col>
      <v-col v-if="storeGroupDetails.showCreateEntityPopup">
        <create-entity-popup />
      </v-col>
      <delete-pop-up
        v-if="showDeletePopUp"
        :params="params"
        :storeGroupListData="storeGroupFilterList"
      />
      <v-col v-if="viewType == 'card_view'">
        <storegroup-card-view
          :storeGroupListData="storeGroupFilterList"
          :filterResult="filterRespone"
        />
      </v-col>
      <v-col v-if="viewType == 'grid_view'">
        <storegroup-grid-view
          :storeGroupListData="storeGroupFilterList"
          :filterResult="filterRespone"
        />
      </v-col>
      <v-col v-if="viewType == 'table_view'">
        <storegroup-table-view
          :storeGroupListData="storeGroupFilterList"
          :filterResult="filterRespone"
          :params="params"
        />
      </v-col>
      <!-- <v-col v-if="storeGroupList.length === 0">
        <brierley-no-result :noRecordFoundHeader="$t('noRecordFoundHeader')"
          :noResultMessage="$t('noResultMessage')">
        </brierley-no-result>
      </v-col> -->
      <v-col v-if="storeGroupCount === 0 && loadmore === false">
        <brierley-no-result
          :noRecordFoundHeader="$t('noRecordFoundHeader')"
          :noResultMessage="$t('noResultMessage')"
        >
        </brierley-no-result>
      </v-col>
      <v-col align="center" class="bpb4">
        <loadmore
          loadingText="loading"
          v-if="loadmore"
          id="viewuser_loadmore"
          class="margin-auto"
        />
      </v-col>
    </v-row>
  </v-col>
</template>
<script>
import {
  BrierleyFilter,
  BrierleyViewOption,
  BrierleyPageHeadings,
  BrierleyNoResult,
  BrierleyFilterResult,
  Loadmore
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import StoregroupCardView from '../components/child/StoregroupCardView';
import StoregroupGridView from '../components/child/StoregroupGridView';
import StoregroupTableView from '../components/child/StoregroupTableView';
import deletePopUp from './child/deletePopUp.vue';
import { storeGroupListObj } from '../../../i18n/language.js';
import createEntityPopup from '../components/child/createEntityPopup';
import _ from 'lodash';
export default {
  components: {
    BrierleyFilter,
    BrierleyViewOption,
    StoregroupCardView,
    StoregroupGridView,
    StoregroupTableView,
    BrierleyPageHeadings,
    BrierleyNoResult,
    createEntityPopup,
    BrierleyFilterResult,
    Loadmore,
    deletePopUp
  },
  data () {
    return {
      viewType: 'grid_view',
      loadmore: true,
      // businessEntities: "",
      businessEntity: '',
      isHidden: false,
      // filter start
      filterRespone: null,
      dateErrorMsg: false,
      fromDateMenu: false,
      toDateMenu: false,
      searchQuery: '',
      isTyping: false,
      programId: '',
      searchRequest: {
        searchText: null,
        pageNumber: 1,
        pageSize: 20,
        fromDate: null,
        toDate: null,
        // businessEntity: 0,
        entityId: 0
        // businessEntityId:0,
      },
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('gridViewText')
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('tableViewText')
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('cardViewText')
        }
      ]
    };
  },
  mounted () {
    this.storeGroups();
    window.addEventListener('scroll', this.onScroll);
  },
  i18n: storeGroupListObj,
  computed: {
    ...mapState('storeGroupModule', {
      storeGroupDetails: state => {
        return state.storeGroupDetails;
      }
    }),
    ...mapState('storeGroupModule', ['params', 'showDeletePopUp']),
    ...mapState('storeGroupModule', {
      storeGroupList: state => {
        return state.getStoreGroupListMutations;
      },
      storeGroupCount: state => {
        return state.getStoreGroupCount;
      },
      storeGroupSortObj: state => {
        return state.storeGroupSortObj;
      }
      // programEntities: (state) => {
      //   return state.businessEntities;
      // },
    }),
    // filter
    storeGroupFilterList: {
      get () {
        return this.filterRespone ? this.filterRespone : this.storeGroupList;
      }
    },
    ...mapState({
      businessEntities: state => state.storeModule.businessEntities,
      businessEntityId: state => state.storeModule.businessEntityId,
      storesGroupCount: state => state.storeModule.storesGroupCount
    })
  },
  watch: {
    '$root.GlobalStoreEventStore.state.programList' () {
      this.params.pageSize = 10;
      this.storeGroups();
      this.loadmore = false;
    },
    businessEntities () {
      if (this.businessEntities.length > 0) {
        let filteredEntities = this.businessEntities.filter(
          e => e.businessEntityId === this.businessEntityId
        );
        if (filteredEntities.length > 0) {
          this.entityId = this.businessEntityId;
        } else {
          this.entityId = this.businessEntities[0].businessEntityId;
        }
      }
    },
    searchQuery: _.debounce(function () {
      this.isTyping = false; // eslint-disable-line no-invalid-this
      this.searchRequest.PageNumber = 1; // eslint-disable-line no-invalid-this
    }, 1000),
    isTyping: function (value) {
      if (this.searchQuery === '') {
        this.searchRequest.searchText = '';
      }
      if (!value) {
        this.searchStore();
      }
    }
  },
  methods: {
    openDialog () {
      let programId = localStorage.getItem('programId');
      this.$store.dispatch(
        'storeGroupModule/getStoreBusinessEntityAction',
        programId
      );
      this.$store.commit(
        'storeGroupModule/closeCreateEntityPopupMutation',
        true
      );
    },
    storeGroups () {
      this.loadmore = true;
      this.params.programId = localStorage.getItem('programId');
      if (this.params.programId !== null) {
        this.$store.dispatch(
          'storeGroupModule/getStoreGroupListActions',
          this.params
        );
        if (this.storeGroupCount === 0) {
          this.loadmore = false;
        }
      } else {
        this.$store.commit('storeGroupModule/getStoreGroupCount', 0);
        this.loadmore = false;
      }
      if (
        this.params.pageNumber * this.params.pageSize <
        this.storeGroupCount + 12
      ) {
        let requestForLazyLoading = {
          ...this.params,
          ...this.storeGroupSortObj
        };
        this.$store.dispatch(
          'storeGroupModule/getStoreGroupListActions',
          requestForLazyLoading
        );
      } else {
        this.loadmore = false;
      }
    },
    onScroll () {
      window.onscroll = () => {
        if (
          document.documentElement.scrollHeight ===
          document.documentElement.scrollTop + window.innerHeight
        ) {
          this.params.pageSize += 10;
          this.storeGroups();
        }
      };
    },
    initialize () {
      let s = this;
      s.$store
        .dispatch('storeDefinitionModule/getBusinessEntityNode')
        .then(() => {
          let programId = localStorage.getItem('programId');
          if (programId !== null) {
            s.$store.dispatch('storeModule/setBusinessEntities', programId);
          }
        })
        .then(() => {
          if (s.businessEntityId > 0) {
            s.searchRequest.businessEntityId = s.businessEntityId;
            s.$store.dispatch('storeModule/filterStores', s.searchRequest);
          }
          // else {
          //   s.showEntitySwitcher = true;
          // }
        });
    },
    searchStore () {
      let programId = this.params.programId;
      let searchPaginationData = {
        searchText: this.searchQuery,
        programId: programId
      };
      let requestForSerachBox = {
        ...this.searchRequest,
        ...searchPaginationData
      };
      this.$store.dispatch(
        'storeGroupModule/storeGroupSearch',
        requestForSerachBox
      );
    },
    fromDateSubmit () {
      if (this.searchRequest.fromDate) {
        let fromDate = this.searchRequest.fromDate;
        this.$refs.fromDateMenu.save(fromDate);
      }
      if (this.searchRequest.toDate) {
        let toDate = this.searchRequest.toDate;
        if (this.searchRequest.fromDate < toDate) {
          let toDate = this.searchRequest.toDate;
          this.$refs.toDateMenu.save(toDate);
          this.dateErrorMsg = false;
        } else {
          if (this.searchRequest.fromDate > toDate) {
            let toDate = this.searchRequest.toDate;
            this.$refs.toDateMenu.save(toDate);
            this.dateErrorMsg = true;
          }
        }
      }
    },

    toDateSubmit () {
      if (this.searchRequest.toDate) {
        let toDate = this.searchRequest.toDate;
        this.$refs.toDateMenu.save(toDate);
      }
      if (this.searchRequest.fromDate) {
        let fromDate = this.searchRequest.fromDate;
        if (this.searchRequest.toDate < fromDate) {
          let toDate = this.searchRequest.toDate;
          this.$refs.toDateMenu.save(toDate);
          this.dateErrorMsg = true;
        } else {
          if (this.searchRequest.toDate > fromDate) {
            let toDate = this.searchRequest.toDate;
            this.$refs.toDateMenu.save(toDate);
            this.dateErrorMsg = false;
          }
        }
      }
    },
    submitStoreGroupFilter () {
      if (this.dateErrorMsg) {
        return true;
      }
      let programId = this.params.programId;
      let filterRequest = {
        programId: programId,
        pageSize: 20,
        pageNumber: 1,
        searchText: this.searchQuery,
        fromDate: this.searchRequest.fromDate
          ? this.searchRequest.fromDate
          : '',
        toDate: this.searchRequest.toDate ? this.searchRequest.toDate : '',
        programEntityId: this.searchRequest.entityId
        // businessEntityId: this.searchRequest.businessEntityId,
      };
      this.$store
        .dispatch('storeGroupModule/getStoreGroupFilterActions', filterRequest)
        .then(res => {
          if (res) {
            if (res.storeGroups.length > 0) {
              this.filterRespone = res.storeGroups;
              this.isHidden = false;
            }
          }
        })
        .catch(() => {
          this.isHidden = false;
          this.filterRespone = null;
        });
    },
    resetFilter () {
      this.searchRequest.searchText = '';
      this.searchRequest.fromDate = '';
      this.searchRequest.toDate = '';
      this.searchRequest.entityId = '';
      this.dateErrorMsg = false;
    }
  },
  created () {
    this.$store.commit(
      'storeGroupModule/closeCreateEntityPopupMutation',
      false
    );
    this.initialize();
  }
};
</script>
