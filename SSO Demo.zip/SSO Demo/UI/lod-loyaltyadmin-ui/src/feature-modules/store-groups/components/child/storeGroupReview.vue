<template>
  <v-row class="loyalty-users-common" no-gutters>
    <v-col>
      <brierley-form-title
       :formTitle="$t('formTitle')"
        currentStep="3"
        totalStep="3"
       :infoText="$t('infoText')"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <v-col sm="12" col="12">
      <brierley-summary-info-box class="bpr0">
        <template v-slot:summary-block>
          <v-col class="sub-section" sm="12">
            <v-row no-gutters class="sub-section_title">
              <v-col xs="12" sm="9" md="9">
                <p class="fbold text-left text-uppercase">
                  {{ $t('basicInfo') }}
                </p>
              </v-col>
              <v-col xs="12" sm="3" md="3" class="hoverEdit">
                <p
                  class="primary-text fbold text-right text-uppercase"
                  @click="editBasicInfo()"
                >
                  <v-icon class="bpr1" color="#000">create</v-icon>{{ $t('edit') }}
                </p>
              </v-col>
            </v-row>
            <hr />
            <v-col class="bpa0 bmy5">
              <p>
                <strong>{{ $t('storeGroupName') }}:</strong>
                <span class="pl-1">{{ reviewData.name }}</span>
              </p>
              <p>
                <strong>{{ $t('storeGroupDes') }}:</strong>
                <span class="pl-1">{{ reviewData.description }}</span>
              </p>
              <!-- <p>
                <strong>Created By:</strong>
                <span class="pl-1">{{
                  storeGroupDetails.storeGroupCreatedBy
                }}</span>
              </p> -->
            </v-col>
          </v-col>
        </template>
      </brierley-summary-info-box>
    </v-col>
    <v-col sm="12" col="12">
      <brierley-summary-info-box class="bpt0 bpr0">
        <template v-slot:summary-block>
          <v-col class="sub-section bmb0" sm="12">
            <v-row no-gutters class="sub-section_title">
              <v-col xs="12" sm="9" md="9">
                <!-- Sub Header Start-->
                <p class="fbold text-left text-uppercase">
                  {{ $t('criteria') }}
                </p>
                <!-- Sub Header End-->
              </v-col>
              <v-col xs="12" sm="3" md="3" class="hoverEdit">
                <!-- Edit Button Start -->
                <p
                  class="primary-text fbold text-right text-uppercase"
                  @click="editCriteriaInfo()"
                >
                  <v-icon class="bpr1" color="#000">create</v-icon>{{ $t('edit') }}
                </p>
                <!-- Edit Button End-->
              </v-col>
            </v-row>
            <hr />
            <v-col class="bpa0 bmy5">
              <span v-for="(items, i) in reviewData.criteria" :key="i">
                <p>
                  <strong>{{ $t('entity') }}:</strong>
                  <span class="pl-1">{{
                    getProgramEntity(items.programEntityId, i)
                  }}</span>
                </p>
                <p>
                  <strong>{{ $t('storeGroupAttribute') }}:</strong>
                  <span
                    v-for="(item, j) in items.criteriaList"
                    :key="j"
                    class="pl-1"
                  >
                    {{ getColumnName(item.criteriaType, i, j) }}
                    {{ getOperator(item.operator, i, j) }}
                    {{ item.criteriaValue }}
                    <span v-if="items.criteriaList.length - 1 !== j">,</span>
                  </span>
                </p>
                <hr
                  v-if="reviewData.criteria.length - 1 !== i"
                  class="separationLine bmt5 bmb3"
                />
              </span>
              <!-- Summary End -->
            </v-col>
          </v-col>
        </template>
      </brierley-summary-info-box>
    </v-col>
  </v-row>
</template>
<script>
import {
  BrierleySummaryInfoBox,
  BrierleyFormTitle,
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { storeGroupReviewObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleySummaryInfoBox,
    BrierleyFormTitle,
  },
  i18n: storeGroupReviewObj,
  computed: {
    ...mapState('storeGroupModule', {
      storeGroupDetails: (state) => {
        return state.storeGroupDetails;
      },
      storeGroupEntityArray: (state) => {
        return state.storeGroupEntityArray;
      },
      reviewData: (state) => {
        return state.reviewData;
      },
    }),
  },
  methods: {
    getProgramEntity (item, i) {
      let value = this.storeGroupEntityArray[i].storeGroupBusinessEntity.filter(
        (x) => x.businessEntityId === item
      );
      return value[0].name;
    },
    getColumnName (item, i, j) {
      let value = this.storeGroupEntityArray[i].storeGroupAttibuteOperatorArray[
        j
      ].storeGroupAttributeArray.filter((x) => x.columnName === item);
      return value[0].columnName;
    },
    getOperator (item, i, j) {
      let value = this.storeGroupEntityArray[i].storeGroupAttibuteOperatorArray[
        j
      ].storeGroupOperatorArray.filter((x) => x.value === item);
      return value[0].name;
    },
    editBasicInfo () {
      this.$store.commit('storeGroupModule/updateStoreGroupStepperMutation', 1);
    },
    editCriteriaInfo () {
      this.$store.commit('storeGroupModule/updateStoreGroupStepperMutation', 2);
    },
  },
};
</script>
<style lang="scss" scoped>
#link {
  color: #0628b1;
  position: relative;
  top: 2px;
  right: 2px;
}
#acclockicon {
  position: relative;
  color: #bdbdbd !important;
  left: 155px;
  bottom: 32px;
}
.gen2-summarybox {
  background-color: white !important;
  padding-left: 0px !important;
  padding-right: 0px !important;
  padding-bottom: 0px !important;
}
.v-icon {
  font-size: 20px !important;
}
.separationLine {
  border-top: 1px dashed #bbb !important;
}
.textWrap {
  word-wrap: break-all !important;
}
.hoverEdit {
  .primary-text {
    float: right;
    cursor: pointer !important;
  }
}
</style>
<style lang="scss">
.gen2-summarybox.bpr0 {
  .gen2-summarybox_scrollbox {
    padding-right: 0 !important;
  }
}
</style>
