<template>
  <StoreGroupLayout />
</template>
<script>
import StoreGroupLayout from './storeGroupLayout.vue';
export default {
  components: {
    StoreGroupLayout
  }
};
</script>
