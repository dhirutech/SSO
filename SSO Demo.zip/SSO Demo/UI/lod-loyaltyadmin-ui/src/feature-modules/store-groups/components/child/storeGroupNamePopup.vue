<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closePopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
           {{ $t("storeNameAlreadyExists") }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <v-alert
                  class="b-alert-error"
                  type="error"
                  :dismissible="false"
                >
                  <v-row class="alert-block align-center havebtn" no-gutters>
                    <v-col class="alert-block__body">
                      {{ $t("storeDes") }}
                    </v-col>
                  </v-row>
                </v-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="org_btn_deleteDeleteDialog"
            data-qe-id="communicationManagement_yes_btn"
            class="primaryctabtn text-uppercase"
            title
            @click="navigateToStepOne()"
            >{{ $t("okTxt") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { storeNamePopUpObject } from '../../../../i18n/language.js';
export default {
  data () {
    return {
      dialog: false
    };
  },
  components: {
    BrierleyDialogbox
  },
  i18n: storeNamePopUpObject,
  methods: {
    navigateToStepOne () {
      this.$store.commit('storeGroupModule/updateStoreGroupStepperMutation', 1);
      this.$store.commit(
        'storeGroupModule/storeGroupNameExistsMutation',
        true
      );
      this.$store.commit(
        'storeGroupModule/showStoreGroupNamePopupMutation',
        false
      );
    },
    closePopup () {
      this.$store.commit(
        'storeGroupModule/showStoreGroupNamePopupMutation',
        false
      );
    },
    closeDeleteEntityPopupWhenClickNo () {
      this.closePopup();
    }
  },
  computed: {
    ...mapState('storeGroupModule', ['showNamePopUp'])
  }
};
</script>
