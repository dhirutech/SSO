<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox :dialog="true" persistent @closeMe="closePopup()">
        <template v-slot:dialog-header>
          <v-card-title
            class="gen2-dialog-title text-uppercase"
            data-qe-id="org_addEntity_cardTitle"
            >{{ $t("pgmEntity") }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <p class="line-height-normal">
              {{ $t("bodyDes") }}
            </p>
            <v-row
              no-gutters
              class="flex-column gen2-forms form-light-bg min-height-240 overflow-y-hidden"
            >
              <v-col class="bmt2" sm="4" xs="12" md="6">
                <p class="label-text line-height-normal">
                  {{ $t("pgmEntity") }}
                </p>
                <v-select
                  :items="storeBusinessEntity"
                  item-text="name"
                  item-value="businessEntityId"
                  v-model="select"
                  :disabled="disableBtn"
                  filled
                  attach
                  offset-y
                  @change="
                    selectedProgram => selectBusinessEntity(selectedProgram)
                  "
                  class="gen2select gen2select__dark mini-list"
                  :label="alertMessage"
                  append-icon="expand_more"
                ></v-select>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            text
            class="cancel no-ripple cursor-p btn-hover-none"
            @click="closeDeleteEntityPopupWhenClickNo()"
            >{{ $t("cancelTxt") }}</v-btn
          >
          <v-btn
            class="primaryctabtn text-uppercase cursor-p"
            @click="navigateToBasicInfo()"
            :disabled="select !== '' ? false : true"
            >{{ $t("continueTxt") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { createStoreEntityObj } from '../../../../i18n/language.js';
export default {
  data () {
    return {
      select: '',
      disableBtn: false
    };
  },
  computed: {
    ...mapState('storeGroupModule', {
      storeBusinessEntity: state => {
        return state.storeBusinessEntity;
      },
      alertMessage () {
        if (this.storeBusinessEntity.length === 0) {
          this.disableBtn = true;
          return this.$t('noPgmEntity');
        } else {
          this.disableBtn = false;
          return this.$t('selectEntity');
        }
      }
    })
  },
  i18n: createStoreEntityObj,
  components: {
    BrierleyDialogbox
  },
  methods: {
    selectBusinessEntity (val) {
      let programEntity = this.storeBusinessEntity.filter(
        x => x.businessEntityId === val
      );
      this.$store.commit(
        'storeGroupModule/selectedProgramEntityMutation',
        programEntity
      );
    },
    closePopup () {
      this.$store.commit(
        'storeGroupModule/closeCreateEntityPopupMutation',
        false
      );
    },
    navigateToBasicInfo () {
      this.$router.push('/loyaltyadmin/storeGroupPage');
    },
    closeDeleteEntityPopupWhenClickNo () {
      this.closePopup();
    }
  }
};
</script>
