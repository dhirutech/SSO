<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <brierley-form-title
        :formTitle="$t('formTitle')"
        currentStep="1"
        totalStep="3"
        :infoText="$t('infoText')"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <v-col>
      <v-row no-gutters class="bmt5">
        <v-col sm="7" class="gen2-forms form-light-bg">
          <v-row class="flex-column " no-gutters>
            <v-col class="label-text">{{ $t("storeDetails") }}</v-col>
            <v-col sm="7">
              <validation-provider
                id="user_v_email"
                rules="required"
                v-slot="{ errors }"
              >
                <v-text-field
                  autocomplete="off"
                  data-qe-id="storeGroupName"
                  :label="$t('storeGroupName')"
                  @input="nameField()"
                  v-model="storeGroupDetails.storeGroupName"
                  maxLength="50"
                  @blur="
                    storeGroupDetails.storeGroupName = removeSpaces(
                      storeGroupDetails.storeGroupName
                    )"
                  filled
                ></v-text-field>
                <v-layout class="custom-error-msg" v-if="storeGroupNameExists"
                  >{{ $t("nameAlreadyExists") }}
                </v-layout>
                <!-- <v-layout
                  class="custom-error-msg"
                  >error
                </v-layout> -->
                <p
                  class="custom-error-msg"
                  v-if="
                    errors[0] != undefined &&
                      errors[0].length > 0 &&
                      errors[0] == 'This field is required'">
                  {{ $t("commNameRequired") }}
                </p>
              </validation-provider>
            </v-col>
            <v-col sm="9">
              <v-textarea
                :label="$t('storeGroupDes')"
                data-qe-id="storeGroupDes"
                v-model="storeGroupDetails.storeGroupDescription"
                maxLength="1000"
                auto-grow
                filled
              ></v-textarea>
            </v-col>
            <!-- <v-col sm="7">
              <v-text-field
                autocomplete="off"
                data-qe-id="storeCreatedBy"
                :label="$t('storeCreatedBy')"
                disabled
                v-model="storeGroupDetails.storeGroupCreatedBy"
                filled
              ></v-text-field>
            </v-col> -->
          </v-row>
        </v-col>
        <v-col sm="5">
          <brierley-info-side>
            <template v-slot:info-side-header>
              <div class="info_title">
                <v-icon>info</v-icon>{{ $t("storeInfo") }}
              </div>
            </template>
            <template v-slot:info-side-body>
              <div>
                {{ $t("storeInfoText") }}
              </div>
            </template>
          </brierley-info-side>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import { mapState } from 'vuex';
import {
  BrierleyInfoSide,
  BrierleyFormTitle,
} from '@brierley/SharedComponents';
import { storeGroupBasicInfoObj } from '../../../../i18n/language.js';
export default {
  data () {
    return {
      storeGroupNameDisabled: false,
    };
  },
  components: {
    BrierleyInfoSide,
    BrierleyFormTitle,
  },
  i18n: storeGroupBasicInfoObj,
  computed: {
    ...mapState('storeGroupModule', {
      storeGroupDetails: (state) => {
        return state.storeGroupDetails;
      },
      storeGroupNameExists: (state) => {
        return state.storeGroupNameExists;
      },
    }),
  },
  methods: {
    removeSpaces (string) {
      return string.trim();
    },
    nameField () {
      this.$store.commit(
        'storeGroupModule/storeGroupNameExistsMutation',
        false
      );
    },
  },
};
</script>
