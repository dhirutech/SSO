<template>
  <v-row>
    <v-row v-if="success" class="flex-column" no-gutters>
      <v-col>
        <brierley-form-title
          formTitle="Review"
          currentStep="2"
          totalStep="3"
          infoText="Review the following information before you save the store group."
          :showSteps="true"
        ></brierley-form-title>
      </v-col>
      <v-col class="bmt5">
        <v-row no-gutters>
          <v-col cols="12">
            <v-row no-gutters class="sub-section_title">
              <v-col xs="12" sm="9" md="9">
                <!-- Sub Header Start-->
                <p class="fbold text-left text-uppercase">
                  Personal Information
                </p>
                <!-- Sub Header End-->
              </v-col>
              <v-col xs="12" sm="3" md="3" class="hoverEdit">
                <!-- Edit Button Start -->
                <p class="text-right text-uppercase">
                  <span class="cursor-p primary-text fbold"
                    ><v-icon class="bpr1" color="#000">create</v-icon>Edit</span
                  >
                </p>
                <!-- Edit Button End-->
              </v-col>
            </v-row>
            <v-divider class="bmt0 bmb2"></v-divider>
            <v-row no-gutters class="sub-section_descripition">
              <v-col>
                <p><strong>Email Address:</strong> alice.bryant@example.com</p>
                <p><strong>First Name:</strong> Alice</p>
                <p><strong>Last Name:</strong> Bryant</p>
                <p><strong>Phone Number:</strong> (316) 555-0116</p>
                <p><strong>External ID:</strong> 989385</p>
              </v-col>
            </v-row>
          </v-col>
          <v-col cols="12" class="bmt5 bmb2">
            <v-row no-gutters class="sub-section_title">
              <v-col xs="12" sm="9" md="9">
                <!-- Sub Header Start-->
                <p class="fbold text-left text-uppercase">Role Information</p>
                <!-- Sub Header End-->
              </v-col>
              <v-col xs="12" sm="3" md="3" class="hoverEdit">
                <!-- Edit Button Start -->
                <p class="text-right text-uppercase">
                  <span class="cursor-p primary-text fbold"
                    ><v-icon class="bpr1" color="#000">create</v-icon>Edit</span
                  >
                </p>
                <!-- Edit Button End-->
              </v-col>
            </v-row>
            <v-divider class="bmt0 bmb2"></v-divider>
            <v-row no-gutters class="sub-section_descripition">
              <v-col>
                <p><strong>Administrator ?:</strong> No</p>
                <p><strong>Selected Program 01:</strong> M Rewards(UK)</p>
                <p><strong>Role Assignment:</strong> Loyalty Manager</p>
              </v-col>
            </v-row>
            <v-divider class="dashed-border" bmy4></v-divider>
            <v-row no-gutters class="sub-section_descripition">
              <v-col>
                <p><strong>Selected Program 02:</strong> M Rewards(USA)</p>
                <p>
                  <strong>Role Assignment:</strong> Loyalty Manager, Customer
                  Care Agent
                </p>
              </v-col>
            </v-row>
          </v-col>
        </v-row>
      </v-col>
    </v-row>
    <v-row class="store-review-success flex-column" no-gutters v-else>
      <v-row no-gutters>
        <v-col>
          <brierley-form-title
            :formTitle="$t('successFormTitle')"
          ></brierley-form-title>
        </v-col>
      </v-row>
      <v-row no-gutters>
        <v-col md="12" class="store-review-success__alert">
          <v-alert
            class="b-alert-success"
            type="success"
            :dismissible="false"
            infoText="Success"
            style="min-width: 100%"
            icon="done"
          >
            <v-row class="alert-block align-center" no-gutters>
              <v-col class="alert-block__body">
                <h3>{{ $t("successAlertHeader") }}</h3>
                <p>{{ $t("newStoreText") }}</p>
              </v-col>
            </v-row>
          </v-alert>
        </v-col>
        <v-col
          md="12"
          class="store-review-success__actions gen2-frm-footer-previous"
        >
          <v-btn
            form="basic_form"
            type="submit"
            class="primaryctabtn bmt2 bml2 large ml-0"
            id="success-close-btn"
            @click.native="openDialog()"
          >
            {{ $t("closeText") }}
          </v-btn>
          <p class="mt-8">
            <strong>{{ $t("anotherStore") }}</strong> <br />
            <span>
              {{ $t("storeGroup")
              }}<v-btn
                text
                class="no-ripple cancel store-review-success__actions--click-here"
                @click="openDialogg()"
              >
                {{ $t("clickHere") }}
              </v-btn></span
            >
          </p>
        </v-col>
      </v-row>
    </v-row>
  </v-row>
</template>
<script>
import { BrierleyFormTitle } from '@brierley/SharedComponents';
import { storeGrpSuccessObj } from '../../../../i18n/language';
export default {
  i18n: storeGrpSuccessObj,
  components: {
    BrierleyFormTitle
  },
  alertMessage () {
    if (this.$route.path.includes('/loyaltyadmin/storegrouplist/edit')) {
      return this.$t('editStore');
    } else {
      return this.$t('$t("newStoreText")');
    }
  },
  props: {
    success: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    openDialogg () {
      let programId = localStorage.getItem('programId');
      this.$store.dispatch(
        'storeGroupModule/getStoreBusinessEntityAction',
        programId
      );
      this.$store.commit(
        'storeGroupModule/closeCreateEntityPopupMutation',
        true
      );
      this.$router.push('/loyaltyadmin/storegrouplist');
    },
    openDialog () {
      this.$store.commit('storeGroupModule/closePopupMutation', true);
    }
  }
};
</script>
<style lang="scss" scoped>
.sub-section_descripition {
  p {
    margin-bottom: 0;
    line-height: 32px;
  }
}
</style>
