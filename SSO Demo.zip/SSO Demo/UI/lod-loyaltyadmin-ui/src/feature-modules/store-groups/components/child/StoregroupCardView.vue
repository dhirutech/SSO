<template>
  <v-row>
    <v-col md="6" sm="12" xs="12" v-for="(item, i) in storeGroupList" :key="i">
      <brierley-card>
        <template v-slot:header>
          <h2>
            <!-- <v-icon class="mtn-6 primary-text icon-btn-hover-none"
              >mdi-bookmark</v-icon
            > -->
            {{ item.name }}
          </h2>
        </template>

        <template v-slot:footer>
          <v-col sm="12" class="bmb3">
            <p>
              <strong> {{ $t("storeGroupDescription") }}:</strong> <br />
              {{ item.description }}
            </p>
          </v-col>
          <v-col sm="7">
            <p>
              <!-- <strong> {{ $t('storeGroupCreatedBy') }}: </strong><br />
              <span>{{ item.authorFullName }}</span> -->
              <strong>{{ $t("programEntityLabel") }}: </strong>
              <span>{{ item.programEntityName }}</span>
            </p>
          </v-col>
          <v-col sm="5">
            <p>
              <strong> {{ $t("createdOnText") }}: </strong><br />
              <span
                >{{ format_date(item.createdDate) }} {{ localTimeZone }}</span
              >
            </p>
          </v-col>
          <v-col sm="7" class="bmy3">
            <!-- <p>
              <strong>{{ $t('programEntityLabel') }}: </strong>
              <span>{{ item.programEntityName }}</span>
            </p> -->
          </v-col>
          <v-col sm="5" class="bmy3">
            <p>
              <strong> {{ $t("statusLabel") }}: </strong><br />
            </p>
            <brierley-status
              v-if="item.status === true"
              status="Active"
            ></brierley-status>
          </v-col>
          <v-col sm="12">
            <brierleyCardIcons>
              <template v-slot:action-icons>
                <span :title="$t('viewDetails')" class="active">
                  <v-icon>fe fe-eye</v-icon>
                  <span class="viewdetails-icon">{{ $t("viewDetails") }}</span>
                </span>
                <span
                  :title="$t('editLabel')"
                  data-qe-id="edit_btn"
                  @click="editStoreGroup(item)"
                >
                  <v-icon id="viewuser_edit-icon" class="blackicon"
                    >fe fe-edit
                  </v-icon>
                  <span class="edit-icon" id="viewuser-edit">{{
                    $t("editLabel")
                  }}</span>
                </span>
                <span :title="$t('cloneLabel')" @click="cloneStoreGroup(item)">
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >feather-icon fe fe-copy</v-icon
                  >
                  <span class="clone-icon">
                    {{ $t("cloneLabel") }}
                  </span>
                </span>
                <span
                  :title="$t('deleteText')"
                  data-qe-id="delete_btn"
                  @click="deleteStoreGroup(item)"
                >
                  <v-icon class="blackicon cursor-p">fe fe-trash-2</v-icon>
                  <span class="delete-icon"> {{ $t("deleteText") }}</span>
                </span>
              </template>
            </brierleyCardIcons>
          </v-col>
        </template>
      </brierley-card>
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyCardIcons,
  BrierleyCard,
  BrierleyStatus
} from '@brierley/SharedComponents';
import { storeGroupListObj } from './../../../../i18n/language.js';
import moment from 'moment-timezone';
export default {
  components: {
    BrierleyCardIcons,
    BrierleyCard,
    BrierleyStatus
  },
  computed: {
    storeGroupList: {
      get () {
        return this.filterResult
          ? this.filterResult
          : this.storeGroupListData.filter(item => {
            return item.status === true;
          });
      }
    }
  },
  data () {
    return {
      localTimeZone: ''
    };
  },
  i18n: storeGroupListObj,
  props: {
    storeGroupListData: {
      type: Array,
      defualt: []
    },
    filterResult: {
      type: Array,
      default: () => 0
    },
    params: {
      type: Array,
      defualt: []
    }
  },
  methods: {
    editStoreGroup (val) {
      let programId = localStorage.getItem('programId');
      this.$store
        .dispatch('storeGroupModule/getStoreBusinessEntityAction', programId)
        .then(() => {
          let obj = [
            {
              name: val.programEntityName,
              businessEntityId: val.programEntityId
            }
          ];
          this.$store.commit(
            'storeGroupModule/selectedProgramEntityMutation',
            obj
          );
          this.$router.push({
            name: 'StoreGroupPageEdit',
            query: { res: val.storeGroupId }
          });
        });
    },
    cloneStoreGroup (val) {
      let programId = localStorage.getItem('programId');
      this.$store
        .dispatch('storeGroupModule/getStoreBusinessEntityAction', programId)
        .then(() => {
          let obj = [
            {
              name: val.programEntityName,
              businessEntityId: val.programEntityId
            }
          ];
          this.$store.commit(
            'storeGroupModule/selectedProgramEntityMutation',
            obj
          );
          this.$router.push({
            name: 'StoreGroupPageClone',
            query: { res: val.storeGroupId }
          });
        });
    },
    format_date (value) {
      if (value) {
        let localZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        this.localTimeZone = moment()
          .tz(localZone)
          .zoneAbbr();
        return moment(String(value)).format('MMM Do YYYY, h:mm A');
      }
    },
    deleteStoreGroup (val) {
      this.$store.commit(
        'storeGroupModule/showDeletePopUpDialogueMutation',
        true
      );
      let deleteStoreGroupObj = {
        id: val.storeGroupId,
        name: val.name
      };
      this.$store.commit(
        'storeGroupModule/deleteStoreGroupIdMutation',
        deleteStoreGroupObj
      );
    }
  }
};
</script>
<style lang="scss" scoped>
.mtn-6 {
  margin-top: -6px !important;
}
</style>
