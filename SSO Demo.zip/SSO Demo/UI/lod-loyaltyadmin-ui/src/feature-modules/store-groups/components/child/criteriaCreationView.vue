<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <brierley-form-title
        :formTitle="$t('formTitle')"
        currentStep="2"
        totalStep="3"
        :infoText="$t('infoText')"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <v-col class="bmt5 bpt4 gray-bg">
      <v-row
        no-gutters
        v-for="(item, index) in storeGroupEntityArray"
        :key="index"
        class="flex-column bpx4"
      >
        <v-col class="bpx3 bpy2" v-if="index >= 1">
          <v-btn
            depressed
            :class="[
              item.storeGroupAndToggled ? 'green-btn bmr1' : 'white-btn'
            ]"
            @click="andOperator(item, index)"
            >AND</v-btn
          >
          <v-btn
            depressed
            :class="[item.storeGroupOrToggled ? 'green-btn bmr1' : 'white-btn']"
            @click="orOperator(item, index)"
            >OR</v-btn
          >
        </v-col>
        <v-col>
          <v-row
            class="white-bg flex-column bpx4 bpy3 gen2-forms form-light-bg"
            no-gutters
          >
            <v-col class="label-text bmb1">{{ $t("chooseStore") }}</v-col>
            <v-col>
              <v-row>
                <v-col class="max-width-290">
                  <v-select
                    :label="$t('selectEntity')"
                    :items="item.storeGroupBusinessEntity"
                    item-text="name"
                    item-value="businessEntityId"
                    v-model="item.selectedBusinessEntity"
                    filled
                    attach
                    offset-y
                    @change="
                      selectedProgram =>
                        selectBusinessEntity(selectedProgram, index)
                    "
                    class="gen2select gen2select__dark mini-list"
                    append-icon="expand_more"
                  ></v-select>
                  <p class="custom-error-msg" v-if="item.entityErrorExists">
                    {{ $t("errorText") }}
                  </p>
                </v-col>
              </v-row>
            </v-col>
            <v-col><v-divider class="dashed bmt2 bmb4"></v-divider></v-col>
            <v-col
              v-if="
                storeGroupEntityArray[index].storeGroupAttibuteOperatorArray[0]
                  .storeGroupAttributeArray.length > 0
              "
            >
              <v-row
                v-for="(entity, j) in item.storeGroupAttibuteOperatorArray"
                :key="j"
              >
                <v-col class="bpb0">
                  <v-select
                    filled
                    :items="entity.storeGroupAttributeArray"
                    item-text="columnName"
                    item-value="extensionPropertyId"
                    v-model="entity.selectedGroupAttribute"
                    :label="$t('selectStoreAttr')"
                    @change="
                      selectedAttribute(
                        item.storeGroupAttibuteOperatorArray[j],
                        index,
                        j
                      )
                    "
                    attach
                    offset-y
                    class="gen2select gen2select__dark mini-list"
                    append-icon="expand_more"
                  ></v-select>
                  <p
                    class="custom-error-msg"
                    v-if="entity.attributeErrorExists"
                  >
                    {{ $t("errorText") }}
                  </p>
                </v-col>
                <v-col class="bpb0">
                  <v-select
                    filled
                    :label="$t('selectOper')"
                    :items="entity.storeGroupOperatorArray"
                    v-model="entity.selectedGroupOperator"
                    @change="
                      selectedOperator(
                        item.storeGroupAttibuteOperatorArray[j],
                        j
                      )
                    "
                    item-text="name"
                    item-value="name"
                    attach
                    offset-y
                    class="gen2select gen2select__dark mini-list"
                    append-icon="expand_more"
                  ></v-select>
                  <p class="custom-error-msg" v-if="entity.operatorErrorExists">
                    {{ $t("errorText") }}
                  </p>
                </v-col>
                <v-col class="bpb0 max-width-290">
                  <v-select
                    filled
                    :items="entity.storeGroupValueArray"
                    v-model="entity.selectedGroupValue"
                    @change="
                      selectedValue(item.storeGroupAttibuteOperatorArray[j], j)
                    "
                    item-text="extensionPropertyValue"
                    item-value="extensionPropertyValue"
                    :label="getLabel(index, j)"
                    :disabled="entity.valueName === 'No options available'"
                    attach
                    offset-y
                    class="gen2select gen2select__dark mini-list"
                    append-icon="expand_more"
                  ></v-select>
                  <p class="custom-error-msg" v-if="entity.valueErrorExists">
                    {{ $t("errorText") }}
                  </p>
                </v-col>
                <v-col class="btn-ic-width text-right bpl6 bpb0">
                  <v-btn
                    depressed
                    class="blue-icon-btn"
                    @click="addstoreGroupAttibuteOperatorRow(entity, index, j)"
                  >
                    <v-icon>add_circle_outline</v-icon>
                  </v-btn>
                  <v-btn
                    depressed
                    class="blue-icon-btn bml2"
                    :disabled="
                      storeGroupEntityArray.length === 1 &&
                        item.storeGroupAttibuteOperatorArray.length === 1
                    "
                    @click="
                      removestoreGroupAttibuteOperatorRow(entity, index, j)
                    "
                  >
                    <v-icon>remove_circle_outline</v-icon>
                  </v-btn>
                </v-col>
              </v-row>
            </v-col>
            <v-col>
              <v-row class="d-inline-flex icon-with-head align-center">
                <v-col>
                  <v-icon class="bmr1">playlist_add_check</v-icon>
                </v-col>
                <v-col @click="ShowSinglePreviewPopup(index)">
                  {{ $t("previewText") }}</v-col
                >
              </v-row>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </v-col>
    <v-col class="gray-bg bpx4 bpb3">
      <v-row
        class="d-inline-flex icon-with-head align-center bmr3"
        @click="addMoreCriteria(storeGroupEntityArray)"
      >
        <v-col>
          <v-icon class="bmr1">add_circle_outline</v-icon>
        </v-col>
        <v-col class="text-uppercase">{{ $t("addQualifying") }}</v-col>
      </v-row>
      <v-row class="d-inline-flex icon-with-head align-center">
        <v-col>
          <v-icon class="bmr1">playlist_add_check</v-icon>
        </v-col>
        <v-col @click="ShowPreviewPopup()"> {{ $t("previewText") }}</v-col>
      </v-row>
    </v-col>
    <v-col>
      <preview-popup v-if="showPreviewPopup" />
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyFormTitle } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import PreviewPopup from './StoreGroupPreviewPopup';
import { storeGroupCriteriaObj } from '../../../../i18n/language.js';
import Vue from 'vue';
export default {
  data () {
    return {
      select: '',
      operatorArray: []
    };
  },
  i18n: storeGroupCriteriaObj,
  components: {
    BrierleyFormTitle,
    PreviewPopup
  },
  mounted () {
    let self = this;
    async function getAttributeValues () {
      let extensionArray = [];
      const promises = self.storeGroupEntityArray.map(async (val, i) => {
        val.storeGroupAttibuteOperatorArray.map(async (arr, j) => {
          let attributeValue = arr.storeGroupAttributeArray.filter(
            x => x.extensionPropertyId === arr.selectedGroupAttribute
          );
          await Vue.prototype.$http
            .get(
              '/product/api/v2/extensionProperties/stores/values?ExtensionPropertyId=' +
                attributeValue[0].extensionPropertyId +
                '&ColumnName=' +
                attributeValue[0].columnName +
                '&IsExtendedAttribute=' +
                attributeValue[0].isExtendedAttribute
            )
            .then(res => {
              const dataresult = [...new Set(res.data.data)];
              extensionArray = dataresult.map((item, index) => {
                const extensionObj = {
                  index: index,
                  extensionPropertyValue: item
                };
                return extensionObj;
              });
              extensionArray = extensionArray.filter(obj => {
                if (obj.extensionPropertyValue !== null) {
                  return obj;
                }
              });
              let obj = {
                entityIndex: i,
                valueIndex: j,
                valueArray: extensionArray
              };
              self.$store.commit(
                'storeGroupModule/editUpdatestoreGroupValueArrayMutation',
                obj
              );
              let valueNameObj = {
                entityIndex: i,
                valueIndex: j,
                valueName: attributeValue[0].columnName
              };
              self.$store.commit(
                'storeGroupModule/updateValueNameMutation',
                valueNameObj
              );
            });
        });
      });
      await Promise.all(promises);
    }
    if (
      this.$route.name === 'StoreGroupPageEdit' ||
      this.$route.name === 'StoreGroupPageClone'
    ) {
      getAttributeValues();
    }
  },
  methods: {
    andOperator (item, index) {
      let operatorPayload = {
        operator: 'AND',
        index: index,
        toggled: 'storeGroupAndToggled'
      };
      this.$store.commit(
        'storeGroupModule/updatestoreGroupDefaultConditionMutation',
        operatorPayload
      );
    },
    orOperator (item, index) {
      let operatorPayload = {
        operator: 'OR',
        index: index,
        toggled: 'storeGroupOrToggled'
      };
      this.$store.commit(
        'storeGroupModule/updatestoreGroupDefaultConditionMutation',
        operatorPayload
      );
    },
    addMoreCriteria (storeGroupEntityArray) {
      let entityResult = storeGroupEntityArray.filter(obj => {
        return (
          obj.selectedBusinessEntity === '' ||
          obj.selectedBusinessEntity === undefined
        );
      });
      let obj = {
        storeGroupDefaultCondition: 'AND',
        storeGroupAndToggled: true,
        storeGroupOrToggled: false,
        storeGroupBusinessEntity: this.storeBusinessEntity,
        selectedBusinessEntity: '',
        entityErrorExists: false,
        storeGroupAttibuteOperatorArray: [
          {
            storeGroupAttributeArray: [],
            selectedGroupAttribute: '',
            attributeErrorExists: false,
            storeGroupOperatorArray: [],
            selectedGroupOperator: '',
            operatorErrorExists: false,
            storeGroupValueArray: [],
            selectedGroupValue: '',
            valueErrorExists: false,
            valueName: ''
          }
        ]
      };
      if (entityResult.length === 0) {
        this.$store.commit('storeGroupModule/addMoreCriteriaMutation', obj);
      }
    },
    getLabel (a, b) {
      if (
        this.storeGroupEntityArray[a].storeGroupAttibuteOperatorArray[b]
          .valueName === 'No options available'
      ) {
        return 'No options available';
      } else {
        if (
          this.storeGroupEntityArray[a].storeGroupAttibuteOperatorArray[b]
            .valueName
        ) {
          return (
            this.$t('select') +
            ' ' +
            this.storeGroupEntityArray[a].storeGroupAttibuteOperatorArray[b]
              .valueName
          );
        } else {
          return this.$t('select');
        }
      }
    },
    removestoreGroupAttibuteOperatorRow (entity, a, b) {
      if (
        this.storeGroupEntityArray[a].storeGroupAttibuteOperatorArray.length ===
        1
      ) {
        this.storeGroupEntityArray.splice(a, 1);
      } else {
        this.storeGroupEntityArray[a].storeGroupAttibuteOperatorArray.splice(
          b,
          1
        );
        let obj = {
          index: a,
          attrArr: this.storeGroupEntityArray[a].storeGroupAttibuteOperatorArray
        };
        this.$store.commit(
          'storeGroupModule/updatestoreAttibuteOperatorArrayMutation',
          obj
        );
      }
    },
    addstoreGroupAttibuteOperatorRow (entity, a, b) {
      if (
        entity.selectedGroupAttribute === undefined ||
        entity.selectedGroupAttribute === ''
      ) {
        entity.attributeErrorExists = true;
      } else {
        entity.attributeErrorExists = false;
      }
      if (
        entity.selectedGroupOperator === undefined ||
        entity.selectedGroupOperator === ''
      ) {
        entity.operatorErrorExists = true;
      } else {
        entity.operatorErrorExists = false;
      }
      if (
        entity.selectedGroupValue === undefined ||
        entity.selectedGroupValue === ''
      ) {
        entity.valueErrorExists = true;
      } else {
        entity.valueErrorExists = false;
      }
      // if (entity.valueName === 'No options available') {
      //   entity.valueErrorExists = false;
      // }
      if (
        entity.selectedGroupAttribute &&
        entity.selectedGroupOperator &&
        entity.selectedGroupValue
      ) {
        let obj = {
          index: a,
          storeGroupAttributeArray: this.storeGroupEntityArray[a]
            .storeGroupAttibuteOperatorArray[b].storeGroupAttributeArray,
          selectedGroupAttribute: '',
          attributeErrorExists: false,
          storeGroupOperatorArray: [],
          selectedGroupOperator: '',
          operatorErrorExists: false,
          storeGroupValueArray: [],
          selectedGroupValue: '',
          valueErrorExists: false
        };
        this.$store.commit(
          'storeGroupModule/updatestoreGroupAttibuteOperatorArrayMutation',
          obj
        );
      }
    },
    selectBusinessEntity (val, a) {
      this.$store
        .dispatch('storeGroupModule/getExtensionPropertyValueAction', val)
        .then(res => {
          let obj = {
            index: a,
            attributeArray: res.data.data
          };
          this.$store.commit(
            'storeGroupModule/updatestoreGroupAttributeArrayMutation',
            obj
          );
          let attributeResult = res.data.data.filter(obj => {
            return (
              obj.extensionPropertyId ===
              this.storeGroupEntityArray[a].storeGroupAttibuteOperatorArray[0]
                .selectedGroupAttribute
            );
          });
          if (attributeResult[0].dataType === 'String') {
            this.operatorArray = [
              { name: 'Matches Exactly', value: 8 },
              { name: 'Contains', value: 9 },
              { name: 'Starts With', value: 10 }
            ];
          } else if (attributeResult[0].dataType === 'Boolean') {
            this.operatorArray = [
              { name: 'Is', value: 6 },
              { name: 'Is Not', value: 7 }
            ];
          } else if (
            attributeResult[0].dataType === 'DateTime' ||
            attributeResult[0].dataType === 'Number'
          ) {
            this.operatorArray = [
              { name: 'Equals', value: 0 },
              { name: 'Less Than', value: 1 },
              { name: 'Less Than or Equals', value: 2 },
              { name: 'Greater Than', value: 3 },
              {
                name: 'Greater Than or Equals',
                value: 4
              },
              { name: 'Does Not Equal', value: 5 }
            ];
          }
          let stringObj = {
            entityIndex: a,
            valueIndex: 0,
            valueArray: this.operatorArray
          };
          this.$store.commit(
            'storeGroupModule/updatestoreGroupOperatorArrayMutation',
            stringObj
          );
          this.$store
            .dispatch(
              'storeGroupModule/getValuePropertyAction',
              attributeResult[0]
            )
            .then(res => {
              this.$store.commit(
                'storeGroupModule/updatestoreGroupValueMutation',
                a
              );
              const dataresult = [...new Set(res.data.data)];
              let extensionArray = dataresult.map((item, index) => {
                const extensionObj = {
                  index: index,
                  extensionPropertyValue: item
                };
                return extensionObj;
              });
              extensionArray = extensionArray.filter(obj => {
                if (obj.extensionPropertyValue !== null) {
                  return obj;
                }
              });
              let obj = {
                entityIndex: a,
                valueIndex: 0,
                valueArray: extensionArray
              };
              this.$store.commit(
                'storeGroupModule/updatestoreGroupValueArrayMutation',
                obj
              );
              if (res.data.data === undefined) {
                let valueNameObj = {
                  entityIndex: a,
                  valueIndex: 0,
                  valueName: 'No options available'
                };
                this.$store.commit(
                  'storeGroupModule/updateValueNameMutation',
                  valueNameObj
                );
              } else {
                let valueNameObj = {
                  entityIndex: a,
                  valueIndex: 0,
                  valueName: attributeResult[0].columnName
                };
                this.$store.commit(
                  'storeGroupModule/updateValueNameMutation',
                  valueNameObj
                );
              }
              let storeObj = {
                index: a,
                operator: this.storeGroupEntityArray[a]
                  .storeGroupAttibuteOperatorArray[0]
              };
              this.$store.commit(
                'storeGroupModule/updateAttibuteOperatorArrayMutation',
                storeObj
              );
            });
        });
      this.$store.commit('storeGroupModule/updateErrorsMutation', a);
    },
    ShowSinglePreviewPopup (i) {
      let previewStore = [];
      let criteria = [];
      this.storeGroupEntityArray.forEach((val, i) => {
        let andOrCondition = 0;
        if (i === 0) {
          criteria[i] = {
            operator: andOrCondition,
            programEntityId: val.selectedBusinessEntity,
            criteriaList: []
          };
        } else if (i >= 1) {
          criteria[i] = {
            operator: val.storeGroupDefaultCondition === 'AND' ? 1 : 2,
            programEntityId: val.selectedBusinessEntity,
            criteriaList: []
          };
        }
        val.storeGroupAttibuteOperatorArray.forEach((arr, j) => {
          let attributeValue = arr.storeGroupAttributeArray.filter(
            x => x.extensionPropertyId === arr.selectedGroupAttribute
          );
          let operatorValue = arr.storeGroupOperatorArray.filter(
            x => x.name === arr.selectedGroupOperator
          );
          criteria[i].criteriaList[j] = {
            criteriaType: attributeValue[0].columnName,
            operator: operatorValue[0].value,
            criteriaValue: arr.selectedGroupValue,
            isExtensionProperty: attributeValue[0].isExtendedAttribute
          };
        });
      });
      previewStore.pageSize = 10;
      previewStore.pageNumber = 1;
      criteria[i].operator = 0;
      previewStore.storeGroupCrieterias = [{ ...criteria[i] }];
      previewStore = [{ ...previewStore }];
      this.$store.commit('storeGroupModule/preiewStore', previewStore);
      this.$store.dispatch('storeGroupModule/getStoreDetails', previewStore);
      this.$store.commit('storeGroupModule/previewPopupValuesMutations', [
        { ...criteria[i] }
      ]);
      this.$store.commit('storeGroupModule/previewPopupMutation', true);
      let content = document.querySelector('html');
      content.classList.add('overflow-y-hidden');
    },
    ShowPreviewPopup () {
      let previewStore = [];
      let criteria = [];
      this.storeGroupEntityArray.forEach((val, i) => {
        let andOrCondition = 0;
        if (i === 0) {
          criteria[i] = {
            operator: andOrCondition,
            programEntityId: val.selectedBusinessEntity,
            criteriaList: []
          };
        } else if (i >= 1) {
          criteria[i] = {
            operator: val.storeGroupDefaultCondition === 'AND' ? 1 : 2,
            programEntityId: val.selectedBusinessEntity,
            criteriaList: []
          };
        }
        val.storeGroupAttibuteOperatorArray.forEach((arr, j) => {
          let attributeValue = arr.storeGroupAttributeArray.filter(
            x => x.extensionPropertyId === arr.selectedGroupAttribute
          );
          let operatorValue = arr.storeGroupOperatorArray.filter(
            x => x.name === arr.selectedGroupOperator
          );
          criteria[i].criteriaList[j] = {
            criteriaType: attributeValue[0].columnName,
            operator: operatorValue[0].value,
            criteriaValue: arr.selectedGroupValue,
            isExtensionProperty: attributeValue[0].isExtendedAttribute
          };
        });
      });
      previewStore.pageSize = 10;
      previewStore.pageNumber = 1;
      previewStore.storeGroupCrieterias = criteria;
      previewStore = [{ ...previewStore }];
      this.$store.commit('storeGroupModule/preiewStore', previewStore);
      this.$store.dispatch('storeGroupModule/getStoreDetails', previewStore);
      this.$store.commit(
        'storeGroupModule/previewPopupValuesMutations',
        criteria
      );
      this.$store.commit('storeGroupModule/previewPopupMutation', true);
      let content = document.querySelector('html');
      content.classList.add('overflow-y-hidden');
    },
    selectedOperator (val) {
      if (
        val.selectedGroupOperator === undefined ||
        val.selectedGroupOperator === ''
      ) {
        val.operatorErrorExists = true;
      } else {
        val.operatorErrorExists = false;
      }
    },
    selectedValue (val) {
      if (
        val.selectedGroupValue === undefined ||
        val.selectedGroupValue === ''
      ) {
        val.valueErrorExists = true;
      } else {
        val.valueErrorExists = false;
      }
    },
    selectedAttribute (val, a, b) {
      let attributeResult = val.storeGroupAttributeArray.filter(obj => {
        return obj.extensionPropertyId === val.selectedGroupAttribute;
      });
      if (attributeResult[0].dataType === 'String') {
        this.operatorArray = [
          { name: 'Matches Exactly', value: 8 },
          { name: 'Contains', value: 9 },
          { name: 'Starts With', value: 10 }
        ];
      } else if (attributeResult[0].dataType === 'Boolean') {
        this.operatorArray = [
          { name: 'Is', value: 6 },
          { name: 'Is Not', value: 7 }
        ];
      } else if (
        attributeResult[0].dataType === 'DateTime' ||
        attributeResult[0].dataType === 'Number'
      ) {
        this.operatorArray = [
          { name: 'Equals', value: 0 },
          { name: 'Less Than', value: 1 },
          { name: 'Less Than or Equals', value: 2 },
          { name: 'Greater Than', value: 3 },
          {
            name: 'Greater Than or Equals',
            value: 4
          },
          { name: 'Does Not Equal', value: 5 }
        ];
      }
      let stringObj = {
        entityIndex: a,
        valueIndex: b,
        valueArray: this.operatorArray
      };
      this.$store.commit(
        'storeGroupModule/updatestoreGroupOperatorArrayMutation',
        stringObj
      );
      this.$store
        .dispatch('storeGroupModule/getValuePropertyAction', attributeResult[0])
        .then(res => {
          val.selectedGroupValue = '';
          const dataresult = [...new Set(res.data.data)];
          let extensionArray = dataresult.map((item, index) => {
            const extensionObj = { index: index, extensionPropertyValue: item };
            return extensionObj;
          });
          extensionArray = extensionArray.filter(obj => {
            if (obj.extensionPropertyValue !== null) {
              return obj;
            }
          });
          let obj = {
            entityIndex: a,
            valueIndex: b,
            valueArray: extensionArray
          };
          this.$store.commit(
            'storeGroupModule/updatestoreGroupValueArrayMutation',
            obj
          );
          if (res.data.data === undefined) {
            let valueNameObj = {
              entityIndex: a,
              valueIndex: b,
              valueName: 'No options available'
            };
            this.$store.commit(
              'storeGroupModule/updateValueNameMutation',
              valueNameObj
            );
          } else {
            let valueNameObj = {
              entityIndex: a,
              valueIndex: b,
              valueName: attributeResult[0].columnName
            };
            this.$store.commit(
              'storeGroupModule/updateValueNameMutation',
              valueNameObj
            );
          }
        });
      let indexObj = {
        entityIndex: a,
        valueIndex: b
      };
      this.$store.commit(
        'storeGroupModule/updateOperatorErrorMutation',
        indexObj
      );
    }
  },
  computed: {
    ...mapState('storeGroupModule', {
      storeGroupDetails: state => {
        return state.storeGroupDetails;
      },
      storeBusinessEntity: state => {
        return state.storeBusinessEntity;
      },
      showPreviewPopup: state => {
        return state.showPreviewPopup;
      },
      storeGroupAttributeArray: state => {
        return state.storeGroupAttributeArray;
      },
      storeGroupEntityArray: state => {
        return state.storeGroupEntityArray;
      }
    })
  }
};
</script>
<style lang="scss" scoped>
.max-width-290 {
  max-width: 290px !important;
}
</style>
