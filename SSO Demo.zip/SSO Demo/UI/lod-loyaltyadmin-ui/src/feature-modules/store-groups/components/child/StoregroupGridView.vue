<template>
  <v-row>
    <v-col cols="12" v-for="(item, i) in storeGroupList" :key="i">
      <v-card class="gen2-card gen2-typo3">
        <v-row no-gutters>
          <v-col md="3" sm="12" xs="12">
            <v-card-title class="elipsis-fullwidth">
              <!-- <v-icon class="primary-text icon-btn-hover-none"
                >mdi-bookmark</v-icon
              > -->
              <!-- <v-icon
                id="prom_grid_bookmark_false"
                v-else
                class="primary-text icon-btn-hover-none"
                @click="updateBookmark(commMsg, index)"
                >bookmark_border</v-icon
              > -->
              {{ item.name }}
            </v-card-title>
            <div class="gen2-card-copy">
              <!-- <p class="elipsis-fullwidth bmb1" id="viewuser_email">
                <strong>{{ $t('storeGroupCode') }}: </strong>
                {{ item.storeGroupId }}
              </p>
              <p>
                <strong>{{ $t('storesCount') }}: </strong>
                {{ item.storesCount }}
              </p>-->
              <p>
                <strong>{{ $t("programEntityLabel") }}: </strong>
                {{ item.programEntityName }}
              </p>
            </div>
          </v-col>
          <v-col md="3" sm="12" xs="12" class="bpx4">
            <v-row no-gutters class="flex-column">
              <v-col>
                <p class="bmt0">
                  <strong>{{ $t("storeGroupDescription") }}:</strong>
                </p>
              </v-col>
              <v-col>
                <p class="elipsis-twoline bmt0" :title="item.description">
                  {{ item.description }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col md="4" sm="12" xs="12" class="bpr6 bpl6">
            <!-- <v-row no-gutters class="pr-3 bmb1">
              <v-col class="text-xs-left">
                <p class="bmt0">
                  <strong>{{ $t('storeGroupCreatedBy') }}: </strong>
                </p>
              </v-col>
              <v-col class="text-xs-right">
                <p class="bmt0">
                  {{ item.authorFullName }}
                </p>
              </v-col>
            </v-row> -->
            <v-row no-gutters class="pr-3">
              <v-col class="text-xs-left">
                <p class="bmt0">
                  <strong>{{ $t("createdOnText") }}:</strong>
                </p>
              </v-col>
              <v-col class="text-xs-right bpr3 bpl3">
                <p class="bmt0">
                  {{ format_date(item.createdDate) }} {{ localTimeZone }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col sm="2">
            <v-row no-gutters>
              <v-col md="12" class="bpt0 bpb0">
                <p class="bmt0">
                  <strong>{{ $t("statusLabel") }}</strong>
                </p>
              </v-col>
              <v-col sm="12">
                <brierley-status
                  v-if="item.status === true"
                  status="Active"
                ></brierley-status>
              </v-col>
            </v-row>
          </v-col>
          <v-col sm="12" class="bmt1">
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span :title="$t('viewDetails')" class="active">
                  <v-icon>fe fe-eye</v-icon>
                  <span class="viewdetails-icon">{{ $t("viewDetails") }}</span>
                </span>
                <span
                  :title="$t('editLabel')"
                  data-qe-id="edit_btn"
                  @click="editStoreGroup(item)"
                >
                  <v-icon id="viewuser_edit-icon" class="blackicon"
                    >fe fe-edit</v-icon
                  >
                  <span class="edit-icon" id="viewuser-edit">{{
                    $t("editLabel")
                  }}</span>
                </span>
                <span :title="$t('cloneLabel')" @click="cloneStoreGroup(item)">
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >feather-icon fe fe-copy</v-icon
                  >
                  <span class="clone-icon">
                    {{ $t("cloneLabel") }}
                  </span>
                </span>
                <span
                  :title="$t('deleteText')"
                  data-qe-id="delete_btn"
                  @click="deleteStoreGroup(item)"
                >
                  <v-icon class="blackicon cursor-p">fe-trash-2</v-icon>
                  <span class="delete-icon">{{ $t("deleteText") }}</span>
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
        </v-row>
      </v-card>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyCardIcons, BrierleyStatus } from '@brierley/SharedComponents';
import { storeGroupListObj } from './../../../../i18n/language.js';
import moment from 'moment-timezone';
export default {
  components: {
    BrierleyCardIcons,
    BrierleyStatus
  },
  computed: {
    storeGroupList: {
      get () {
        return this.filterResult
          ? this.filterResult
          : this.storeGroupListData.filter(item => {
            return item.status === true;
          });
      }
    }
  },
  data () {
    return {
      localTimeZone: ''
    };
  },

  i18n: storeGroupListObj,
  props: {
    storeGroupListData: {
      type: Array,
      defualt: []
    },
    filterResult: {
      type: Array,
      default: () => 0
    },
    params: {
      type: Array,
      defualt: []
    }
  },
  methods: {
    editStoreGroup (val) {
      let programId = localStorage.getItem('programId');
      this.$store
        .dispatch('storeGroupModule/getStoreBusinessEntityAction', programId)
        .then(() => {
          let obj = [
            {
              name: val.programEntityName,
              businessEntityId: val.programEntityId
            }
          ];
          this.$store.commit(
            'storeGroupModule/selectedProgramEntityMutation',
            obj
          );
          this.$router.push({
            name: 'StoreGroupPageEdit',
            query: { res: val.storeGroupId }
          });
        });
    },
    cloneStoreGroup (val) {
      let programId = localStorage.getItem('programId');
      this.$store
        .dispatch('storeGroupModule/getStoreBusinessEntityAction', programId)
        .then(() => {
          let obj = [
            {
              name: val.programEntityName,
              businessEntityId: val.programEntityId
            }
          ];
          this.$store.commit(
            'storeGroupModule/selectedProgramEntityMutation',
            obj
          );
          this.$router.push({
            name: 'StoreGroupPageClone',
            query: { res: val.storeGroupId }
          });
        });
    },
    format_date (value) {
      if (value) {
        let localZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        this.localTimeZone = moment()
          .tz(localZone)
          .zoneAbbr();
        return moment(String(value)).format('MMM Do YYYY, h:mm A');
      }
    },
    deleteStoreGroup (val) {
      this.$store.commit(
        'storeGroupModule/showDeletePopUpDialogueMutation',
        true
      );
      let deleteStoreGroupObj = {
        id: val.storeGroupId,
        name: val.name
      };
      this.$store.commit(
        'storeGroupModule/deleteStoreGroupIdMutation',
        deleteStoreGroupObj
      );
    }
  }
};
</script>
