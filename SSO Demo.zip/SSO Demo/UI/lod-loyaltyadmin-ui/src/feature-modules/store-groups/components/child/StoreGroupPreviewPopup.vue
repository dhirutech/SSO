<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        class="custom-dialog__large custom-large"
        :dialog="true"
        @closeMe="closePopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ $t("storesList") }}
          </v-card-title>
        </template>
        <template v-slot:dialog-body-description>
          <v-col class="preview-stores-list">
            <v-row no-gutters>
              <v-col md="12" class="mt-5"
                    ><h3 class="preview-stores-list__title">
                      {{ $t("storeCriteriaDetails") }}
                    </h3></v-col
                  >
              <v-col class="preview-stores-list__criteria" cols="12">
                <v-col class="bpa0 bmy5">
              <span v-for="(items, i) in previewPopupRes" :key="i">
                <p>
                  <strong>{{ $t('entity') }}:</strong>
                  <span class="pl-1">{{
                    getProgramEntity(items.programEntityId, i)
                  }}</span>
                </p>
                <p>
                  <strong>{{ $t('storeGroupAttribute') }}:</strong>
                  <span
                    v-for="(item, j) in items.criteriaList"
                    :key="j"
                    class="pl-1"
                  >
                    {{ getColumnName(item.criteriaType, i, j) }}
                    {{ getOperator(item.operator, i, j) }}
                    {{ item.criteriaValue }}
                  </span>
                </p>
                <hr
                  v-if="previewPopupRes.length - 1 !== i"
                  class="separationLine bmt5 bmb3"
                />
              </span>
            </v-col>
              </v-col>
              <v-row no-gutters class="mt-7 px-0">
                <v-col md="12"
                  ><h3 class="preview-stores-list__title">
                    {{ $t("storeDetails") }}<small>({{ getStoreGroupStoresCountRes }} {{ $t("stores") }})</small>
                  </h3></v-col
                >
                <v-col md="12" class="mt-7">
                  <v-simple-table class="gen2-sample-table" v-if="getStoreGroupStoresCountRes > 0">
                    <thead>
                      <tr>
                        <th>{{ $t("storeName") }}</th>
                        <th>{{ $t("storeCode") }}</th>
                        <th>{{ $t("storeAddress") }}</th>
                        <th>{{ $t("countryCityName") }}</th>
                        <th>{{ $t("status") }}</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="item in getStoreGroupStoresRes"
                        :key="item.storeName">
                        <td>{{ item.storeName }}</td>
                        <td>{{ externalStoreCode }}</td>
                        <td>
                          {{ item.addressLineOne }}, {{ item.addressLineTwo }},
                          {{ item.city }}, {{ item.stateOrProvince }}, {{ item.zipOrPostalCode }}
                        </td>
                        <td>{{ item.city }}</td>
                        <td>
                          <brierleyStatus status="Active"></brierleyStatus>
                        </td>
                      </tr>
                    </tbody>
                  </v-simple-table>
                  <brierley-no-result
                    v-if="getStoreGroupStoresCountRes === 0"
                    :noRecordFoundHeader="$t('noRecordFoundHeader')"
                    :noResultMessage="$t('noResultMessage')"
                  >
                </brierley-no-result>
                </v-col>
              </v-row>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer v-if="loadmore === true">
          <v-col md="12" class="text-center">
            <v-row
              class="d-flex d-inline-flex flex-column load-more-listing text-center"
              no-gutters
            >
              <v-col class="bpa2">
                <v-progress-circular
                  :width="3"
                  indeterminate
                  color="brown"
                ></v-progress-circular>
              </v-col>
              <v-col>{{ $t("loadMore") }}</v-col>
            </v-row>
          </v-col>
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox, BrierleyNoResult } from '@brierley/SharedComponents';
import { storeCancelPopUpObject } from '../../../../i18n/language.js';
import { BrierleyStatus } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
export default {
  data () {
    return {
      dialog: false,
      loadmore: true
    };
  },
  components: {
    BrierleyDialogbox,
    BrierleyStatus,
    BrierleyNoResult
  },
  i18n: storeCancelPopUpObject,
  mounted () {
    let scrollInnerHeight = document.querySelector('.v-dialog--fullscreen');
    document.querySelector('.v-dialog--fullscreen').onscroll  = () => {
      if (
        scrollInnerHeight.scrollHeight ===
          scrollInnerHeight.scrollTop + scrollInnerHeight.clientHeight
      ) {
        this.loadMoreStores();
      }
    };
  },
  methods: {
    getProgramEntity (item, i) {
      let value = this.storeGroupEntityArray[i].storeGroupBusinessEntity.filter(
        (x) => x.businessEntityId === item
      );
      return value[0].name;
    },
    getColumnName (item, i, j) {
      let value = this.storeGroupEntityArray[i].storeGroupAttibuteOperatorArray[
        j
      ].storeGroupAttributeArray.filter((x) => x.columnName === item);
      return value[0].columnName;
    },
    getOperator (item, i, j) {
      let value = this.storeGroupEntityArray[i].storeGroupAttibuteOperatorArray[
        j
      ].storeGroupOperatorArray.filter((x) => x.value === item);
      return value[0].name;
    },
    loadMoreStores () {
      if (this.getStoreGroupStoresCountRes > this.getStoreGroupStoresRes.length) {
        this.loadmore = true;
        this.preiewStore[0].pageSize += 10;
        this.$store.dispatch('storeGroupModule/getStoreDetails', this.preiewStore);
      }
    },
    closePopup () {
      this.$store.commit('storeGroupModule/previewPopupMutation', false);
    },
  },
  computed: {
    ...mapState('storeGroupModule', {
      previewPopupRes: (state) => {
        return state.previewPopupValues;
      },
      getStoreGroupStoresRes: (state) => {
        return state.getStoreGroupStores;
      },
      storeGroupEntityArray: (state) => {
        return state.storeGroupEntityArray;
      },
      reviewData: (state) => {
        return state.reviewData;
      },
      getStoreGroupStoresCountRes: (state) => {
        return state.getStoreGroupStoresCount;
      },
      preiewStore: (state) => {
        return state.preiewStore;
      },
    })
  },
  watch: {
    getStoreGroupStoresRes () {
      this.loadmore = false;
    },
  }
};
</script>
