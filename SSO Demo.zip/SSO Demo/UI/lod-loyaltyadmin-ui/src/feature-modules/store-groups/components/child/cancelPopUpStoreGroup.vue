<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closePopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title
            class="gen2-dialog-title text-uppercase"
            v-if="
              $route.name === 'StoreGroupPage' ||
                $route.name === 'StoreGroupPageClone'
            "
          >
            {{ $t("cardTitle") }}</v-card-title
          >
          <v-card-title
            class="gen2-dialog-title text-uppercase"
            v-if="$route.name === 'StoreGroupPageEdit'"
          >
            {{ $t("saveChanges") }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col
            v-if="
              $route.name === 'StoreGroupPage' ||
                $route.name === 'StoreGroupPageClone'
            "
          >
            <v-row no-gutters>
              <v-col md="12">
                <brierley-alert
                  alertType="error"
                  :alertBody="$t('alertMsg')"
                ></brierley-alert>
              </v-col>
            </v-row>
          </v-col>
          <v-col v-if="$route.name === 'StoreGroupPageEdit'">
            <v-row no-gutters>
              <v-col md="12">
                <brierley-alert
                  alertType="error"
                  :alertBody="$t('saveYourChanges')"
                ></brierley-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="org_btn_cancelDeleteDialog"
            data-qe-id="communicationManagement_no_btn"
            text
            class="cancel no-ripple"
            @click="closeDeleteEntityPopupWhenClickNo()"
            >{{ $t("noBtnText") }}</v-btn
          >
          <v-btn
            id="org_btn_deleteDeleteDialog"
            class="primaryctabtn text-uppercase"
            data-qe-id="communicationManagement_yes_btn"
            title
            @click="navigateToList()"
            >{{ $t("yesBtnText") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox, brierleyAlert } from '@brierley/SharedComponents';
import { storeCancelPopUpObject } from '../../../../i18n/language.js';
import { mapState } from 'vuex';
export default {
  data () {
    return {
      dialog: false,
    };
  },
  components: {
    BrierleyDialogbox,
    brierleyAlert,
  },
  i18n: storeCancelPopUpObject,
  computed: {
    ...mapState('storeGroupModule', {
      storeGroupDetails: (state) => {
        return state.storeGroupDetails;
      },
      reviewData: (state) => {
        return state.reviewData;
      },
      storeBusinessEntity: (state) => {
        return state.storeBusinessEntity;
      },
      storeGroupAttributeArray: (state) => {
        return state.storeGroupAttributeArray;
      },
      storeGroupEntityArray: (state) => {
        return state.storeGroupEntityArray;
      },
      programEntity: (state) => {
        return state.programEntity;
      },
    }),
  },
  methods: {
    errorCriteria () {
      let errorCount = 0;
      let extensionArray = this.storeGroupEntityArray.filter((obj) => {
        if (
          obj.selectedBusinessEntity === null ||
          obj.selectedBusinessEntity === '' ||
          obj.selectedBusinessEntity === undefined
        ) {
          obj.entityErrorExists = true;
          errorCount++;
        } else {
          obj.entityErrorExists = false;
        }
        let attributeArray = obj.storeGroupAttibuteOperatorArray.filter(
          (item) => {
            if (
              item.selectedGroupAttribute === null ||
              item.selectedGroupAttribute === '' ||
              item.selectedGroupAttribute === undefined
            ) {
              item.attributeErrorExists = true;
              errorCount++;
            } else {
              item.attributeErrorExists = false;
            }
            if (
              item.selectedGroupOperator === null ||
              item.selectedGroupOperator === '' ||
              item.selectedGroupOperator === undefined
            ) {
              item.operatorErrorExists = true;
              errorCount++;
            } else {
              item.operatorErrorExists = false;
            }
            if (
              item.selectedGroupValue === null ||
              item.selectedGroupValue === '' ||
              item.selectedGroupValue === undefined
            ) {
              item.valueErrorExists = true;
              errorCount++;
            } else {
              item.valueErrorExists = false;
            }
          }
        );
      });
      return errorCount;
    },
    closePopup () {
      this.$store.commit('storeGroupModule/closePopupMutation', false);
    },
    navigateToList () {
      if (
        this.$route.name === 'StoreGroupPage' ||
        this.$route.name === 'StoreGroupPageClone'
      ) {
        this.$router.push('/loyaltyadmin/storeGroupList');
      } else if (this.$route.name === 'StoreGroupPageEdit') {
        const count = this.errorCriteria();
        if (count === 0) {
          let storeGroupData = {};
          let criteria = [];
          let programId = localStorage.getItem('programId');
          storeGroupData.storeGroupId = this.storeGroupDetails.storeGroupId
            ? this.storeGroupDetails.storeGroupId
            : 0;
          storeGroupData.name = this.storeGroupDetails.storeGroupName;
          storeGroupData.description = this.storeGroupDetails.storeGroupDescription;
          storeGroupData.businessEntityId = this.programEntity[0].businessEntityId;
          storeGroupData.programId = programId;
          this.storeGroupEntityArray.forEach((val, i) => {
            let andOrCondition = 0;
            if (i === 0) {
              criteria[i] = {
                operator: andOrCondition,
                programEntityId: val.selectedBusinessEntity,
                criteriaList: [],
              };
            } else if (i >= 1) {
              criteria[i] = {
                operator: val.storeGroupDefaultCondition === 'AND' ? 1 : 2,
                programEntityId: val.selectedBusinessEntity,
                criteriaList: [],
              };
            }
            val.storeGroupAttibuteOperatorArray.forEach((arr, j) => {
              let attributeValue = arr.storeGroupAttributeArray.filter(
                (x) => x.extensionPropertyId === arr.selectedGroupAttribute
              );
              let operatorValue = arr.storeGroupOperatorArray.filter(
                (x) => x.name === arr.selectedGroupOperator
              );
              criteria[i].criteriaList[j] = {
                criteriaType: attributeValue[0].columnName,
                operator: operatorValue[0].value,
                criteriaValue: arr.selectedGroupValue,
                isExtensionProperty: attributeValue[0].isExtendedAttribute,
              };
            });
          });
          storeGroupData.criteria = [...criteria];
          if (this.storeGroupDetails.storeGroupName) {
            this.saveStoreGroupData(storeGroupData);
          } else {
            this.$store.commit('storeGroupModule/closePopupMutation', false);
          }
        } else if (count > 0) {
          this.$store.commit('storeGroupModule/closePopupMutation', false);
        }
      }
    },
    closeDeleteEntityPopupWhenClickNo () {
      if (
        this.$route.name === 'StoreGroupPage' ||
        this.$route.name === 'StoreGroupPageClone'
      ) {
        this.$store.commit('storeGroupModule/closePopupMutation', false);
      } else if (this.$route.name === 'StoreGroupPageEdit') {
        this.$router.push('/loyaltyadmin/storeGroupList');
      }
    },
    saveStoreGroupData (storeGroupData) {
      let programId = localStorage.getItem('programId');
      let obj = {
        name: this.storeGroupDetails.storeGroupName,
        programId: programId,
        storeGroupId: this.storeGroupDetails.storeGroupId ? this.storeGroupDetails.storeGroupId : 0
      };
      this.$store
        .dispatch('storeGroupModule/storeGroupNameExistsOrNotAction', obj)
        .then((res) => {
          if (res.status === 200 || res.status === 201) {
            this.$store
              .dispatch(
                'storeGroupModule/saveStoreGroupDataAction',
                storeGroupData
              )
              .then((res) => {
                if (res.status === 201 || res.status === 200) {
                  this.$store.commit(
                    'storeGroupModule/closePopupMutation',
                    false
                  );
                  this.$store.commit(
                    'storeGroupModule/updateStoreGroupStepperMutation',
                    4
                  );
                }
              })
              .catch((error) => {
                return error.response;
              });
          }
        })
        .catch((err) => {
          if (err.response.status === 400) {
            this.$store.commit(
              'storeGroupModule/closePopupMutation',
              false
            );
            this.$store.commit(
              'storeGroupModule/storeGroupNameExistsMutation',
              true
            );
            this.$store.commit(
              'storeGroupModule/updateStoreGroupStepperMutation',
              1
            );
          }
        });
    },
  },
};
</script>
