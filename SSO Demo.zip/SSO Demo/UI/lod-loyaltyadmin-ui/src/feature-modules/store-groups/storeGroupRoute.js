import StoreGroupPage from './components/storeGroupPage.vue';
import StoreGroupLayout from './components/storeGroupLayout.vue';
import StoreGroupList from './components/StoreGroupList.vue';

const storeGroupRoutes = [
  {
    path: '/loyaltyadmin/storeGroupPage',
    name: 'StoreGroupPage',
    component: StoreGroupPage,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/storeGroupPage/edit',
    name: 'StoreGroupPageEdit',
    component: StoreGroupLayout,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/storeGroupPage/clone',
    name: 'StoreGroupPageClone',
    component: StoreGroupLayout,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/storeGroupLayout',
    name: 'StoreGroupLayout',
    component: StoreGroupLayout,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/storeGroupList',
    name: 'StoreGroupList',
    component: StoreGroupList,
    meta: {
      showNavigation: true
    }
  }
];

export default storeGroupRoutes;
