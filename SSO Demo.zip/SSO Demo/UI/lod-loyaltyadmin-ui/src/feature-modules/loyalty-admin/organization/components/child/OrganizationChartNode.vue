<template>
  <table>
    <tbody>
      <tr class="topTR">
        <td
          :colspan="
            datasource.children && datasource.children.length
              ? datasource.children.length * 2
              : null
          "
        >
          <div
            class="node"
            :id="datasource.id"
            @click.stop="handleClick(datasource)"
          >
            <slot :node-data="datasource">
              <div class="nodeItem" :class="constructClass()">
                <v-list-item class="px-0">
                  <!-- <v-list-item-avatar style="margin-right:0px" class="bmy0">

                  </v-list-item-avatar> -->

                  <v-icon color="#000">{{ datasource.icon }}</v-icon>

                  <v-list-item-title class="nodeTitle">
                    {{ datasource.name }}
                  </v-list-item-title>

                  <v-row no-gutters class="abc">
                    <v-col>
                      <v-menu offset-y attach close-on-click="true">
                        <template v-slot:activator="{ on }">
                          <v-btn
                            icon
                            small
                            class="content-ma-0 btn-hover-none"
                            v-on="on"
                          >
                            <v-icon class="bml1" small>more_vert</v-icon>
                          </v-btn>
                        </template>
                        <v-list class="node-more-menu text-left">
                          <v-list-item @click="onAdd(datasource)">
                            <v-list-item-title>
                              <v-icon class="font24" left>add</v-icon
                              >{{ $t('addText') }}
                            </v-list-item-title>
                          </v-list-item>

                          <v-list-item @click="onEdit(datasource)">
                            <v-list-item-title>
                              <v-icon class="font24" left>edit</v-icon
                              >{{ $t('editText') }}
                            </v-list-item-title>
                          </v-list-item>
                          <v-list-item @click="onDelete(datasource)">
                            <v-list-item-title>
                              <v-icon class="font24" left>delete</v-icon
                              >{{ $t('deleteText') }}
                            </v-list-item-title>
                          </v-list-item>
                        </v-list>
                      </v-menu>
                    </v-col>
                  </v-row>
                </v-list-item>
              </div>
            </slot>
          </div>
        </td>
      </tr>
      <template v-if="datasource.children && datasource.children.length">
        <tr class="lines">
          <td :colspan="datasource.children.length * 2">
            <div
              :class="{
                downLine: datasource.children.length > 2,
                downLine1: datasource.children.length === 2,
                downLine2: datasource.children.length === 1
              }"
            ></div>
          </td>
        </tr>
        <tr class="lines">
          <td class="rightLine"></td>
          <template v-for="n in datasource.children.length - 1">
            <td class="leftLine topLine" :key="`leftLine-${n}`"></td>
            <td class="rightLine topLine" :key="`rightLine-${n}`"></td>
          </template>
          <td class="leftLine"></td>
        </tr>
        <tr class="nodes">
          <td colspan="2" v-for="child in datasource.children" :key="child.id">
            <node :datasource="child" :handle-click="handleClick"></node>
          </td>
        </tr>
      </template>
    </tbody>
  </table>
</template>

<script>
import { organizationChartNodeElementObject } from '../../../../../i18n/language.js';
export default {
  name: 'node',
  props: {
    datasource: Object,
    handleClick: Function
  },
  i18n: organizationChartNodeElementObject,
  methods: {
    onAdd (datasource) {
      let entityNodeObject = datasource;
      this.$store.dispatch('orgModule/entityObjectAction', entityNodeObject);
      this.$store.dispatch('orgModule/showAddEntityDialogAction', {
        showAddEntityDialog: true,
        showAddEntityDetailsDialog: false
      });
      let content = document.querySelector('html');
      content.classList.add('overflow-y-hidden');
    },
    myIconColor (icon) {
      switch (icon) {
      case 'business':
        return '0E1E61';
      case 'domain':
        return '0E1E61';
      case 'language':
        return '5BB9BC';
      case 'store':
        return '60BFFE';
      case 'location_city':
        return 'A154F2';
      default:
        return '000';
      }
    },
    onEdit (res) {
      let entityNodeObject = res;
      this.$store.dispatch('orgModule/entityObjectAction', entityNodeObject);
      this.$store.dispatch('orgModule/showUpdateEntityDialogAction', true);
    },
    onDelete (res) {
      let entityNodeObject = res;
      this.$store.dispatch('orgModule/entityObjectAction', entityNodeObject);
      this.$store.dispatch('orgModule/showDeleteEntityDialogAction', true);
    },
    constructClass () {
      if (this.datasource.parentEntityId === null) {
        return 'company-node';
      } else {
        let getClass = '';
        switch (this.datasource.icon) {
        case 'business':
          getClass = 'company-node';
          break;
        case 'domain':
          getClass = 'nodeItem';
          break;
        case 'language':
          getClass = 'nodeItem1';
          break;
        case 'store':
          getClass = 'nodeItem2';
          break;
        case 'location_city':
          getClass = 'nodeItem3';
          break;
        default:
          getClass = 'nodeItem';
          break;
        }
        return getClass;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.nodeTitle {
  text-align: left;
  width: 35px;
  height: 14px;
  font-family: 'Open Sans', sans-serif !important;
  font-size: 10px !important;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #000000;
  padding-top: 3px;
}
.nodeRow {
  margin: 0;
  position: relative;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
  padding: 10px;
}
.node-more-menu {
  min-width: 143px;
  .v-list-item__title {
    color: #212121 !important;
    font-size: 15px !important;
    font-weight: 600 !important;
  }
  .v-icon {
    color: #000000 !important;
    margin-left: 0;
  }
  .v-list-item {
    min-height: 48px !important;
  }
}
.nodeItem {
  .v-btn {
    .v-icon {
      color: #000000 !important;
    }
  }
}
</style>
