<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <template v-if="orgData">
        <org-chart :datasource="orgData"></org-chart>
      </template>
    </v-col>
    <v-col v-if="showDialog.showAddEntityDialog">
      <AddEntity></AddEntity>
    </v-col>
    <v-col v-if="showDialog.showAddEntityDetailsDialog">
      <AddTypeEntity></AddTypeEntity>
    </v-col>
    <v-col v-if="showUpdateEntityDialog">
      <update-pop-up />
    </v-col>
    <v-col v-if="showDeleteEntityDialog">
      <delete-pop-up />
    </v-col>
  </v-row>
</template>

<script>
import { mapState } from 'vuex';
import OrgChart from './OrganizationChartContainer.vue';
import AddEntity from './AddEntity.vue';
import AddTypeEntity from './AddTypeEntity.vue';
import { getJsonData } from '../../helper/org-helper.js';
import UpdatePopUp from './UpdatePopUp';
import DeletePopUp from './DeletePopUp';
export default {
  name: 'app',
  components: {
    OrgChart,
    AddEntity,
    AddTypeEntity,
    UpdatePopUp,
    DeletePopUp
  },
  computed: {
    ...mapState('orgModule', {
      orgData: (state) => {
        return getJsonData(state.orgData);
      }
    }),
    ...mapState('orgModule', ['showDialog']),
    ...mapState('orgModule', ['showUpdateEntityDialog']),
    ...mapState('orgModule', ['showDeleteEntityDialog'])
  },
  created () {
    this.$store.dispatch('orgModule/getOrganizationDataAction');
    this.$store.dispatch('orgModule/getOrganizationTypeDropDownDataAction');
  }
};
</script>
