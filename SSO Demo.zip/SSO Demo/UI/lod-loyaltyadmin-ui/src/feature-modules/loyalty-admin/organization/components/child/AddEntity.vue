<template>
  <Validation-Observer v-slot="{ handleSubmit }">
    <form id="entity_popup" @submit.prevent="handleSubmit(onsubmit)">
      <brierley-dialogbox
        :dialog="true"
        persistent
        @closeMe="closeAddNewEntityPopup()"
      >
        <template v-slot:dialog-header>
          <v-card-title
            class="gen2-dialog-title text-uppercase"
            data-qe-id="org_addEntity_cardTitle"
            >{{ $t("cardTitle") }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row
              no-gutters
              class="flex-column gen2-forms form-light-bg min-height-200 overflow-y-hidden"
            >
              <v-col class="bmt2" sm="4" xs="12" md="6">
                <v-select
                  :items="orgTypeItems"
                  item-text="name"
                  item-value="name"
                  v-model="organizationType"
                  filled
                  attach
                  offset-y
                  class="gen2select gen2select__dark mini-list"
                  :label="$t('typeOfOrgText')"
                  append-icon="expand_more"
                  :disabled="orgTypeBoolean"
                  :data-qe-id="`org_addEntityOrgType_${organizationType}`"
                ></v-select>
              </v-col>
              <v-col sm="6" md="6" v-if="organizationType === 'Other'">
                <validation-provider rules="required" v-slot="{ errors }">
                  <v-text-field
                    autocomplete="off"
                    :label="$t('enterOrgText')"
                    @input="enterEntityText()"
                    v-model="otherTypeOrgName"
                    filled
                    required
                    :maxLength="max"
                    data-qe-id="org_addEntity_orgText"
                  ></v-text-field>
                  <p
                    class="custom-error-msg"
                    v-if="
                      errors[0] != undefined &&
                        errors[0].length > 0 &&
                        errors[0] === 'This field is required'
                    "
                  >
                    {{ $t("nameErrorText") }}
                  </p>
                  <p
                    class="custom-error-msg"
                    v-else-if="errors[0] != undefined && errors[0].length > 0"
                  >
                    {{ errors[0] }}
                  </p>
                  <p
                    v-if="entityExists && otherTypeOrgName"
                    class="custom-error-msg"
                  >
                    {{ entityExistsErrorMsg }}
                  </p>
                </validation-provider>
              </v-col>
              <v-col sm="6" md="6" class="bpr6">
                <validation-provider rules="required" v-slot="{ errors }">
                  <v-text-field
                    autocomplete="off"
                    :label="$t('howManyText')"
                    @keypress="onlyNumber"
                    @paste.prevent
                    filled
                    v-model.number="noOfLevels"
                    data-qe-id="org_addEntity_levels"
                  ></v-text-field>
                  <p
                    class="custom-error-msg"
                    v-if="
                      errors[0] != undefined &&
                        errors[0].length > 0 &&
                        errors[0] === 'This field is required'
                    "
                  >
                    {{ $t("fieldErrorText") }}
                  </p>
                  <p
                    class="custom-error-msg"
                    v-if="
                      errors[0] != undefined &&
                        errors[0].length > 0 &&
                        errors[0] === 'Fields must be greater than one'
                    "
                  >
                    {{ $t("fieldErrorText") }}
                  </p>
                </validation-provider>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            text
            class="cancel no-ripple cursor-p btn-hover-none"
            @click="closeAddNewEntityPopup()"
            data-qe-id="org_addEntity_cancelBtn"
            >{{ $t("cancelBtnText") }}</v-btn
          >
          <v-btn
            class="primaryctabtn text-uppercase cursor-p"
            title="Default"
            type="submit"
            form="entity_popup"
            data-qe-id="org_addEntity_saveBtn"
            >{{ $t("saveBtnText") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </form>
  </Validation-Observer>
</template>
<script>
import Vue from 'vue';
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { addEntityOrganizationObject } from '../../../../../i18n/language.js';
export default {
  name: 'pop-up',
  data: () => ({
    entityExists: false,
    entityExistsErrorMsg: '',
    orgTypeBoolean: false,
    organizationType: '',
    tab: null,
    dialog: false,
    orgTypeItems: [],
    noOfLevels: '',
    description: '',
    max: 50,
    name: '',
    IsOtherTypeNameEmpty: false,
    HowManyFields: false,
    otherTypeOrgName: '',
    otherEntityObject: {}
  }),
  components: {
    BrierleyDialogbox
  },
  computed: {
    ...mapState('orgModule', ['entityObj']),
    ...mapState('orgModule', {
      orgTypeData: state => {
        return state.orgTypeData;
      }
    }),
    ...mapState('orgModule', ['otherEntityObj'])
  },
  mounted () {
    if (this.entityObj['children']) {
      let orgTypeResult = this.orgTypeData.filter(obj => {
        return obj.name === this.entityObj.children[0].entityTypeName;
      });
      this.orgTypeItems = orgTypeResult;
      this.orgTypeBoolean = true;
    } else {
      this.orgTypeBoolean = false;
      this.orgTypeItems = this.orgTypeData;
    }
    this.clearAddEntityFields();
    this.organizationType = this.orgTypeItems[0].name;
  },
  i18n: addEntityOrganizationObject,
  methods: {
    enterEntityText () {
      this.entityExistsErrorMsg = '';
    },
    clearAddEntityFields () {
      this.organizationType = '';
      this.noOfLevels = '';
    },
    closeAddNewEntityPopup () {
      this.clearAddEntityFields();
      this.$store.dispatch('orgModule/showAddEntityDialogAction', {
        showAddEntityDialog: false,
        showAddEntityDetailsDialog: false
      });
    },
    onlyNumber ($event) {
      let keyCode = $event.keyCode ? $event.keyCode : $event.which;
      if (keyCode < 48 || keyCode > 57) {
        $event.preventDefault();
      }
    },
    onsubmit () {
      if (this.organizationType === 'Other') {
        this.otherEntityObject['name'] = this.otherTypeOrgName;
        this.otherEntityObject['description'] = this.otherTypeOrgName;
        Vue.prototype.$http
          .post(
            '/loyaltyconfiguration/api/v1/businessEntityTypes',
            this.otherEntityObject
          )
          .then(res => {
            if (res.status === 201) {
              this.$store.dispatch(
                'orgModule/getOrganizationTypeDropDownDataAction'
              );
              if (this.organizationType && this.noOfLevels) {
                let entityObject = {};
                entityObject['parentEntityId'] = this.entityObj.id;
                entityObject['icon'] = this.entityObj.icon;
                entityObject['noOfLevels'] = this.noOfLevels;
                entityObject['otherOrgAdded'] = true;
                entityObject['businessEntityTypeId'] =
                  res.data.businessEntityTypeId;
                entityObject['orgType'] = this.otherTypeOrgName;
                this.$store.dispatch('orgModule/addEntityAction', entityObject);
                this.$store.dispatch('orgModule/showAddEntityDialogAction', {
                  showAddEntityDialog: false,
                  showAddEntityDetailsDialog: true
                });
              }
              this.entityExists = false;
            }
          })
          .catch(err => {
            if (err.response.status === 409) {
              this.entityExistsErrorMsg = err.response.data;
              this.entityExists = true;
            }
          });
      } else {
        if (this.organizationType && this.noOfLevels) {
          if (this.entityObj['children']) {
            let entityObject = {};
            entityObject['parentEntityId'] = this.entityObj.id;
            entityObject[
              'businessEntityTypeId'
            ] = this.entityObj.children[0].entityTypeId;
            entityObject['icon'] = this.entityObj.icon;
            entityObject['noOfLevels'] = this.noOfLevels;
            entityObject['orgType'] = this.entityObj.children[0].entityTypeName;
            this.$store.dispatch('orgModule/addEntityAction', entityObject);
            this.$store.dispatch('orgModule/showAddEntityDialogAction', {
              showAddEntityDialog: false,
              showAddEntityDetailsDialog: true
            });
          } else {
            let orgTypeArray = this.orgTypeData.filter(obj => {
              return obj.name === this.organizationType;
            });
            let entityObject = {};
            entityObject['parentEntityId'] = this.entityObj.id;
            entityObject['businessEntityTypeId'] = orgTypeArray[0].id;
            entityObject['icon'] = this.entityObj.icon;
            entityObject['noOfLevels'] = this.noOfLevels;
            entityObject['orgType'] = orgTypeArray[0].name;
            this.$store.dispatch('orgModule/addEntityAction', entityObject);
            this.$store.dispatch('orgModule/showAddEntityDialogAction', {
              showAddEntityDialog: false,
              showAddEntityDetailsDialog: true
            });
          }
        }
      }
      let content = document.querySelector('html');
      content.classList.remove('overflow-y-hidden');
    }
  }
};
</script>
<style lang="scss" scoped>
.iconText {
  margin-bottom: 0px !important;
}
.v-tabs-slider-wrapper {
  display: none;
}
.v-tab {
  padding: 0px !important;
  min-width: 50px !important;
}
.v-slide-group__next {
  display: none;
}
.nodeTab {
  background-color: #ddf4fc;
}
.gen2select {
  ::v-deep .v-menu__content {
    background: white !important;
    max-height: 210px !important;
  }
}
</style>
