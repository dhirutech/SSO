import OrganizationChart from './components/organizationChart';
const organizationRoutes = [
  {
    path: '/loyaltyadmin/organization',
    name: 'OrganizationChart',
    component: OrganizationChart,
    meta: {
      showNavigation: false
    }
  }
];

export default organizationRoutes;
