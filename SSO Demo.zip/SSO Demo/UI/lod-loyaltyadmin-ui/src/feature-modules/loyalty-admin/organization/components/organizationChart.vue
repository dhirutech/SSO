<template>
  <brierley-inner-view :class="{ 'success-block': currentStep === 2 }">
    <!-- Form Header Slots -->
    <template v-slot:header>
      <span class="inner-head">
        {{ $t("headerText") }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>{{ $t("closeBtnText") }}
      </v-btn>
    </template>
    <!-- Form Header Slots -->

    <!-- Form Body Slots -->
    <template v-slot:body-container :currentStep="currentStep">
      <v-row
        class="d-flex flex-column bpt4"
        no-gutters
        v-if="currentStep === 1"
      >
        <v-col>
          <brierley-form-title
            :formTitle="$t('programHierarchyFormTitle')"
            :showIcon="true"
            :infoText="$t('hierarchyInfoText')"
          />
        </v-col>
        <v-col class="bmy5" v-if="currentStep === 1">
          {{ $t("programHierarchyText") }}
        </v-col>
        <v-col v-if="currentStep === 1">
          <LoyaltyAdmin />
        </v-col>
      </v-row>
      <template v-if="currentStep === 2">
        <v-row class="bmt3 flex-column" no-gutters>
          <v-col>
            <brierley-form-title
              :formTitle="$t('successFormTitle')"
              :infoText="$t('successInfoText')"
            ></brierley-form-title>
          </v-col>
          <v-col class="bmt5 bmb2">
            <brierley-alert
              class="bmb0"
              :isSiteLevel="true"
              alertType="success"
              :alertHeader="$t('formTitleSuccess')"
              :alertBody="alertMessage"
              icon="done"
            ></brierley-alert>
          </v-col>
        </v-row>
      </template>
    </template>
    <template v-slot:footer-redirect v-if="currentStep === 2">
      <v-btn
        id="org_btn_goToStarted"
        class="primaryctabtn bmt2"
        @click.native="$router.push('/gettingstarted')"
        >{{ $t("continueBtnText") }}</v-btn
      >
    </template>
    <template v-slot:footer v-if="currentStep === 1">
      <v-btn class="primaryctabtn" @click="currentStep += 1">{{
        $t("continueBtnText")
      }}</v-btn>
    </template>
    <!-- Form Footer Slots -->
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyFormTitle,
  BrierleyInnerView,
  brierleyAlert
} from '@brierley/SharedComponents';
import LoyaltyAdmin from './child/LoyaltyAdmin';
import { mapState } from 'vuex';
import { getJsonData } from '../helper/org-helper.js';
import { organizationChartObject } from './../../../../i18n/language.js';
export default {
  components: {
    BrierleyFormTitle,
    LoyaltyAdmin,
    BrierleyInnerView,
    brierleyAlert
  },
  computed: {
    ...mapState('orgModule', {
      orgData: state => {
        return getJsonData(state.orgData);
      }
    }),
    alertMessage () {
      return (
        this.$t('programHierarchyCompany') +
        ' ' +
        `${this.orgData.name.bold()}` +
        ' ' +
        this.$t('updatedSuccesfulText')
      );
    }
  },
  data () {
    return {
      isHidden: false,
      viewType: 'grid',
      currentStep: 1
    };
  },
  i18n: organizationChartObject
};
</script>

<style lang="scss" scoped>
// .btm-ngt-margin {
//   margin-bottom: -80px !important;
// }
</style>
