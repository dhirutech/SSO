import {
  getOrgData,
  putOrgData,
  deleteEntity,
  getOrgTypeData, getProductDefinitionById
} from '../api/viewOrganization.api';
import {
  addOrganizationNodeDataAddAction,
  otherOrganizationNodeDataAddAction, nameExistsData
} from './../api/addOrganization.api.js';
const showAddEntityDialogAction = (context, payload) => {
  context.commit('showAddEntityDialogMutation', payload);
};

const showUpdateEntityDialogAction = (context, payload) => {
  context.commit('showUpdateEntityDialogMutation', payload);
};

const showDeleteEntityDialogAction = (context, payload) => {
  context.commit('showDeleteEntityDialogMutation', payload);
};

const entityObjectAction = (context, payload) => {
  context.commit('entityObjectMutation', payload);
};

const otherEntityObjectAction = (context, payload) => {
  return otherOrganizationNodeDataAddAction(payload);
};

const addEntityAction = (context, payload) => {
  context.commit('addEntityMutation', payload);
};

const getOrgDataAction = context => {
  getOrgData().then(orgDataRes => {
    context.commit('getOrganizationDataMutation', orgDataRes.data);
  });
};

const getOrganizationTypeDropDownDataAction = context => {
  getOrgTypeData().then(orgDataTypeRes => {
    context.commit(
      'getOrganizationTypeDropDownDataMutation',
      orgDataTypeRes.data
    );
  });
};

const getOrganizationDataAction = context => {
  context.dispatch('getOrgDataAction');
};

const postOrganizationNodeDataAddAction = (context, payload) => {
  addOrganizationNodeDataAddAction(payload).then(res => {
    if (res) context.dispatch('getOrgDataAction');
  });
};

const deleteEntityActions = (context, payload) => {
  deleteEntity(payload).then(res => {
    if (res.status === 200 || res.status === 201) {
      context.dispatch('getOrganizationDataAction');
    }
  });
};


const getProductDefinitionByIdAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getProductDefinitionById(payload)
      .then((res)=>{
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const postOrganizationDataAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    nameExistsData(payload)
      .then((res)=>{
        resolve(res);
        context.dispatch('getOrganizationDataAction');
      })
      .catch(err => {
        reject(err);
      });
  });
};

const putOrganidationDataAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    putOrgData(payload)
      .then((res)=>{
        resolve(res);
        context.dispatch('getOrganizationDataAction');
        context.commit('showUpdateEntityDialogMutation', false);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export default {
  postOrganizationDataAction,
  addEntityAction,
  getOrganizationDataAction,
  postOrganizationNodeDataAddAction,
  getOrgDataAction,
  showAddEntityDialogAction,
  entityObjectAction,
  putOrganidationDataAction,
  deleteEntityActions,
  showUpdateEntityDialogAction,
  showDeleteEntityDialogAction,
  getOrganizationTypeDropDownDataAction,
  otherEntityObjectAction,
  getProductDefinitionByIdAction
};
