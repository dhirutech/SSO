import Vue from 'vue';
const getOrgData = () => {
  return Vue.prototype.$http.get(
    '/loyaltyconfiguration/api/v1/businessEntities/structure'
  );
};

const getOrgTypeData = () => {
  return Vue.prototype.$http.get(
    '/loyaltyconfiguration/api/v1/businessEntityTypes'
  );
};

const putOrgData = res => {
  return Vue.prototype.$http.put(
    '/loyaltyconfiguration/api/v1/businessEntities',
    res
  );
};
const deleteEntity = deleteEntityId => {
  return Vue.prototype.$http.delete(
    'loyaltyconfiguration/api/v1/businessEntities/' + deleteEntityId
  );
};

const getProductDefinitionById = id => {
  return Vue.prototype.$http.get(
    '/product/api/v1/productdefinitions/getproductdefinitionbyid?productDefinitionId=' +
      id
  );
};

export { getOrgData, putOrgData, deleteEntity, getOrgTypeData, getProductDefinitionById };
