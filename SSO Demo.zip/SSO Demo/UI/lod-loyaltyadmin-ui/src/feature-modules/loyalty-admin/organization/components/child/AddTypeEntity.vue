<template>
  <Validation-Observer v-slot="{ handleSubmit }">
    <form id="addEntity_popup" @submit.prevent="handleSubmit(onsubmit)">
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closeAddTypeEntity()"
        class="custom-dialog"
      >
        <template v-slot:dialog-header>
          <v-card-title
            class="gen2-dialog-title text-uppercase"
            data-qe-id="org_addTypeEntity_cardTitle"
            >{{ $t("cardTitle") }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col class="gen2-forms form-light-bg">
            <v-row
              no-gutters
              v-for="(items, i) in addNewEntityFormResultArray"
              :key="i"
              class="flex-column bmy3"
            >
              <v-col sm="4">
                <p class="font42 f300 line-height-normal" v-if="i < 9">
                  {{ "0" + (i + 1) }}
                </p>
                <p class="font42 f300 line-height-normal" v-if="i > 8">
                  {{ i + 1 }}
                </p>
                <p class="label-text line-height-normal">
                  {{ addEntity.orgType }} {{ $t("orgTypeDetails") }}
                </p>
                <!-- orgNameCheck: {
                      orgData: addNewEntityFormResultArray,
                      indexData: i
                    } -->
                <validation-provider
                  :rules="{
                    required: true
                  }"
                  v-slot="{ errors }"
                >
                  <v-text-field
                    autocomplete="off"
                    :label="
                      $t('orgTypeName', { orgType: `${addEntity.orgType}` })
                    "
                    @input="enterEntityText()"
                    filled
                    :maxLength="max"
                    v-model="items.name"
                  ></v-text-field>
                  <p
                    class="custom-error-msg"
                    v-if="
                      errors[0] != undefined &&
                        errors[0].length > 0 &&
                        errors[0] === 'This field is required'
                    "
                  >
                    {{ addEntity.orgType }} {{ $t("nameErrorText") }}
                  </p>
                  <p
                    v-if="items.isEntityError && items.name !== ''"
                    class="custom-error-msg"
                  >
                    {{ $t("nameError") }}
                  </p>
                </validation-provider>
              </v-col>
              <v-col sm="6">
                <validation-provider v-slot="{ errors }">
                  <v-textarea
                    filled
                    auto-grow
                    :maxLength="descMax"
                    :label="
                      $t('orgTypeDescription', {
                        orgType: `${addEntity.orgType}`
                      })
                    "
                    v-model="items.description"
                  ></v-textarea>
                  <p
                    class="custom-error-msg"
                    v-if="
                      errors[0] != undefined &&
                        errors[0].length > 0 &&
                        errors[0] ===
                          'Description must be lesser than 500 characters'
                    "
                  >
                    {{ addEntity.orgType }} {{ $t("descriptionErrorText") }}
                  </p>
                </validation-provider>
              </v-col>
            </v-row>
            <p class="custom-error-msg" v-if="orgNameExists">
              {{ orgNameExistsErrorMsg }}
            </p>
          </v-col>
        </template>

        <template v-slot:dialog-footer>
          <v-btn text class="cancel no-ripple" @click="closeAddTypeEntity()">{{
            $t("cancelBtnText")
          }}</v-btn>
          <v-btn
            class="primaryctabtn text-uppercase"
            title="Default"
            type="submit"
            form="addEntity_popup"
            :disabled="isEntityExists"
            >{{ $t("saveBtnText") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </form>
  </Validation-Observer>
</template>
<script>
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { addTypeEntityOrganizationObject } from '../../../../../i18n/language.js';
import { mapState } from 'vuex';
export default {
  name: 'pop-up',
  data: () => ({
    dialog: false,
    addNewEntityFormResultArray: [],
    nameRequired: false,
    newEntityName: false,
    max: 50,
    descMax: 500,
    isEntityExists: false
  }),
  components: {
    BrierleyDialogbox
  },
  computed: {
    ...mapState('orgModule', [
      'addEntity',
      'orgNameExists',
      'orgNameExistsErrorMsg'
    ])
  },
  mounted () {
    let content = document.querySelector('html');
    content.classList.add('overflow-y-hidden');
    if (this.addEntity.noOfLevels > 0) {
      if (this.addEntity.otherOrgAdded === true) {
        this.addNewEntityFormResultArray = new Array(this.addEntity.noOfLevels)
          .fill(null)
          .map(() => ({
            parentEntityId: this.addEntity.parentEntityId,
            businessEntityTypeId: this.addEntity.businessEntityTypeId,
            icon: 'location_city',
            name: '',
            description: ''
          }));
      } else {
        let entityIcon = this.myIcon(this.addEntity.orgType);
        this.addNewEntityFormResultArray = new Array(this.addEntity.noOfLevels)
          .fill(null)
          .map(() => ({
            parentEntityId: this.addEntity.parentEntityId,
            businessEntityTypeId: this.addEntity.businessEntityTypeId,
            icon: entityIcon,
            name: '',
            description: ''
          }));
      }
    }
  },
  i18n: addTypeEntityOrganizationObject,
  methods: {
    enterEntityText (entityName) {
      if (entityName !== '') {
        this.checkEntityError();
      }
    },
    checkEntityError () {
      let errorObj = {
        errorMsg: '',
        errorExists: false
      };
      this.$store.commit('orgModule/nameExistsErrorMsgMutation', errorObj);
      if (this.addNewEntityFormResultArray.length > 1) {
        for (let z = 0; z < this.addNewEntityFormResultArray.length; z++) {
          this.addNewEntityFormResultArray[z].isEntityError = false;
        }
        const entityNameList = this.addNewEntityFormResultArray.map(
          item => item.name
        );
        let duplicateList = entityNameList.reduce(function (acc, el, i, arr) {
          if (arr.indexOf(el) !== i && acc.indexOf(el) < 0) acc.push(el);
          return acc;
        }, []);
        if (duplicateList.length > 0) {
          this.isEntityExists = true;
          for (let l = 0; l < duplicateList.length; l++) {
            for (let m = 0; m < this.addNewEntityFormResultArray.length; m++) {
              if (
                this.addNewEntityFormResultArray[m].name === duplicateList[l]
              ) {
                this.addNewEntityFormResultArray[m].isEntityError = true;
              }
            }
          }
        } else {
          this.isEntityExists = false;
          for (let n = 0; n < this.addNewEntityFormResultArray.length; n++) {
            this.addNewEntityFormResultArray[n].isEntityError = false;
            this.checkEntityError();
          }
        }
      }
    },
    myIcon (orgType) {
      switch (orgType) {
      case 'Brand':
        return 'store';
      case 'Region':
        return 'language';
      case 'Company':
        return 'domain';
      case 'Custom Entity':
        return 'location_city';
      default:
        return 'location_city';
      }
    },
    clearAddEntityTypeFields () {
      this.addNewEntityFormResultArray = [];
    },
    closeAddTypeEntity () {
      this.clearAddEntityTypeFields();
      this.$store.dispatch('orgModule/showAddEntityDialogAction', {
        showAddEntityDialog: false,
        showAddEntityDetailsDialog: false
      });
      let errorObj = {
        errorMsg: '',
        errorExists: false
      };
      this.$store.commit('orgModule/nameExistsErrorMsgMutation', errorObj);
    },
    onsubmit () {
      this.$store
        .dispatch(
          'orgModule/postOrganizationDataAction',
          this.addNewEntityFormResultArray
        )
        .then(res => {
          if (res.status === 201 || res.status === 200) {
            let errorObj = {
              errorMsg: '',
              errorExists: false
            };
            this.$store.commit(
              'orgModule/nameExistsErrorMsgMutation',
              errorObj
            );
            this.$store.dispatch('orgModule/showAddEntityDialogAction', {
              showAddEntityDialog: false,
              showAddEntityDetailsDialog: false
            });
            this.clearAddEntityTypeFields();
          }
        })
        .catch(err => {
          if (err.response.status === 409) {
            let errorObj = {
              errorMsg: err.response.data,
              errorExists: true
            };
            this.$store.commit(
              'orgModule/nameExistsErrorMsgMutation',
              errorObj
            );
            this.$store.dispatch('orgModule/showAddEntityDialogAction', {
              showAddEntityDialog: false,
              showAddEntityDetailsDialog: true
            });
          }
        });
    }
  }
};
</script>
<style scoped>
.info_title {
  font-size: 24px !important;
}
</style>
