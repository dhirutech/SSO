<template>
  <div class="chart-container loyalty-org">
    <div class="orgchart-container">
      <div class="orgchart">
        <organization-chart-node
          :datasource="datasource"
        ></organization-chart-node>
      </div>
    </div>
    <brierley-legend-icon-set class="legendSet">
      <template v-slot:org-legends>
        <p class="fbold text-uppercase font12">{{ $t('legendText') }}</p>
        <v-row class="gen2-legend-icons" no-gutters>
          <v-col class="bmr3">
            <p class="font12">
              <v-icon class="iconcolor1">domain</v-icon>{{ $t('companyText') }}
            </p>
            <p class="font12">
              <v-icon class="iconcolor4">language</v-icon>{{ $t('regionText') }}
            </p>
          </v-col>
          <v-col>
            <p class="font12">
              <v-icon class="iconcolor2">location_city</v-icon
              >{{ $t('customEntityText') }}
            </p>
            <p class="font12">
              <v-icon class="iconcolor3">store</v-icon>{{ $t('brandText') }}
            </p>
          </v-col>
        </v-row>
      </template>
    </brierley-legend-icon-set>
  </div>
</template>

<script>
import OrganizationChartNode from './OrganizationChartNode.vue';
import { BrierleyLegendIconSet } from '@brierley/SharedComponents';
import { organizationChartContainerObject } from '../../../../../i18n/language.js';
export default {
  name: 'Container',
  mounted () {
    this.orgChatOnload();
  },
  i18n: organizationChartContainerObject,
  methods: {
    orgChatOnload: function () {
      let content = document.querySelector('.orgchart-container');
      let calcx = document.querySelector('.orgchart > table .topTR > td .node');
      content.scrollLeft = calcx.offsetLeft - 458;
    }
  },
  props: {
    datasource: {
      type: Object,
      required: true
    }
  },
  components: {
    OrganizationChartNode,
    BrierleyLegendIconSet
  }
};
</script>

<style lang="scss" scoped>
.orgchart-container {
  .orgchart {
    padding-right: 100px;
    padding-left: 100px;
    padding-bottom: 140px !important;
  }
}
</style>
