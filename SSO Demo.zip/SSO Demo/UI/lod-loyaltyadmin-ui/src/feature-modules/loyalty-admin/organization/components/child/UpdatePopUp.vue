<template>
  <Validation-Observer v-slot="{ handleSubmit }">
    <form id="updateEntity_popup" @submit.prevent="handleSubmit(onsubmit)">
      <v-row class="d-flex" no-gutters>
        <v-col>
          <v-row>
            <v-col></v-col>
          </v-row>
          <brierley-dialogbox
            :dialog="true"
            @closeMe="closeUpdateEntityPopup()"
            id="btnClose"
          >
            <template v-slot:dialog-header>
              <v-card-title
                class="gen2-dialog-title text-uppercase"
                id="lblHeading"
                >{{ $t("editText") }} {{ entityObj.entityTypeName }}
                {{ $t("detailsText") }}</v-card-title
              >
            </template>
            <template v-slot:dialog-body-description>
              <v-col class="bmt2">
                <v-row no-gutters>
                  <v-col
                    class="gen2-forms form-light-bg"
                    sm="12"
                    xs="12"
                    md="12"
                  >
                    <p class="fbold text-uppercase" id="lblCustomDetails">
                      {{ entityObj.entityTypeName }} {{ $t("detailsText") }}
                    </p>
                    <validation-provider rules="required" v-slot="{ errors }">
                      <v-text-field
                        autocomplete="off"
                        :label="
                          $t('orgTypeName', {
                            orgType: `${entityObj.entityTypeName}`
                          })
                        "
                        id="txtDescription"
                        style="max-width: 20px"
                        filled
                        @input="enterEntityText()"
                        v-model="name"
                        :maxLength="max"
                      ></v-text-field>
                      <p
                        class="custom-error-msg"
                        v-if="
                          errors[0] != undefined &&
                            errors[0].length > 0 &&
                            errors[0] === 'This field is required'
                        "
                      >
                        {{ entityObj.entityTypeName }} {{ $t("nameErrorText") }}
                      </p>
                      <p
                        class="custom-error-msg"
                        v-else-if="
                          errors[0] != undefined && errors[0].length > 0
                        "
                      >
                        {{ errors[0] }}
                      </p>
                    </validation-provider>
                  </v-col>
                  <v-col sm="12">
                    <validation-provider v-slot="{ errors }">
                      <v-textarea
                        style="max-width: 400px"
                        filled
                        auto-grow
                        :label="
                          $t('orgTypeDescription', {
                            orgType: `${entityObj.entityTypeName}`
                          })
                        "
                        :maxLength="descMax"
                        v-model="description"
                      ></v-textarea>
                      <p
                        class="custom-error-msg"
                        v-if="
                          errors[0] != undefined &&
                            errors[0].length > 0 &&
                            errors[0] ===
                              'Description must be lesser than 500 characters'
                        "
                      >
                        {{ entityObj.entityTypeName }}
                        {{ $t("descriptionErrorText") }}
                      </p>
                    </validation-provider>
                  </v-col>
                  <v-col
                    class="bmt1"
                    v-if="entityObj.entityTypeName === 'CUSTOM'"
                  >
                    <p class="fbold text-uppercase">
                      {{ $t("customIconText") }}
                    </p>
                    <brierley-custom-icon />
                  </v-col>
                  <v-col>
                    <p class="custom-error-msg" v-if="orgNameExists">
                      {{ orgNameExistsErrorMsg }}
                    </p>
                  </v-col>
                </v-row>
              </v-col>
            </template>
            <template v-slot:dialog-footer>
              <v-btn
                text
                class="cancel no-ripple"
                @click="closeUpdateEntityPopup()"
                id="btnCancel"
                >{{ $t("cancelBtnText") }}</v-btn
              >
              <v-btn
                class="primaryctabtn text-uppercase"
                title="Default"
                id="btnSave"
                type="submit"
                form="updateEntity_popup"
                >{{ btnText }}</v-btn
              >
            </template>
          </brierley-dialogbox>
        </v-col>
      </v-row>
    </form>
  </Validation-Observer>
</template>
<script>
import {
  BrierleyDialogbox,
  BrierleyCustomIcon
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { updatePopUpOrganizationObject } from '../../../../../i18n/language.js';
export default {
  name: 'pop-up',
  data: () => ({
    dialog: false,
    items: ['Brand', 'Region', 'Other'],
    noOfLevels: '',
    entityDetailsDialog: false,
    description: '',
    name: '',
    nameRequired: false,
    max: 50,
    descMax: 500,
    btnText: 'SAVE & CLOSE'
  }),
  computed: {
    ...mapState('orgModule', [
      'entityObj',
      'orgNameExists',
      'orgNameExistsErrorMsg'
    ])
  },
  mounted () {
    this.name = this.entityObj.name;
    this.description = this.entityObj.description;
    if (this.entityObj.entityTypeName === 'CUSTOM') {
      this.btnText = this.$t('saveBtnText');
    } else {
      this.btnText = this.$t('saveCloseBtnText');
    }
  },
  components: {
    BrierleyDialogbox,
    BrierleyCustomIcon
  },
  i18n: updatePopUpOrganizationObject,
  methods: {
    enterEntityText () {
      let errorObj = {
        errorMsg: '',
        errorExists: false
      };
      this.$store.commit('orgModule/nameExistsErrorMsgMutation', errorObj);
    },
    onsubmit () {
      let entityIcon = this.myIcon(this.entityObj.entityTypeName);
      const res1 = {
        id: this.entityObj.businessEntityGuid,
        description: this.description,
        businessEntityId: this.entityObj.id,
        productDefinitionId: this.entityObj.productDefinitionId,
        parentEntityId: this.entityObj.parentEntityId,
        businessEntityTypeId: this.entityObj.entityTypeId,
        icon: entityIcon,
        name: this.name,
        applicableForProduct: true
      };
      this.$store
        .dispatch('orgModule/putOrganidationDataAction', res1)
        .then(res => {
          if (res.status === 201 || res.status === 200) {
            let errorObj = {
              errorMsg: '',
              errorExists: false
            };
            this.$store.commit(
              'orgModule/nameExistsErrorMsgMutation',
              errorObj
            );
          }
        })
        .catch(err => {
          if (err.response.status === 409 || err.response.status === 400) {
            let errorObj = {
              errorMsg: err.response.data,
              errorExists: true
            };
            this.$store.commit(
              'orgModule/nameExistsErrorMsgMutation',
              errorObj
            );
            this.$store.dispatch(
              'orgModule/showUpdateEntityDialogAction',
              true
            );
          }
        });
    },
    myIcon (orgType) {
      switch (orgType) {
      case 'Brand':
        return 'store';
      case 'Region':
        return 'language';
      case 'Company':
        return 'domain';
      case 'Custom Entity':
        return 'location_city';
      default:
        return 'location_city';
      }
    },
    closeUpdateEntityPopup () {
      this.$store.dispatch('orgModule/showUpdateEntityDialogAction', false);
      let errorObj = {
        errorMsg: '',
        errorExists: false
      };
      this.$store.commit('orgModule/nameExistsErrorMsgMutation', errorObj);
    }
  }
};
</script>
