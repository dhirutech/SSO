import Vue from 'vue';
const showAddEntityDialogMutation = (state, payload) => {
  Object.assign(state.showDialog, payload);
};
const showUpdateEntityDialogMutation = (state, payload) => {
  state.showUpdateEntityDialog = payload;
};
const showDeleteEntityDialogMutation = (state, payload) => {
  state.showDeleteEntityDialog = payload;
};

const getOrganizationTypeDropDownDataMutation = (state, payload) => {
  state.orgTypeData = payload;
};

const entityObjectMutation = (state, payload) => {
  state.entityObj = payload;
};

const otherEntityObjectMutation = (state, payload) => {
  Vue.set(state.otherEntityObj, payload);
};

const addEntityMutation = (state, payload) => {
  state.addEntity = payload;
};

const getOrganizationDataMutation = (state, payload) => {
  state.orgData = payload;
};

const putOrganizationDataMutation = (state, payload) => {
  state.orgDataUpdate = payload;
};

const nameExistsErrorMsgMutation = (state, payload) => {
  state.orgNameExistsErrorMsg = payload.errorMsg;
  state.orgNameExists = payload.errorExists;
};

export default {
  nameExistsErrorMsgMutation,
  addEntityMutation,
  getOrganizationDataMutation,
  showAddEntityDialogMutation,
  entityObjectMutation,
  putOrganizationDataMutation,
  showUpdateEntityDialogMutation,
  showDeleteEntityDialogMutation,
  getOrganizationTypeDropDownDataMutation,
  otherEntityObjectMutation
};
