export default {
  entityObj: {},
  addEntity: {},
  orgData: [],
  showDialog: {
    showAddEntityDialog: false,
    showAddEntityDetailsDialog: false
  },
  showUpdateEntityDialog: false,
  showDeleteEntityDialog: false,
  orgDataUpdate: [],
  orgTypeData: [],
  otherEntityObj: {},
  orgNameExists: false,
  orgNameExistsErrorMsg: ''
};
