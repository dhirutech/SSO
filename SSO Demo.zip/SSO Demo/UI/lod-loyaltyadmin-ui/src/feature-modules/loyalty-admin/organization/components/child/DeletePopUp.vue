<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closeDeleteEntityPopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title
            class="gen2-dialog-title text-uppercase"
            data-qe-id="org_btn_deleteDeleteCardTitle"
          >{{ $t("cardTitle") }}</v-card-title>
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <v-alert
                  class="b-alert-error"
                  type="error"
                  :dismissible="false"
                >
                  <v-row class="alert-block align-center havebtn" no-gutters>
                    <v-col class="alert-block__body">
                      <p v-for="error in errorMessages" :key="error">{{error}}</p>
                    </v-col>
                  </v-row>
                </v-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            data-qe-id="org_btn_cancelDeleteDialog"
            v-if="cancelButton"
            text
            class="cancel no-ripple"
            @click="closeDeleteEntityPopup()"
          >{{ $t("cancelBtnText") }}</v-btn>
          <v-btn
            data-qe-id="org_btn_deleteDeleteDialog"
            class="primaryctabtn text-uppercase"
            title
            @click="deleteEntityMethod()"
          >{{ btnText }}</v-btn>
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { deletePopUpOrganizationObject } from '../../../../../i18n/language.js';

export default {
  components: {
    BrierleyDialogbox
  },
  data: () => ({
    dialog: false,
    btnText: '',
    productDefinitionName: '',
    cancelButton: false,
    errorMessages: []
  }),
  created () {
    this.setErrorMessages();
  },
  computed: {
    ...mapState('orgModule', ['entityObj']),
  },
  methods: {
    setErrorMessages () {
      this.btnText = this.$t('okBtnText');
      this.cancelButton = false;
      this.errorMessages = [];

      if (this.entityObj.programsCount > 0) {
        this.errorMessages.push(this.$t('activeProgramDeleteEntityText'));
      }

      if (this.entityObj.productDefinitionId !== null || this.entityObj.storeDefinitionId !== null) {

        let errorMsg = this.entityObj.programsCount > 0 ?
          this.$t('activeProgramAndDataDefinitionDeleteEntityText') :
          this.$t('dataDefinitionDeleteEntityText');

        this.errorMessages = [];
        this.errorMessages.push(errorMsg);

        if (this.entityObj.productDefinitionId !== null) {
          this.$store.dispatch('orgModule/getProductDefinitionByIdAction', this.entityObj.productDefinitionId)
            .then((res) => {
              this.errorMessages.push(res.data.data.name);
            });
        }

        if (this.entityObj.storeDefinitionId !== null) {
          this.$store.dispatch('storeDefinitionModule/getStoreDefinition', this.entityObj.storeDefinitionId)
            .then((res) => {
              this.errorMessages.push(res.name);
            });
        }
      }

      if (this.errorMessages.length < 1) {
        this.errorMessages.push(this.$t('deleteEntityText'));
        this.btnText = this.$t('yesBtnText');
        this.cancelButton = true;
      }

    },
    deleteEntityMethod () {
      if (this.btnText === this.$t('yesBtnText')) {
        this.$store.dispatch(
          'orgModule/deleteEntityActions',
          this.entityObj.id
        );
      }
      this.closeDeleteEntityPopup();
    },
    closeDeleteEntityPopup () {
      this.$store.dispatch('orgModule/showDeleteEntityDialogAction', false);
    },
  },
  i18n: deletePopUpOrganizationObject,
};
</script>
