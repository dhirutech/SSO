import _ from 'lodash';
const getJsonData = data => {
  let unflatten = function (array, parent, tree) {
    tree = typeof tree !== 'undefined' ? tree : [];
    parent = typeof parent !== 'undefined' ? parent : { id: null };
    let children = _.filter(array, function (child) {
      if (child !== null && typeof child === 'object' && child.activeTF) {
        if (child.IsEdited === undefined) {
          child['IsEdited'] = true;
        }
        if (child.extend === undefined) {
          child['extend'] = true;
        }
        if (child.IsSaved === undefined) {
          child['IsSaved'] = true;
        }
      }
      return child.parentEntityId === parent.id && child.activeTF;
    });
    if (!_.isEmpty(children)) {
      if (parent.id === null) {
        tree = children;
      } else {
        parent['children'] = children;
      }
      _.each(children, function (child) {
        unflatten(array, child);
      });
    }
    return tree;
  };
  let finalREsult = unflatten(data);
  let dummyChildren = finalREsult[0];
  return dummyChildren;
};

export { getJsonData };
