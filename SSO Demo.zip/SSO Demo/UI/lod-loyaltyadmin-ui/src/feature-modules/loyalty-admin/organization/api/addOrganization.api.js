import Vue from 'vue';
const addOrganizationNodeDataAddAction = addEntityObjectsForNode => {
  return Vue.prototype.$http.post(
    '/loyaltyconfiguration/api/v1/businessEntities',
    addEntityObjectsForNode
  );
};

const otherOrganizationNodeDataAddAction = otherEntityObjectsForNode => {
  return Vue.prototype.$http.post(
    '/loyaltyconfiguration/api/v1/businessEntityTypes',
    otherEntityObjectsForNode
  );
};

const nameExistsData = entityObjectsForNode => {
  return Vue.prototype.$http.post(
    '/loyaltyconfiguration/api/v1/businessEntities',
    entityObjectsForNode
  );
};

export { addOrganizationNodeDataAddAction, otherOrganizationNodeDataAddAction, nameExistsData };
