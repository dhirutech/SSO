import communication from './components/communications.vue';
import CommunicationSetUpLayout from './components/CommunicationSetUpLayout';
import communicationDashboard from '../communicationManagement/components/communicationDashboard.vue';

const communicationRoutes = [
  {
    path: '/loyaltyadmin/communication',
    name: 'communication',
    component: communication,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/communicationSetup',
    name: 'CommunicationSetUpLayout',
    component: CommunicationSetUpLayout,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/communicationSetupEdit',
    name: 'CommunicationSetUpLayoutEdit',
    component: CommunicationSetUpLayout,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/communications',
    name: 'communicationDashboard',
    component: communicationDashboard,
    meta: {
      showNavigation: true
    }
  }
];

export default communicationRoutes;
