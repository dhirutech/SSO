<template>
  <brierley-inner-view>
    <template v-slot:header>
      <span class="inner-head">{{ $t('headerText') }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        data-qe-id="communication_routerbtn"
        href
        target="_blank"
        text
        @click.native="$router.push('/gettingStarted')"
      >
        <v-icon data-qe-id="communication_close_icon">mdi-close</v-icon>
        {{ $t('closeText') }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <Validation-Observer v-slot="{ handleSubmit }">
        <form id="comp_form" @submit.prevent="handleSubmit(onsubmit)">
          <v-row
            class="bmt5 flex-column"
            no-gutters
            v-if="communicationStep === 1"
          >
            <v-col>
              <brierley-form-title
                :formTitle="$t('communicationFormTitle')"
                :infoText="$t('communicationInfoText')"
              ></brierley-form-title>
            </v-col>
            <v-col>
              <v-col
                class="gray-bg rule-parent-container gen2-program-rule bmt5 bpa3 line-height-32 font24 f600"
              >
                {{ $t('channelSetUpText') }}
              </v-col>
              <v-divider></v-divider>
              <v-col
                cols="12"
                class="gray-bg rule-parent-container gen2-program-rule bpx3 bpt5 bpb3 bmb2"
              >
                <v-row no-gutters>
                  <v-col class="bpy0" xs="12" md="12" sm="12">
                    <v-row class="flex-column" no-gutters>
                      <v-row class="no-gutters bpa0">
                        <v-row v-if="alertPopUpOpen" no-gutters>
                          <v-col>
                            <brierley-dialogbox
                              :dialog="true"
                              @closeMe="cancelPopupAlert"
                              :persistent="false"
                            >
                              <template v-slot:dialog-header>
                                <v-card-title
                                  class="gen2-dialog-title text-uppercase"
                                  >{{ $t('alertText') }}</v-card-title
                                >
                              </template>
                              <template v-slot:dialog-body-alert>
                                <v-alert
                                  icon="done"
                                  data-qe-id="communication_done_icon"
                                  class="success b-alert-success max-width-full"
                                >
                                  <h4>{{ programNameAlert.join(', ') }}</h4>
                                </v-alert>
                              </template>
                              <template v-slot:dialog-footer>
                                <v-btn
                                  class="primaryctabtn"
                                  title="Default"
                                  data-qe-id="communication_setupbtn"
                                  id="prom_stop_yes"
                                  >{{ $t('setUpText') }}</v-btn
                                >
                              </template>
                            </brierley-dialogbox>
                          </v-col>
                        </v-row>
                        <template>
                          <Validation-Observer v-slot="{ handleSubmit }">
                            <form
                              id="connect_popup"
                              @submit.prevent="handleSubmit(onSubmitPopup)"
                            >
                              <brierley-dialogbox
                                :dialog="dialog"
                                @closeMe="closePopUp"
                                :persistent="false"
                                max-width="1065"
                                class="customfullheightdialog"
                              >
                                <template v-slot:dialog-header>
                                  <v-card-title
                                    v-if="connectStep === 1"
                                    class="gen2-dialog-title text-uppercase"
                                    >{{ $t('providerName') }}</v-card-title
                                  >
                                  <v-card-title
                                    v-if="connectStep === 2"
                                    class="gen2-dialog-title text-uppercase"
                                  >
                                    {{ $t('confirmationHeader') }}
                                  </v-card-title>
                                </template>
                                <template
                                  v-slot:dialog-body-description
                                  v-if="connectStep === 1"
                                >
                                  <v-col>
                                    <v-row
                                      class="flex-column"
                                      no-gutters
                                      v-for="(config, l) in providerarr"
                                      :key="l"
                                    >
                                      <v-col class="label-text bmt2">{{
                                        $t('providerConfigParams')
                                      }}</v-col>
                                      <v-col
                                        sm="6"
                                        class="bpr4 gen2-forms form-light-bg"
                                      >
                                        <validation-provider
                                          rules="required"
                                          v-slot="{ errors }"
                                        >
                                          <v-text-field
                                            autocomplete="off"
                                            :label="$t('userNameLabel')"
                                            class="isrequired"
                                            v-model="config.userName"
                                            data-qe-id="communication_userName"
                                            maxlength="100"
                                            filled
                                            @input="onBlurPassword()"
                                            v-bind:class="[
                                              !updateInvalidLoginError
                                                ? 'error--text'
                                                : ''
                                            ]"
                                          />
                                          <p
                                            class="custom-error-msg"
                                            v-if="
                                              errors[0] != undefined &&
                                                errors[0].length > 0 &&
                                                errors[0] ===
                                                  'This field is required'
                                            "
                                          >
                                            {{ $t('userNameError') }}
                                          </p>
                                        </validation-provider>
                                      </v-col>
                                      <v-col
                                        sm="6"
                                        class="bpr4 gen2-forms form-light-bg"
                                      >
                                        <validation-provider
                                          rules="required"
                                          v-slot="{ errors }"
                                        >
                                          <v-text-field
                                            autocomplete="off"
                                            class="isrequired"
                                            maxlength="20"
                                            :append-icon="
                                              showPwd
                                                ? 'mdi-eye'
                                                : 'mdi-eye-off'
                                            "
                                            :type="
                                              showPwd ? 'text' : 'password'
                                            "
                                            v-bind:class="[
                                              !updateInvalidLoginError
                                                ? 'error--text'
                                                : ''
                                            ]"
                                            :label="$t('passwordLabel')"
                                            data-qe-id="communication_passwordlabel"
                                            @click:append="showPwd = !showPwd"
                                            filled
                                            v-model="config.password"
                                            @input="onBlurPassword()"
                                          />
                                          <p
                                            class="custom-error-msg"
                                            v-if="
                                              errors[0] != undefined &&
                                                errors[0].length > 0 &&
                                                errors[0] ===
                                                  'This field is required'
                                            "
                                          >
                                            {{ $t('passwordError') }}
                                          </p>
                                        </validation-provider>
                                      </v-col>
                                      <v-col
                                        sm="8"
                                        class="gen2-forms form-light-bg"
                                      >
                                        <validation-provider
                                          rules="required"
                                          v-slot="{ errors }"
                                        >
                                          <v-textarea
                                            class="isrequired"
                                            auto-grow
                                            maxlength="200"
                                            filled
                                            :label="$t('apiUrlLabel')"
                                            data-qe-id="communication_apiurllabel"
                                            rows="2"
                                            v-model="config.apiUrl"
                                            @input="onBlurUrl()"
                                            v-bind:class="[
                                              !updateInvalidLoginError
                                                ? 'error--text'
                                                : ''
                                            ]"
                                          ></v-textarea>
                                          <p
                                            class="custom-error-msg"
                                            v-if="
                                              errors[0] != undefined &&
                                                errors[0].length > 0 &&
                                                errors[0] ===
                                                  'This field is required'
                                            "
                                          >
                                            {{ $t('apiUrlError') }}
                                          </p>
                                          <p
                                            class="custom-error-msg"
                                            v-if="!updateInvalidLoginError"
                                          >
                                            {{ $t('invalidCredentials') }}
                                          </p>
                                        </validation-provider>
                                      </v-col>
                                    </v-row>
                                  </v-col>
                                </template>
                                <template
                                  v-slot:dialog-body-alert
                                  v-if="connectStep === 2"
                                >
                                  <v-alert
                                    icon="done"
                                    class="success b-alert-success max-width-full"
                                  >
                                    <h3>
                                      {{ $t('successTitle') }}
                                    </h3>
                                    <p>{{ alertMessage }}</p>
                                  </v-alert>
                                </template>
                                <template v-slot:dialog-footer>
                                  <v-btn
                                    data-qe-id="communication_button_Cancel"
                                    text
                                    v-if="connectStep === 1"
                                    class="cancel no-ripple"
                                    @click="cancelPopUp"
                                    >{{ $t('cancelBtnTextPopUp') }}</v-btn
                                  >
                                  <v-btn
                                    data-qe-id="communication_button_Done"
                                    class="primaryctabtn"
                                    v-if="connectStep === 1"
                                    type="submit"
                                    form="connect_popup"
                                    >{{ $t('connectBtnTextPopUp') }}</v-btn
                                  >
                                  <v-btn
                                    data-qe-id="communication_button_close"
                                    class="primaryctabtn"
                                    v-if="connectStep === 2"
                                    @click="clsPopUp"
                                    >{{ $t('closeBtnTextPopUp') }}</v-btn
                                  >
                                </template>
                              </brierley-dialogbox>
                            </form>
                          </Validation-Observer>
                        </template>
                        <v-row class="d-flex flex-column bpa0" no-gutters>
                          <v-col
                            class="bpt0"
                            v-for="(item, index) in channelData"
                            :key="index"
                          >
                            <v-col class="bpa0">
                              <p class="label-text">
                                {{ $t('headerChannelText') }}
                              </p>
                            </v-col>
                            <Validation-Observer ref="exclusionObs">
                              <v-row
                                class="white-bg bpl2 bpt2  each-category"
                                no-gutters
                              >
                                <v-col
                                  class="max-width260 gen2-forms form-light-bg bpr20px"
                                >
                                  <validation-provider v-slot="{ errors }">
                                    <v-select
                                      v-if="!edit"
                                      :items="allProgramStatusCommunication"
                                      data-qe-id="communication_allprograms"
                                      item-text="name"
                                      item-value="programId"
                                      filled
                                      v-bind:class="[
                                        item.errorMsg.includes(
                                          'Select Program to be configured'
                                        )
                                          ? 'error--text'
                                          : ''
                                      ]"
                                      @change="
                                        clearProgramErrorMsg(
                                          item.programName,
                                          index
                                        )
                                      "
                                      v-model="item.programName"
                                      :label="$t('selectProgramLabel')"
                                      attach
                                      offset-y
                                      class="gen2select gen2select__dark field-min-width-none"
                                      append-icon="expand_more"
                                    ></v-select>
                                    <v-select
                                      v-if="edit"
                                      :items="allProgramStatusCommunication"
                                      item-text="name"
                                      item-value="programId"
                                      :disabled="true"
                                      filled
                                      v-model="item.programName"
                                      :label="$t('selectProgramLabel')"
                                      data-qe-id="communication_selectprograms"
                                      attach
                                      offset-y
                                      class="gen2select gen2select__dark field-min-width-none"
                                      append-icon="expand_more"
                                    ></v-select>
                                    <p
                                      class="custom-error-msg"
                                      v-if="
                                        errors[0] != undefined &&
                                          errors[0].length > 0 &&
                                          errors[0] === 'This field is required'
                                      "
                                    >
                                      {{ $t('filedRequiredError') }}
                                    </p>
                                    <p
                                      class="custom-error-msg"
                                      v-if="item.isProgramError"
                                    >
                                      {{ $t('programErrorText') }}
                                    </p>
                                  </validation-provider>
                                </v-col>
                                <v-col>
                                  <v-row
                                    class="d-flex looped-fields"
                                    no-gutters
                                  >
                                    <v-col
                                      class="bpr20px max-width260 gen2-forms form-light-bg"
                                    >
                                      <validation-provider v-slot="{ errors }">
                                        <v-autocomplete
                                          :items="item.channelsList"
                                          item-text="name"
                                          item-value="name"
                                          filled
                                          v-bind:class="[
                                            item.errorMsg.includes(
                                              'Select Communication Channel to be configured'
                                            )
                                              ? 'error--text'
                                              : ''
                                          ]"
                                          @change="
                                            clearChannelErrorMsg(
                                              item.channelName,
                                              index
                                            )
                                          "
                                          v-model="item.channelName"
                                          :label="$t('selectChannelLabel')"
                                          data-qe-id="communication_selectchannel"
                                          attach
                                          offset-y
                                          class="gen2select gen2select__dark field-min-width-none"
                                          append-icon="expand_more"
                                        ></v-autocomplete>
                                        <p class="custom-error-msg">
                                          {{ errors[0] }}
                                        </p>
                                      </validation-provider>
                                    </v-col>
                                    <v-col
                                      class="bpr20px max-width190 gen2-forms form-light-bg"
                                    >
                                      <validation-provider v-slot="{ errors }">
                                        <v-autocomplete
                                          :items="item.providersList"
                                          item-text="name"
                                          item-value="name"
                                          v-model="item.providerName"
                                          v-bind:class="[
                                            item.errorMsg.includes(
                                              'Select Provider to be used for managing Communication'
                                            )
                                              ? 'error--text'
                                              : ''
                                          ]"
                                          @change="
                                            clearProviderErrorMsg(
                                              item.providerName,
                                              index
                                            )
                                          "
                                          filled
                                          :label="$t('selectProviderLabel')"
                                          data-qe-id="communication_selectprovider"
                                          attach
                                          offset-y
                                          class="gen2select gen2select__dark field-min-width-none"
                                          append-icon="expand_more"
                                        ></v-autocomplete>
                                        <p class="custom-error-msg">
                                          {{ errors[0] }}
                                        </p>
                                      </validation-provider>
                                    </v-col>
                                    <v-col class="pt-3">
                                      <v-row
                                        class=""
                                        no-gutters
                                        v-if="
                                          (item.programName ||
                                            item.programName === 0) &&
                                            item.providerName &&
                                            item.channelName
                                        "
                                      >
                                        <v-col
                                          class="f600 primary-text cursor-p"
                                          @click="addMoreExclusions(index)"
                                          data-qe-id="communication_btnAddMoreExc"
                                        >
                                          {{ $t('configureProviderLabel') }}
                                        </v-col>
                                      </v-row>
                                      <v-row class="" no-gutters v-else>
                                        <v-col
                                          class=""
                                          data-qe-id="communication_rules_btnAddMoreExc"
                                        >
                                          <span class="disabledText f600">{{
                                            $t('configureProviderLabel')
                                          }}</span>
                                        </v-col>
                                      </v-row>
                                    </v-col>
                                    <v-col
                                      class="btn-ic-width text-right bml6 bmt1 max-width100"
                                    >
                                      <v-row>
                                        <v-btn
                                          depressed
                                          class="blue-icon-btn"
                                          disabled
                                          data-qe-id="communication_btn"
                                        >
                                          <v-icon>add_circle_outline</v-icon>
                                        </v-btn>
                                        <v-btn
                                          depressed
                                          class="blue-icon-btn bml1"
                                          :disabled="index == 0"
                                          data-qe-id="communication_removepgmdata"
                                          @click="removeProgramData(index)"
                                        >
                                          <v-icon>remove_circle_outline</v-icon>
                                        </v-btn>
                                      </v-row>
                                    </v-col>
                                  </v-row>
                                </v-col>
                              </v-row>
                            </Validation-Observer>
                            <v-row
                              v-if="
                                item.errorMsg.length > 0 &&
                                  item.errorMsg.length !== undefined
                              "
                              no-gutters
                            >
                              <v-col>
                                <v-alert
                                  class="b-alert-error max-width-full bmt2"
                                  type="error"
                                  :dismissible="false"
                                >
                                  <v-row
                                    class="alert-block align-center havebtn"
                                    no-gutters
                                  >
                                    <v-col class="alert-block__body">
                                      <h3>{{ $t('errorText') }}</h3>
                                      <p
                                        v-for="error in item.errorMsg"
                                        :key="error"
                                      >
                                        {{ error }}
                                      </p>
                                    </v-col>
                                  </v-row>
                                </v-alert>
                              </v-col>
                            </v-row>

                            <v-divider class="dashed bmy5"></v-divider>
                          </v-col>
                        </v-row>
                      </v-row>
                    </v-row>
                    <v-row
                      v-if="
                        !anotherProgramExistence &&
                          $route.name !== 'CommunicationSetUpLayoutEdit'
                      "
                      class="d-inline-flex icon-with-head align-center pointer-text"
                      no-gutters
                      data-qe-id="communication_setupanotherpgm"
                      @click="setUpAnotherProgram()"
                    >
                      <v-col data-qe-id="communication_rules_btnAddExc">
                        <v-icon class="bmr1">add_circle_outline</v-icon>
                      </v-col>
                      <v-col
                        cols="1"
                        data-qe-id="communication_rules_btnAddMoreExc"
                        >{{ $t('setUpProgramText') }}</v-col
                      >
                    </v-row>
                    <v-row
                      v-else
                      class="d-inline-flex icon-with-head align-center pointer-none"
                      no-gutters
                    >
                      <v-col
                        class="pointer-none"
                        data-qe-id="communications_btnAddExc"
                      >
                        <v-icon class="bmr1" disabled
                          >add_circle_outline</v-icon
                        >
                      </v-col>
                      <v-col
                        class="pointer-none"
                        cols="1"
                        data-qe-id="communication_setUpProgramText"
                      >
                        <span class="disabledText fbold">
                          {{ $t('setUpProgramText') }}
                        </span>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col>
                        <CancelPopUp v-if="showPopUpDialogue" />
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </v-col>
            </v-col>
          </v-row>
          <v-row
            class="bmt5 flex-column"
            no-gutters
            v-if="communicationStep === 2"
          >
            <v-col>
              <brierley-form-title
                :formTitle="$t('reviewFormTitle')"
                :infoText="$t('reviewInfoText')"
              ></brierley-form-title>
            </v-col>
            <v-col>
              <CommunicationPreviewAndSave />
            </v-col>
            <v-col>
              <CancelPopUp v-if="showPopUpDialogue" />
            </v-col>
          </v-row>
          <v-row
            class="bmt5 flex-column"
            no-gutters
            v-if="communicationStep === 3"
          >
            <v-col>
              <brierley-form-title
                :formTitle="$t('successFormTitle')"
              ></brierley-form-title>
            </v-col>
            <v-col
              class="bmt4"
              v-if="$route.name !== 'CommunicationSetUpLayoutEdit'"
            >
              <brierley-alert
                class="bmb0"
                :isSiteLevel="true"
                :alertHeader="$t('successFormTitle')"
                :alertBody="$t('saveCommunicationText')"
                alertType="success"
              ></brierley-alert>
            </v-col>
            <v-col
              class="bmt4"
              v-if="$route.name === 'CommunicationSetUpLayoutEdit'"
            >
              <brierley-alert
                class="bmb0"
                :isSiteLevel="true"
                :alertHeader="$t('successFormTitle')"
                :alertBody="$t('updateCommunication')"
                alertType="success"
                icon="done"
              ></brierley-alert>
            </v-col>
          </v-row>
        </form>
      </Validation-Observer>
    </template>
    <template v-slot:footer>
      <v-btn
        v-if="communicationStep <= 2"
        text
        @click="cancelOpenPopUp()"
        data-qe-id="communication_cancelopenpopup_btn"
        class="cancel no-ripple bmt2 bmr5"
        >{{ $t('cancelList') }}</v-btn
      >
      <v-btn
        v-if="communicationStep === 1"
        :disabled="reviewBtnStatus"
        type="submit"
        form="comp_form"
        data-qe-id="communication_nextreviewbtn"
        class="primaryctabtn bmt2 bml2"
        >{{ $t('nextReviewText') }}</v-btn
      >
      <v-btn
        id="user_btn_saveUser"
        v-if="communicationStep === 2"
        class="primaryctabtn bmt2"
        :disabled="buttonDisabled"
        data-qe-id="communication_onsavesetupbtn"
        @click="onSaveSetup()"
        >{{ $t('saveSetUpText') }}</v-btn
      >
    </template>
    <template v-slot:footer-previous v-if="communicationStep === 2">
      <v-btn
        id="user_btn_previous"
        text
        class="mr-5 cancel no-ripple"
        data-qe-id="communication_previousclick"
        @click="onPreviousClick()"
      >
        <v-icon class="bpr1">arrow_back</v-icon>
        {{ $t('previousText') }}
      </v-btn>
    </template>
    <template v-slot:footer-redirect v-if="communicationStep === 3">
      <v-btn
        @click="goToCommunicationList()"
        data-qe-id="communication_commlistbtn"
        id="user_btn_goToUsers"
        class="primaryctabtn bmt2"
        >{{ $t('goToList') }}</v-btn
      >
    </template>
    <template v-if="communicationStep === 3" v-slot:footer-notes>
      <div class="bmt7">
        <v-row class="bpt2 bmt2"></v-row>
        <span
          id="LabelNextStepsText"
          class="font15 fbold text-uppercase bpt1"
          >{{ $t('setUpCommunicationText') }}</span
        >
      </div>
      <div class="bmt1">
        <span
          id="LabelCreateText"
          data-qe-id="communication_gotosetup"
          class="font15 label-create-txt"
        >
          {{ $t('communicationForProgramText') }}
          <a
            id="BtnCampaigns"
            v-on:click="goToSetup"
            data-qe-id="communication_gotosetupbtn"
          >
            <span id="LabelFooterText" class="font15 fbold primary-text pl-2">{{
              $t('clickHereText')
            }}</span>
          </a>
        </span>
      </div>
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyInnerView,
  BrierleyFormTitle,
  brierleyAlert,
  BrierleyDialogbox
} from '@brierley/SharedComponents';
import CommunicationPreviewAndSave from './CommunicationPreviewAndSave.vue';
import { communicationSetUpObj } from '../../../i18n/language.js';
import { mapState } from 'vuex';
import CancelPopUp from './CancelPopUp.vue';
import Vue from 'vue';
export default {
  components: {
    BrierleyInnerView,
    BrierleyFormTitle,
    brierleyAlert,
    BrierleyDialogbox,
    CommunicationPreviewAndSave,
    CancelPopUp
  },
  i18n: communicationSetUpObj,
  data () {
    return {
      edit: false,
      programData: {},
      dialog: false,
      showPwd: false,
      alertProgramNameText: '',
      connectStep: 1,
      alertPopUpOpen: false,
      errorMessages: [],
      userName: '',
      providerarr: [],
      programNameAlert: [],
      channelProviderIndex: null
    };
  },
  methods: {
    onBlurUrl () {
      this.$store.commit(
        'communicationModule/updateInvalidLoginErrorMutation',
        true
      );
    },
    goToCommunicationList () {
      this.$router.push('/loyaltyadmin/communication');
    },
    onBlurPassword () {
      this.$store.commit(
        'communicationModule/updateInvalidLoginErrorMutation',
        true
      );
    },
    cancelOpenPopUp () {
      this.$store.commit('communicationModule/showPopUpDialogueMutation', true);
    },
    removeProgramData (channelAndProviderIndex) {
      this.$store.dispatch(
        'communicationModule/setUserReviewBtnMutation',
        false
      );
      this.$store.dispatch(
        'communicationModule/removeProgramStatusForCommunicationAction',
        channelAndProviderIndex
      );
      const configuredArray = this.channelData.filter(
        (item) => item.configured === false
      );
      if (configuredArray.length === 0) {
        this.$store.dispatch(
          'communicationModule/updateAnotherProgramAction',
          false
        );
      }
      if (channelAndProviderIndex <= 1) {
        let allProgramData = {
          programId: 0,
          name: 'AllPrograms',
          programName: 0,
          programStatus: 0,
          description: 'AllPrograms'
        };
        this.allProgramStatusCommunication.push(allProgramData);
      }
      this.checkProgramError();
    },
    addMoreExclusions (index) {
      this.dialog = true;
      this.providerarr = this.channelData[index].providersList;
      this.$store.dispatch('communicationModule/setChannelIndexAction', index);
      this.channelProviderIndex = index;
      this.connectStep = 1;
      this.seedDataObject.apiUrl = this.channelData[
        index
      ].providersList[0].apiUrl;
      this.seedDataObject.userName = this.channelData[
        index
      ].providersList[0].userName;
      this.seedDataObject.password = this.channelData[
        index
      ].providersList[0].password;
      this.$store.dispatch(
        'communicationModule/setDataObjectAction',
        this.seedDataObject
      );
    },
    clearFields () {
      this.configParams.userName = ''
      ;this.configParams.password = '', this.configParams.apiURL = '';
    },
    onSubmitPopup () {
      this.channelData[
        this.channelProviderIndex
      ].providersList[0].providerName = this.channelData[
        this.channelProviderIndex
      ].providersList[0].name;
      this.$store
        .dispatch(
          'communicationModule/postChannelProviderDataAction',
          this.channelData[this.channelProviderIndex].providersList[0]
        )
        .then((res) => {
          const programArray = this.channelData.filter(
            (item) => item.isProgramError === true
          );
          if (programArray.length === 0 || programArray === undefined) {
            this.$store.commit(
              'communicationModule/setUserReviewBtnMutation',
              false
            );
          }
          if (
            res.data.isError === false &&
            res.data.httpStatusCode === 200 &&
            res.data.data.isConnected === true
          ) {
            if (this.channelData[this.channelProviderIndex].programName === 0) {
              this.$store.dispatch(
                'communicationModule/updateAnotherProgramAction',
                true
              );
            } else if (this.$route.name === 'CommunicationSetUpLayout') {
              let objIndex = this.allProgramStatusCommunication.find(
                (x) => x.programId === 0
              );
              if (objIndex !== undefined) {
                let obj = this.allProgramStatusCommunication.filter(
                  (x) => x.programId !== objIndex.programId
                );
                this.$store.commit(
                  'communicationModule/getAllProgramStatusForCommunicationMutation',
                  obj
                );
              }
            }
            if (this.connectStep === 1) {
              this.connectStep += 1;
            }
            this.channelData[this.channelProviderIndex].configured = true;
            this.channelData[
              this.channelProviderIndex
            ].providersList[0].userName = this.providerarr[0].userName;
            this.channelData[
              this.channelProviderIndex
            ].providersList[0].password = this.providerarr[0].password;
            this.channelData[
              this.channelProviderIndex
            ].providersList[0].apiUrl = this.providerarr[0].apiUrl;
            this.$store.commit(
              'communicationModule/updateUrlErrorMutation',
              true
            );
            this.$store.commit(
              'communicationModule/updateInvalidLoginErrorMutation',
              true
            );
          }
        });
    },
    closePopUp () {
      this.dialog = false;
      if (this.connectStep === 1) {
        this.channelData[
          this.channelProviderIndex
        ].providersList[0].userName = this.seedDataObject.userName;
        this.channelData[
          this.channelProviderIndex
        ].providersList[0].password = this.seedDataObject.password;
        this.channelData[
          this.channelProviderIndex
        ].providersList[0].apiUrl = this.seedDataObject.apiUrl;
      }
      if (this.connectStep === 2) {
        this.connectStep -= 1;
      }

      this.$store.commit('communicationModule/updateUrlErrorMutation', true);
      this.$store.commit(
        'communicationModule/updateInvalidLoginErrorMutation',
        true
      );
    },
    cancelPopUp () {
      this.dialog = false;
      this.channelData[
        this.channelProviderIndex
      ].providersList[0].userName = this.seedDataObject.userName;
      this.channelData[
        this.channelProviderIndex
      ].providersList[0].password = this.seedDataObject.password;
      this.channelData[
        this.channelProviderIndex
      ].providersList[0].apiUrl = this.seedDataObject.apiUrl;
      this.$store.commit('communicationModule/updateUrlErrorMutation', true);
      this.$store.commit(
        'communicationModule/updateInvalidLoginErrorMutation',
        true
      );
    },
    cancelPopupAlert () {
      this.alertPopUpOpen = false;
    },
    clsPopUp () {
      this.dialog = false;
    },
    clearChannelErrorMsg (val, idx) {
      if (
        this.channelData[idx].channelName &&
        this.channelData[idx].providerName &&
        this.channelData[idx].programName &&
        this.channelData[idx].isProgramError === false
      ) {
        this.channelData[idx].showConfigureText = true;
      } else {
        this.channelData[idx].showConfigureText = false;
      }
      if (val) {
        for (let i = 0; i <= this.channelData[idx].errorMsg.length - 1; i++) {
          if (
            this.channelData[idx].errorMsg[i] === this.$t('channelErrorTxt')
          ) {
            this.channelData[idx].errorMsg.splice(i, 1);
          }
        }
      }
    },
    checkProgramError () {
      if (this.channelData.length === 1) {
        this.channelData[0].isProgramError = false;
      }
      if (this.channelData.length > 1) {
        for (let z = 0; z < this.channelData.length; z++) {
          this.channelData[z].isProgramError = false;
        }
        const programIdList = this.channelData.map((item) => item.programName);
        let duplicateList = programIdList.reduce(function (acc, el, i, arr) {
          if (arr.indexOf(el) !== i && acc.indexOf(el) < 0) acc.push(el);
          return acc;
        }, []);
        if (duplicateList.length > 0) {
          this.$store.commit(
            'communicationModule/setUserReviewBtnMutation',
            true
          );
          for (let l = 0; l < duplicateList.length; l++) {
            for (let m = 0; m < this.channelData.length; m++) {
              if (this.channelData[m].programName === duplicateList[l]) {
                this.channelData[m].isProgramError = true;
              }
            }
            // this.channelData[
            //   this.channelData.length - 1
            // ].showConfigureText = false;
          }
        } else {
          this.$store.commit(
            'communicationModule/setUserReviewBtnMutation',
            false
          );
          for (let n = 0; n < this.channelData.length; n++) {
            this.channelData[n].isProgramError = false;
          }
          // this.channelData[this.channelData.length - 1].showConfigureText = true;
        }
      }
    },
    clearProgramErrorMsg (val, idx) {
      this.checkProgramError(val, idx);
    },
    clearProviderErrorMsg (val, idx) {
      if (
        this.channelData[idx].channelName &&
        this.channelData[idx].providerName &&
        this.channelData[idx].programName &&
        this.channelData[idx].isProgramError === false
      ) {
        this.channelData[idx].showConfigureText = true;
      } else {
        this.channelData[idx].showConfigureText = false;
      }
      if (val) {
        for (let i = 0; i <= this.channelData[idx].errorMsg.length - 1; i++) {
          if (
            this.channelData[idx].errorMsg[i] === this.$t('providerErrorTxt')
          ) {
            this.channelData[idx].errorMsg.splice(i, 1);
          }
        }
      }
    },
    setUpAnotherProgram () {
      this.$store.commit('communicationModule/setUserReviewBtnMutation', true);
      this.programData = {};
      this.$store.dispatch(
        'communicationModule/updateAnotherProgramAction',
        true
      );

      let self = this;
      Vue.prototype.$http
        .get(
          'communication/api/v1/providerconfiguration/getchannelsandproviders'
        )
        .then((res) => {
          if (res.status === 200) {
            self.programData.channelsList = res.data.data.channelsList;
            self.programData.providersList = res.data.data.providersList;
            self.programData.configured = false;
            self.programData.isProgramError = false;
            let mockData = JSON.parse(
              res.data.data.providersList[0].configurationJson
            );
            self.programData.providersList[0].apiUrl = mockData.ApiUrl;
            self.programData.providersList[0].userName = mockData.UserName;
            self.programData.providersList[0].password = mockData.Password;

            self.programData.errorMsg = [];
            if (
              this.channelData.length <=
              this.allProgramStatusCommunication.length
            ) {
              this.$store.dispatch(
                'communicationModule/pushProgramDataForCommunicationAction',
                this.programData
              );
            }
          }
        });
    },
    onsubmit () {
      this.programNameAlert = [];
      for (let i = 0; i <= this.channelData.length - 1; i++) {
        if (
          this.channelData[i].configured === false ||
          this.channelData[i].configured === undefined
        ) {
          this.programNameAlert.push(this.channelData[i].programName);
        } else if (
          this.channelData[i].configured === true &&
          !this.channelData[i].isProgramError
        ) {
          this.channelData[i].errorMsg = [];
        }
      }
      if (
        this.programNameAlert.length > 0 &&
        this.programNameAlert.length !== undefined
      ) {
        for (let i = 0; i < this.programNameAlert.length; i++) {
          for (let j = 0; j < this.channelData.length; j++) {
            this.channelData[j].errorMsg = [];
            if (
              this.channelData[j].programName === '' ||
              this.channelData[j].programName === null ||
              this.channelData[j].programName === undefined
            ) {
              this.channelData[j].errorMsg.push(this.$t('programErrorTxt'));
            }
            if (this.channelData[j].programName === this.programNameAlert[i]) {
              if (
                this.channelData[j].channelName === null ||
                this.channelData[j].channelName === undefined ||
                this.channelData[j].channelName === ''
              ) {
                this.channelData[j].errorMsg.push(this.$t('channelErrorTxt'));
              }
              if (
                this.channelData[j].providerName === null ||
                this.channelData[j].providerName === undefined ||
                this.channelData[j].providerName === ''
              ) {
                this.channelData[j].errorMsg.push(this.$t('providerErrorTxt'));
              }
            }
          }
        }
      } else {
        const programArray = this.channelData.filter(
          (item) => item.isProgramError === true
        );
        if (programArray.length === 0 || programArray === undefined) {
          this.$store.commit(
            'communicationModule/setCommunicationStep',
            this.communicationStep += 1
          );
        }
      }
    },
    goToSetup () {
      this.edit = false;
      this.$store.dispatch(
        'communicationModule/updateAnotherProgramAction',
        true
      );
      this.$router.push({
        name: 'CommunicationSetUpLayout'
      });
      this.$store.commit('communicationModule/setCommunicationStep', 1);
      this.$store.dispatch(
        'communicationModule/getAllProgramStatusForCommunicationAction'
      );
      this.$store.dispatch('communicationModule/getChannelProviderDataAction');
    },
    onPreviousClick () {
      this.$store.commit(
        'communicationModule/setCommunicationStep',
        this.communicationStep -= 1
      );
    },
    onSaveSetup () {
      let saveChannelAndProviderData = [];
      let isAllProgram;
      for (let i = 0; i <= this.channelData.length - 1; i++) {
        if (this.channelData[i].programName !== 0) {
          isAllProgram = false;
        } else {
          isAllProgram = true;
          this.channelData[i].configurationId = 0;
          this.channelData[i].programName = 0;
        }
        if (
          this.channelData[i].configurationId === null ||
          this.channelData[i].configurationId === undefined
        ) {
          this.channelData[i].configurationId = 0;
        }
        saveChannelAndProviderData[i] = {
          configurationId: this.channelData[i].configurationId,
          programId: this.channelData[i].programName,
          channelId: this.channelData[i].channelsList[0].channelId,
          channelName: this.channelData[i].channelsList[0].name,
          providerId: this.channelData[i].providersList[0].providerId,
          providerName: this.channelData[i].providersList[0].name,
          providerAttributes: {
            userName: this.channelData[i].providersList[0].userName,
            password: this.channelData[i].providersList[0].password,
            apiUrl: this.channelData[i].providersList[0].apiUrl
          },
          isConfigued: true,
          isAllProgram: isAllProgram
        };
      }
      this.$store
        .dispatch(
          'communicationModule/saveChannelProgramAndProviderAction',
          saveChannelAndProviderData
        )
        .then((res) => {
          if (res.status === 201 || res.status === 200) {
            this.$store.commit(
              'communicationModule/setCommunicationStep',
              this.communicationStep += 1
            );
          }
        });
    }
  },
  watch: {
    channelData () {
      if (
        this.$route.query.isConfigued === false &&
        this.$route.name === 'CommunicationSetUpLayoutEdit'
      ) {
        if (
          !this.channelData[0].providerName &&
          !this.channelData[0].channelName
        ) {
          this.channelData[0].programName = this.$route.query.res;
        }
      }
    }
  },
  created () {
    this.$store.commit('communicationModule/showPopUpDialogueMutation', false);
    if (
      this.$route.name === 'CommunicationSetUpLayoutEdit' &&
      this.$route.query.isConfigued === true
    ) {
      this.edit = true;
      this.$store.dispatch(
        'communicationModule/getAllProgramStatusForCommunicationUpdateAction'
      );
      this.$store.commit('communicationModule/setCommunicationStep', 1);
      this.$store.dispatch(
        'communicationModule/editCommunicationSetup',
        this.$route.query.res
      );
    } else if (
      this.$route.name === 'CommunicationSetUpLayoutEdit' &&
      this.$route.query.isConfigued === false
    ) {
      this.edit = true;
      this.$store.dispatch(
        'communicationModule/getAllProgramStatusForCommunicationUpdateAction'
      );
      this.$store.commit('communicationModule/setCommunicationStep', 1);
      this.$store.dispatch('communicationModule/getChannelProviderDataAction');
    } else {
      this.$store.dispatch(
        'communicationModule/getAllProgramStatusForCommunicationAction'
      );
      this.$store.commit('communicationModule/setCommunicationStep', 1);
      this.$store.dispatch('communicationModule/getChannelProviderDataAction');
    }
  },
  computed: {
    ...mapState('communicationModule', {
      reviewBtnStatus: (state) => {
        return state.reviewBtnStatus;
      }
    }),
    ...mapState('communicationModule', {
      channelProviderData: (state) => {
        return state.channelProviderData;
      }
    }),
    ...mapState('communicationModule', {
      emailTemplatesCount: (state) => {
        return state.emailTemplatesCount;
      }
    }),
    ...mapState('communicationModule', {
      communicationStep: (state) => {
        return state.communicationStep;
      }
    }),
    ...mapState('communicationModule', {
      allProgramStatusCommunication: (state) => {
        return state.allProgramStatusListForCommunication;
      }
    }),
    ...mapState('communicationModule', {
      channelData: (state) => {
        return state.channelData;
      }
    }),
    ...mapState('communicationModule', {
      anotherProgramExistence: (state) => {
        return state.anotherProgramExistence;
      }
    }),
    ...mapState('communicationModule', {
      showPopUpDialogue: (state) => {
        return state.showPopUpDialogue;
      }
    }),
    ...mapState('communicationModule', {
      updateUrlError: (state) => {
        return state.updateUrlError;
      }
    }),
    ...mapState('communicationModule', {
      updateInvalidLoginError: (state) => {
        return state.updateInvalidLoginError;
      }
    }),
    ...mapState('communicationModule', {
      seedDataObject: (state) => {
        return state.seedDataObject;
      }
    }),
    alertMessage () {
      return (
        this.$t('mapConfigText') +
        ' ' +
        this.$t('fndText') +
        ' ' +
        this.emailTemplatesCount +
        ' ' +
        this.$t('rndText')
      );
    }
  }
};
</script>

<style lang="scss" scoped>
.line-height-32 {
  line-height: 32px !important;
}
.bmb28 {
  margin-bottom: 28px;
}
.fontChannel {
  font-size: 24px !important;
  font-weight: 600 !important;
}
.label-create-txt {
  white-space: nowrap;
}
.max-width260 {
  max-width: 260px;
}
.max-width250 {
  max-width: 250px;
}
.max-width230 {
  max-width: 230px;
}
.max-width190 {
  max-width: 190px;
}
.max-width100 {
  max-width: 100px;
}
.dNone {
  display: none !important;
}
.disabledText {
  color: #dddddd;
}
.successText {
  font-weight: 600 !important;
}
.pointer-text {
  cursor: pointer !important;
}
.pointer-none {
  cursor: context-menu !important;
}
</style>
