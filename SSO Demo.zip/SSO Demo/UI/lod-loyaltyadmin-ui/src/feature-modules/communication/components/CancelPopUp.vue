<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closePopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            $t('cardTitle')
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <brierley-alert
                  alertType="error"
                  :alertBody="$t('alertMsg')"
                ></brierley-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="org_btn_cancelDeleteDialog"
            data-qe-id="communication_cancel_nobtn"
            text
            class="cancel no-ripple"
            @click="closeDeleteEntityPopupWhenClickNo()"
            >{{ $t('noBtnTextPopUp') }}</v-btn
          >
          <v-btn
            id="org_btn_deleteDeleteDialog"
            class="primaryctabtn text-uppercase"
            data-qe-id="communication_cancel_yesbtn"
            title
            @click="navigateToList()"
            >{{ $t('yesBtnTextPopUp') }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox, brierleyAlert } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { communicationSetUpObj } from '../../../i18n/language.js';
export default {
  data () {
    return {
      dialog: false
    };
  },
  components: {
    BrierleyDialogbox,
    brierleyAlert
  },
  i18n: communicationSetUpObj,
  computed: {
    ...mapState('communicationModule', {
      communicationStep: (state) => {
        return state.communicationStep;
      }
    })
  },
  methods: {
    closePopup () {
      this.$store.commit('communicationModule/showPopUpDialogueMutation', false);
    },
    navigateToList () {
      this.$router.push('/loyaltyadmin/communication');
    },
    closeDeleteEntityPopupWhenClickNo () {
      this.closePopup();
    }
  }
};
</script>
