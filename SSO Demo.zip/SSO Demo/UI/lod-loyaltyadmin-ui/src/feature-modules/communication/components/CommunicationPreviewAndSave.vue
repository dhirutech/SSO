<template>
  <v-row no-gutters class="d-flex">
    <v-col class="gen2-forms form-light-bg" xs="12" sm="12" md="12">
      <v-row>
        <v-col class="bmt5" xs="11" sm="11" md="11">
          <h3 class="fbold bml1">{{ $t('headerText') }}</h3>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-col class="bml1 mt-2 pl-0">
        <span v-for="(items, i) in channelReviewData" :key="i">
          <p>
            <strong>{{ $t('programNameText') }}</strong>
            <span data-qe-id="communication_programname" class="pl-1">{{
              items.programName
            }}</span>
          </p>
          <p class="textWrap">
            <strong>{{ $t('providerText') }}</strong>
            <span data-qe-id="communication_provider_channel_name">
              {{ items.providerName }} ({{ items.channelName }})
            </span>
          </p>
          <v-row v-if="channelReviewData.length - 1 !== i">
            <v-col xs="12" sm="12" md="12">
              <v-divider
                class="dashed bmb2"
                xs="12"
                sm="12"
                md="12"
              ></v-divider>
            </v-col>
          </v-row>
        </span>

        <!-- Summary End -->
      </v-col>
    </v-col>
  </v-row>
</template>

<script>
import { communicationPreviewObj } from '../../../i18n/language.js';
import { mapState } from 'vuex';
export default {
  data () {
    return {
      channelReviewData: []
    };
  },
  i18n: communicationPreviewObj,
  computed: {
    ...mapState('communicationModule', {
      channelData: (state) => {
        return state.channelData;
      }
    }),
    ...mapState('communicationModule', {
      allProgramStatusCommunication: (state) => {
        return state.allProgramStatusListForCommunication;
      }
    })
  },
  mounted () {
    let programName = '';
    this.channelReviewData = this.channelData.map((data) => {
      programName = this.allProgramStatusCommunication.filter((userItem) => {
        if (userItem.programId === data.programName) {
          return userItem.name;
        }
      });
      const arrData = {
        programName: programName[0].name,
        channelName: data.channelName,
        providerName: data.providerName
      };
      return arrData;
    });
  }
};
</script>
