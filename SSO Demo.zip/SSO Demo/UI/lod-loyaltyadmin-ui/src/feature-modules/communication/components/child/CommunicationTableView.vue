<template>
  <brierley-table-module
    class="bmb2 no-gutters"
    v-if="communicationlistdata.length > 0"
    :no-gutters="true"
  >
    <template v-slot:tablehead>
      <tr class="text-left">
        <th
          data-qe-id="communication_header"
          v-for="item in header"
          :key="item.name"
          class="text-left"
          :width="item.width"
        >
          {{ item.text }}
        </th>
      </tr>
    </template>
    <template v-slot:tablebody>
      <tr v-for="item in communicationlistdata" :key="item.programName">
        <td>
          <v-row class="head-name user-display-name" no-gutters>
            <v-col class="elipsis-twoline" data-qe-id="communication_name">
              <v-img
                v-if="item.programImageUrl !== null"
                :src="item.programImageUrl"
                style="width: 110px;"
              ></v-img>
              <v-img
                v-else
                src="../../../../assets/images/No_Image_Lower_Medium.png"
                style="width: 110px;"
              ></v-img>
            </v-col>
          </v-row>
        </td>
        <td class="vertical-middle">
          <v-row class="d-flex head-name user-display-name" no-gutters>
            <v-col
              class="elipsis-twoline darkgray-text"
              :title="item.programName"
              data-qe-id="communication_name"
              >{{ item.programName }}</v-col
            >
          </v-row>
        </td>
        <td class="vertical-middle">
          <v-row no-gutters>
            <v-col
              class="elipsis-twoline"
              :title="item.programDescription"
              data-qe-id="communication_description"
              >{{ item.programDescription }}</v-col
            >
          </v-row>
        </td>
        <td class="vertical-middle">
          <v-row no-gutters>
            <v-col
              class="elipsis-twoline"
              data-qe-id="communication_description"
            >
              <p
                class="bmb0"
                v-for="provider in item.providers"
                :key="provider.name"
              >
                {{ provider.name }}
              </p>
            </v-col>
          </v-row>
        </td>
        <td class="vertical-middle">
          <v-row no-gutters>
            <v-col
              class="elipsis-twoline"
              data-qe-id="communication_description"
            >
              <p
                class="bmb0"
                v-for="provider in item.providers"
                :key="provider.channels"
              >
                <span
                  v-for="(channel, index) in provider.channels"
                  :key="channel"
                >
                  <span v-if="index < provider.channels.length - 1">
                    {{ channel }},
                  </span>
                  <span v-else>
                    {{ channel }}
                  </span>
                </span>
                <br />
              </p>
            </v-col>
          </v-row>
        </td>
        <td class="vertical-middle">
          <v-row no-gutters>
            <v-col
              class="elipsis-twoline"
              data-qe-id="communication_description"
            >
              <brierley-status
                v-if="item.isConfigued"
                data-qe-id="communication_active"
                title="Completed"
                status="Completed"
              ></brierley-status>
              <brierley-status
                v-if="!item.isConfigued"
                data-qe-id="communication_inactive"
                title="Not Completed"
                status="Not Completed"
              ></brierley-status>
            </v-col>
          </v-row>
          <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
            <v-col>
              <brierleyCardIcons>
                <template v-slot:action-icons>
                  <span
                    data-qe-id="communication_campaign"
                    class="active"
                    @click="goToCommMsg(item)"
                  >
                    <v-icon title="Campaign" class="blackicon icon-gray"
                      >campaign</v-icon
                    >
                    <span class="campain-icon">{{ $t('GOTOCOMMMSG') }}</span>
                  </span>
                  <span
                    data-qe-id="communication_edit"
                    @click="editUser(item.programId, item)"
                  >
                    <v-icon data-qe-id="communication_edit" class="blackicon"
                      >fe-edit</v-icon
                    >
                    <span class="edit-icon">{{ $t('editText') }}</span>
                  </span>
                </template>
              </brierleyCardIcons>
            </v-col>
          </v-row>
        </td>
      </tr>
    </template>
  </brierley-table-module>
</template>

<script>
import {
  BrierleyCardIcons,
  BrierleyTableModule,
  BrierleyStatus
} from '@brierley/SharedComponents';
import { communicationCardViewObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyCardIcons,
    BrierleyStatus,
    BrierleyTableModule
  },

  data () {
    return {
      sortKey: ['name'],
      sortOrder: ['asc'],
      isToggled: false,
      changeColor: false,
      btext: '',
      msg: '',
      headertext: '',
      header: [
        { name: 'logo', text: this.$t('pgmLogo'), sort: 'asc' },
        { name: 'name', text: this.$t('pgmNameTable'), sort: 'asc' },
        { name: 'description', text: this.$t('des'), sort: 'asc' },
        { name: 'provider', text: this.$t('Provider'), sort: 'asc' },
        { name: 'channel', text: this.$t('Channel'), sort: 'asc' },
        { name: 'programSetup', text: this.$t('pgmSetup'), sort: 'asc' }
      ]
    };
  },
  i18n: communicationCardViewObj,
  props: {
    communicationlistdata: {
      type: Array
    }
  },
  methods: {
    goToCommMsg (res) {
      localStorage.setItem('programId', res.programId);
      let val = this.$root.GlobalStoreEventStore.state.programList;
      val.forEach((result) => {
        if (res.programId === result.programId) {
          result.isDefault = true;
        } else {
          result.isDefault = false;
        }
      });
      this.$root.GlobalStoreEventStore.dispatch('getProgramList', val);
      this.$router.push({
        name: 'communicationDashboard'
      });
    },
    editUser (id, program) {
      if (program.isConfigued === true) {
        this.$router.push({
          name: 'CommunicationSetUpLayoutEdit',
          isConfigued: true,
          query: { res: id, isConfigued: true }
        });
      } else if (program.isConfigued === false) {
        this.$router.push({
          name: 'CommunicationSetUpLayoutEdit',
          isconfigured: false,
          query: { res: id, isConfigued: false }
        });
      }
    }
  }
};
</script>
