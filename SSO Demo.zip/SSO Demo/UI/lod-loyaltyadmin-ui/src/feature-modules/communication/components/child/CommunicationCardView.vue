<template>
  <v-row class="d-flex flex-column" no-gutters>
    <v-col>
      <v-row class="row-margin-10 mb-1">
        <v-col
          md="6"
          sm="12"
          xs="12"
          v-for="(program, index) in communicationlistdata"
          :key="index"
        >
          <brierley-card-with-logo
            :logo="false"
            class="min-height-elements-card"
          >
            <template v-slot:cardlogo-image>
              <img
                data-qe-id="communication_img"
                v-if="program.programImageUrl !== null"
                :src="program.programImageUrl"
                width="320"
                height="173"
              />
              <img
                v-else
                data-qe-id="communication_img"
                width="320"
                height="173"
                src="../../../../assets/images/No_Image_Large.png"
              />
            </template>
            <template v-slot:heading>
              <h2
                data-qe-id="communication_name"
                class="bmb2 elipsis-fullwidth text-uppercase fbold darkgray-text"
              >
                {{ program.programName }}
              </h2>
            </template>
            <template v-slot:body>
              <p data-qe-id="communication_description_title">
                <strong>{{ $t('pgmDescription') }}:</strong>
              </p>
              <p
                class="bmb4 min-height-48 elipsis-twoline"
                data-qe-id="communication_description"
              >
                {{ program.programDescription }}
              </p>
              <p class="bmb2">
                <v-row>
                  <v-col md="8" v-if="program.providers.length > 0">
                    <span
                      v-for="provider in program.providers"
                      :key="provider.name"
                    >
                      <strong data-qe-id="communication_provider_title"
                        >{{ $t('Provider') }}:</strong
                      >
                      {{ provider.name }} (
                      <span
                        data-qe-id="communication_channel_title"
                        v-for="(channel, index) in provider.channels"
                        :key="channel"
                      >
                        <span v-if="index < provider.channels.length - 1">
                          {{ channel }},
                        </span>
                        <span v-else>
                          {{ channel }}
                        </span>
                      </span>
                      )
                      <br />
                    </span>
                  </v-col>
                  <v-col md="4">
                    <p data-qe-id="communication_provider_setup">
                      <strong>{{ $t('providerSetup') }}</strong>
                    </p>
                    <brierley-status
                      v-if="program.isConfigued"
                      data-qe-id="communication_active"
                      title="Completed"
                      status="Completed"
                    ></brierley-status>
                    <brierley-status
                      v-if="!program.isConfigued"
                      data-qe-id="communication_inactive"
                      title="Not Completed"
                      status="Not Completed"
                    ></brierley-status>
                  </v-col>
                </v-row>
              </p>
            </template>

            <template v-slot:icons>
              <brierleyCardIcons>
                <template v-slot:action-icons>
                  <span
                    class="active"
                    data-qe-id="communication_campaign"
                    @click="goToCommMsg(program)"
                  >
                    <v-icon
                      :title="$t('GOTOCOMMMSG')"
                      class="blackicon icon-gray"
                      >campaign</v-icon
                    >
                    <span class="campain-icon">{{ $t('GOTOCOMMMSG') }}</span>
                  </span>
                  <span
                    data-qe-id="communication_edit"
                    @click="editUser(program.programId, program)"
                  >
                    <v-icon :title="$t('editText')" class="blackicon"
                      >fe-edit</v-icon
                    >
                    <span
                      data-qe-id="communication_edit_icon"
                      class="edit-icon"
                      >{{ $t('editText') }}</span
                    >
                  </span>
                </template>
              </brierleyCardIcons>
            </template>
          </brierley-card-with-logo>
        </v-col>
      </v-row>
      <brierley-dialogbox :dialog="dialog" @closeMe="dialog = false">
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            $t('deleteProgGridListPageText')
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-alert>
          <brierley-alert
            alertType="error"
            :alertBody="$t('progGridListDelAlertText')"
          ></brierley-alert>
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <p>
              {{ $t('progGridListDeleteText') }}
            </p>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            data-qe-id="communication_cancel_btn"
            text
            class="cancel no-ripple"
            @click="dialog = false"
            >{{ $t('noLabelText') }}</v-btn
          >
          <v-btn
            class="primaryctabtn btn-close"
            title="Default"
            @click="deleteProgram()"
            data-qe-id="communication_delete_btn"
            >{{ $t('yesLabelText') }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyCardIcons,
  BrierleyDialogbox,
  BrierleyStatus,
  BrierleyCardWithLogo
} from '@brierley/SharedComponents';
import { communicationCardViewObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyCardIcons,
    BrierleyDialogbox,
    BrierleyStatus,
    BrierleyCardWithLogo
  },
  i18n: communicationCardViewObj,
  props: {
    communicationlistdata: {
      type: Array
    }
  },
  methods: {
    goToCommMsg (res) {
      localStorage.setItem('programId', res.programId);
      let val = this.$root.GlobalStoreEventStore.state.programList;
      val.forEach((result) => {
        if (res.programId === result.programId) {
          result.isDefault = true;
        } else {
          result.isDefault = false;
        }
      });
      this.$root.GlobalStoreEventStore.dispatch('getProgramList', val);
      this.$router.push({
        name: 'communicationDashboard'
      });
    },
    editUser (id, program) {
      if (program.isConfigued === true) {
        this.$router.push({
          name: 'CommunicationSetUpLayoutEdit',
          isConfigued: true,
          query: { res: id, isConfigued: true }
        });
      } else if (program.isConfigued === false) {
        this.$router.push({
          name: 'CommunicationSetUpLayoutEdit',
          isconfigured: false,
          query: { res: id, isConfigued: false }
        });
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.min-height-48 {
  min-height: 48px;
  margin-bottom: 8px !important;
}
</style>
