<template>
  <v-row no-gutters>
    <v-col
      cols="12"
      v-for="(program, index) in communicationlistdata"
      :key="index"
      class="bmt1 bmb2"
    >
      <v-card class="gen2-card gen2-typo3">
        <v-row no-gutters>
          <v-col sm="5" xs="12">
            <v-row>
              <v-col md="4" class="bpt0 bpb0">
                <v-img
                  data-qe-id="communication_image"
                  v-if="program.programImageUrl !== null"
                  :src="program.programImageUrl"
                  style="width: 137px;
                              height: 77.1px;"
                ></v-img>
                <v-img
                  v-else
                  data-qe-id="communication_image"
                  src="../../../../assets/images/No_Image_Lower_Medium.png"
                  style="width: 137px;
                              height: 77.1px;"
                ></v-img>
              </v-col>
              <v-col md="8" class="bpt0 bpb0" data-qe-id="communication_name">
                <v-row class="flex-column" no-gutters>
                  <v-col>
                    <strong>{{$t("pgmName")}}</strong>
                  </v-col>
                  <v-col :title="ProgramName" data-qe-id="communication_title">
                    <span
                      class="elipsis-fullwidth text-uppercase display-block fbold font18 bpr4 mt-1"
                    >
                      {{ program.programName }}
                    </span>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
          </v-col>

          <v-col sm="4" xs="12">
            <v-row no-gutters>
              <v-col sm="12">
                <p class="bmt0">
                  <strong data-qe-id="communication_description_title"
                    >{{$t('pgmDescription')}}:</strong
                  >
                </p>
                <p
                  class="elipsis-twoline bmt0 bpr2"
                  :title="programdescription"
                  data-qe-id="communication_description"
                >
                  {{ program.programDescription }}
                </p>
              </v-col>
              <v-col sm="12" v-if="program.providers.length > 0">
                <p v-for="provider in program.providers" :key="provider.name">
                  <strong data-qe-id="communication_provider_title"
                    >{{$t("Provider")}}:</strong
                  >
                  {{ provider.name }} (
                  <span
                    data-qe-id="communication_provider_channel"
                    v-for="(channel, index) in provider.channels"
                    :key="channel"
                  >
                    <span v-if="index < provider.channels.length - 1"
                      >{{ channel }},
                    </span>
                    <span v-else>
                      {{ channel }}
                    </span>
                  </span>
                  )
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col sm="3">
            <p class="bmt0">
              <strong>{{ $t('providerSetup') }}</strong>
            </p>
            <p class="discription bmt0">
              <brierley-status
                data-qe-id="communication_active"
                v-if="program.isConfigued"
                title="Completed"
                status="Completed"
              ></brierley-status>
              <brierley-status
                data-qe-id="communication_inactive"
                v-if="!program.isConfigued"
                title="Not Completed"
                status="Not Completed"
              ></brierley-status>
            </p>
          </v-col>
          <v-col sm="12">
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span
                  class="active"
                  :title="$t('GOTOCOMMMSG')"
                  data-qe-id="communication_campaign"
                   @click="goToCommMsg(program)"
                >
                  <v-icon class="blackicon icon-gray">campaign</v-icon>
                  <span class="campain-icon">{{$t("GOTOCOMMMSG")}}</span>
                </span>
                <span
                  data-qe-id="communication_edit"
                  :title="$t('editText')"
                  @click="editUser(program.programId, program)"
                >
                  <v-icon class="blackicon">fe-edit</v-icon>
                  <span class="edit-icon">{{ $t('editText') }}</span>
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
        </v-row>
      </v-card>
    </v-col>
  </v-row>
</template>

<script>
import { BrierleyCardIcons, BrierleyStatus } from '@brierley/SharedComponents';
import { communicationCardViewObj } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyCardIcons,
    BrierleyStatus
  },
  i18n: communicationCardViewObj,
  props: {
    communicationlistdata: {
      type: Array,
      defualt: []
    }
  },
  methods: {
    goToCommMsg (res) {
      localStorage.setItem('programId', res.programId);
      let val = this.$root.GlobalStoreEventStore.state.programList;
      val.forEach(result => {
        if (res.programId === result.programId) {
          result.isDefault = true;
        } else {
          result.isDefault = false;
        }
      });
      this.$root.GlobalStoreEventStore.dispatch(
        'getProgramList',
        val
      );
      localStorage.setItem('commProgramClick', true);
      this.$router.push({
        name: 'communicationDashboard'
      });
    },
    editUser (id, program) {
      if (program.isConfigued === true) {
        this.$router.push({
          name: 'CommunicationSetUpLayoutEdit',
          isConfigued: true,
          query: { res: id, isConfigued: true, }
        });
      } else if (program.isConfigued === false) {
        this.$router.push({
          name: 'CommunicationSetUpLayoutEdit',
          isconfigured: false,
          query: { res: id, isConfigued: false }
        });
      }
    }
  }
};
</script>
<style lang="scss">
.gen2-card-btm-icons {
  span.active {
    .v-icon.icon-gray {
      color: #0628b1 !important;
    }
    &:hover {
      .v-icon.icon-gray.blackicon {
        color: #0628b1 !important;
      }
    }
  }
  &:hover {
    span.active {
      .v-icon.icon-gray {
        color: #212121 !important;
      }
    }
  }
}
</style>
