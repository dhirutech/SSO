<template>
  <brierley-inner-view>
    <template v-slot:header>
      <span
        data-qe-id="communication_lable_heading"
        class="inner-head bpl1"
        style="position:relative; right:5px"
        >{{ $t('comminicationLabel') }}</span
      >
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        data-qe-id="communication_btn_close"
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>{{ $t('closeBtnText') }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row class="flex-column bpt4" no-gutters>
        <v-col>
          <brierley-form-title
            data-qe-id="communication_title"
            :formTitle="$t('commSetup')"
            :infoText="$t('commSetupInfoText')"
          >
          </brierley-form-title>
        </v-col>
        <v-col>
          <v-row class="gen2-search-filter bpt5 bmb1" no-gutters>
            <v-col class="label-text bmb1" cols="6">
              {{ $t('pgmList') }}
            </v-col>
            <v-col cols="6" class="text-right align-self-center">
              <div class="d-inline-block view-options-padding-none mtn-10">
                <brierley-view-option
                  id="communication_viewoptions"
                  :viewList="cardlist"
                  @viewOptionClicked="clearFilter()"
                  data-qe-id="communication_viewoptions"
                  @viewChanged="viewType = $event"
                ></brierley-view-option>
              </div>
            </v-col>
          </v-row>
        </v-col>
        <v-col>
          <communication-card-view
            v-if="viewType === 'card_view'"
            :communicationlistdata="communicationsList"
            data-qe-id="communication_card_view"
          />
          <CommunicationGidView
            data-qe-id="communication_grid_view"
            v-if="viewType === 'grid_view'"
            :communicationlistdata="communicationsList"
          />
          <communication-table-view
            data-qe-id="communication_table_view"
            v-if="viewType === 'table_view'"
            :communicationlistdata="communicationsList"
          />
          <brierley-no-result
            data-qe-id="communication_no_results"
            v-if="communicationsList.length === 0 && !loadmore"
            :noResultMessage="noRecordsFound"
          ></brierley-no-result>
        </v-col>
      </v-row>

      <v-col align="center" v-if="loadmore">
        <loadmore loadingText="loading" class="margin-auto" />
      </v-col>
    </template>
    <template v-slot:footer>
      <v-btn
        data-qe-id="communication_btn_getting_started"
        text
        class="primaryctabtn no-ripple"
        @click.native="$router.push('/gettingstarted')"
        >{{ $t('closeBtnText') }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyFormTitle,
  BrierleyInnerView,
  BrierleyViewOption,
  BrierleyNoResult,
  Loadmore
} from '@brierley/SharedComponents';
import CommunicationCardView from './child/CommunicationCardView';
import CommunicationGidView from './child/CommunicationGidView';
import CommunicationTableView from './child/CommunicationTableView';
import { mapState } from 'vuex';
import { communicationObj } from '../../../i18n/language.js';
export default {
  components: {
    BrierleyFormTitle,
    CommunicationCardView,
    CommunicationGidView,
    BrierleyInnerView,
    BrierleyViewOption,
    Loadmore,
    CommunicationTableView,
    BrierleyNoResult
  },
  data () {
    return {
      noRecordsFound:
        'No Product definitions have been created for this Program entity. Please use the link on the top right corner of this page to create one',
      isHidden: false,
      searchText: '',
      isTyping: false,
      loadmore: true,
      showPopUp: false,
      viewType: 'grid_view',
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('gridViewText')
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('tableViewText')
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('cardViewText')
        }
      ]
    };
  },
  i18n: communicationObj,
  methods: {
    getCommunicationsListData () {
      this.loadMore = true;
      this.$store.dispatch(
        'communicationModule/getCommunicationsList',
        this.params
      );
    },

    onScroll () {
      window.onscroll = () => {
        if (
          document.documentElement.scrollHeight ===
          document.documentElement.scrollTop + window.innerHeight
        ) {
          this.params.pageSize += 10;
          this.loadmore = true;
          this.getCommunicationsListData();
        }
      };
    },
    clearFilter () {
      this.isHidden = false;
    }
  },
  watch: {
    communicationsList () {
      this.loadmore = false;
    }
  },
  mounted () {
    this.getCommunicationsListData();
    window.addEventListener('scroll', this.onScroll);
  },
  beforeDestroy () {
    window.removeEventListener('scroll', this.onScroll);
  },
  computed: {
    ...mapState('communicationModule', {
      communicationsList: (state) => {
        return state.communicationlist;
      }
    }),
    ...mapState('communicationModule', ['params'])
  }
};
</script>
<style scoped></style>
