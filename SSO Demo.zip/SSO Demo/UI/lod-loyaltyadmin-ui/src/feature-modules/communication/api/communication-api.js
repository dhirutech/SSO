import Vue from 'vue';

const getCommunications = payload => {
  return Vue.prototype.$http.get(
    '/communication/api/v1/providerconfiguration/getall/' + payload.pageNumber + '/' + payload.pageSize
  );
};

const getAllProgramStatusForCommunication = () => {
  return Vue.prototype.$http.get('communication/api/v1/providerconfiguration/programstoconfigure');
};
const getAllProgramStatusForCommunicationEdit = () => {
  return Vue.prototype.$http.get('loyaltyconfiguration/api/v1/programs');
};

const getChannelProviderData = () => {
  return Vue.prototype.$http.get(
    'communication/api/v1/providerconfiguration/getchannelsandproviders'
  );
};

const updateProviderChannelInfo = payload => {
  return Vue.prototype.$http.post(
    'communication/api/v1/providerconfiguration/verifyprovider',
    payload
  );
};

const saveChannelProgramAndProviderData = payload => {
  return Vue.prototype.$http.post(
    'communication/api/v1/providerconfiguration/save',
    payload
  );
};

const getEditCommunication = payload => {
  return Vue.prototype.$http.get(
    'communication/api/v1/providerconfiguration/getbyprogram/' + payload
  );
};

export {
  getCommunications,
  getAllProgramStatusForCommunication,
  saveChannelProgramAndProviderData,
  getAllProgramStatusForCommunicationEdit,
  getChannelProviderData,
  updateProviderChannelInfo,
  getEditCommunication
};
