const getCommunicationList = state => state.communicationlist;

export default { getCommunicationList };
