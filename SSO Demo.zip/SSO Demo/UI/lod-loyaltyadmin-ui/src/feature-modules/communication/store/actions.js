import {
  getCommunications,
  getAllProgramStatusForCommunication,
  saveChannelProgramAndProviderData,
  getAllProgramStatusForCommunicationEdit,
  getChannelProviderData,
  updateProviderChannelInfo,
  getEditCommunication
} from '../api/communication-api';

const getCommunicationsList = (context, payload) => {
  getCommunications(payload)
    .then(result => {
      context.commit('communicationListMutation', result.data.data);
    })
    .catch();
};

const getAllProgramStatusForCommunicationAction = context => {
  return new Promise((resolve, reject) => {
    getAllProgramStatusForCommunication()
      .then(res => {
        resolve(res);
        context.commit(
          'getAllProgramStatusForCommunicationMutation',
          res.data.data
        );
      })
      .catch(err => {
        reject(err);
        if (err.response.status === 400 || err.response.status === 404) {
          context.commit(
            'getAllProgramStatusForCommunicationMutation',
            err.response.data.data
          );
        }
      });
  });
};

const getAllProgramStatusForCommunicationUpdateAction = context => {
  return new Promise((resolve, reject) => {
    getAllProgramStatusForCommunicationEdit()
      .then(res => {
        resolve(res);
        context.commit('getAllProgramStatusForCommunicationMutation', res.data);
      })
      .catch(err => {
        reject(err);
        if (err.response.status === 400 || err.response.status === 404) {
          context.commit(
            'getAllProgramStatusForCommunicationMutation',
            err.response.data.data
          );
        }
      });
  });
};

const getChannelProviderDataAction = context => {
  getChannelProviderData().then(channelProviderDataRes => {
    let mockData = JSON.parse(
      channelProviderDataRes.data.data.providersList[0].configurationJson
    );
    channelProviderDataRes.data.data.providersList[0].apiUrl = mockData.ApiUrl;
    channelProviderDataRes.data.data.providersList[0].userName =
      mockData.UserName;
    channelProviderDataRes.data.data.providersList[0].password =
      mockData.Password;
    context.commit(
      'getChannelProviderDataMutation',
      channelProviderDataRes.data
    );
  });
};

const setChannelIndexAction = (context, payload) => {
  context.commit('setChannelIndexMutation', payload);
};

const updateAnotherProgramAction = (context, payload) => {
  context.commit('updateanotherProgramExistenceMutation', payload);
};

const setDataObjectAction = (context, payload) => {
  context.commit('setDataObjectMutation', payload);
};

const postChannelProviderDataAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    updateProviderChannelInfo(payload)
      .then(res => {
        resolve(res);
        if (
          res.data.isError === false &&
          res.data.httpStatusCode === 200 &&
          res.data.data === false
        ) {
          context.commit('updateInvalidLoginErrorMutation', res.data.isError);
          context.commit('updateUrlErrorMutation', false);
        }
        context.commit(
          'updateanotherProgramExistenceMutation',
          res.data.isError
        );
        context.commit(
          'emailTemplatesCountMutation',
          res.data.data.emailTemplatesCount
        );
        context.commit('updateChannelDataMutation', res.data.isError);
      })
      .catch(err => {
        reject(err);
        if (err.response.data.isError && err.response.status === 400) {
          context.commit('updateInvalidLoginErrorMutation', false);
          context.commit(
            'updateUrlErrorMutation',
            err.response.data.developerMessage
          );
        }
        if (
          err.response.status === 400 &&
          !err.response.data.data.isConnected
        ) {
          context.commit(
            'updateUrlErrorMutation',
            err.response.data.developerMessage
          );
          context.commit('updateInvalidLoginErrorMutation', false);
        }
      });
  });
};

const saveChannelProgramAndProviderAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    saveChannelProgramAndProviderData(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const pushProgramDataForCommunicationAction = (context, payload) => {
  context.commit('pushProgramDataForCommunicationMutation', payload);
};

const pushAllProgramData = (context, payload) => {
  context.commit('pushAllProgramDataMutation', payload);
};

const removeProgramStatusForCommunicationAction = (context, payload) => {
  context.commit('removeProgramStatusForCommunicationMutation', payload);
};

const editCommunicationSetup = (context, payload) => {
  getEditCommunication(payload).then(result => {
    let mockData = JSON.parse(result.data.data[0].configurationJson);
    let channelData = [];
    channelData = [
      {
        channelsList: [
          {
            channelId: result.data.data[0].channelId,
            name: result.data.data[0].channelName,
            displayName: result.data.data[0].channelName,
            isActive: true
          }
        ],
        providersList: [
          {
            providerId: result.data.data[0].providerId,
            name: result.data.data[0].providerName,
            configurationJson: result.data.data[0].configurationJson,
            apiUrl: mockData.ApiUrl,
            userName: mockData.UserName,
            password: mockData.Password
          }
        ],
        programName: result.data.data[0].programId,
        channelName: result.data.data[0].channelName,
        providerName: result.data.data[0].providerName,
        errorMsg: [],
        configured: false,
        configurationId: result.data.data[0].configurationId
      }
    ];
    context.commit('editCommunication', channelData);
  });
};

export default {
  getCommunicationsList,
  getAllProgramStatusForCommunicationAction,
  getAllProgramStatusForCommunicationUpdateAction,
  getChannelProviderDataAction,
  pushAllProgramData,
  saveChannelProgramAndProviderAction,
  pushProgramDataForCommunicationAction,
  removeProgramStatusForCommunicationAction,
  postChannelProviderDataAction,
  setChannelIndexAction,
  updateAnotherProgramAction,
  setDataObjectAction,
  editCommunicationSetup
};
