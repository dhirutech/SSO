export default {
  moduleVar: 'I am Module',
  communicationlist: [],
  allProgramStatusListForCommunication: [],
  channelProviderData: [],
  channelData: [],
  configParams: {
    userName: 'alice.john@gmail.com',
    password: 'alicejosn',
    apiURL: 'kona-dev@brieley.com'
  },
  communicationStep: 1,
  showPopUpDialogue: false,
  emailTemplatesCount: null,
  channelIndex: null,
  anotherProgramExistence: true,
  updateUrlError: '',
  updateInvalidLoginError: true,
  seedDataObject: {},
  params: {
    pageSize: 10,
    pageNumber: 1
  },
  reviewBtnStatus: true
};
