const communicationListMutation = (state, payload) => {
  state.communicationlist = payload;
};

const getAllProgramStatusForCommunicationMutation = (state, payload) => {
  state.allProgramStatusListForCommunication = payload;
};

const getChannelProviderDataMutation = (state, payload) => {
  state.channelData = [];
  state.channelProviderData.push(payload.data);
  payload.data.errorMsg = [];
  payload.data.configured = false;
  payload.data.isProgramError = false;
  payload.data.showConfigureText = false;
  state.channelData.push(payload.data);
};
const showPopUpDialogueMutation = (state, payload) => {
  state.showPopUpDialogue = payload;
};
const pushProgramDataForCommunicationMutation = (state, payload) => {
  state.channelData.push(payload);
};

const setChannelIndexMutation = (state, payload) => {
  state.channelIndex = payload;
};

const setDataObjectMutation = (state, payload) => {
  state.seedDataObject = payload;
};

const updateUrlErrorMutation = (state, payload) => {
  state.updateUrlError = payload;
};

const emailTemplatesCountMutation = (state, payload) => {
  state.emailTemplatesCount = payload;
};

const updateInvalidLoginErrorMutation = (state, payload) => {
  state.updateInvalidLoginError = payload;
};

const updateChannelDataMutation = (state, payload) => {
  state.channelData[state.channelIndex].configured = payload;
};

const updateanotherProgramExistenceMutation = (state, payload) => {
  state.anotherProgramExistence = payload;
};

const setCommunicationStep = (state, payload) => {
  state.communicationStep = payload;
};

const pushAllProgramDataMutation = (state, payload) => {
  state.allProgramStatusListForCommunication.push(payload);
};

const removeProgramStatusForCommunicationMutation = (state, payload) => {
  state.channelData.splice(payload, 1);
};

const configParameterUserMutations = (state, payload) => {
  state.configParams = payload;
};

const editCommunication = (state, payload) => {
  state.channelData = payload;
};

const setUserReviewBtnMutation = (state, payload) => {
  state.reviewBtnStatus = payload;
};

export default {
  setUserReviewBtnMutation,
  communicationListMutation,
  getAllProgramStatusForCommunicationMutation,
  pushAllProgramDataMutation,
  showPopUpDialogueMutation,
  configParameterUserMutations,
  getChannelProviderDataMutation,
  setCommunicationStep,
  pushProgramDataForCommunicationMutation,
  removeProgramStatusForCommunicationMutation,
  setChannelIndexMutation,
  emailTemplatesCountMutation,
  updateChannelDataMutation,
  updateanotherProgramExistenceMutation,
  updateUrlErrorMutation,
  updateInvalidLoginErrorMutation,
  setDataObjectMutation,
  editCommunication
};
