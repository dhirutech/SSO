import UserLayout from './components/UserLayout';
import EditProfile from './components/EditProfile';
import { Demo } from '@brierley/SharedComponents';

const userRoutes = [
  {
    path: '/loyaltyadmin/user/create',
    name: 'UserLayout',
    component: UserLayout,
    meta: {
      showNavigation: false,
    },
  },
  {
    path: '/loyaltyadmin/editprofile',
    name: 'EditProfile',
    component: EditProfile,
    meta: {
      showNavigation: false,
    },
  },
  {
    path: '/loyaltyadmin/user/edit',
    name: 'UserLayoutEdit',
    component: UserLayout,
    meta: {
      showNavigation: false,
    },
  },
  {
    path: '/loyaltyadmin/user/clone',
    name: 'UserLayoutClone',
    component: UserLayout,
    meta: {
      showNavigation: false,
    },
  },
  {
    path: '/loyaltyadmin/demo',
    name: 'demo',
    component: Demo,
    meta: {
      showNavigation: true,
    },
  },
];

export default userRoutes;
