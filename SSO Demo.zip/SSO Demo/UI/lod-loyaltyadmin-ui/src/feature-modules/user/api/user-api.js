import Vue from 'vue';
// import { ApiClient } from '@brierley/SharedComponents';

const getUserAsync = (userId) => {
  return Vue.prototype.$http.get(
    'https://localhost:44305/identity/api/v1/users/' + userId
  );
};

const putUserAsync = (user) => {
  return Vue.prototype.$http.patch(
    'identity/api/v1/users/', user);
};

const getUsers = id => {
  return Vue.prototype.$http.get('identity/api/v1/users/' + id);
};

const cloneUser = id => {
  return Vue.prototype.$http.get('identity/api/v1/users/' + id);
};

const getAllProgramStatus = () => {
  return Vue.prototype.$http.get('loyaltyconfiguration/api/v1/programs');
};

const getAllRolesAssignment = () => {
  return Vue.prototype.$http.get('rbac/api/v1/permissions/rolesServiceMethods');
};

const createUser = createUserModel => {
  if (createUserModel.userId) {
    return Vue.prototype.$http.patch('identity/api/v2/users', createUserModel);
  } else {
    return Vue.prototype.$http.post('identity/api/v2/users', createUserModel);
  }
};

const userExistsOrNot = userExistsModel => {
  return Vue.prototype.$http.get(
    '/identity/api/v2/users/userexists/' + userExistsModel
  );
};

export { getUserAsync, putUserAsync, getUsers, createUser, userExistsOrNot, getAllProgramStatus, getAllRolesAssignment, cloneUser };


