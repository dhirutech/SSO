<template>
  <brierley-inner-view class="gen2-container-py0">
    <template v-slot:header>
      <span class="inner-head">{{ title }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>{{ $t("closeBtnText") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <brierley-primary-stepper :currentStep="userCurrentStep" :stepperSize="4">
        <template v-slot:stepper-steps>
          <v-stepper-step step="1">{{
            $t("personalInfoLabel")
          }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="2">{{
            $t("roleAssignmentLabel")
          }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="3">{{ $t("reviewSaveLabel") }}</v-stepper-step>
        </template>
        <template slot="stepper-content">
          <Validation-Observer ref="observerValid" v-slot="{ handleSubmit }">
            <form id="user_form" @submit.prevent="handleSubmit(onsubmit)">
              <v-stepper-items>
                <v-stepper-content step="1">
                  <v-row class="flex-column" no-gutters>
                    <v-col>
                      <brierley-form-title
                        :formTitle="$t('personalInfoFormTitle')"
                        :currentStep="1"
                        :totalStep="3"
                        :infoText="$t('personalInfoText')"
                        :showSteps="true"
                      ></brierley-form-title>
                    </v-col>
                    <v-col>
                      <keep-alive>
                        <Validation-Observer v-if="userCurrentStep === 1">
                          <PersonalInformation />
                        </Validation-Observer>
                      </keep-alive>
                    </v-col>
                  </v-row>
                  <CancelPopUp
                    v-if="showPopUpDialogue && userCurrentStep == 1"
                  />
                </v-stepper-content>
                <v-stepper-content step="2">
                  <v-row class="flex-column" no-gutters>
                    <v-col>
                      <brierley-form-title
                        :formTitle="$t('roleInfoFormTitle')"
                        :currentStep="2"
                        :totalStep="3"
                        :infoText="$t('roleInfoText')"
                        :showSteps="true"
                      ></brierley-form-title>
                    </v-col>
                    <v-col>
                      <Validation-Observer v-slot="{ handleSubmit }">
                        <form
                          id="role_child_form"
                          @submit.prevent="handleSubmit(onRoleSubmit)"
                        >
                          <role-assignment v-if="userCurrentStep === 2" />
                        </form>
                      </Validation-Observer>
                      <CancelPopUp
                        v-if="showPopUpDialogue && userCurrentStep == 2"
                      />
                    </v-col>
                  </v-row>
                </v-stepper-content>
                <v-stepper-content step="3">
                  <v-row class="flex-column" no-gutters>
                    <v-col>
                      <brierley-form-title
                        :formTitle="$t('reviewInfoFormTitle')"
                        :currentStep="3"
                        :totalStep="3"
                        :infoText="$t('reviewInfoText')"
                        :showSteps="true"
                      ></brierley-form-title>
                    </v-col>
                    <v-col>
                      <PreviewAndSave
                        v-on:previewToPersonalInfo="onPreviewClick"
                        v-if="userCurrentStep === 3"
                      />
                      <CancelPopUp
                        v-if="showPopUpDialogue && userCurrentStep == 3"
                      />
                    </v-col>
                  </v-row>
                </v-stepper-content>
                <v-stepper-content step="4">
                  <v-row class="flex-column" no-gutters>
                    <v-col>
                      <brierley-form-title
                        :formTitle="$t('successFormTitle')"
                      ></brierley-form-title>
                    </v-col>
                    <v-col class="bpt5">
                      <brierley-alert
                        :isSiteLevel="true"
                        alertType="success"
                        :alertBody="alertMessage"
                        :alertHeader="$t('successAlertHeader')"
                      ></brierley-alert>
                    </v-col>
                  </v-row>
                </v-stepper-content>
              </v-stepper-items>
            </form>
          </Validation-Observer>
        </template>
      </brierley-primary-stepper>
    </template>
    <template
      v-slot:footer-previous
      v-if="userCurrentStep > 1 && userCurrentStep < 4"
    >
      <v-btn
        id="user_btn_previous"
        text
        class="mr-5 cancel no-ripple"
        @click="onPreviousClick()"
        title="Preview"
      >
        <v-icon class="bpr1">arrow_back</v-icon>{{ $t("previousBtnText") }}
      </v-btn>
    </template>
    <template v-slot:footer-redirect v-if="userCurrentStep == 4">
      <v-btn
        id="user_btn_goToUsers"
        title="Go To Users"
        class="primaryctabtn bmt2"
        @click="gotoUsersClick()"
        >{{ $t("gotoUsersBtnText") }}</v-btn
      >
    </template>
    <template v-slot:footer>
      <v-btn
        title="Cancel"
        id="user_btn_cancel"
        v-if="userCurrentStep < 4"
        text
        class="cancel no-ripple bmt2 bmr5"
        @click="showPopUp()"
        >{{ $t("cancelBtnText") }}</v-btn
      >
      <v-btn
        id="user_btn_roleAssignment"
        title="Next : Role Assignment"
        v-if="userCurrentStep == 1"
        class="primaryctabtn bmt2 bml2"
        type="submit"
        form="user_form"
        >{{ $t("roleAssignmentNextBtnText") }}</v-btn
      >
      <v-btn
        title="Next : Review"
        id="user_btn_preview"
        v-else-if="userCurrentStep == 2"
        :disabled="userReviewBtnStatus"
        class="primaryctabtn bmt2"
        type="submit"
        form="role_child_form"
        >{{ $t("previewNextBtnText") }}</v-btn
      >
      <v-btn
        title="Save User"
        id="user_btn_saveUser"
        v-else-if="userCurrentStep == 3"
        class="primaryctabtn bmt2"
        :disabled="buttonDisabled"
        @click="onSaveUser()"
        >{{ $t("saveUserBtnText") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyInnerView,
  BrierleyPrimaryStepper,
  BrierleyFormTitle,
  brierleyAlert
} from '@brierley/SharedComponents';
import PersonalInformation from './child/PersonalInformation';
import PreviewAndSave from './child/PreviewAndSave';
import CancelPopUp from './child/CancelPopUp';
import { mapState } from 'vuex';
import RoleAssignment from './child/RoleAssignment';
import { userLayoutObject } from '../../../i18n/language.js';
export default {
  components: {
    BrierleyInnerView,
    BrierleyPrimaryStepper,
    BrierleyFormTitle,
    PersonalInformation,
    PreviewAndSave,
    brierleyAlert,
    CancelPopUp,
    RoleAssignment
  },
  computed: {
    ...mapState('userModule', [
      'partialUser',
      'showPopUpDialogue',
      'userCurrentStep',
      'isAdmin',
      'roleAssignmentChildUser',
      'userRoleObject',
      'userReviewBtnStatus'
    ]),
    alertMessage () {
      if (this.$route.path.includes('/loyaltyadmin/user/edit')) {
        return this.$t('userSuccessMessage');
      } else {
        return (
          this.$t('emailSuccessText') +
          ' ' +
          `${this.partialUser.email.bold()}` +
          ' ' +
          this.$t('successText')
        );
      }
    }
  },
  data () {
    return {
      buttonDisabled: false,
      currentStep: 1,
      showDialogueBox: false,
      title: this.$t('newUserOnboardText')
    };
  },
  i18n: userLayoutObject,
  created () {
    this.$store.dispatch('userModule/setAdminStatusAction', false);
    this.$root.$refs.UserLayout = this;
    if (this.$route.name === 'UserLayoutEdit') {
      this.title = this.$t('editUserText');
      this.$store.dispatch('userModule/editUserAction', this.$route.query.res);
    } else if (this.$route.name === 'UserLayoutClone') {
      this.title = this.$t('newUserOnboardText');
      this.$store.dispatch('userModule/cloneUserAction', this.$route.query.res);
    } else {
      this.$store.commit('userModule/createUserMutations', {
        tenantId: '',
        email: '',
        passwordHash: '',
        status: true,
        isProfileComplete: true,
        roles: '',
        firstName: '',
        lastName: '',
        alternateEmail: '',
        phoneNumber: '',
        externalId: '',
        defaultApp: '',
        userPrograms: []
      });
    }
    this.$store.commit('userModule/roleAssignmentChildObjectMutation', {
      userPrograms: []
    });
    this.$store.dispatch('userModule/getAllProgramStatusAction');
    this.$store.dispatch('userModule/getAllRolesAssignmentAction');
  },
  mounted () {
    if (this.userCurrentStep !== 1) {
      this.$store.commit(
        'userModule/setUserCurrentStep',
        this.userCurrentStep = 1
      );
    }
  },
  methods: {
    async submit () {
      const isValid = await this.$refs.observerValid.validate();
      if (!isValid) {
        return;
      }
    },
    onsubmit () {
      if (
        this.$route.path.includes('/loyaltyadmin/user/create') ||
        this.$route.path.includes('/loyaltyadmin/user/clone')
      ) {
        this.$store
          .dispatch(
            'userModule/checkEmailExistingOrNotActions',
            this.partialUser.email
          )
          .then(res => {
            if (res.status === 204) {
              if (this.userCurrentStep === 1) {
                this.$store.commit(
                  'userModule/setUserCurrentStep',
                  this.userCurrentStep + 1
                );
              }
            } else if (res.status === 200) {
              this.$store.commit('userModule/userExistsOrNotMutations', true);
            }
          })
          .catch();
      } else {
        this.$store.commit(
          'userModule/setUserCurrentStep',
          this.userCurrentStep + 1
        );
      }
    },
    onSaveUser () {
      if (this.partialUser.userId) {
        this.partialUser.id = this.partialUser.userId;
      }
      if (this.isAdmin) {
        let roleDetailsObj = {};
        roleDetailsObj['roleId'] = this.partialUser.userPrograms[0].roleId;
        roleDetailsObj['roleName'] = this.partialUser.userPrograms[0].roleName;
        this.partialUser.userPrograms[0] = {};
        this.partialUser.userPrograms[0]['userRoleDetails'] = [];
        this.partialUser.userPrograms[0].userRoleDetails.push(roleDetailsObj);
        this.partialUser.tenantId = 'brierley';
        this.partialUser.status = true;
        this.partialUser.alternateEmail = this.partialUser.email;
        this.partialUser.passwordHash = 'Kona_2019';
        this.partialUser.isProfileComplete = true;
        this.partialUser.roles = '';
        this.$store
          .dispatch('userModule/createUserActions', this.partialUser)
          .then(res => {
            if (res.status === 201 || res.status === 200) {
              this.$store.commit(
                'userModule/setUserCurrentStep',
                this.userCurrentStep + 1
              );
            }
          })
          .catch();
      } else {
        if (this.userRoleObject.userPrograms !== undefined) {
          this.partialUser.userPrograms = this.userRoleObject.userPrograms;
          this.partialUser.tenantId = 'brierley';
          this.partialUser.status = true;
          this.partialUser.alternateEmail = this.partialUser.email;
          this.partialUser.passwordHash = 'Kona_2019';
          this.partialUser.isProfileComplete = true;
          this.partialUser.roles = '';
          this.$store
            .dispatch('userModule/createUserActions', this.partialUser)
            .then(res => {
              if (res.status === 201 || res.status === 200) {
                this.$store.commit(
                  'userModule/setUserCurrentStep',
                  this.userCurrentStep + 1
                );
              }
            })
            .catch();
        }
      }
    },
    onRoleSubmit () {
      this.$store.commit(
        'userModule/setUserCurrentStep',
        this.userCurrentStep + 1
      );
    },
    showPopUp () {
      if (this.userCurrentStep === 1) {
        if (
          this.partialUser.email === '' &&
          this.partialUser.firstName === '' &&
          this.partialUser.lastName === '' &&
          this.partialUser.phoneNumber === ''
        ) {
          this.$router.push({ name: 'viewuser' });
        } else {
          this.$store.commit('userModule/showPopUpDialogueMutation', true);
        }
      } else if (this.userCurrentStep === 2) {
        if (
          this.partialUser.email === '' &&
          this.partialUser.firstName === '' &&
          this.partialUser.lastName === '' &&
          this.partialUser.phoneNumber === ''
        ) {
          this.$router.push({ name: 'viewuser' });
        } else {
          this.$store.commit('userModule/showPopUpDialogueMutation', true);
        }
      } else if (this.userCurrentStep === 3) {
        if (
          this.userRoleObject.email === '' &&
          this.userRoleObject.firstName === '' &&
          this.userRoleObject.lastName === '' &&
          this.userRoleObject.phoneNumber === ''
        ) {
          this.$router.push({ name: 'viewuser' });
        } else {
          this.$store.commit('userModule/showPopUpDialogueMutation', true);
        }
      }
    },
    onPreviewClick () {
      this.$store.commit(
        'userModule/setUserCurrentStep',
        this.userCurrentStep - 2
      );
    },
    onPreviousClick () {
      this.$store.commit(
        'userModule/setUserCurrentStep',
        this.userCurrentStep - 1
      );
      this.$store.commit('userModule/showPopUpDialogueMutation', false);
    },
    onClickUserLayout () {
      this.onsubmit();
    },
    onClickYes () {
      this.$store.commit('userModule/setUserCurrentStep', 2);
      this.$store.commit('userModule/showPopUpDialogueMutation', false);
    },
    gotoUsersClick () {
      this.$store.commit('userModule/createUserMutations', {
        tenantId: '',
        email: '',
        passwordHash: '',
        status: true,
        isProfileComplete: true,
        roles: '',
        firstName: '',
        lastName: '',
        alternateEmail: '',
        phoneNumber: '',
        externalId: '',
        defaultApp: ''
      });
      this.$router.push({ name: 'viewuser' });
    }
  }
};
</script>
