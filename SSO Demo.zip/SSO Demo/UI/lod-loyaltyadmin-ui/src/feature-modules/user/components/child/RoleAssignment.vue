<template>
  <v-row no-gutters>
    <v-col>
      <v-row v-if="isAdmin" class="bmt5" no-gutters>
        <v-col>
          <brierley-alert
            alertType="info"
            :alertBody="$t('alertBody')"
            :alertHeader="$t('alertHeader')"
            icon
            :isSiteLevel="true"
          ></brierley-alert>
        </v-col>
      </v-row>
      <v-row no-gutters class="bmt5 flex-column">
        <v-col>
          <p class="label-text">{{ $t("headerText") }}</p>
          <v-radio-group row v-model="roleAdminActive" class="radiolight">
            <v-radio
              id="user_adminAssign_yes"
              :label="$t('yesLabelText')"
              :value="true"
              @change="isAdminRole(true)"
            ></v-radio>
            <v-radio
              id="user_adminAssign_no"
              :label="$t('noLabelText')"
              :value="false"
              @change="isAdminRole(false)"
            ></v-radio>
          </v-radio-group>
        </v-col>
        <v-col v-if="isAdmin">
          <role-administrator></role-administrator>
        </v-col>
        <v-col v-if="!isAdmin">
          <role-assignment-child></role-assignment-child>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>

<script>
import { mapState } from 'vuex';
import { brierleyAlert } from '@brierley/SharedComponents';
import RoleAssignmentChild from './RoleAssignmentChild.vue';
import RoleAdministrator from './RoleAdministrator.vue';
import { roleAssignmentObject } from './../../../../i18n/language.js';
export default {
  components: {
    brierleyAlert,
    RoleAssignmentChild,
    RoleAdministrator
  },
  methods: {
    isAdminRole (value) {
      this.$store.dispatch('userModule/setAdminStatusAction', value);
    }
  },
  computed: {
    ...mapState('userModule', ['isAdmin'])
  },
  i18n: roleAssignmentObject,
  mounted () {
    this.roleAdminActive = this.isAdmin;
  },
  data () {
    return {
      roleAdminActive: false
    };
  }
};
</script>
