<template>
  <v-row no-gutters class="d-flex ">
    <v-col class="gen2-forms form-light-bg" xs="12" sm="6" md="7">
      <p class="fbold text-uppercase bmt3">{{ $t("message.username") }}</p>
      <v-col sm="8" xs="12" class="bpa0">
        <v-text-field
          autocomplete="off"
          :label="$t('message.nameLabel')"
          :disabled="true"
          filled
          required
          v-model="user.username"
        >
        </v-text-field>
      </v-col>

      <p class="fbold text-uppercase">{{ $t("message.userDetails") }}</p>
      <v-col sm="8" xs="12" class="bpa0">
        <v-text-field
          autocomplete="off"
          :label="$t('message.firstnameLabel')"
          filled
          required
          v-model="user.firstname"
          :rules="nameRules"
          @keyup="updateFirstName"
        >
        </v-text-field>
      </v-col>
      <v-col sm="8" xs="12" class="bpa0">
        <v-text-field
          autocomplete="off"
          :label="$t('message.lastnameLabel')"
          filled
          required
          v-model="user.lastname"
          :rules="lastnameRules"
          @keyup="updateLastName"
        >
        </v-text-field>
      </v-col>
      <v-col sm="4" xs="6" class="bpa0">
        <v-text-field
          autocomplete="off"
          :label="$t('message.phonenumberLabel')"
          filled
          v-model="user.phonenumber"
          :rules="phoneRules"
          @keyup="updatePhone"
        >
        </v-text-field>
      </v-col>

      <p class="fbold text-uppercase">{{ $t("message.externalId") }}</p>
      <v-col sm="4" xs="6" class="bpa0">
        <v-text-field
          autocomplete="off"
          :label="$t('message.externalIdLabel')"
          v-model="user.externalId"
          :disabled="true"
          :readonly="true"
          filled
        >
        </v-text-field>
      </v-col>
      <br />
      <v-col sm="12" xs="12" class="bmb3">
        <v-divider class="dashed"></v-divider>
      </v-col>
      <p class="fbold text-uppercase bmt3">{{ $t("message.picture") }}</p>
      <v-col sm="8" xs="12" class="bmb3">
        <brierley-media-upload></brierley-media-upload>
      </v-col>
      <v-col sm="12" xs="12" class="bmb3">
        <v-divider class="dashed"></v-divider>
      </v-col>

      <p class="fbold text-uppercase bmt3">{{ $t("message.password") }}</p>
      <v-col sm="4" xs="6" class="bpa0">
        <v-text-field
          autocomplete="off"
          :label="$t('message.passwordLabel')"
          :disabled="true"
          :readonly="true"
          type="password"
          filled
          v-model="user.password"
        >
        </v-text-field>
      </v-col>
      <p class="btn-link">
        {{ $t("message.passwordNote") }}
        <span @click="clickHere">{{ $t("message.clickHere") }}</span>
      </p>
    </v-col>
    <v-col class="bpt4 bpl4" xs="12" sm="6" md="5">
      <brierley-info-side>
        <template v-slot:info-side-header>
          <div class="info_title">
            <v-icon>info</v-icon>{{ $t("message.info") }}
          </div>
        </template>
        <template v-slot:info-side-body>
          <div class="bpl4">
            {{ $t("message.infoBody") }}
          </div>
        </template>
      </brierley-info-side>
    </v-col>
    <brierley-dialogbox
      :dialog="passwordDialog"
      @closeMe="passwordDialog = $event"
      customDialog = "custom-dialog-password"
      cardStyle = "gen2-dialogbox-password"
      cardStyleContent = "gen2-dialogbox-password__content"
    >
      <template v-slot:dialog-header>
        <v-card-title class="gen2-dialog-title-password text-uppercase">{{
          $t("message.changeDialogTitle")
        }}</v-card-title>
      </template>
      <template v-slot:dialog-body-alert>
        <v-row no-gutters class="d-flex ">
          <v-col class="gen2-forms form-light-bg" xs="12" sm="6" md="6">
            <p class="fbold text-uppercase bmt3">
              {{ $t("message.passwordLabel") }}
            </p>
            <v-col sm="10" xs="12" class="bpa0">
              <v-form ref="resetPasswordForm">
                <p v-html="printLabel"></p>
                <v-text-field
                  autocomplete="off"
                  type="password"
                  :label="$t('message.oldPassword')"
                  filled
                  required
                  :rules="requiredRule"
                  v-model="oldPassword"
                >
                </v-text-field>
                <v-text-field
                  autocomplete="off"
                  type="password"
                  :label="$t('message.newPassword')"
                  filled
                  required
                  :rules="newPasswordRules"
                  v-model="newPassword"
                  @input="passwordField()"
                >
                </v-text-field>
              <v-layout class="custom-error-msg" v-if="breachedPasswordOrNot"
              >There is a problem with this password. Please contact your Administrator
              </v-layout>
                <v-text-field
                  autocomplete="off"
                  type="password"
                  :label="$t('message.confirmPassword')"
                  filled
                  required
                  ref="confirmPassword"
                  :rules="confirmPasswordRules"
                  name = "confirmPassword"
                  v-model="confirmPassword"
                >
                </v-text-field>
              </v-form>
            </v-col>
          </v-col>
          <v-col class="bpt4" xs="12" sm="6" md="6">
            <brierley-info-side infoStyle="gen2-infobox-password">
              <template v-slot:info-side-header>
                <div class="info_title">
                  <v-icon>info</v-icon>{{ $t("message.info") }}
                </div>
              </template>
              <template v-slot:info-side-body>
                <div class="bpl5" >
                  <p>{{ $t("message.lineOne") }}</p>
                  <p v-html="printInfo"></p>
                </div>
              </template>
            </brierley-info-side>
          </v-col>
        </v-row>
      </template>
      <template v-slot:dialog-footer>
        <v-row no-gutters>
          <v-col xs="12" sm="12" md="12" class="d-flex justify-end align-center">
            <span v-show="loading" class="text-uppercase update-password-processing bmb1">{{$t("message.processing")}}</span>
          </v-col>
          <v-col xs="12" sm="12" md="12" class="d-flex justify-end align-center">
            <v-btn text class="cancel no-ripple" @click="displayCancel = true">
              {{$t("message.cancel")}}</v-btn>
            <v-btn class="primaryctabtn-password" title="Default" @click="changePassword" :loading="loading">
              {{$t("message.save")}}
            </v-btn>
          </v-col>
        </v-row>
      </template>
    </brierley-dialogbox>

    <brierley-dialogbox :dialog="displayError" @closeMe="displayError = $event">
      <template v-slot:dialog-header>
        <v-card-title class="gen2-dialog-title text-uppercase">{{
          $t("message.errorTitle")
        }}</v-card-title>
      </template>
      <template v-slot:dialog-body-alert>
        <brierley-alert
          alertType="error"
          :alertBody="errorMsg"
          icon="notifications_active"
        ></brierley-alert>
      </template>
      <template v-slot:dialog-footer>
        <v-btn
          class="primaryctabtn"
          title="Default"
          @click="displayError = false"
          >{{ $t("message.ok") }}</v-btn
        >
      </template>
    </brierley-dialogbox>
    <brierley-dialogbox
      :dialog="displayCancel"
      @closeMe="displayCancel = $event"
    >
      <template v-slot:dialog-header>
        <v-card-title class="gen2-dialog-title text-uppercase">{{
          $t("message.cancelTitle")
        }}</v-card-title>
      </template>
      <template v-slot:dialog-body-alert>
        <brierley-alert
          alertType="warning"
          :alertBody="$t('message.cancelMessage')"
          icon="notifications_active"
        ></brierley-alert>
      </template>
      <template v-slot:dialog-footer>
        <v-btn text class="cancel no-ripple" @click="closeAll">{{
          $t("message.no")
        }}</v-btn>
        <v-btn class="primaryctabtn" title="Default" @click="changePassword">{{
          $t("message.yes")
        }}</v-btn>
      </template>
    </brierley-dialogbox>
  </v-row>
</template>
<script>
import {
  brierleyAlert,
  BrierleyDialogbox,
  BrierleyInfoSide,
  BrierleyMediaUpload
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
export default {
  components: {
    brierleyAlert,
    BrierleyDialogbox,
    BrierleyMediaUpload,
    BrierleyInfoSide
  },
  props: {
    user: Object
  },
  data () {
    return {
      oldPassword: '',
      newPassword: '',
      confirmPassword: '',
      printInfo: this.$t('message.passwordFormat'),
      printLabel: this.$t('message.line'),
      displayError: false,
      passwordDialog: false,
      errorMsg: '',
      displayCancel: false,
      nameRules: [v => !!v || this.$t('message.nameIsRequired')],
      lastnameRules: [v => !!v || this.$t('message.lastIsRequired')],
      passwordRules: [
        v =>  /[A-Z]/.test(v) && /[a-z]/.test(v) && /[0-9]/.test(v) && /[~`!@#$%^&*()+=_\-{}[\]\\|:;'"?/<>,.]/.test(v) && v.length >= 8 || v.length === 0  || this.$t('message.errorMsgInvalidPassword'),
      ],
      requiredRule: [
        v => !!v.trim() || this.$t('message.errorFieldRequired')
      ],
      phoneRules: [
        v => /^[0-9]{0,}$/.test(v) || this.$t('message.phoneNumberError'),
        v =>
          !(v.length !== 0 && v.length !== 10) ||
          this.$t('message.phoneNumberLengthError')
      ],
      loading: false
    };
  },
  computed: {
    confirmPasswordRules () {
      const rules = [];
      let	errorMsg = this.$t('message.errorMsgConfirmPassword');
      const ruleConfirmPwd = v => v === this.newPassword  || errorMsg;
      rules.push(ruleConfirmPwd);
      return rules.concat(this.requiredRule);
    },
    newPasswordRules () {
      return this.passwordRules.concat(this.requiredRule);
    },
    ...mapState('userModule', ['breachedPasswordOrNot']),
  },
  watch: {
    'newPassword' () {
      this.$refs.confirmPassword.validate();
    }
  },
  methods: {
    passwordField () {
      this.$store.commit('userModule/breachedPasswordOrNotMutation', false);
    },
    clickHere () {
      this.passwordDialog = true;
      this.oldPassword = '';
      this.newPassword = '';
      this.confirmPassword = '';
    },
    updateFirstName () {
      this.$emit('update:user.firstname', this.user.firstname);
    },
    updateLastName () {
      this.$emit('update:user.lastname', this.user.lastname);
    },
    updatePhone () {
      this.$emit('update:user.phonenumber', this.user.phonenumber);
    },
    validateData () {
      if (this.oldPassword.length < 8) return false;
      if (this.newPassword.length < 8 || this.confirmPassword.length < 8)
        return false;
      if (this.newPassword !== this.confirmPassword) return false;
      let expMay = /[A-Z]/.test(this.newPassword) ? 1 : 0;
      let expMin = /[a-z]/.test(this.newPassword) ? 1 : 0;
      let expDig = /[0-9]/.test(this.newPassword) ? 1 : 0;
      let expSpecial = /[~`!@#$%^&*()+=_\-{}[\]\\|:;'"?/<>,.]/.test(this.newPassword) ? 1 : 0;
      if (expMay + expMin + expDig + expSpecial < 4) return false;
      return true;
    },
    closeAll () {
      this.oldPassword = '';
      this.newPassword = '';
      this.confirmPassword = '';
      this.displayCancel = false;
      this.passwordDialog = false;
      this.displayError = false;
    },
    async changePassword () {
      let s = this;
      s.displayCancel = false;
      if (!s.loading && s.$refs.resetPasswordForm.validate()) {
        if (s.validateData()) {
          s.loading = true;
          try {
            let userObj = {
              UserId: s.user.Id,
              PasswordHash: btoa(s.newPassword),
              CurrentPassword: btoa(s.oldPassword),
              Status: true
            };

            let res = await s.$store.dispatch('userModule/putUser', userObj);
            if (res.status === 200) {
              s.passwordDialog = false;
              s.displayError = false;
              s.$root.GlobalStoreEventStore.dispatch('logOut', s.$router);
            }
          } catch (err) {
            s.displayError = true;
            if (err.response === undefined) {
              s.errorMsg = s.$t('message.errorMessage');
            } else if (err.response.status === 422) {
              s.errorMsg = s.$t('message.errorMsg422');
            } else if (err.response.status === 403) {
              s.errorMsg = s.$t('message.errorMsg403');
            } else if (err.response.status === 400) {
              this.$store.commit('userModule/breachedPasswordOrNotMutation', true);
              s.displayError = false;
            }
          } finally {
            s.loading = false;
          }
        } else {
          if (s.oldPassword.length < 8 && s.oldPassword.length !== 0) s.errorMsg = s.$t('message.errorMsg403');
          else s.errorMsg = s.$t('message.errorMessage');
          s.displayError = true;
        }
      }
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          username: 'Email Address',
          nameLabel: 'Email',
          userDetails: 'User Details',
          firstnameLabel: 'First Name',
          lastnameLabel: 'Last Name',
          phonenumberLabel: 'Phone Number',
          externalId: 'External ID',
          externalIdLabel: 'External ID',
          password: 'Change Password',
          passwordLabel: 'Password',
          picture: 'Profile Picture',
          passwordNote: 'If you want to change your password ',
          clickHere: 'Click Here',
          info: 'Info',
          infoBody:
            'To change any of your user details, enter your new information in the appropriate fields.',
          nameIsRequired: 'Enter First Name',
          lastIsRequired: 'Enter Last Name',
          phoneNumberLengthError: 'Phone number must be 10 digits long',
          phoneNumberError: 'Only numeric characters are allowed',
          changeDialogTitle: 'Change Password',
          cancel: 'Cancel',
          save: 'Save',
          oldPassword: 'Old Password *',
          newPassword: 'New Password *',
          confirmPassword: 'Confirm Password *',
          line:
            'A password is required to log in into Loyalty Services. Use the form below to set up one.',
          lineOne:
            'In order to protect your account, please make sure your password:',
          passwordFormat:
            '<p class="bpt1"> <ol style="padding-left: 0px; margin-left: 1.2em;"> <li class="bpb1">Be a minimum of eight (8) characters in length</li> <li>Contain at least one (1) character all of the following categories: </br> <ul> <li> Uppercase letter (A-Z) </li> <li> Lowercase letter (a-z) </li> <li> Digit (0-9) </li> <li> Special character </br> (~`!@#$%^&*()+=_-{}[]\\|:;\'"?/<>,.) </li> </ul></li> </ol>  </p>',
          ok: 'ok',
          errorTitle: 'Error while saving',
          errorMessage: 'An error occurred and unable to perform the password change. Please try again.',
          errorMsg422: 'Your new password should not match any of your previous 3 passwords.',
          errorMsg403: 'Incorrect old password.',
          no: 'No',
          yes: 'Yes',
          cancelTitle: 'Save Password?',
          cancelMessage: 'Would you like to save your password?',
          errorMsgInvalidPassword: 'The new password you picked does not meet the password guidelines. Please try creating another password.',
          errorMsgConfirmPassword: 'The New Password and Confirm Password don’t match.',
          errorFieldRequired: 'This field is required.',
          processing: 'Processing'
        }
      },
      ja: {
        message: {
          username: 'ユーザ名（メールアドレス）',
          nameLabel: 'メールアドレス',
          userDetails: 'ユーザ詳細',
          firstnameLabel: '名前（名）',
          lastnameLabel: '名前（姓）',
          phonenumberLabel: '電話番号',
          externalId: '外部ID',
          externalIdLabel: '外部ID',
          password: 'パスワード変更',
          passwordLabel: 'パスワード',
          picture: 'プロフィールピクチャー',
          passwordNote:
            'パスワードを変更する場合は、',
          clickHere: 'ここをクリックしてください',
          info: 'インフォメーション',
          infoBody:
            '各フィールドの値を変更することで、ユーザ詳細の更新が行えます。',
          nameIsRequired: '「名前（名）」を入力してください',
          lastIsRequired: '「名前（姓）」を入力してください',
          phoneNumberLengthError:
            '「電話番号」には10桁の値を設定してください。',
          phoneNumberError:
            '「電話番号」には数値のみ入力可能です',
          changeDialogTitle: 'パスワード変更',
          cancel: 'キャンセル',
          save: '保存する',
          oldPassword: '現在のパスワード *',
          newPassword: '新パスワード *',
          confirmPassword: '新パスワード(確認) *',
          line:
            'LODにログインするためには、パスワードの設定が必要です。',
          lineOne:
            'お客様のアカウントを保護するため、以下の条件を満たしたパスワードを設定してください。',
          passwordFormat:
            '<p> <ol> <li>8文字以上であること</li> <li>以下のすべての文字種をそれぞれ最低1文字以上含むこと: </br> <ul> <li> アルファベット大文字 (A-Z) </li> <li> アルファベット小文字 (a-z) </li> <li> 数字 (0-9) </li> <li> 特殊文字 </br> (~`!@#$%^&*()+=_-{}[]\\|:;\'"?/<>,.) </li> </ul></li> </ol>  </p>',
          ok: 'OK',
          errorTitle: 'エラー',
          errorMessage:
            'エラーが発生したためパスワードの変更に失敗しました。もう一度お試しください。',
          errorMsg422: '過去3回のパスワードに利用した文字列が含まれています。別のパスワードを設定してください。',
          errorMsg403: '「現在のパスワード」が登録されている内容と一致しません',
          no: 'いいえ',
          yes: 'はい',
          cancelTitle: 'パスワードを変更しますか？',
          cancelMessage:
            'パスワードを変更しますか？',
          errorMsgInvalidPassword: '「新パスワード」の設定値が条件を満たしていません。設定しなおしてください。',
          errorMsgConfirmPassword: '「新パスワード」と「新パスワード(確認)」の設定値が一致しません。もう一度ご確認ください。',
          errorFieldRequired: 'この項目は必須項目です',
          processing: '処理中'
        }
      }
    }
  }
};
</script>
