<template>
  <v-row class="gray-bg flex-column bpa3 mb-1" no-gutters>
    <v-col class="label-text">{{ $t("headerText") }}</v-col>
    <v-col v-for="(items, i) in partialUser.userPrograms" :key="i">
      <v-row class="gray-bg flex-column" no-gutters>
        <v-col>
          <v-expansion-panels class="user-role-assignment-expansions">
            <v-expansion-panel>
              <v-expansion-panel-header>
                <!-- <div class="checkbox-block d-flex">
                  <v-checkbox class="checkbox-custom"></v-checkbox>
                </div> -->
                <div class="checkbox-custom">
                  <v-icon>mdi-check-circle</v-icon>
                </div>
                {{ items.roleName }}
              </v-expansion-panel-header>
              <v-expansion-panel-content
                v-for="serviceItem in items.serviceDetails"
                :key="serviceItem.serviceId"
                :disabled="isServiceDisabled(serviceItem.serviceName)"
              >
                <v-row class="flex-column" no-gutters>
                  <v-col class="label-text">{{
                    serviceItem.serviceName
                  }}</v-col>
                  <v-col>
                    <v-row
                      class="flex-column custom-role-assignment-table"
                      no-gutters
                    >
                      <v-col>
                        <v-row
                          class="custom-role-assignment-table__head"
                          no-gutters
                        >
                          <v-col></v-col>
                          <v-col
                            v-for="m in filteredMethods"
                            :key="m.methodId"
                            >{{ m.name }}</v-col
                          >
                        </v-row>
                      </v-col>
                      <v-col
                        v-for="serviceItemChild in serviceItem.serviceDetails"
                        :key="serviceItemChild.serviceId"
                      >
                        <v-row
                          no-gutters
                          v-if="serviceItemChild.serviceDetails.length == 0"
                        >
                          <v-col>{{ serviceItemChild.serviceName }}</v-col>
                          <v-col
                            v-for="method in filteredMethods"
                            :key="method.methodId"
                          >
                            <!-- <v-icon
                              :color="hasPermission(serviceItemChild.serviceId, method.methodId) ? 'green' : 'grey'"
                            >mdi-check-circle-outline</v-icon> -->
                            <v-icon
                              v-if="
                                hasPermission(
                                  serviceItemChild.serviceId,
                                  method.methodId
                                )
                              "
                              >check_circle</v-icon
                            >
                            <v-icon class="uncheck" v-else
                              >remove_circle</v-icon
                            >
                          </v-col>
                        </v-row>

                        <v-row
                          no-gutters
                          v-if="serviceItemChild.serviceDetails.length > 0"
                        >
                          <v-col
                            class="having-child"
                            v-if="serviceItemChild.serviceDetails.length > 0"
                          >
                            <!-- closed -->
                            <v-row class="flex-column child-rows" no-gutters>
                              <v-col class="child-rows__head">
                                <v-row no-gutters>
                                  <v-col>
                                    {{ serviceItemChild.serviceName }}
                                    <v-icon class="float-right"
                                      >keyboard_arrow_down</v-icon
                                    >
                                  </v-col>
                                  <v-col></v-col>
                                  <v-col></v-col>
                                  <v-col></v-col>
                                  <v-col></v-col>
                                </v-row>
                              </v-col>
                              <v-col
                                class="child-rows__content"
                                v-for="serviceItemNestedChild in serviceItemChild.serviceDetails"
                                :key="serviceItemNestedChild.serviceId"
                              >
                                <v-row no-gutters>
                                  <v-col>{{
                                    serviceItemNestedChild.serviceName
                                  }}</v-col>
                                  <v-col
                                    v-for="method in filteredMethods"
                                    :key="method.methodId"
                                    class="text-center"
                                  >
                                    <v-icon
                                      v-if="
                                        hasPermission(
                                          serviceItemNestedChild.serviceId,
                                          method.methodId
                                        )
                                      "
                                      >check_circle</v-icon
                                    >
                                    <v-icon class="uncheck" v-else
                                      >remove_circle</v-icon
                                    >
                                  </v-col>
                                </v-row>
                              </v-col>
                            </v-row>
                          </v-col>
                        </v-row>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </v-expansion-panel-content>
            </v-expansion-panel>
          </v-expansion-panels>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import { mapState } from 'vuex';
import { roleAdminstratorObject } from './../../../../i18n/language.js';
export default {
  data () {
    return {
      checkbox: true,
      methods: [
        {
          methodId: 1,
          name: this.$t('viewText'),
          description: 'View Permission'
        },
        {
          methodId: 2,
          name: this.$t('createText'),
          description: 'Create Permission'
        },
        {
          methodId: 3,
          name: this.$t('editText'),
          description: 'Edit Permission'
        },
        {
          methodId: 4,
          name: this.$t('deleteText'),
          description: 'Delete Permission'
        },
        {
          methodId: 5,
          name: 'Activate',
          description: 'Activate Permission'
        },
        {
          methodId: 6,
          name: 'Deactivate',
          description: 'Deactivate Permission'
        },
        {
          methodId: 7,
          name: 'TBD',
          description: 'TBD Permission'
        }
      ],
      role: {
        roleName: 'Administrator',
        description: 'Description',
        permissions: []
      },
      disabledServices: ['b-Empowered', 'b-Informed', 'Analytics'],
      hiddenMethods: ['Activate', 'Deactivate', 'TBD']
    };
  },
  i18n: roleAdminstratorObject,
  methods: {
    getData () {
      this.partialUser.userPrograms = this.allRolesStatus.filter(
        item => item.roleName === 'Loyalty Administrator'
      );
      let serviceDetailsArray = [];
      for (
        let i = 0;
        i < this.partialUser.userPrograms[0].serviceDetails.length;
        i++
      ) {
        if (
          this.partialUser.userPrograms[0].serviceDetails[i].serviceDetails
            .length > 0
        ) {
          serviceDetailsArray.push(
            this.partialUser.userPrograms[0].serviceDetails[i]
          );
        }
      }
      this.partialUser.userPrograms[0].serviceDetails = serviceDetailsArray;
      return this.partialUser.userPrograms;
    },
    getIconColor (isDisabled, hasAnyPermission) {
      if (isDisabled) return 'grey';
      if (hasAnyPermission) return 'green';
      else return 'black';
    },
    hasAnyPermission (service) {
      let self = this;
      let permission = self.role.permissions.find(
        p => p.serviceId === service.serviceId
      );

      if (permission && permission.methodsId.length > 0) {
        return true;
      } else {
        if (service.serviceDetails.length > 0) {
          for (let i = 0; i < service.serviceDetails.length; i++) {
            if (self.hasAnyPermission(service.serviceDetails[i])) {
              return true;
            }
          }
        }
      }
      return false;
    },
    hasPermission (serviceId, methodId) {
      let self = this;

      let permission = self.role.permissions.find(
        p => p.serviceId === serviceId
      );

      if (permission) {
        let method = permission.methodsId.find(m => m === methodId);
        if (method) {
          return true;
        }
      }
      return false;
    },
    isServiceDisabled (name) {
      return this.disabledServices.indexOf(name) > -1;
    }
  },
  computed: {
    filteredMethods () {
      let self = this;
      return self.methods.filter(function (method) {
        return self.hiddenMethods.indexOf(method.name) < 0;
      });
    },
    ...mapState('userModule', {
      allRolesStatus: state => {
        return state.allRolesStatusList;
      }
    }),
    ...mapState('userModule', {
      partialUser: state => {
        return state.partialUser;
      }
    })
  },
  mounted () {
    let filteredArr = [];
    let permissionsArray = [];
    this.partialUser.userPrograms = this.getData();

    for (
      let i = 0;
      i < this.partialUser.userPrograms[0].serviceDetails.length;
      i++
    ) {
      if (
        this.partialUser.userPrograms[0].serviceDetails[i].serviceDetails.length
      ) {
        for (
          let j = 0;
          j <
          this.partialUser.userPrograms[0].serviceDetails[i].serviceDetails
            .length;
          j++
        ) {
          if (
            this.partialUser.userPrograms[0].serviceDetails[i].serviceDetails[j]
              .serviceDetails.length > 0
          ) {
            for (
              let f = 0;
              f <
              this.partialUser.userPrograms[0].serviceDetails[i].serviceDetails[
                j
              ].serviceDetails.length;
              f++
            ) {
              permissionsArray = this.partialUser.userPrograms[0].serviceDetails[
                i
              ].serviceDetails[j].serviceDetails[f].methodDetails.map(
                userItem => {
                  return userItem.methodId;
                }
              );
              let permissionsObj = {};
              permissionsObj[
                'serviceId'
              ] = this.partialUser.userPrograms[0].serviceDetails[
                i
              ].serviceDetails[j].serviceDetails[f].serviceId;
              permissionsObj['methodsId'] = permissionsArray;
              filteredArr.push(permissionsObj);
              this.role.permissions = filteredArr;
            }
          } else {
            permissionsArray = this.partialUser.userPrograms[0].serviceDetails[
              i
            ].serviceDetails[j].methodDetails.map(userItem => {
              return userItem.methodId;
            });
            let permissionsObj = {};
            permissionsObj[
              'serviceId'
            ] = this.partialUser.userPrograms[0].serviceDetails[
              i
            ].serviceDetails[j].serviceId;
            permissionsObj['methodsId'] = permissionsArray;
            filteredArr.push(permissionsObj);
          }
          this.role.permissions = filteredArr;
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.child-service {
  color: #0628b1;
  margin-left: 15px;
  padding-top: 5px;
  padding-bottom: 18px;
}
.get-access {
  margin-left: 10px;
  margin-top: 3px;
}
.v-expansion-panel {
  background: white !important;
}
.assign {
  color: #0e1e61;
}
.checkbox-custo {
  flex: inherit !important;
}
.role-assignment-expansions {
  border-radius: 0;
  .v-expansion-panel {
    margin-bottom: 24px;
    border-radius: 0 !important;
    &::before {
      box-shadow: none;
    }
    &::after {
      border-color: transparent !important;
    }
    &:last-child {
      margin-bottom: 0px;
    }
    .v-expansion-panel-header {
      font-weight: 600;
      padding: 19px 24px !important;
      min-height: 80px;
      .checkbox-custom {
        max-width: 24px;
        margin-right: 16px !important;
        padding: 0;
        .v-input__slot {
          margin: 0 !important;
        }
      }
    }
    .v-expansion-panel-content {
      &__wrap {
        padding: 0 24px 40px;
        .role-assignment-table {
          &__head {
            min-height: 70px;
            > .col {
              font-weight: bold;
            }
          }
          > .col {
            min-height: 65px;
            overflow: hidden;
            > .row {
              > .col {
                font-weight: bold;
                letter-spacing: -0.2px;
                text-align: center;
                max-height: 65px;
                max-width: 19%;
                padding: 20px 0;
                .v-icon {
                  color: inherit;
                  cursor: pointer;
                }
                &:first-child {
                  padding-left: 24px;
                  text-align: left;
                  border: none;
                  line-height: 26px;
                  text-transform: uppercase;
                  max-width: 24%;
                }
                .v-btn:hover:before {
                  background-color: transparent;
                }
              }
            }
          }
          .having-child {
            > .row {
              > .child-rows {
                max-width: none !important;
                max-height: none;
                padding: 0 !important;
                border: none !important;
                > .row {
                  display: none;
                  > .col {
                    &:first-child {
                      .col {
                        border-top: 0 !important;
                      }
                    }
                    &:last-child {
                      .col {
                        border-bottom: 0 !important;
                      }
                    }
                    > .row {
                      > .col {
                        min-height: 65px;
                        padding-top: 16px;
                        &:first-child {
                          text-align: left;
                          padding-left: 40px;
                          padding-top: 24px;
                          font-weight: bold;
                          border: none;
                          max-width: 20%;
                          line-height: 26px;
                          text-transform: uppercase;
                        }
                      }
                    }
                  }
                }
              }
              > .col {
                max-height: 65px !important;
                border-bottom: 0 !important;
              }
            }
            p {
              font-weight: bold;
              padding-right: 16px;
            }
            .v-icon {
              display: none;
            }
            .float-right {
              display: block;
            }
          }
          .having-child.open {
            min-height: fit-content !important;
            p {
              .v-icon {
                transform: rotate(180deg);
              }
            }
            > .row {
              > .child-rows.col-sm-12 {
                max-height: none !important;
                > .row {
                  display: block;
                }
              }
              > .col {
                .v-icon {
                  display: block;
                  padding-top: 8px;
                }
                .v-btn:hover:before {
                  background-color: transparent;
                }
                .float-right {
                  padding-top: 0;
                }
              }
            }
          }
        }
      }
    }
  }
  .v-expansion-panel--active {
    .v-expansion-panel-header {
      margin-bottom: 10px;
    }
  }
}
.having-child {
  max-width: 100% !important;
  padding: 0 !important;
  min-width: 100% !important;
}
</style>
