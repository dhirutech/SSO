<template>
  <v-row class="loyalty-users-common" no-gutters v-if="userFilteredObj">
    <v-col sm="12" col="12">
      <brierley-summary-info-box class="bpr0">
        <template v-slot:summary-block>
          <v-col class="sub-section" sm="12">
            <v-row no-gutters class="sub-section_title">
              <v-col xs="12" sm="9" md="9">
                <!-- Sub Header Start-->
                <p class="fbold text-left text-uppercase">
                  {{ $t('headerText') }}
                </p>
                <!-- Sub Header End-->
              </v-col>
              <v-col xs="12" sm="3" md="3" class="hoverEdit">
                <!-- Edit Button Start -->
                <p
                  class="primary-text fbold text-right text-uppercase"
                  @click="editPersonalInfo()"
                >
                  <v-icon class="bpr1" color="#000">create</v-icon
                  >{{ $t('editText') }}
                </p>
                <!-- Edit Button End-->
              </v-col>
            </v-row>
            <hr />
            <!-- Summary Start -->
            <v-col class="mt-2 pl-0">
              <p>
                <strong>{{ $t('emailLabel') }}</strong>
                <span class="pl-1">{{ userFilteredObj.email }}</span>
              </p>
              <p>
                <strong>{{ $t('firstNameLabel') }}</strong>
                <span class="pl-1">{{ userFilteredObj.firstName }}</span>
              </p>
              <p>
                <strong>{{ $t('lastNameLabel') }}</strong>
                <span class="pl-1">{{ userFilteredObj.lastName }}</span>
              </p>
              <p>
                <strong>{{ $t('phoneNumberLabel') }}</strong>
                <span class="pl-1">{{ userFilteredObj.phoneNumber }}</span>
              </p>
              <p>
                <strong>{{ $t('externalIdLabel') }}</strong>
                <span class="pl-1">{{ userFilteredObj.externalId }}</span>
              </p>
              <!-- Summary End -->
            </v-col>
          </v-col>
        </template>
      </brierley-summary-info-box>
    </v-col>

    <v-col sm="12" col="12">
      <brierley-summary-info-box class="bpt0 bpr0">
        <template v-slot:summary-block>
          <v-col class="sub-section bmb0" sm="12">
            <v-row no-gutters class="sub-section_title">
              <v-col xs="12" sm="9" md="9">
                <!-- Sub Header Start-->
                <p class="fbold text-left text-uppercase">
                  {{ $t('roleInfoHeader') }}
                </p>
                <!-- Sub Header End-->
              </v-col>
              <v-col xs="12" sm="3" md="3" class="hoverEdit">
                <!-- Edit Button Start -->
                <p
                  class="primary-text fbold text-right text-uppercase"
                  @click="editRoleInfo()"
                >
                  <v-icon class="bpr1" color="#000">create</v-icon
                  >{{ $t('editText') }}
                </p>
                <!-- Edit Button End-->
              </v-col>
            </v-row>
            <hr />
            <!-- Summary Start -->
            <v-col class="mt-2 pl-0 bpb0" v-if="isAdmin">
              <p>
                <strong>{{ $t('adminText') }}</strong>
                <span class="pl-1">{{ userFilteredObj.isAdministrator }}</span>
              </p>
              <p class="bmb0">
                <strong>{{ $t('roleAssignmentText') }}</strong>
                <span class="pl-1">{{ $t('loyaltyAdminText') }}</span>
              </p>
              <!-- Summary End -->
            </v-col>

            <v-col class="mt-2 pl-0 bpb0" v-else>
              <p>
                <strong>{{ $t('adminText') }}</strong>
                <span class="pl-1">{{ userFilteredObj.isAdministrator }}</span>
              </p>
              <span v-for="(items, i) in userFilteredObj.userPrograms" :key="i">
                <p>
                  <strong>{{ $t('selectedProgram') }} {{ i + 1 }}:</strong>
                  <span class="pl-1">{{ items.programName }}</span>
                </p>
                <p class="textWrap bmb0">
                  <strong>{{ $t('roleAssignmentText') }}</strong>
                  <span
                    v-for="(item, j) in items.userRoleDetails"
                    :key="j"
                    class="pl-1"
                  >
                    {{ item.roleName }}
                    <span v-if="items.userRoleDetails.length - 1 !== j">,</span>
                  </span>
                </p>
                <hr
                  v-if="userFilteredObj.userPrograms.length - 1 !== i"
                  class="separationLine bmy3"
                />
              </span>
              <!-- Summary End -->
            </v-col>
          </v-col>
        </template>
      </brierley-summary-info-box>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleySummaryInfoBox } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { previewAndSaveObject } from './../../../../i18n/language.js';
export default {
  computed: {
    ...mapState('userModule', [
      'partialUser',
      'roleAssignmentChildUser',
      'isAdmin',
      'userRoleObject',
      'userCurrentStep'
    ])
  },
  components: {
    BrierleySummaryInfoBox
  },
  i18n: previewAndSaveObject,
  methods: {
    editUser () {
      this.$emit('previewToPersonalInfo', this.currentStep);
    },
    editPersonalInfo () {
      this.$store.commit('userModule/setUserCurrentStep', 1);
    },
    editRoleInfo () {
      this.$store.commit('userModule/setUserCurrentStep', 2);
    }
  },
  data () {
    return {
      userFilteredObj: {},
      isHidden: false,
      currentStep: 1,
      userlist: [
        {
          name: 'Gloria wilson',
          email: 'hello@gmail.com',
          phonenumber: 1234567890,
          mrewardsU: 'Loyalty Manager, CS Customer Manager',
          lastactivity: 'Jan 1ST 2020 12:00 AM EST',
          externalID: 9999999991,
          status: 'active',
          accountlock: 'mdi-lock',
          Country: 'USA'
        }
      ],
      listData: {
        title: 'Programs',
        list: [
          {
            name: 'M REWARDS (USA)',
            description:
              'Get points on purchasing qualifying products at selected stores.',
            options: [
              {
                head: 'heading',
                items: [
                  'Product Attributes',
                  'Product Attributes2',
                  'Product Attributes3'
                ]
              },
              {
                head: 'heading',
                items: [
                  'Product Attributes',
                  'Product Attributes2',
                  'Product Attributes3'
                ]
              }
            ]
          },
          {
            name: 'M REWARDS (UK)',
            description:
              'Get points on purchasing qualifying products at selected stores.',
            options: [
              {
                head: 'heading',
                items: [
                  'Product Attributes',
                  'Product Attributes2',
                  'Product Attributes3'
                ]
              },
              {
                head: 'heading',
                items: [
                  'Product Attributes',
                  'Product Attributes2',
                  'Product Attributes3'
                ]
              }
            ]
          },
          {
            name: 'M REWARDS (UN)',
            description:
              'Get points on purchasing qualifying products at selected stores.',
            options: [
              {
                head: 'heading',
                items: [
                  'Product Attributes',
                  'Product Attributes2',
                  'Product Attributes3'
                ]
              },
              {
                head: 'heading',
                items: [
                  'Product Attributes',
                  'Product Attributes2',
                  'Product Attributes3'
                ]
              }
            ]
          }
        ]
      }
    };
  },
  mounted () {
    if (!this.isAdmin) {
      if (this.roleAssignmentChildUser.userPrograms !== undefined) {
        let filteredArr = [];
        let userArray = [];
        this.userFilteredObj = this.roleAssignmentChildUser;
        for (let i = 0; i < this.userFilteredObj.userPrograms.length; i++) {
          for (
            let j = 0;
            j < this.userFilteredObj.userPrograms[i].checkedFilters.length;
            j++
          ) {
            userArray = this.userFilteredObj.userPrograms[i].serviceDetails.map(
              (userItem) => {
                if (
                  userItem.roleId ===
                  this.userFilteredObj.userPrograms[i].checkedFilters[j]
                ) {
                  return userItem;
                }
              }
            );
            userArray = userArray.filter((item) => item);
            let userObj = {};
            userObj['roleId'] = userArray[0].roleId;
            userObj['roleName'] = userArray[0].roleName;
            filteredArr.push(userObj);
          }
          this.userFilteredObj.userPrograms[i].userRoleDetails = filteredArr;
          filteredArr = [];
        }
        this.roleAssignmentChildUser.isProfileComplete = this.partialUser.isProfileComplete;
        this.roleAssignmentChildUser.userName = this.partialUser.userName;
        this.roleAssignmentChildUser.tenantId = this.partialUser.tenantId;
        this.roleAssignmentChildUser.email = this.partialUser.email;
        this.roleAssignmentChildUser.roles = this.partialUser.roles;
        this.roleAssignmentChildUser.firstName = this.partialUser.firstName;
        this.roleAssignmentChildUser.lastName = this.partialUser.lastName;
        this.roleAssignmentChildUser.alternateEmail = this.partialUser.alternateEmail;
        this.roleAssignmentChildUser.phoneNumber = this.partialUser.phoneNumber;
        this.roleAssignmentChildUser.externalId = this.partialUser.externalId;
        this.roleAssignmentChildUser.defaultApp = this.partialUser.defaultApp;
        this.roleAssignmentChildUser.passwordHash = this.partialUser.passwordHash;
        this.roleAssignmentChildUser.status = this.partialUser.status;
        // this.roleAssignmentChildUser.userProgramsSelected = this.roleAssignmentChildUser.userProgramsSelected;

        this.$store.dispatch(
          'userModule/setUserRoleObjectAction',
          this.userFilteredObj
        );
        if (this.userFilteredObj.userPrograms !== undefined) {
          if (
            this.userFilteredObj.userPrograms[0].roleName !==
            'Loyalty Administrator'
          ) {
            this.userFilteredObj.isAdministrator = 'No';
          }
        }
      }
    } else {
      this.userFilteredObj = this.partialUser;
      this.$store.dispatch(
        'userModule/setUserRoleObjectAction',
        this.partialUser
      );
      if (this.userFilteredObj.userPrograms !== undefined) {
        if (
          this.userFilteredObj.userPrograms[0].roleName ===
          'Loyalty Administrator'
        ) {
          this.userFilteredObj.isAdministrator = 'Yes';
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
#link {
  color: #0628b1;
  position: relative;
  top: 2px;
  right: 2px;
}
#acclockicon {
  position: relative;
  color: #bdbdbd !important;
  left: 155px;
  bottom: 32px;
}
.gen2-summarybox {
  background-color: white !important;
  padding-left: 0px !important;
  padding-right: 0px !important;
  padding-bottom: 0px !important;
}
.v-icon {
  font-size: 20px !important;
}
.separationLine {
  border-top: 1px dashed #bbb !important;
}
.textWrap {
  word-wrap: break-all !important;
}
.hoverEdit {
  .primary-text {
    float: right;
    cursor: pointer !important;
  }
}
</style>
<style lang="scss">
.gen2-summarybox.bpr0 {
  .gen2-summarybox_scrollbox {
    padding-right: 0 !important;
  }
}
</style>
