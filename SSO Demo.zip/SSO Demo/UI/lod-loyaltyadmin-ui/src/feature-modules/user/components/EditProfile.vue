<template>
            <brierley-inner-view :footerOnly="false">
              <template v-slot:header>
                <span class="inner-head-role">{{$t("message.title")}}</span>
              </template>
              <template v-slot:headerclose>
                <v-btn class="no-ripple" href target="_blank" text @click="closeMe">
                  <v-icon>mdi-close</v-icon>{{$t("message.close")}}
                </v-btn>
              </template>
              <template v-slot:body-container>
                <v-row class="bpt2">
                  <brierley-form-title
                    :formTitle="$t('message.title')"
                    :infoText="$t('message.infoText')"
                  ></brierley-form-title>
                </v-row>
                <v-form
                  ref="userData"
                >
                  <user-information
                    :user.sync="user"
                  />
                </v-form>
              </template>
              <template v-slot:footer>
                <v-btn
                  text class="cancel no-ripple bmt2 bmr6"
                  @click="openDialog">
                  {{$t("message.cancel")}}
                </v-btn>
                <v-btn
                  class="primaryctabtn bmt2 bml2"
                  @click="validate"
                >{{$t("message.save")}}</v-btn>

                <brierley-dialogbox :dialog="cancelDialog" @closeMe="cancelDialog = $event">
                    <template v-slot:dialog-header>
                    <v-card-title class="gen2-dialog-title text-uppercase">{{$t("message.dialogTitle")}}</v-card-title>
                    </template>
                    <template v-slot:dialog-body-alert>
                    <brierley-alert
                        alertType="warning"
                        :alertBody="$t('message.dialogBody')"
                        icon="notifications_active"
                    ></brierley-alert>
                    </template>
                    <template v-slot:dialog-footer>
                    <v-btn text class="cancel no-ripple" @click="closeMe">{{$t("message.no")}}</v-btn>
                    <v-btn class="primaryctabtn" title="Default" @click="validate">{{$t("message.yes")}}</v-btn>
                    </template>
                </brierley-dialogbox>
              </template>
        </brierley-inner-view>
</template>

<script>
import {
  brierleyAlert,
  BrierleyDialogbox,
  BrierleyFormTitle,
  BrierleyInnerView,
} from '@brierley/SharedComponents';
import UserInformation from './child/UserInformation';
import { mapState } from 'vuex';
export default {
  components: {
    brierleyAlert,
    BrierleyDialogbox,
    BrierleyFormTitle,
    BrierleyInnerView,
    UserInformation
  },
  data: () => ({
    cancelDialog: false,
    userId: ''
  }),
  computed: {
    ...mapState('userModule', {
      user: state => {
        return state.user;
      }
    })
  },
  created () {
    this.$store.commit('userModule/breachedPasswordOrNotMutation', false);
  },
  mounted: function () {
    this.userId = localStorage.getItem('userId');
    this.$store.dispatch('userModule/getUser', this.userId);
  },
  methods: {
    openDialog () {
      this.cancelDialog = true;
    },
    closeMe () {
      this.cancelDialog = false;
      this.$router.back();
      this.$destroy();
    },
    save () {
      const self = this;
      let userObj = {
        UserId: self.userId,
        FirstName: self.user.firstname,
        LastName: self.user.lastname,
        PhoneNumber: self.user.phonenumber
      };
      this.$store.dispatch('userModule/putUser', userObj);
    },
    validate () {
      this.cancelDialog = false;
      if (this.$refs.userData.validate()) {
        this.save();
        this.closeMe();
      }
    }
  },
  i18n: {
    messages: {
      en: {
        message: {
          errorHandlingDialogTitle: 'TEST Message',
          errorHandlingDialogAlertBody: 'TEST',
          ok: 'OK',
          close: 'CLOSE',
          title: 'EDIT PROFILE',
          cancel: 'Cancel',
          save: 'Save',
          infoText:
            'You may edit your user profile information or change your password below.',
          dialogTitle: 'Save Changes',
          dialogBody: 'Do you want to save the changes you’ve made?',
          no: 'NO',
          yes: 'YES'
        }
      },
      ja: {
        message: {
          errorHandlingDialogTitle: 'テストメッセージ',
          errorHandlingDialogAlertBody: 'テスト',
          ok: 'OK',
          close: '閉じる',
          title: 'プロフィール 更新',
          cancel: 'キャンセル',
          save: '保存する',
          infoText:
            'ユーザプロフィールの更新やパスワードの変更ができます。',
          dialogTitle: '変更内容を保存',
          dialogBody:
            '変更内容を保存します。よろしいですか？',
          no: 'いいえ',
          yes: 'はい'
        }
      }
    }
  }
};
</script>
