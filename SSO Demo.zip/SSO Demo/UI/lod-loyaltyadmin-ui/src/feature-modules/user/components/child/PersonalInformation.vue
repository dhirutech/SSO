<template>
  <v-row no-gutters class="bmt5 gen2-forms form-light-bg">
    <v-col sm="5" xs="12">
      <p class="label-text">{{ $t("emailHeader") }}</p>
      <validation-provider
        id="user_v_email"
        rules="required|email"
        v-slot="{ errors }"
      >
        <v-text-field
          autocomplete="off"
          :label="$t('emailLabel')"
          id="user_email"
          filled
          :disabled="emailDisabled"
          v-model="partialUser.email"
          @focusout="checkEmail()"
          @input="emailField()"
        ></v-text-field>
        <v-layout class="custom-error-msg" v-if="emailExistsOrNot"
          >{{ $t("emailValidationError") }}
        </v-layout>
        <p
          class="custom-error-msg"
          v-if="
            errors[0] != undefined &&
              errors[0].length > 0 &&
              errors[0] == 'This field is required'">
          {{ $t('emailText') }}
        </p>
        <p
          class="custom-error-msg"
          v-else-if="errors[0] != undefined && errors[0].length > 0"
        >
          {{ $t("incorrectEmailText") }}
        </p>
      </validation-provider>
      <p class="label-text bmt1">{{ $t("userHeader") }}</p>
      <validation-provider
        id="user_v_firstName"
        rules="required"
        v-slot="{ errors }"
      >
        <v-text-field
          autocomplete="nope"
          :label="$t('firstNameLabel')"
          id="user_firstName"
          filled
          v-model="partialUser.firstName"
        ></v-text-field>
        <p
          class="custom-error-msg"
          v-if="
            errors[0] != undefined &&
              errors[0].length > 0 &&
              errors[0] == 'This field is required'
          "
        >
          {{ $t("firstNameText") }}
        </p>
        <p
          class="custom-error-msg"
          v-else-if="errors[0] != undefined && errors[0].length > 0"
        >
          {{ $t("firstNameValidationError") }}
        </p>
      </validation-provider>
      <validation-provider
        id="user_v_lastName"
        rules="required"
        v-slot="{ errors }"
      >
        <v-text-field
          autocomplete="off"
          :label="$t('lastNameLabel')"
          id="user_lastName"
          filled
          v-model="partialUser.lastName"
        ></v-text-field>
        <p
          class="custom-error-msg"
          v-if="
            errors[0] != undefined &&
              errors[0].length > 0 &&
              errors[0] == 'This field is required'
          "
        >
          {{ $t("lastNameText") }}
        </p>
        <p
          class="custom-error-msg"
          v-else-if="errors[0] != undefined && errors[0].length > 0"
        >
          {{ $t("lastNameValidationError") }}
        </p>
      </validation-provider>
    </v-col>
    <v-col sm="6"></v-col>
    <v-col sm="3">
      <validation-provider
        id="user_v_phoneNumber"
        rules="integer|max:10|min:10"
        v-slot="{ errors }"
      >
        <v-text-field
          autocomplete="off"
          :label="$t('phoneNumberLabel')"
          id="user_phoneNumber"
          filled
          v-model="partialUser.phoneNumber"
        ></v-text-field>
        <p
          class="custom-error-msg"
          v-if="errors[0] != undefined && errors[0].length > 0"
        >
          {{ $t("phoneNumberValidationError") }}
        </p>
      </validation-provider>
    </v-col>
    <v-col sm="9"></v-col>
    <v-col sm="4">
      <p class="label-text bmt1">{{ $t("externalIdText") }}</p>
      <v-text-field
        autocomplete="off"
        :label="$t('externalIdLabel')"
        id="user_externalId"
        filled
        v-model="partialUser.externalId"
      ></v-text-field>
    </v-col>
  </v-row>
</template>
<script>
import { mapState } from 'vuex';
import { personalInformationObject } from './../../../../i18n/language.js';
export default {
  computed: {
    ...mapState('userModule', [
      'partialUser',
      'emailExistsOrNot',
      'cloneUserData'
    ])
  },
  methods: {
    checkEmail () {
      this.$store
        .dispatch(
          'userModule/checkEmailExistingOrNotActions',
          this.partialUser.email
        )
        .then(res => {
          if (res.status === 200) {
            this.$store.commit('userModule/userExistsOrNotMutations', true);
          }
        })
        .catch();
    },
    emailField () {
      this.$store.commit('userModule/userExistsOrNotMutations', false);
    }
  },
  data () {
    return {
      emailDisabled: false,
      errclass: '',
      valid: false
    };
  },
  i18n: personalInformationObject,
  created () {
    if (this.$route.name === 'UserLayoutEdit') {
      this.emailDisabled = true;
    }
    this.$store.commit('userModule/userExistsOrNotMutations', false);
  }
};
</script>
<style lang="scss" scoped>
.errclass {
  p {
    color: red;
  }
}
</style>
