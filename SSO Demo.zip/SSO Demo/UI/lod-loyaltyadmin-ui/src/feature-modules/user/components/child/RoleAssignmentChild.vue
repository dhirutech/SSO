<template>
  <v-row no-gutters>
    <v-col>
      <v-row
        class="gray-bg flex-column bpa3"
        no-gutters
        v-for="(user, k) in roleAssignmentChildUser.userPrograms"
        :key="k"
      >
        <v-col>
          <v-row no-gutters>
            <v-col class="label-text">
              {{ $t("programText") }}
            </v-col>
            <v-col
              class="text-right"
              v-if="roleAssignmentChildUser.userPrograms.length > 1"
            >
              <span
                class="fbold text-uppercase assign primary-text cursor-p"
                @click="removeProgram(k)"
              >
                <v-icon color="#0E1E61" class="pr-3 primary-text"
                  >remove_circle_outline</v-icon
                >{{ $t("removeText") }}
              </span>
            </v-col>
          </v-row>
        </v-col>
        <v-col sm="4" xs="6">
          <!-- nameCheck: {
                programData: roleAssignmentChildUser.userPrograms,
                indexData: k
              } -->
          <validation-provider
            :rules="{
              required: true
            }"
            v-slot="{ errors }"
          >
            <v-select
              :items="allProgramStatus"
              item-text="name"
              item-value="programId"
              filled
              attach
              offset-y
              hide-details
              v-model="user.programId"
              class="gen2select gen2select__light bmb2"
              :label="$t('programName')"
              append-icon="expand_more"
              @change="selectedProgram => changeProgram(selectedProgram, user)"
            ></v-select>
            <span class="custom-error-msg" v-if="user.isProgramError">
              <small class="red--text clearb">{{
                $t("programNameError")
              }}</small>
            </span>
            <span
              class="custom-error-msg"
              v-if="errors[0] != undefined && errors[0].length > 0"
            >
              <small class="red--text clearb">{{ $t("fieldRequired") }}</small>
            </span>
          </validation-provider>
        </v-col>
        <v-col class="label-text bmt1">{{ $t("roleAssignmentText") }}</v-col>
        <v-col class="pt-0">
          <validation-provider :rules="{ required: true }" v-slot="{ errors }">
            <v-layout
              class="custom-error-msg"
              v-if="
                errors[0] != undefined &&
                  errors[0].length > 0 &&
                  errors[0] == 'This field is required'
              "
              >{{ $t("roleSelectionText") }}</v-layout
            >
            <v-row class="flex-column" no-gutters>
              <v-col
                class="bmb3"
                v-for="(items, i) in user.serviceDetails"
                :key="i"
              >
                <v-row class="gray-bg flex-column" no-gutters>
                  <v-col>
                    <v-expansion-panels class="user-role-assignment-expansions">
                      <v-expansion-panel
                        :disabled="isServiceDisabled(items.roleName)"
                      >
                        <v-expansion-panel-header>
                          <div class="checkbox-block d-flex">
                            <v-checkbox
                              class="bmt0 checkbox-custom"
                              :ripple="false"
                              v-model="user.checkedFilters"
                              :value="items.roleId"
                              :id="items.roleName"
                              @click.native="check($event)"
                            ></v-checkbox>
                          </div>
                          {{ items.roleName }}
                        </v-expansion-panel-header>

                        <v-expansion-panel-content
                          v-for="serviceItem in items.serviceDetails"
                          :key="serviceItem.serviceId"
                          :disabled="isServiceDisabled(serviceItem.serviceName)"
                        >
                          <v-row class="flex-column" no-gutters>
                            <v-col class="label-text">
                              {{ serviceItem.serviceName }}
                            </v-col>
                            <v-col>
                              <v-row
                                class="flex-column custom-role-assignment-table"
                                no-gutters
                              >
                                <v-col>
                                  <v-row
                                    class="custom-role-assignment-table__head"
                                    no-gutters
                                  >
                                    <v-col></v-col>
                                    <v-col
                                      v-for="m in filteredMethods"
                                      :key="m.methodId"
                                      >{{ m.name }}</v-col
                                    >
                                  </v-row>
                                </v-col>
                                <v-col
                                  v-for="serviceItemChild in serviceItem.serviceDetails"
                                  :key="serviceItemChild.serviceId"
                                >
                                  <v-row
                                    no-gutters
                                    v-if="
                                      serviceItemChild.serviceDetails.length ==
                                        0
                                    "
                                  >
                                    <v-col>{{
                                      serviceItemChild.serviceName
                                    }}</v-col>
                                    <v-col
                                      v-for="method in filteredMethods"
                                      :key="method.methodId"
                                    >
                                      <!-- <v-icon
                                :color="hasPermission(serviceItemChild.serviceId, method.methodId) ? 'green' : 'grey'"
                                  >mdi-check-circle-outline</v-icon>-->
                                      <v-icon
                                        v-if="
                                          hasPermission(
                                            serviceItemChild,
                                            method.methodId
                                          )
                                        "
                                        >check_circle</v-icon
                                      >
                                      <v-icon class="uncheck" v-else
                                        >remove_circle</v-icon
                                      >
                                    </v-col>
                                  </v-row>
                                  <v-row
                                    no-gutters
                                    v-if="
                                      serviceItemChild.serviceDetails.length > 0
                                    "
                                  >
                                    <v-col
                                      class="having-child"
                                      v-if="
                                        serviceItemChild.serviceDetails.length >
                                          0
                                      "
                                    >
                                      <!-- closed -->
                                      <v-row
                                        class="flex-column child-rows"
                                        no-gutters
                                      >
                                        <v-col class="child-rows__head">
                                          <v-row no-gutters>
                                            <v-col>
                                              {{ serviceItemChild.serviceName }}
                                              <v-icon class="float-right"
                                                >keyboard_arrow_down</v-icon
                                              >
                                            </v-col>
                                            <v-col></v-col>
                                            <v-col></v-col>
                                            <v-col></v-col>
                                            <v-col></v-col>
                                          </v-row>
                                        </v-col>
                                        <v-col
                                          class="child-rows__content"
                                          v-for="serviceItemNestedChild in serviceItemChild.serviceDetails"
                                          :key="
                                            serviceItemNestedChild.serviceId
                                          "
                                        >
                                          <v-row no-gutters>
                                            <v-col>
                                              {{
                                                serviceItemNestedChild.serviceName
                                              }}
                                            </v-col>
                                            <v-col
                                              v-for="method in filteredMethods"
                                              :key="method.methodId"
                                              class="text-center"
                                            >
                                              <!-- <v-icon
                                        :color="hasPermission(serviceItemNestedChild.serviceId, method.methodId) ? 'green' : 'grey'"
                                          >mdi-check-circle-outline</v-icon>-->
                                              <v-icon
                                                v-if="
                                                  hasPermission(
                                                    serviceItemNestedChild,
                                                    method.methodId
                                                  )
                                                "
                                                >check_circle</v-icon
                                              >
                                              <v-icon class="uncheck" v-else
                                                >remove_circle</v-icon
                                              >
                                            </v-col>
                                          </v-row>
                                        </v-col>
                                      </v-row>
                                    </v-col>
                                  </v-row>
                                </v-col>
                              </v-row>
                            </v-col>
                          </v-row>
                        </v-expansion-panel-content>
                      </v-expansion-panel>
                    </v-expansion-panels>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
          </validation-provider>
        </v-col>
      </v-row>
      <v-row
        no-gutters
        class="bmt4"
        v-if="
          roleAssignmentChildUser.userPrograms.length < allProgramStatus.length
        "
      >
        <v-col sm="6" class="assign">
          <span
            class="fbold text-uppercase assign primary-text cursor-p"
            @click="assignProgram()"
            title="Assign another program"
          >
            <v-icon color="#0E1E61" class="pr-3 primary-text"
              >add_circle_outline</v-icon
            >{{ $t("assignProgramText") }}
          </span>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import { mapState } from 'vuex';
import { roleAssignmentChildObject } from './../../../../i18n/language.js';
// import { BrierleyRoleAssignment } from '@brierley/SharedComponents';
export default {
  components: {
    // BrierleyRoleAssignment
  },
  data () {
    return {
      userPrograms: [],
      programListStatus: '',
      addRoleAssignmentArray: 2,
      dataList: [],
      checkedFilters: [],
      methods: [
        {
          methodId: 1,
          name: this.$t('viewText'),
          description: 'View Permission'
        },
        {
          methodId: 2,
          name: this.$t('createText'),
          description: 'Create Permission'
        },
        {
          methodId: 3,
          name: this.$t('editText'),
          description: 'Edit Permission'
        },
        {
          methodId: 4,
          name: this.$t('deleteText'),
          description: 'Delete Permission'
        },
        {
          methodId: 5,
          name: 'Activate',
          description: 'Activate Permission'
        },
        {
          methodId: 6,
          name: 'Deactivate',
          description: 'Deactivate Permission'
        },
        {
          methodId: 7,
          name: 'TBD',
          description: 'TBD Permission'
        }
      ],
      role: {
        roleName: 'Administrator',
        description: 'Description',
        permissions: []
      },
      disabledServices: ['b-Empowered', 'b-Informed', 'Analytics'],
      hiddenMethods: ['Activate', 'Deactivate', 'TBD']
    };
  },
  computed: {
    filteredMethods () {
      let self = this;
      return self.methods.filter(function (method) {
        return self.hiddenMethods.indexOf(method.name) < 0;
      });
    },
    ...mapState('userModule', {
      allProgramStatus: state => {
        return state.allProgramStatusList;
      }
    }),
    ...mapState('userModule', {
      partialUser: state => {
        return state.partialUser;
      }
    }),
    ...mapState('userModule', {
      allRolesStatus: state => {
        return state.allRolesStatusList;
      }
    }),
    ...mapState('userModule', {
      roleAssignmentChildUser: state => {
        return state.roleAssignmentChildUser;
      }
    })
  },
  i18n: roleAssignmentChildObject,
  methods: {
    check: function (e) {
      e.cancelBubble = true;
    },
    openTab (k, index) {
      let filteredArr = [];
      let permissionsArray = [];
      for (
        let i = 0;
        i <
        this.roleAssignmentChildUser.userPrograms[k].serviceDetails[index]
          .serviceDetails.length;
        i++
      ) {
        if (
          this.roleAssignmentChildUser.userPrograms[k].serviceDetails[index]
            .serviceDetails[i].serviceDetails.length
        ) {
          for (
            let j = 0;
            j <
            this.roleAssignmentChildUser.userPrograms[k].serviceDetails[index]
              .serviceDetails[i].serviceDetails.length;
            j++
          ) {
            if (
              this.roleAssignmentChildUser.userPrograms[k].serviceDetails[index]
                .serviceDetails[i].serviceDetails[j].serviceDetails.length > 0
            ) {
              for (
                let f = 0;
                f <
                this.roleAssignmentChildUser.userPrograms[k].serviceDetails[
                  index
                ].serviceDetails[i].serviceDetails[j].serviceDetails.length;
                f++
              ) {
                permissionsArray = this.roleAssignmentChildUser.userPrograms[
                  k
                ].serviceDetails[index].serviceDetails[i].serviceDetails[
                  j
                ].serviceDetails[f].methodDetails.map(userItem => {
                  return userItem.methodId;
                });
                let permissionsObj = {};
                permissionsObj[
                  'serviceId'
                ] = this.roleAssignmentChildUser.userPrograms[k].serviceDetails[
                  index
                ].serviceDetails[i].serviceDetails[j].serviceDetails[
                  f
                ].serviceId;
                permissionsObj['methodsId'] = permissionsArray;
                filteredArr.push(permissionsObj);
                this.roleAssignmentChildUser.userPrograms[k].serviceDetails[
                  index
                ].serviceDetails[i].serviceDetails[j].serviceDetails[
                  f
                ].permissions = filteredArr;
              }
            } else {
              permissionsArray = this.roleAssignmentChildUser.userPrograms[
                k
              ].serviceDetails[index].serviceDetails[i].serviceDetails[
                j
              ].methodDetails.map(userItem => {
                return userItem.methodId;
              });
              let permissionsObj = {};
              permissionsObj[
                'serviceId'
              ] = this.roleAssignmentChildUser.userPrograms[k].serviceDetails[
                index
              ].serviceDetails[i].serviceDetails[j].serviceId;
              permissionsObj['methodsId'] = permissionsArray;
              filteredArr.push(permissionsObj);
            }
            this.roleAssignmentChildUser.userPrograms[k].serviceDetails[
              index
            ].serviceDetails[i].serviceDetails[j].permissions = filteredArr;
          }
        }
      }
    },
    getData () {
      // let filteredArr = [];
      // let permissionsArray = [];
      let serviceDetailsArray = [];
      for (
        let l = 0;
        l < this.roleAssignmentChildUser.userPrograms.length;
        l++
      ) {
        for (
          let i = 0;
          i <
          this.roleAssignmentChildUser.userPrograms[l].serviceDetails.length;
          i++
        ) {
          for (
            let j = 0;
            j <
            this.roleAssignmentChildUser.userPrograms[l].serviceDetails[i]
              .serviceDetails.length;
            j++
          ) {
            if (
              this.roleAssignmentChildUser.userPrograms[l].serviceDetails[i]
                .serviceDetails[j].serviceDetails.length > 0
            ) {
              serviceDetailsArray.push(
                this.roleAssignmentChildUser.userPrograms[l].serviceDetails[i]
                  .serviceDetails[j]
              );
            }
          }
          this.roleAssignmentChildUser.userPrograms[l].serviceDetails[
            i
          ].serviceDetails = serviceDetailsArray;
          serviceDetailsArray = [];
        }
      }
      return this.roleAssignmentChildUser.userPrograms;
    },
    removeProgram (index) {
      this.roleAssignmentChildUser.userPrograms.splice(index, 1);
      this.checkProgramError();
      const prog = this.roleAssignmentChildUser.userPrograms.filter(
        item => item.isProgramError
      );
      if (prog.length >= 1) {
        this.$store.dispatch('userModule/setUserReviewBtnAction', true);
      } else {
        this.$store.dispatch('userModule/setUserReviewBtnAction', false);
      }
    },
    findDuplicates (arr) {
      let sorted_arr = arr.slice().sort();
      let results = [];
      for (let i = 0; i < sorted_arr.length - 1; i++) {
        if (sorted_arr[i + 1] === sorted_arr[i]) {
          results.push(sorted_arr[i]);
        }
      }
      return results;
    },
    checkProgramError () {
      if (this.roleAssignmentChildUser.userPrograms.length === 1) {
        this.roleAssignmentChildUser.userPrograms[0].isProgramError = false;
      }
      if (this.roleAssignmentChildUser.userPrograms.length > 1) {
        for (
          let z = 0;
          z < this.roleAssignmentChildUser.userPrograms.length;
          z++
        ) {
          this.roleAssignmentChildUser.userPrograms[z].isProgramError = false;
        }
        const programIdList = this.roleAssignmentChildUser.userPrograms.map(
          item => item.programId
        );
        let duplicateList = programIdList.reduce(function (acc, el, i, arr) {
          if (arr.indexOf(el) !== i && acc.indexOf(el) < 0) acc.push(el);
          return acc;
        }, []);
        if (duplicateList.length > 0) {
          this.$store.dispatch('userModule/setUserReviewBtnAction', true);
          for (let l = 0; l < duplicateList.length; l++) {
            for (
              let m = 0;
              m < this.roleAssignmentChildUser.userPrograms.length;
              m++
            ) {
              if (
                this.roleAssignmentChildUser.userPrograms[m].programId ===
                duplicateList[l]
              ) {
                this.roleAssignmentChildUser.userPrograms[
                  m
                ].isProgramError = true;
              }
            }
          }
        } else {
          this.$store.dispatch('userModule/setUserReviewBtnAction', false);
          for (
            let n = 0;
            n < this.roleAssignmentChildUser.userPrograms.length;
            n++
          ) {
            this.roleAssignmentChildUser.userPrograms[n].isProgramError = false;
            this.checkProgramError();
          }
        }
      }
    },
    changeProgram (programId, programObj) {
      let programObjName = '';
      programObjName = this.allProgramStatus.filter(userItem => {
        if (userItem.programId === programId) {
          return userItem;
        }
      });
      programObj.programName = programObjName[0].name;

      if (programId) {
        this.checkProgramError();
      }
    },
    assignProgram () {
      let roleObject = {};
      roleObject['programId'] = '';
      roleObject['programName'] = '';
      roleObject['checked'] = false;
      roleObject['isProgramError'] = false;
      roleObject['checkedFilters'] = [];
      roleObject['serviceDetails'] = [...this.dataList];
      this.roleAssignmentChildUser.userPrograms.push(roleObject);
      if (this.roleAssignmentChildUser) {
        this.roleAssignmentChildUser.userPrograms = this.getData();
      }
      for (
        let m = 0;
        m < this.roleAssignmentChildUser.userPrograms.length;
        m++
      ) {
        for (
          let n = 0;
          n <
          this.roleAssignmentChildUser.userPrograms[m].serviceDetails.length;
          n++
        ) {
          this.openTab(m, n);
        }
      }
    },
    getIconColor (isDisabled, hasAnyPermission) {
      if (isDisabled) return 'grey';
      if (hasAnyPermission) return 'green';
      else return 'black';
    },
    hasAnyPermission (service) {
      let self = this;
      let permission = self.role.permissions.find(
        p => p.serviceId === service.serviceId
      );
      if (permission && permission.methodsId.length > 0) {
        return true;
      } else {
        if (service.serviceDetails.length > 0) {
          for (let i = 0; i < service.serviceDetails.length; i++) {
            if (self.hasAnyPermission(service.serviceDetails[i])) {
              return true;
            }
          }
        }
      }
      return false;
    },
    hasPermission (service, methodId) {
      // let self = this;
      let permission = service.permissions.find(
        p => p.serviceId === service.serviceId
      );
      if (permission) {
        let method = permission.methodsId.find(m => m === methodId);
        if (method) {
          return true;
        }
      }
      return false;
    },
    isServiceDisabled (name) {
      return this.disabledServices.indexOf(name) > -1;
    }
  },
  mounted () {
    this.dataList = this.allRolesStatus.filter(
      item => item.roleName !== 'Loyalty Administrator'
    );
    if (this.roleAssignmentChildUser.userPrograms.length === 0) {
      let roleObject = {};
      roleObject['programId'] = '';
      roleObject['programName'] = '';
      roleObject['checked'] = false;
      roleObject['isProgramError'] = false;
      roleObject['checkedFilters'] = [];
      roleObject['serviceDetails'] = [...this.dataList];
      this.roleAssignmentChildUser.userPrograms.push(roleObject);
      if (this.roleAssignmentChildUser) {
        this.roleAssignmentChildUser.userPrograms = this.getData();
      }
    }
    for (let m = 0; m < this.roleAssignmentChildUser.userPrograms.length; m++) {
      for (
        let n = 0;
        n < this.roleAssignmentChildUser.userPrograms[m].serviceDetails.length;
        n++
      ) {
        this.openTab(m, n);
      }
    }
    if (
      this.$route.path.includes('clone') ||
      this.$route.path.includes('edit')
    ) {
      if (this.roleAssignmentChildUser.userPrograms[0].programId !== '') {
        this.partialUser.userPrograms = this.roleAssignmentChildUser.userPrograms;
      }
      if (this.partialUser.userPrograms[0].roleId !== 201) {
        let arr = [];
        arr = this.roleAssignmentChildUser.userPrograms[0].serviceDetails;
        this.roleAssignmentChildUser.userPrograms = [];
        for (let i = 0; i < this.partialUser.userPrograms.length; i++) {
          this.partialUser.userPrograms[i].serviceDetails = arr;
          let programName = this.allProgramStatus.filter(userItem => {
            if (
              userItem.programId === this.partialUser.userPrograms[i].programId
            ) {
              return userItem;
            }
          });
          if (programName[0].name) {
            this.partialUser.userPrograms[i].programName = programName[0].name;
          }
          this.roleAssignmentChildUser.userPrograms.push(
            this.partialUser.userPrograms[i]
          );
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.child-service {
  color: #0628b1;
  margin-left: 15px;
  padding-top: 5px;
  padding-bottom: 18px;
}
.get-access {
  margin-left: 10px;
  margin-top: 3px;
}
.v-expansion-panel {
  background: white !important;
}
.assign {
  color: #0e1e61;
}
.checkbox-custo {
  flex: inherit !important;
}
.role-assignment-expansions {
  border-radius: 0;
  .v-expansion-panel {
    margin-bottom: 24px;
    border-radius: 0 !important;
    &::before {
      box-shadow: none;
    }
    &::after {
      border-color: transparent !important;
    }
    &:last-child {
      margin-bottom: 0px;
    }
    .v-expansion-panel-header {
      font-weight: 600;
      padding: 19px 24px !important;
      min-height: 80px;
      .checkbox-custom {
        max-width: 24px;
        margin-right: 16px !important;
        padding: 0;
        .v-input__slot {
          margin: 0 !important;
        }
      }
    }
    .v-expansion-panel-content {
      &__wrap {
        padding: 0 24px 40px;
        .role-assignment-table {
          &__head {
            min-height: 70px;
            > .col {
              font-weight: bold;
            }
          }
          > .col {
            min-height: 65px;
            overflow: hidden;
            > .row {
              > .col {
                font-weight: bold;
                letter-spacing: -0.2px;
                text-align: center;
                max-height: 65px;
                max-width: 19%;
                padding: 20px 0;
                .v-icon {
                  color: inherit;
                  cursor: pointer;
                }
                &:first-child {
                  padding-left: 24px;
                  text-align: left;
                  border: none;
                  line-height: 26px;
                  text-transform: uppercase;
                  max-width: 24%;
                }
                .v-btn:hover:before {
                  background-color: transparent;
                }
              }
            }
          }
          .having-child {
            > .row {
              > .child-rows {
                max-width: none !important;
                max-height: none;
                padding: 0 !important;
                border: none !important;
                > .row {
                  display: none;
                  > .col {
                    &:first-child {
                      .col {
                        border-top: 0 !important;
                      }
                    }
                    &:last-child {
                      .col {
                        border-bottom: 0 !important;
                      }
                    }
                    > .row {
                      > .col {
                        min-height: 65px;
                        padding-top: 16px;
                        &:first-child {
                          text-align: left;
                          padding-left: 40px;
                          padding-top: 24px;
                          font-weight: bold;
                          border: none;
                          max-width: 20%;
                          line-height: 26px;
                          text-transform: uppercase;
                        }
                      }
                    }
                  }
                }
              }
              > .col {
                max-height: 65px !important;
                border-bottom: 0 !important;
              }
            }
            p {
              font-weight: bold;
              padding-right: 16px;
            }
            .v-icon {
              display: none;
            }
            .float-right {
              display: block;
            }
          }
          .having-child.open {
            min-height: fit-content !important;
            p {
              .v-icon {
                transform: rotate(180deg);
              }
            }
            > .row {
              > .child-rows.col-sm-12 {
                max-height: none !important;
                > .row {
                  display: block;
                }
              }
              > .col {
                .v-icon {
                  display: block;
                  padding-top: 8px;
                }
                .v-btn:hover:before {
                  background-color: transparent;
                }
                .float-right {
                  padding-top: 0;
                }
              }
            }
          }
        }
      }
    }
  }
  .v-expansion-panel--active {
    .v-expansion-panel-header {
      margin-bottom: 10px;
    }
  }
}
.having-child {
  max-width: 100% !important;
  padding: 0 !important;
  min-width: 100% !important;
}
.fullWidth {
  width: 100% !important;
}
.v-expansion-panel {
  box-shadow: none;
}
.checkbox-custom {
  .v-input__control {
    .v-input__slot {
      min-height: 8px !important;
      margin-bottom: 16px !important;
      .v-input--selection-controls__input {
        .v-icon {
          display: none;
        }
        &::before {
          width: 24px;
          height: 24px;
          content: " ";
          border: solid 1px #bbbbbb;
          position: absolute;
          top: 0;
          background: #f4f4f4;
          border-radius: 0%;
          left: 0;
        }
        &::after {
          content: " ";
          width: 18px;
          height: 14px;
          position: absolute;
          top: 6px;
          background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAMCAYAAABr5z2BAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAADZSURBVHgBnZItDsJAEEZnlj9TUUOoLDeApJZAb8ANAEEoDkkQpUfAI+AISFwpugkcAY+pqGlIuuxsKKGK3T41yc7bfDO7CBXw1pYNDTjAC2YImki5CaEobUC4aF3wK3PgCTLs16vKOcvdffB8MDqcb9q9CvKdzmpL35ogY2dnaEAcpZGOTDCeg/upA8+3tjqyTBBf05MzMLpiozTGqEiiIhPfV1j4nRsCyl0g5zuOOP4nyxGKImOZK5plk5BXKnIpATENTLOVt0JKoiKXEhDHIEkoCf0wFZl4A4/igv08PHalAAAAAElFTkSuQmCC");
          opacity: 0;
          left: 4px;
          transition: all ease 0s !important;
          background-size: 88% auto;
          background-repeat: no-repeat;
        }
      }
    }
    .v-messages {
      min-height: 0;
    }
  }
  .assign {
    cursor: pointer;
  }
}
</style>
