<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closeDeleteEntityPopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase"
            >{{ $t("cardTitle") }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <brierley-alert
                  alertType="error"
                  :alertBody="$t('alertMsg')"
                ></brierley-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="org_btn_cancelDeleteDialog"
            text
            class="cancel no-ripple"
            @click="closeDeleteEntityPopupWhenClickNo()"
            >{{ $t("noBtnText") }}</v-btn
          >
          <v-btn
            id="org_btn_deleteDeleteDialog"
            class="primaryctabtn text-uppercase"
            title
            @click="addUser()"
            >{{ $t("yesBtnText") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox, brierleyAlert } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { cancelPopUpObject } from './../../../../i18n/language.js';
export default {

  data: () => ({
    dialog: false,
    btnText: '',
    currentStep: 2,
    validations: '',
  }),
  computed: {
    ...mapState('userModule', ['partialUser', 'userCurrentStep', 'userRoleObject', 'roleAssignmentChildUser', 'isAdmin']),
    ...mapState('userModule', {
      allRolesStatus: (state) => {
        return state.allRolesStatusList;
      },
    })
  },
  components: {
    BrierleyDialogbox,
    brierleyAlert,
  },
  i18n: cancelPopUpObject,
  methods: {
    setRoleAssignmentUser () {
      if (!this.isAdmin) {
        if (this.roleAssignmentChildUser.userPrograms !== undefined) {
          let filteredArr = [];
          let userArray = [];
          this.userFilteredObj = this.roleAssignmentChildUser;
          for (
            let i = 0;
            i < this.userFilteredObj.userPrograms.length;
            i++
          ) {
            for (
              let j = 0;
              j <
            this.userFilteredObj.userPrograms[i].checkedFilters.length;
              j++
            ) {
              userArray = this.userFilteredObj.userPrograms[
                i
              ].serviceDetails.map((userItem) => {
                if (
                  userItem.roleId ===
               this.userFilteredObj.userPrograms[i].checkedFilters[j]
                ) {
                  return userItem;
                }
              });
              userArray = userArray.filter((item) => item);
              let userObj = {};
              userObj['roleId'] = userArray[0].roleId;
              userObj['roleName'] = userArray[0].roleName;
              filteredArr.push(userObj);
            }
            this.userFilteredObj.userPrograms[
              i
            ].userRoleDetails = filteredArr;
            filteredArr = [];
          }
          this.roleAssignmentChildUser.isProfileComplete = this.partialUser.isProfileComplete;
          this.roleAssignmentChildUser.userName = this.partialUser.userName;
          this.roleAssignmentChildUser.tenantId = this.partialUser.tenantId;
          this.roleAssignmentChildUser.email = this.partialUser.email;
          this.roleAssignmentChildUser.roles = this.partialUser.roles;
          this.roleAssignmentChildUser.firstName = this.partialUser.firstName;
          this.roleAssignmentChildUser.lastName = this.partialUser.lastName;
          this.roleAssignmentChildUser.alternateEmail = this.partialUser.alternateEmail;
          this.roleAssignmentChildUser.phoneNumber = this.partialUser.phoneNumber;
          this.roleAssignmentChildUser.externalId = this.partialUser.externalId;
          this.roleAssignmentChildUser.defaultApp = this.partialUser.defaultApp;
          this.roleAssignmentChildUser.passwordHash = this.partialUser.passwordHash;
          this.roleAssignmentChildUser.status = this.partialUser.status;
          // this.roleAssignmentChildUser.userProgramsSelected = this.roleAssignmentChildUser.userProgramsSelected;
          this.$store.dispatch('userModule/roleAssignmentChildObjectMutation', this.userFilteredObj);
          if (this.userFilteredObj.userPrograms !== undefined) {
            if (
              this.userFilteredObj.userPrograms[0].roleName !==
          'Loyalty Administrator'
            ) {
              this.userFilteredObj.isAdministrator = 'No';
            }
          }
        }

      } else {
        let roleDetailsObj = {};
        roleDetailsObj['roleId'] = this.partialUser.userPrograms[0].roleId;
        roleDetailsObj['roleName'] = this.partialUser.userPrograms[0].roleName;
        this.partialUser.userPrograms[0].userRoleDetails=[];
        this.partialUser.userPrograms[0].userRoleDetails.push(roleDetailsObj);
        this.$store.commit('userModule/roleAssignmentChildObjectMutation', this.partialUser);
      }
    },
    addUser () {
      this.$root.$refs.UserLayout.submit();
      if (this.partialUser.userId) {
        this.partialUser.id = this.partialUser.userId;
      }
      if (this.userCurrentStep===1) {
        this.partialUser.tenantId = 'brierley';
        this.partialUser.status = true;
        this.partialUser.alternateEmail = this.partialUser.email;
        this.partialUser.passwordHash = 'Kona_2019';
        this.partialUser.isProfileComplete = false;
        this.partialUser.roles='';
        this.$store
          .dispatch('userModule/createUserActions', this.partialUser)
          .then((res) => {
            if (res.status === 201 || res.status === 200) {
              this.$router.push({ name: 'viewuser' });
              this.closeDeleteEntityPopup();
              this.$store.commit('userModule/createUserMutations', {
                tenantId: '',
                email: '',
                passwordHash: '',
                status: true,
                isProfileComplete: true,
                roles: '',
                firstName: '',
                lastName: '',
                alternateEmail: '',
                phoneNumber: '',
                externalId: '',
                defaultApp: '',
                userPrograms: []
              });

            }
          })
          .catch((err)=>{
            if (err.response.status===400 || err.response.status===409) {
              this.closeDeleteEntityPopup();
            }
          });
      } else if (this.userCurrentStep===2) {
        // this.$store.commit("userModule/setUserCurrentStep", this.userCurrentStep + 1);
        this.setRoleAssignmentUser();
        this.roleAssignmentChildUser.tenantId = 'brierley';
        this.roleAssignmentChildUser.status = true;
        this.roleAssignmentChildUser.email = this.partialUser.email;
        this.roleAssignmentChildUser.firstName =this.partialUser.firstName;
        this.roleAssignmentChildUser.lastName = this.partialUser.lastName;
        this.roleAssignmentChildUser.phoneNumber=this.partialUser.phoneNumber;
        this.roleAssignmentChildUser.externalId=this.partialUser.externalId;
        this.roleAssignmentChildUser.passwordHash = 'Kona_2019';
        this.roleAssignmentChildUser.isProfileComplete = false;
        this.roleAssignmentChildUser.roles='';
        if (this.roleAssignmentChildUser) {
          this.$store
            .dispatch('userModule/createUserActions', this.roleAssignmentChildUser)
            .then((res) => {
              if (res.status === 201 || res.status === 200) {
                this.$router.push({ name: 'viewuser' });
                this.closeDeleteEntityPopup();
                this.$store.commit('userModule/roleAssignmentChildObjectMutation', { userPrograms: [] });
                this.$store.commit('userModule/partialUser', { userPrograms: [] });
                this.$store.dispatch('userModule/setAdminStatusAction', false);
              }
            })
            .catch((err)=>{
              if (err.response.status === 400 || err.response.status === 409) {
                this.closeDeleteEntityPopup();
              }
            });
        }
      } else if (this.userCurrentStep === 3) {
        this.userRoleObject.tenantId = 'brierley';
        this.userRoleObject.status = true;
        this.userRoleObject.email = this.partialUser.email;
        this.userRoleObject.passwordHash = 'Kona_2019';
        this.userRoleObject.isProfileComplete = false;
        this.userRoleObject.roles='';
        this.$store
          .dispatch('userModule/createUserActions', this.userRoleObject)
          .then((res) => {
            if (res.status === 201 || res.status === 200) {
              this.$router.push({ name: 'viewuser' });
              this.closeDeleteEntityPopup();
              this.$store.dispatch('userModule/setUserRoleObjectAction', {
                tenantId: '',
                email: '',
                passwordHash: '',
                status: true,
                isProfileComplete: true,
                roles: '',
                firstName: '',
                lastName: '',
                alternateEmail: '',
                phoneNumber: '',
                externalId: '',
                defaultApp: '',
                userPrograms: []
              });
              this.$store.commit('userModule/roleAssignmentChildObjectMutation', { userPrograms: [] });
              this.$store.commit('userModule/partialUser', { userPrograms: [] });
              this.$store.dispatch('userModule/setAdminStatusAction', false);
            }
          })
          .catch((err)=>{
            if (err.response.status===400 || err.response.status===409) {
              this.closeDeleteEntityPopup();
            }
          });
      }

    },
    closeDeleteEntityPopup () {
      this.$store.commit('userModule/showPopUpDialogueMutation', false);
    },
    closeDeleteEntityPopupWhenClickNo () {
      if (this.userCurrentStep===1) {
        this.$store.commit('userModule/showPopUpDialogueMutation', false);
        this.$router.push({ name: 'viewuser' });
        this.$store.commit('userModule/createUserMutations', {
          tenantId: '',
          email: '',
          passwordHash: '',
          status: true,
          isProfileComplete: true,
          roles: '',
          firstName: '',
          lastName: '',
          alternateEmail: '',
          phoneNumber: '',
          externalId: '',
          defaultApp: '',
          userPrograms: []
        });
      } else if (this.userCurrentStep===2) {
      //  this.closeDeleteEntityPopup();
        this.$store.commit('userModule/showPopUpDialogueMutation', false);
        this.$router.push({ name: 'viewuser' });
        this.$store.commit('userModule/setUserRoleObjectAction', {
          tenantId: '',
          email: '',
          passwordHash: '',
          status: true,
          isProfileComplete: true,
          roles: '',
          firstName: '',
          lastName: '',
          alternateEmail: '',
          phoneNumber: '',
          externalId: '',
          defaultApp: '',
          userPrograms: []
        });
        this.$store.commit('userModule/roleAssignmentChildObjectMutation', { userPrograms: [] });
        this.$store.commit('userModule/partialUser', { userPrograms: [] });
        this.$store.dispatch('userModule/setAdminStatusAction', false);
      } else if (this.userCurrentStep===3) {
        this.$store.commit('userModule/showPopUpDialogueMutation', false);
        this.$router.push({ name: 'viewuser' });
        this.$store.commit('userModule/setUserRoleObjectAction', {
          tenantId: '',
          email: '',
          passwordHash: '',
          status: true,
          isProfileComplete: true,
          roles: '',
          firstName: '',
          lastName: '',
          alternateEmail: '',
          phoneNumber: '',
          externalId: '',
          defaultApp: '',
          userPrograms: []
        });
        this.$store.commit('userModule/roleAssignmentChildObjectMutation', { userPrograms: [] });
        this.$store.commit('userModule/partialUser', { userPrograms: [] });
        this.$store.dispatch('userModule/setAdminStatusAction', false);
      }
    },
  },
};
</script>
