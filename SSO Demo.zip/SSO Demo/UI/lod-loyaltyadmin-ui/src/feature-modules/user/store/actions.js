import {
  getUserAsync,
  putUserAsync,
  getUsers,
  getAllProgramStatus,
  getAllRolesAssignment,
  createUser,
  userExistsOrNot,
  cloneUser
} from '../api/user-api.js';

const getUser = async ({ commit }, userId) => {
  let response = await getUserAsync(userId);
  let responseData = {
    Id: response.data.userId,
    username: response.data.email,
    firstname: response.data.firstName,
    lastname: response.data.lastName,
    phonenumber: response.data.phoneNumber,
    externalId: response.data.externalId,
    password: 'aaaaaaaaaaaa'
  };
  commit('setUser', responseData);
};

const putUser = async (context, user) => {
  return await putUserAsync(user);
};

const getUsersActions = (context, payload) => {
  return new Promise((resolve, reject) => {
    getUsers(payload)
      .then(res => {
        context.commit('partialUser', res.data);
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};
const getAllProgramStatusAction = context => {
  getAllProgramStatus()
    .then(res => {
      context.commit('getAllProgramStatusMutations', res.data);
    })
    .catch();
};

const setAdminStatusAction = (context, payload) => {
  context.commit('setAdminStatusMutation', payload);
};

const setUserRoleObjectAction = (context, payload) => {
  context.commit('setUserRoleObjectMutation', payload);
};

const cloneUserAction = (context, payload) => {
  cloneUser(payload).then(res => {
    let cloneUserData = {};
    let userPrograms = [];
    let name = `copy of ${res.data.userName}`;
    if (res.data.userPrograms !== null) {
      for (let i = 0; i < res.data.userPrograms.length; i++) {
        let roleIdList = [];
        for (
          let j = 0;
          j < res.data.userPrograms[i].userRoleDetails.length;
          j++
        ) {
          roleIdList.push(res.data.userPrograms[i].userRoleDetails[j].roleId);
        }
        userPrograms[i] = {
          programId: res.data.userPrograms[i].programId,
          programName: res.data.userPrograms[i].programName,
          checked: false,
          checkedFilters: [...roleIdList]
        };
      }
    }
    cloneUserData = [
      {
        email: name,
        userPrograms: [...userPrograms]
      }
    ];
    if (res.data.userPrograms !== null) {
      if (cloneUserData[0].userPrograms[0].checkedFilters[0] === 201) {
        context.commit('setAdminStatusMutation', true);
      }
    }
    context.commit('setCloneuserDataMutation', cloneUserData);
  });
};

const editUserAction = (context, payload) => {
  cloneUser(payload).then(res => {
    let cloneUserData = {};
    let userPrograms = [];
    if (res.data.userPrograms !== null) {
      for (let i = 0; i < res.data.userPrograms.length; i++) {
        let roleIdList = [];
        for (
          let j = 0;
          j < res.data.userPrograms[i].userRoleDetails.length;
          j++
        ) {
          roleIdList.push(res.data.userPrograms[i].userRoleDetails[j].roleId);
        }
        userPrograms[i] = {
          programId: res.data.userPrograms[i].programId,
          programName: res.data.userPrograms[i].programName,
          checked: false,
          checkedFilters: [...roleIdList]
        };
      }
    }
    cloneUserData = [
      {
        tenantId: res.data.tenantId,
        userId: res.data.userId,
        email: res.data.email,
        passwordHash: res.data.passwordHash,
        status: res.data.status,
        isProfileComplete: res.data.isProfileComplete,
        roles: res.data.roles,
        firstName: res.data.firstName,
        lastName: res.data.lastName,
        alternateEmail: res.data.alternateEmail,
        phoneNumber: res.data.phoneNumber,
        externalId: res.data.externalId,
        defaultApp: res.data.defaultApp,
        userPrograms: [...userPrograms]
      }
    ];
    if (res.data.userPrograms !== null) {
      if (cloneUserData[0].userPrograms[0].checkedFilters[0] === 201) {
        context.commit('setAdminStatusMutation', true);
      }
    }
    context.commit('setCloneuserDataMutation', cloneUserData);
  });
};

const getAllRolesAssignmentAction = context => {
  getAllRolesAssignment()
    .then(res => {
      context.commit('getAllRolesAssignmentMutations', res.data);
    })
    .catch();
};
const createUserActions = (context, payload) => {
  return new Promise((resolve, reject) => {
    createUser(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};
const checkEmailExistingOrNotActions = (context, payload) => {
  return new Promise((resolve, reject) => {
    userExistsOrNot(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const setUserReviewBtnAction = (context, payload) => {
  context.commit('setUserReviewBtnMutation', payload);
};

export default {
  getUser,
  putUser,
  getUsersActions,
  createUserActions,
  checkEmailExistingOrNotActions,
  getAllProgramStatusAction,
  getAllRolesAssignmentAction,
  setAdminStatusAction,
  setUserRoleObjectAction,
  cloneUserAction,
  editUserAction,
  setUserReviewBtnAction
};
