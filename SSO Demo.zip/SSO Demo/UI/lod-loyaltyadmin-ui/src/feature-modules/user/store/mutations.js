const setDashboard = (state, payload) => {
  state.dashboard = payload;
};

const setModuleVar = (state, payload) => {
  state.moduleVar = payload;
};
const getUsersMutations = (state, payload) => {
  state.Users = payload;
};
const createUserMutations = (state, payload) => {
  state.partialUser = payload;
};
const userExistsOrNotMutations = (state, payload) => {
  state.emailExistsOrNot = payload;
};

const getAllProgramStatusMutations = (state, payload) => {
  state.allProgramStatusList = payload;
};

const setAdminStatusMutation = (state, payload) => {
  state.isAdmin = payload;
};

const getAllRolesAssignmentMutations = (state, payload) => {
  state.allRolesStatusList = payload;
};

const showPopUpDialogueMutation = (state, payload) => {
  state.showPopUpDialogue = payload;
};

const setUserCurrentStep = (state, payload) => {
  state.userCurrentStep = payload;
};

const setUserRoleObjectMutation = (state, payload) => {
  state.userRoleObject = payload;
};

const roleAssignmentChildObjectMutation = (state, payload) => {
  state.roleAssignmentChildUser = payload;
};

const setCloneuserDataMutation = (state, payload) => {
  state.partialUser = payload[0];
};

const partialUser = (state, payload) => {
  state.partialUser = payload;
};

const setUser = (state, payload) => {
  state.user = payload;
};

const setUserReviewBtnMutation = (state, payload) => {
  state.userReviewBtnStatus = payload;
};

const breachedPasswordOrNotMutation = (state, payload) => {
  state.breachedPasswordOrNot = payload;
};

export default {
  setDashboard,
  breachedPasswordOrNotMutation,
  setModuleVar,
  getUsersMutations,
  setUserCurrentStep,
  createUserMutations,
  userExistsOrNotMutations,
  showPopUpDialogueMutation,
  setAdminStatusMutation,
  getAllProgramStatusMutations,
  getAllRolesAssignmentMutations,
  partialUser,
  setUserRoleObjectMutation,
  setCloneuserDataMutation,
  roleAssignmentChildObjectMutation,
  setUser,
  setUserReviewBtnMutation
};
