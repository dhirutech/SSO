const getModuleVar = (state) => state.moduleVar;
const partialUser = (state) => state.partialUser;
const userCurrentStep = (state) => state.userCurrentStep;
const getUserData = (state) => state.user;

export default {
  getModuleVar,
  partialUser,
  userCurrentStep,
  getUserData
};
