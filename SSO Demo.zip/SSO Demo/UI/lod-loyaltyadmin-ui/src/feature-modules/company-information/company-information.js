import CompanyInformationLayout from './components/CompanyInformationLayout';
const companyInfoRoutes = [
  {
    path: '/loyaltyadmin/company',
    name: 'CompanyInformationLayout',
    component: CompanyInformationLayout,
    meta: {
      showNavigation: false
    }
  }
];
export default companyInfoRoutes;
