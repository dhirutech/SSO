<template>
  <v-row no-gutters class="d-flex ">
    <v-col class="gen2-forms form-light-bg bmt5" sm="6" xs="12" md="5">
      <p class="label-text text-uppercase ">{{ $t("companyTypeLabel") }}</p>
      <v-select
        :items="items"
        filled
        v-model="selectCategory"
        attach
        offset-y
        id="company_category"
        class="gen2select gen2select__light"
        :label="$t('categoryLabel')"
        append-icon="expand_more"
        @change="checkCategory"
      ></v-select>
      <p class="label-text text-uppercase bmt1">{{ $t("userInfo") }}</p>
      <v-text-field
        autocomplete="nope"
        :label="$t('nameLabel')"
        id="company_user_name"
        filled
        v-model="companyInfoDetails.authorName"
      ></v-text-field>
      <v-text-field
        autocomplete="nope"
        :label="$t('positionLabel')"
        id="company_user_position"
        filled
        v-model="companyInfoDetails.authorPositionName"
      ></v-text-field>
      <validation-provider
        id="comp_v_city"
        rules="nameLength"
        v-slot="{ errors }"
      >
        <v-text-field
          autocomplete="off"
         :label="$t('cityLabel')"
          id="company_user_city"
          filled
          v-model="companyInfoDetails.authorCity"
        ></v-text-field>
        <p
          class="custom-error-msg"
          v-if="
            errors[0] != undefined &&
              errors[0].length > 0 &&
              errors[0] === 'Name must be lesser than 50 characters'
          "
        >
           {{ $t("cityLabelError") }}
        </p>
        <p
          class="custom-error-msg"
          v-else-if="errors[0] != undefined && errors[0].length > 0"
        >
          {{ errors[0] }}
        </p>
      </validation-provider>
      <v-row class="no-gutters">
        <v-col sm="3">
          <v-select
            :items="stateData"
            filled
            attach
            offset-y
            v-model="companyInfoDetails.authorState"
            class="gen2select gen2select__light"
            :label="$t('stateLabel')"
            id="company_state"
            append-icon="expand_more"
            @change="checkState"
          ></v-select>
        </v-col>
        <v-col cols="10">
          <v-select
            :items="countryData"
            filled
            attach
            offset-y
            v-model="companyInfoDetails.authorCountry"
            id="company_country"
            class="gen2select gen2select__light"
            :label="$t('countryLabel')"
            append-icon="expand_more"
            @change="checkCountry"
          ></v-select>
        </v-col>
      </v-row>
    </v-col>
    <v-col class="bmt5 offset-2" cols="5">
      <brierley-info-side>
        <template v-slot:info-side-header>
          <div class="info_title"><v-icon>info</v-icon>{{ $t("infoText") }}</div>
        </template>
        <template v-slot:info-side-body>
          <p class="">
            {{ $t("infoPassage") }}
          </p>
        </template>
      </brierley-info-side>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyInfoSide } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { moreInfoObject } from './../../../../i18n/language.js';
export default {
  components: {
    BrierleyInfoSide
  },
  computed: {
    ...mapState('companyModule', ['companyInfoDetails']),
    ...mapState('companyModule', ['companyTypeInfoDetails'])
  },
  i18n: moreInfoObject,
  methods: {
    checkCategory (category) {
      this.categoryData = this.companyTypeInfoDetails.filter(
        x => x.companyTypeName === category
      )[0];
      this.companyInfoDetails.companyTypeId = this.categoryData.companyTypeId;
    },
    checkState (state) {
      this.companyInfoDetails.state = state;
    },
    checkCountry (country) {
      this.companyInfoDetails.country = country;
    }
  },
  mounted () {
    this.companyTypeInfoDetails.forEach(element => {
      this.items.push(element.companyTypeName);
    });
    let index = this.companyTypeInfoDetails.findIndex(
      x => x.companyTypeId === this.companyInfoDetails.companyTypeId
    );
    this.selectCategory = this.items[index];
  },
  data () {
    return {
      category: '',
      name: '',
      position: '',
      city: '',
      externalId: '',
      state: '',
      Country: '',
      items: [],
      companyTypeData: [],
      categoryData: '',
      testcategory: [],
      selectCategory: '',
      stateData: [
        'Alabama',
        'Alaska',
        'American Samoa',
        'Arizona',
        'Arkansas',
        'California',
        'Colorado',
        'Connecticut',
        'Delaware',
        'District of Columbia',
        'Federated States of Micronesia',
        'Florida',
        'Georgia',
        'Guam',
        'Hawaii',
        'Idaho',
        'Illinois',
        'Indiana',
        'Iowa',
        'Kansas',
        'Kentucky',
        'Louisiana',
        'Maine',
        'Marshall Islands',
        'Maryland',
        'Massachusetts',
        'Michigan',
        'Minnesota',
        'Mississippi',
        'Missouri',
        'Montana',
        'Nebraska',
        'Nevada',
        'New Hampshire',
        'New Jersey',
        'New Mexico',
        'New York',
        'North Carolina',
        'North Dakota',
        'Northern Mariana Islands',
        'Ohio',
        'Oklahoma',
        'Oregon',
        'Palau',
        'Pennsylvania',
        'Puerto Rico',
        'Rhode Island',
        'South Carolina',
        'South Dakota',
        'Tennessee',
        'Texas',
        'Utah',
        'Vermont',
        'Virgin Island',
        'Virginia',
        'Washington',
        'West Virginia',
        'Wisconsin',
        'Wyoming'
      ],
      countryData: ['USA']
    };
  }
};
</script>
