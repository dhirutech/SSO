<template>
  <brierley-inner-view
    :class="{
      'company-info': currentStep === 1,
      'more-info': currentStep === 2,
      'success-block': currentStep > 2
    }"
  >
    <template v-slot:header>
      <span class="inner-head">{{ $t("headerText") }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        @click="goToGettingStarted()"
      >
        <v-icon>mdi-close</v-icon>{{ $t("closeBtnText") }}
      </v-btn>
    </template>
    <template v-slot:body-container :currentStep="currentStep">
      <Validation-Observer v-slot="{ handleSubmit }">
        <form id="comp_form" @submit.prevent="handleSubmit(onsubmit)">
          <v-row class="bmt5 flex-column" no-gutters v-if="currentStep <= 2">
            <v-col>
              <brierley-form-title
                :formTitle="$t('formTitle')"
                :currentStep="currentStep"
                :totalStep="2"
                :infoText="$t('formTitleInfoText')"
                :showSteps="true"
              ></brierley-form-title>
            </v-col>
            <v-col>
              <basic-info v-if="currentStep === 1" />
              <more-info v-else-if="currentStep === 2" />
            </v-col>
          </v-row>
          <template v-if="currentStep > 2">
            <v-row class="bmt3 flex-column" no-gutters>
              <v-col>
                <brierley-form-title
                  :formTitle="$t('formTitleSuccess')"
                  :infoText="$t('formTitleInfoSuccessText')"
                ></brierley-form-title>
              </v-col>
              <v-col class="bmt5 bmb2">
                <brierley-alert
                  class="bmb0"
                  :isSiteLevel="true"
                  alertType="success"
                  :alertHeader="$t('formTitleSuccess')"
                  :alertBody="alertMessage"
                  icon="done"
                ></brierley-alert>
              </v-col>
            </v-row>
          </template>
        </form>
      </Validation-Observer>
    </template>
    <template v-slot:footer-previous>
      <v-btn
        v-if="currentStep === 2"
        @click="currentStep = 1"
        text
        class="mr-5 cancel no-ripple"
      >
        <v-icon class="bpr1">arrow_back</v-icon>{{ $t("previousBtnText") }}
      </v-btn>
    </template>
    <template v-slot:footer-redirect v-if="currentStep > 2">
      <v-btn
        id="company_btn_goToStarted"
        class="primaryctabtn bmt2"
        @click="goToGettingStarted()"
        >{{ $t("continueBtnText") }}</v-btn
      >
    </template>
    <template v-slot:footer v-if="currentStep <= 2">
      <v-btn
        text
        class="cancel no-ripple bmt2 bmr5"
        @click="goToGettingStarted()"
        >{{ $t("cancelBtnText") }}</v-btn
      >
      <v-btn type="submit" form="comp_form" class="primaryctabtn bmt2 bml2">{{
        $t("saveContinueBtnText")
      }}</v-btn>
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyInnerView,
  BrierleyFormTitle,
  brierleyAlert
} from '@brierley/SharedComponents';
import BasicInfo from './child/BasicInfo';
import MoreInfo from './child/MoreInfo';
import { mapState } from 'vuex';
import { companyInfoLayoutObj } from '../../../i18n/language.js';
export default {
  components: {
    BrierleyInnerView,
    BrierleyFormTitle,
    BasicInfo,
    MoreInfo,
    brierleyAlert
  },
  computed: {
    ...mapState('companyModule', ['companyInfoDetails']),
    ...mapState('companyModule', ['companyTypeInfoDetails']),
    alertMessage () {
      return (
        this.$t('companyInfoText') +
        '' +
        `${this.companyInfoDetails.companyName.bold()}` +
        '' +
        this.$t('successfulUpdateText')
      );
    }
  },
  i18n: companyInfoLayoutObj,
  methods: {
    onsubmit () {
      if (this.currentStep === 1) {
        this.$store.dispatch(
          'companyModule/updatedCompanyInfoActions',
          this.companyInfoDetails
        );
        this.currentStep += this.currentStep;
      } else if (this.currentStep === 2) {
        this.$store.dispatch(
          'companyModule/updatedCompanyInfoActions',
          this.companyInfoDetails
        );
        this.currentStep += this.currentStep;
      } else {
        return true;
      }
    },
    goToGettingStarted () {
      this.$router.push('/gettingstarted');
    }
  },
  data () {
    return {
      currentStep: 1
    };
  }
};
</script>

<style lang="scss">
.success-block {
  > .row {
    > .col {
      &:nth-child(2) {
        height: 311px !important;
        max-height: 311px !important;
      }
    }
  }
}
.more-info {
  > .row {
    > .col {
      &:nth-child(2) {
        height: 635px !important;
        max-height: 635px !important;
      }
    }
  }
}
.company-info {
  > .row {
    > .col {
      &:nth-child(2) {
        height: 796px !important;
        max-height: 796px !important;
      }
    }
  }
}
.bmb28 {
  margin-bottom: 28px;
}
</style>
