<template>
  <v-row no-gutters>
    <v-col class="gen2-forms form-light-bg bmt5" cols="5">
      <p class="label-text text-uppercase">{{ $t("companyNameLabel") }}</p>
      <v-text-field
        autocomplete="off"
        :label="$t('companyNameLabel')"
        disabled
        id="company_name"
        filled
        required
        v-model="companyInfoDetails.companyName"
      ></v-text-field>
      <p class="label-text text-uppercase bmt1">{{ $t("companyProfileLabel") }}</p>
      <validation-provider
        id="comp_v_profile"
        rules="descLength"
        v-slot="{ errors }"
      >
        <v-textarea
          filled
          auto-grow
          :label="$t('companyProfileLabel')"
          id="company_profile"
          v-model="companyInfoDetails.companyProfile"
        ></v-textarea>
        <p
          class="custom-error-msg"
          v-if="
            errors[0] != undefined &&
              errors[0].length > 0 &&
              errors[0] === 'Description must be lesser than 500 characters'
          "
        >
          {{ $t("companyProfileError") }}
        </p>
        <p
          class="custom-error-msg"
          v-else-if="errors[0] != undefined && errors[0].length > 0"
        >
          {{ errors[0] }}
        </p>
      </validation-provider>
      <p class="label-text text-uppercase bmt1">{{ $t("companyCorporateLabel") }}</p>
      <validation-provider
        id="comp_v_add1"
        rules="nameLength"
        v-slot="{ errors }"
      >
        <v-text-field
          autocomplete="nope"
          :label="$t('addressLabel')"
          id="company_address1"
          filled
          v-model="companyInfoDetails.address1"
        ></v-text-field>
        <p
          class="custom-error-msg"
          v-if="
            errors[0] != undefined &&
              errors[0].length > 0 &&
              errors[0] === 'Name must be lesser than 50 characters'
          "
        >
          {{ $t("addressLabelError") }}
        </p>
        <p
          class="custom-error-msg"
          v-else-if="errors[0] != undefined && errors[0].length > 0"
        >
          {{ errors[0] }}
        </p>
      </validation-provider>
      <validation-provider
        id="comp_v_add2"
        rules="nameLength"
        v-slot="{ errors }"
      >
        <v-text-field
          autocomplete="nope"
          :label="$t('addressSecondaryLabel')"
          id="company_address2"
          filled
          v-model="companyInfoDetails.address2"
        ></v-text-field>
        <p
          class="custom-error-msg"
          v-if="
            errors[0] != undefined &&
              errors[0].length > 0 &&
              errors[0] === 'Name must be lesser than 50 characters'
          "
        >
         {{ $t("addressSecondaryLabelError") }}
        </p>
        <p
          class="custom-error-msg"
          v-else-if="errors[0] != undefined && errors[0].length > 0"
        >
          {{ errors[0] }}
        </p>
      </validation-provider>
      <validation-provider
        id="comp_v_city"
        rules="nameLength"
        v-slot="{ errors }"
      >
        <v-text-field
          autocomplete="off"
          :label="$t('cityLabel')"
          id="company_city"
          filled
          v-model="companyInfoDetails.city"
        ></v-text-field>
        <p
          class="custom-error-msg"
          v-if="
            errors[0] != undefined &&
              errors[0].length > 0 &&
              errors[0] === 'Name must be lesser than 50 characters'
          "
        >
           {{ $t("cityLabelError") }}
        </p>
        <p
          class="custom-error-msg"
          v-else-if="errors[0] != undefined && errors[0].length > 0"
        >
          {{ errors[0] }}
        </p>
      </validation-provider>
      <v-row class="no-gutters">
        <v-col sm="3">
          <v-select
            :items="stateData"
            filled
            attach
            offset-y
            v-model="companyInfoDetails.state"
            class="gen2select gen2select__light"
            :label="$t('stateLabel')"
            id="company_state"
            append-icon="expand_more"
            @change="checkState"
          ></v-select>
        </v-col>
        <v-col cols="10">
          <v-select
            :items="countryData"
            filled
            attach
            offset-y
            v-model="companyInfoDetails.country"
            id="company_country"
            class="gen2select gen2select__light"
            :label="$t('countryLabel')"
            append-icon="expand_more"
            @change="checkCountry"
          ></v-select>
        </v-col>
      </v-row>
    </v-col>
    <v-col class="bmt5 offset-2" cols="5">
      <brierley-info-side>
        <template v-slot:info-side-header>
          <div class="info_title"><v-icon>info</v-icon>{{ $t("infoText") }}</div>
        </template>
        <template v-slot:info-side-body>
          <p class="">
            {{ $t("infoPassage") }}
          </p>
        </template>
      </brierley-info-side>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyInfoSide } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { basicInfoObject } from './../../../../i18n/language.js';
export default {
  components: {
    BrierleyInfoSide
  },
  computed: {
    ...mapState('companyModule', ['companyInfoDetails'])
  },
  mounted () {
    this.$store.dispatch('companyModule/getCompanyInfoActions');
    this.$store.dispatch('companyModule/getCompanyTypeInfoActions');
  },
  i18n: basicInfoObject,
  methods: {
    checkState (state) {
      this.companyInfoDetails.state = state;
    },
    checkCountry (country) {
      this.companyInfoDetails.country = country;
    }
  },
  data () {
    return {
      companyName: '',
      companyProfile: '',
      address1: '',
      address2: '',
      city: '',
      stateData: [
        'Alabama',
        'Alaska',
        'American Samoa',
        'Arizona',
        'Arkansas',
        'California',
        'Colorado',
        'Connecticut',
        'Delaware',
        'District of Columbia',
        'Federated States of Micronesia',
        'Florida',
        'Georgia',
        'Guam',
        'Hawaii',
        'Idaho',
        'Illinois',
        'Indiana',
        'Iowa',
        'Kansas',
        'Kentucky',
        'Louisiana',
        'Maine',
        'Marshall Islands',
        'Maryland',
        'Massachusetts',
        'Michigan',
        'Minnesota',
        'Mississippi',
        'Missouri',
        'Montana',
        'Nebraska',
        'Nevada',
        'New Hampshire',
        'New Jersey',
        'New Mexico',
        'New York',
        'North Carolina',
        'North Dakota',
        'Northern Mariana Islands',
        'Ohio',
        'Oklahoma',
        'Oregon',
        'Palau',
        'Pennsylvania',
        'Puerto Rico',
        'Rhode Island',
        'South Carolina',
        'South Dakota',
        'Tennessee',
        'Texas',
        'Utah',
        'Vermont',
        'Virgin Island',
        'Virginia',
        'Washington',
        'West Virginia',
        'Wisconsin',
        'Wyoming'
      ],
      countryData: ['USA']
    };
  }
};
</script>
