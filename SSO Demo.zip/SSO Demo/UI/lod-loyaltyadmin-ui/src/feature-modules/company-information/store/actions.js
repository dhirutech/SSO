import {
  getCompanyInfo,
  updateCompanyInfo,
  getCompanyTypeInfo
} from '../api/company-api';

const getCompanyInfoActions = context => {
  getCompanyInfo()
    .then(res => {
      context.commit('getCompanyInfoMutations', res.data);
    })
    .catch();
};
const getCompanyTypeInfoActions = context => {
  getCompanyTypeInfo()
    .then(res => {
      context.commit('getCompanyTypeInfoMutations', res.data);
    })
    .catch();
};
const updatedCompanyInfoActions = (context, payload) => {
  updateCompanyInfo(payload)
    .then(res => {
      context.commit('updateCompanyInfoMutations', res.data);
    })
    .catch();
};
export default {
  getCompanyInfoActions,
  updatedCompanyInfoActions,
  getCompanyTypeInfoActions
};
