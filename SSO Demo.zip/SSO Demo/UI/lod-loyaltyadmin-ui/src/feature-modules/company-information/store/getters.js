const getModuleVar = (state) => state.moduleVar;
const getCompanyInfoGetters = (state) => state.companyInfoDetails;
const getCompanyTypeInfoGetters = (state) => state.companyTypeInfoDetails;
export default {
  getModuleVar,
  getCompanyInfoGetters,
  getCompanyTypeInfoGetters,
};
