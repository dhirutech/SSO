export default {
  moduleVar: 'I am Module',
  dashboard: {},
  companyInfoDetails: {
    companyId: '',
    id: '',
    companyName: '',
    companyProfile: '',
    address1: '',
    address2: '',
    city: '',
    state: '',
    country: '',
    authorName: '',
    authorPositionName: '',
    authorCity: '',
    authorState: '',
    authorCountry: '',
    authorizedUserId: '',
    companyTypeId: '',
    isActive: ''
  },
  companyTypeInfoDetails: [{}]
};
