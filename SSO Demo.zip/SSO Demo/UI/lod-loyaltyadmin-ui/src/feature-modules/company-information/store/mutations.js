const setDashboard = (state, payload) => {
  state.dashboard = payload;
};
const setModuleVar = (state, payload) => {
  state.moduleVar = payload;
};
const getCompanyInfoMutations = (state, payload) => {
  state.companyInfoDetails.authorizedUserId = payload.authorizedUserId;
  state.companyInfoDetails = payload;
};
const updateCompanyInfoMutations = (state, payload) => {
  state.companyInfoDetails = payload;
};
const getCompanyTypeInfoMutations = (state, payload) => {
  state.companyTypeInfoDetails = payload;
};
export default {
  setDashboard,
  setModuleVar,
  getCompanyInfoMutations,
  updateCompanyInfoMutations,
  getCompanyTypeInfoMutations
};
