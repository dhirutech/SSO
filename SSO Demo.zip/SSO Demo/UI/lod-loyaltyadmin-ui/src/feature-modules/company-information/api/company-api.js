import Vue from 'vue';
const getCompanyInfo = () => {
  return Vue.prototype.$http.get('/loyaltyconfiguration/api/v1/company');
};
const getCompanyTypeInfo = () => {
  return Vue.prototype.$http.get('/loyaltyconfiguration/api/v1/companyType');
};
const updateCompanyInfo = updatedCompanyInfo => {
  return Vue.prototype.$http.put(
    '/loyaltyconfiguration/api/v1/company',
    updatedCompanyInfo
  );
};
export { getCompanyInfo, updateCompanyInfo, getCompanyTypeInfo };
