export default {
  moduleVar: 'I am Module',
  dashboard: {},
  getUserData: {},
  breachedPasswordOrNot: false,
  updateUser: {
    firstName: '',
    lastName: '',
    externalId: '',
    phoneNumber: '',
    password: '',
    confirmPassword: ''
  }
};
