import { getUserData, updateUserData } from '../api/signup-api';

const getUserDataActions = (context, payload) => {
  return new Promise((resolve, reject) => {
    getUserData(payload)
      .then((res)=>{
        context.commit('getUserDataMutations', res.data);
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const updateUserActions = (context, payload) => {
  return new Promise((resolve, reject) => {
    updateUserData(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export default {
  getUserDataActions,
  updateUserActions
};
