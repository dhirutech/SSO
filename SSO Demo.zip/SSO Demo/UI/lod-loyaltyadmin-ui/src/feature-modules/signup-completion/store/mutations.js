const getUserDataMutations = (state, payload) => {
  state.getUserData = payload.data;
};

const updateUserMutations = (state, payload) => {
  state.updateUser = payload;
};

const breachedPasswordOrNotMutation = (state, payload) => {
  state.breachedPasswordOrNot = payload;
};

export default {
  getUserDataMutations,
  updateUserMutations,
  breachedPasswordOrNotMutation
};
