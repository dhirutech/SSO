const getModuleVar = (state) => state.moduleVar;
const partialUser = (state) => state.partialUser;

export default {
  getModuleVar,
  partialUser,
};
