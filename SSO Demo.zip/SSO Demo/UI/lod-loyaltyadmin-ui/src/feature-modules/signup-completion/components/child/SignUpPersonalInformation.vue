<template>
  <v-row no-gutters class="d-flex">
    <v-col class="gen2-forms form-light-bg" cols="5">
      <p class="fbold text-uppercase bmt3">User Name</p>
      <v-text-field
        autocomplete="off"
        label="Email"
        id="signup_emmail"
        disabled
        v-model="getUserData.userName"
        filled
      ></v-text-field>
      <p class="fbold text-uppercase bmt1">User Details</p>
      <validation-provider rules="required|alphaSpace" v-slot="{ errors }">
        <v-text-field
          autocomplete="off"
          label="First Name"
          id="signup_fname"
          v-model="getUserData.firstName"
          filled
        ></v-text-field>
        <v-flex v-if="errors[0] != undefined && errors[0].length > 0">
          <v-layout
            class="custom-error-msg"
            v-if="errors[0] === 'This field is required'"
            >Enter First Name</v-layout
          >
          <v-layout class="custom-error-msg" v-else
            >First Name may only contain alphabetic characters</v-layout
          >
        </v-flex>
      </validation-provider>
      <validation-provider rules="required|alphaSpace" v-slot="{ errors }">
        <v-text-field
          autocomplete="off"
          label="Last Name"
          id="signup_lname"
          v-model="getUserData.lastName"
          filled
        ></v-text-field>
        <v-flex v-if="errors[0] != undefined && errors[0].length > 0">
          <v-layout
            class="custom-error-msg"
            v-if="errors[0] == 'This field is required'"
            >Enter Last Name</v-layout
          >
          <v-layout class="custom-error-msg" v-else
            >Last Name may only contain alphabetic characters</v-layout
          >
        </v-flex>
      </validation-provider>

      <v-row class="no-gutters">
        <v-col sm="7">
          <validation-provider
            rules="integer|max:10|min:10"
            v-slot="{ errors }"
          >
            <v-text-field
              autocomplete="off"
              label="Phone Number"
              id="signup_phonenumber"
              filled
              v-model="getUserData.phoneNumber"
            ></v-text-field>
            <v-flex>
              <v-layout
                class="custom-error-msg"
                v-if="errors[0] != undefined && errors[0].length > 0"
                >Phone Number must be 10 characters long</v-layout
              >
            </v-flex>
          </validation-provider>
        </v-col>
      </v-row>
      <p class="fbold text-uppercase bmt1">External ID</p>
      <v-row class="no-gutters">
        <v-col sm="3">
          <v-text-field
            autocomplete="off"
            label="External ID"
            id="signup_externalId"
            filled
            v-model="getUserData.externalId"
          ></v-text-field>
        </v-col>
      </v-row>
      <!-- <v-row>
        <v-col sm="10" class="bmt2">
          <v-divider class="dashed"></v-divider>
        </v-col>
      </v-row> -->

      <!-- <v-row >
        <v-col class="bmt3">
               <p class="fbold text-uppercase">UPLOAD PROFILE PICTURE</p>
          <BrierleyMediaUpload />
        </v-col>
      </v-row> -->
    </v-col>
    <v-col class="bpt3 bmt4 offset-2" cols="5">
      <brierley-info-side>
        <template v-slot:info-side-header>
          <div class="info_title"><v-icon>info</v-icon>Info</div>
        </template>
        <template v-slot:info-side-body>
          <p class="bpl5">
            Please verify and update your personal information as needed.
          </p>
        </template>
      </brierley-info-side>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyInfoSide } from '@brierley/SharedComponents';
// import { BrierleyMediaUpload } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
export default {
  components: {
    BrierleyInfoSide
    // BrierleyMediaUpload,
  },
  computed: {
    ...mapState('signUpModule', ['getUserData'])
  },
  data () {
    return {
      errclass: '',
      valid: false,
      firstName: '',
      lastName: '',
      phoneNumber: ''
    };
  }
};
</script>

<style lang="scss" scoped>
.errclass {
  p {
    color: red;
  }
}
</style>
