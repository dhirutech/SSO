<template>
  <v-row no-gutters class="d-flex">
    <v-col class="gen2-forms form-light-bg" cols="5">
      <p class="fbold text-uppercase bmt3">PASSWORD</p>
      <p class="bmt3">
        A password needs to be created in order to complete your account signup.
        To protect your account, please do not share your password with anyone
        else.
      </p>
      <v-row class="no-gutters bpt1">
        <v-col sm="10">
          <validation-provider
            rules="required|uppercaseletter|specialchar|atleastonenumber|passwordLength"
            v-slot="{ errors }"
            vid="confirmation"
          >
            <v-text-field
              autocomplete="off"
              label="Password"
              id="signup_password"
              type="password"
              filled
              v-model="updateUser.password"
               @input="passwordField()"
            ></v-text-field>
            <v-layout class="custom-error-msg" v-if="breachedPasswordOrNot"
              >There is a problem with this password. Please contact your Administrator
            </v-layout>
            <v-flex v-if="errors[0] != undefined && errors[0].length > 0">
              <v-layout
                class="custom-error-msg"
                v-if="errors[0] == 'This field is required'"
                >Enter Password</v-layout
              >
              <v-layout class="custom-error-msg" v-else>{{
                errors[0]
              }}</v-layout>
            </v-flex>
          </validation-provider>
        </v-col>
      </v-row>
      <v-row class="no-gutters">
        <v-col sm="10">
          <validation-provider
            name="Confirm Password"
            type="password"
            rules="required|confirmed:confirmation"
            v-slot="{ errors }"
          >
            <v-text-field
              autocomplete="off"
              label="Confirm Password"
              id="signup_confirm_password"
              filled
              type="password"
              v-model="updateUser.confirmPassword"
            ></v-text-field>
            <v-flex v-if="errors[0] != undefined && errors[0].length > 0">
              <v-layout
                class="custom-error-msg"
                v-if="errors[0] == 'This field is required'"
                >Password must match</v-layout
              >
              <v-layout class="custom-error-msg" v-else
                >Password does not match</v-layout
              >
            </v-flex>
          </validation-provider>
        </v-col>
      </v-row>
    </v-col>
    <v-col class="bpt3 bmt4 offset-2" cols="5">
      <brierley-info-side>
        <template v-slot:info-side-header>
          <div class="info_title"><v-icon>info</v-icon>Info</div>
        </template>
        <template v-slot:info-side-body>
          <p>
            In order to protect your account, please make sure your password:
          </p>
          <br />
          <v-flex class="bpl1">
            <ol>
              <li>
                Be a minimum of eight (8) characters in length
              </li>
              <li>
                Contain at least one (1) character from four (4) <br />of the
                following categories.
              </li>
            </ol>
          </v-flex>
          <v-flex class="bpl5 bmt2">
            <ul>
              <li>Uppercase letter (A-Z)</li>
              <li>Lowercase letter (a-z)</li>
              <li>Digit (0-9)</li>
              <li>Special character <br />(@#&)</li>
            </ul>
          </v-flex>
        </template>
      </brierley-info-side>
    </v-col>
  </v-row>
</template>

<script>
import { BrierleyInfoSide } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
export default {
  components: {
    BrierleyInfoSide
  },
  computed: {
    ...mapState('signUpModule', ['getUserData', 'updateUser', 'breachedPasswordOrNot'])
  },
  methods: {
    passwordField () {
      this.$store.commit('signUpModule/breachedPasswordOrNotMutation', false);
    }
  },
  data () {
    return {
      password: '',
      confirmPassword: ''
    };
  }
};
</script>
