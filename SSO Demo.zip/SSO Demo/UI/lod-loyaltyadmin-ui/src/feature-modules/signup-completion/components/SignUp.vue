<template>
  <brierley-inner-view>
    <template v-slot:header>
      <span class="inner-head">WELCOME TO LOYALTY ON DEMAND</span>
    </template>

    <template v-slot:body-container :currentStep="currentStep">
      <Validation-Observer v-slot="{ handleSubmit }">
        <form id="user_form" @submit.prevent="handleSubmit(onsubmit)">
          <template v-if="currentStep === 1">
            <v-row class="bmt5">
              <brierley-form-title
                formTitle="PERSONAL INFORMATION"
                :currentStep="1"
                :totalStep="2"
                infoText="Personal information will be used to identify the user and will be displayed on the user’s Profile"
              ></brierley-form-title>
            </v-row>
            <keep-alive>
              <Validation-Observer>
                <PersonalInfo />
              </Validation-Observer>
            </keep-alive>
          </template>
          <template v-if="currentStep === 2">
            <v-row class="bmt5">
              <brierley-form-title
                formTitle="CREATE PASSWORD"
                :currentStep="2"
                :totalStep="2"
                infoText="A password is required to login to Loyalty On Demand. Use the fields below to setup one"
              ></brierley-form-title>
            </v-row>
            <keep-alive>
              <Validation-Observer>
                <create-password />
              </Validation-Observer>
            </keep-alive>
          </template>
        </form>
      </Validation-Observer>
    </template>

    <template v-slot:footer>
      <v-btn
        id="user_btn_cancel"
        v-if="currentStep <= 2"
        text
        class="cancel no-ripple bmt2 bmr5"
        >Cancel</v-btn
      >
      <v-btn
        id="user_btn_roleAssignment"
        v-if="currentStep == 1"
        class="primaryctabtn bmt2 bml2"
        type="submit"
        form="user_form"
        >NEXT : CREATE PASSWORD</v-btn
      >
      <v-btn
        id="user_btn_preview"
        v-else-if="currentStep == 2"
        class="primaryctabtn bmt2"
        type="submit"
        form="user_form"
        >SAVE & PROCEED TO LOGIN</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyInnerView,
  BrierleyFormTitle,
} from '@brierley/SharedComponents';
import CreatePassword from './child/CreatePassword';
import PersonalInfo from './child/SignUpPersonalInformation';
import { mapState } from 'vuex';
export default {
  components: {
    BrierleyInnerView,
    BrierleyFormTitle,
    CreatePassword,
    PersonalInfo,
  },
  computed: {
    ...mapState('signUpModule', ['getUserData', 'updateUser']),
  },
  created () {
    this.$store.commit('signUpModule/breachedPasswordOrNotMutation', false);
  },
  mounted () {
    let obj = {
      userName: this.$route.params.username,
      token: this.$route.params.token,
    };
    this.$store.dispatch('signUpModule/getUserDataActions', obj)
      .catch((err)=>{
        if (err.response.status===412) {
          this.$router.push('/expiredlink');
        }
      });
  },
  methods: {
    onsubmit () {
      if (this.currentStep === 1) {
        this.currentStep = this.currentStep + 1;
      } else {
        let updateUser = {
          id: this.getUserData.userId,
          firstName: this.getUserData.firstName,
          lastName: this.getUserData.lastName,
          externalId: this.getUserData.externalId,
          phoneNumber: this.getUserData.phoneNumber,
          password: btoa(this.updateUser.password)
        };
        this.$store.dispatch('signUpModule/updateUserActions', updateUser)
          .then((res) => {
            debugger
            if (res.status === 201 || res.status === 200) {
              this.$router.push('/login');
            }
          })
          .catch((err)=>{
            if (err.response.status===400) {
              this.$store.commit('signUpModule/breachedPasswordOrNotMutation', true);
            }
          });
      }
    },
  },
  data () {
    return {
      currentStep: 1,
      passwordValue: '',
    };
  },
};
</script>
