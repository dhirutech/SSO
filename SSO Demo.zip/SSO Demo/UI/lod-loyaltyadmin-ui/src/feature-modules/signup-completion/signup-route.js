import SignUp from '../signup-completion/components/SignUp.vue';

const signupuserroutes = [
  {
    path: '/loyaltyadmin/signup/:username/:token',
    name: 'signup',
    component: SignUp,
    meta: {
      showNavigation: false
    }
  }
];

export default signupuserroutes;
