import Vue from 'vue';

const getUserData = params => {
  return Vue.prototype.$http.get(
    '/identity/api/v1/auth/password/' + params.userName + '/' + params.token
  );
};

const updateUserData = updateUserModel => {
  return Vue.prototype.$http.patch(
    '/identity/api/v2/users/password/signup',
    updateUserModel
  );
};

export { getUserData, updateUserData };
