<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <v-row class="gen2-search-filter batch-imports-actions" no-gutters>
        <v-col class="text-left" sm="12" md="4">
          <span class="label-text d-block bmt3" v-if="!toggleSwitchAllFiles">{{
            $t("batchImportListText")
          }}</span>
          <brierley-grid-search
            labelText="Search"
            icon="mdi-magnify"
            @SearchInit="getSearchText"
            v-if="toggleSwitchAllFiles"
          >
          </brierley-grid-search>
        </v-col>
        <v-col sm="12" md="8" class="text-right align-self-center">
          <div
            class="d-inline-block"
            data-qe-id="batch_import_filter_buttom"
            @click="showFiltersCard = !showFiltersCard"
          >
            <brierley-filter></brierley-filter>
          </div>
          <div class="d-inline-block" v-if="!toggleSwitchAllFiles">
            <brierley-view-option
              data-qe-id="batch_import_list_view_options"
              :viewList="cardlist"
              @viewChanged="viewType = $event"
            ></brierley-view-option>
          </div>
          <div class="bmr2 d-inline-block" v-if="isAdminUser">
            <v-btn
              text
              class="no-ripple btn-hover-none bpx0"
              data-qe-id="batch_import_switch_files_button"
              @click="switchAllFiles"
            >
              <span
                class="fbold primary-text"
                data-qe-id="batch_import_detailed_view_switch_all_files_btn"
                v-if="toggleSwitchAllFiles"
              >
                {{ $t("switchImportText") }}
              </span>
              <span
                class="fbold primary-text"
                data-qe-id="batch_import_detailed_view_switch_files_btn"
                v-if="!toggleSwitchAllFiles"
              >
                {{ $t("switchFilesText") }}
              </span>
            </v-btn>
          </div>
          <div
            class="d-inline-block"
            data-qe-id="batch_import_add_new_dialog"
            @click="dialog = true"
            v-if="isAdminUser"
          >
            <brierley-icon-with-head
              class="loyalty-users-common__create-user"
              :iconTitle="$t('addBatchImport')"
              data-qe-id="batch_import_add_new_header_button"
              iconName="add_circle"
            ></brierley-icon-with-head>
          </div>
        </v-col>
        <brierley-filter-result v-if="showFiltersCard" class="bmt1 bpx4 bpt3">
          <template v-slot:body-content>
            <v-row no-gutters class="bmb6">
              <v-col sm="3" class="todate">
                <h3>{{ $t("dateRangeText") }}</h3>
                <v-menu
                  ref="fromDate"
                  data-qe-id="batch_import_from_date_range_menu"
                  v-model="fromDateMenu"
                  :close-on-content-click="hideFromDate"
                  transition="scale-transition"
                  offset-y
                  min-width="290px"
                >
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      clearable
                      v-model="formatedFromDate"
                      :label="$t('fromText')"
                      v-validate="'date_format:dd/MM/yyyy'"
                      data-qe-id="batch_import_filter_from_date"
                      append-icon="event"
                      v-on="on"
                      class="darktxtfield__light"
                      filled
                    ></v-text-field>
                  </template>
                  <v-date-picker
                    data-qe-id="batch_import_from_date_picker"
                    v-model="fromDate"
                    no-title
                    scrollable
                    actions
                    @input="fromDateMenu = false"
                    :max="new Date().toISOString().substr(0, 10)"
                  >
                  </v-date-picker>
                </v-menu>
                <v-menu
                  ref="toDate"
                  data-qe-id="batch_import_to_date_range_menu"
                  v-model="toDateMenu"
                  :close-on-content-click="hideToDate"
                  transition="scale-transition"
                  offset-y
                  min-width="290px"
                >
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      clearable
                      v-model="formatedToDate"
                      :label="$t('toText')"
                      data-qe-id="batch_import_filter_to_date"
                      append-icon="event"
                      v-on="on"
                      class="darktxtfield__light"
                      filled
                    ></v-text-field>
                  </template>
                  <v-date-picker
                    v-model="toDate"
                    data-qe-id="batch_import_from_date_picker"
                    no-title
                    actions
                    scrollable
                    @input="toDateMenu = false"
                    :max="new Date().toISOString().substr(0, 10)"
                  >
                  </v-date-picker>
                </v-menu>
              </v-col>
              <v-col sm="3" offset-sm="1">
                <h3>{{ $t("batchTemplate") }}</h3>
                <v-select
                  :items="batchTemplates"
                  item-text="serviceName"
                  item-value="serviceId"
                  data-qe-id="batch_import_teplate_filter"
                  v-model="batchTemplateId"
                  filled
                  attach
                  offset-y
                  class="gen2select gen2select__light"
                  :label="$t('batchTemplateType')"
                  append-icon="expand_more"
                ></v-select>
                <h3 v-if="!toggleSwitchAllFiles">{{ $t("programEntity") }}</h3>
                <v-select
                  :items="['GAP', 'SAP']"
                  data-qe-id="batch_import_program_entity_filter"
                  v-model="selectedProgramEntity"
                  filled
                  attach
                  offset-y
                  class="gen2select gen2select__light"
                  :label="$t('selectProgramEntity')"
                  v-if="!toggleSwitchAllFiles"
                  append-icon="expand_more"
                ></v-select>
              </v-col>
              <v-col
                sm="3"
                offset-sm="1"
                v-if="toggleSwitchAllFiles">
                <h3>{{ $t("statusText") }}</h3>
                <v-radio-group v-model="status" col hide-details>
                 <v-radio
                  value="Processed"
                  :label="$t('processed')"
                  class="gen2-search-card"
                  data-qe-id="batch_import_status_processed">
                 </v-radio>
                 <v-radio
                  value="Failed"
                  :label="$t('failed')"
                  class="gen2-search-card"
                  data-qe-id="batch_import_status_failed">
                 </v-radio>
                </v-radio-group>
              </v-col>
            </v-row>
          </template>
          <template v-slot:footer>
            <v-btn
              text
              class="mr-5 bmb5 cancel bmt3"
              data-qe-id="batch_import_filter_reset_button"
              @click="resetButton"
              >{{ $t("resetBtn") }}</v-btn
            >
            <v-btn
              depressed
              class="next bmt3 bmb5 primaryctabtn"
              data-qe-id="batch_import_filter_save_button"
              @click="saveButton"
              >{{ $t("saveBtn") }}
            </v-btn>
          </template>
        </brierley-filter-result>
      </v-row>
    </v-col>
    <v-col v-if="!toggleSwitchAllFiles">
      <v-row>
        <v-col v-if="viewType == 'card_view'">
          <batch-imports-card-view
            :batchImportList="batchImportList"
          ></batch-imports-card-view>
        </v-col>
        <v-col v-if="viewType == 'grid_view'">
          <batch-imports-grid-view
            :batchImportList="batchImportList"
          ></batch-imports-grid-view>
        </v-col>
        <v-col v-if="viewType == 'table_view'">
          <batch-imports-table-view
            :batchImportList="batchImportList"
          ></batch-imports-table-view>
        </v-col>
      </v-row>
    </v-col>
    <v-col v-if="toggleSwitchAllFiles">
      <switch-all-files></switch-all-files>
    </v-col>
    <brierley-no-result
      v-if="checkRecords"
      :no-result-message="noResultsMessage"
    ></brierley-no-result>
    <brierley-dialogbox :dialog="dialog" @closeMe="dialog = $event">
      <template v-slot:dialog-header>
        <v-card-title
          class="gen2-dialog-title text-uppercase"
          data-qe-id="batch_import_select_entity_type"
        >
          {{ $t("selectEntityType") }}</v-card-title
        >
      </template>

      <template v-slot:dialog-body-description>
        <v-col>
          <v-row no-gutters class="bpb5 overflow-y-hidden">
            <v-col md="12">
              <p>{{ $t("addImportInfo") }}</p>
            </v-col>
            <v-col md="12">
              <p class="fbold text-uppercase bmt1">
                {{ $t("selectEntity") }}
              </p>
            </v-col>
            <v-col md="5" class="bpb6 bmb4">
              <v-select
                :items="businessEntities"
                data-qe-id="batch_import_entity_type"
                filled
                :label="label"
                item-text="name"
                item-value="businessEntityId"
                attach
                offset-y
                append-icon="expand_more"
                class="gen2select gen2select__dark mini-list"
                v-model="businessEntityId"
              ></v-select>
            </v-col>
          </v-row>
        </v-col>
      </template>
      <template v-slot:dialog-footer>
        <v-row no-gutters>
          <v-col md="12" class="d-flex justify-end align-center">
            <v-btn
              text
              data-qe-id="create_batch_cancel_dialog"
              class="cancel no-ripple bmr6"
              @click="dialog = false"
              >{{ $t("cancel") }}</v-btn
            >
            <v-btn
              data-qe-id="create_batch_import"
              depressed
              :disabled="disabled"
              class="primaryctabtn no-ripple"
              @click.native="createBatchImport()"
            >
              {{ $t("continue") }}
            </v-btn>
          </v-col>
        </v-row>
      </template>
    </brierley-dialogbox>
  </v-row>
</template>

<script>
import {
  BrierleyFilter,
  BrierleyIconWithHead,
  BrierleyViewOption,
  BrierleyDialogbox,
  BrierleyNoResult,
  BrierleyFilterResult,
  BrierleyGridSearch
} from '@brierley/SharedComponents';
import BatchImportsCardView from './child/batchImportsCardView';
import BatchImportsGridView from './child/batchImportsGridView';
import BatchImportsTableView from './child/batchImportsTableView';
import SwitchAllFiles from './child/SwitchAllFiles';
import { mapState } from 'vuex';
import { formatDate } from '../../role/components/listing/utilities';
import { batchImportViewObj } from '../../../i18n/language';

export default {
  i18n: batchImportViewObj,
  components: {
    BrierleyFilter,
    BrierleyIconWithHead,
    BrierleyViewOption,
    BrierleyDialogbox,
    BatchImportsCardView,
    BatchImportsGridView,
    BatchImportsTableView,
    BrierleyNoResult,
    BrierleyFilterResult,
    SwitchAllFiles,
    BrierleyGridSearch
  },
  data () {
    return {
      viewType: 'grid_view',
      showFiltersCard: false,
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('gridViewText')
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('tableViewText')
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('cardViewText')
        }
      ],
      dialog: false,
      toggleSwitchAllFiles: false,
      noResultsMessage: '',
      fromDate: null,
      toDate: null,
      fromDateMenu: false,
      toDateMenu: false,
      hideFromDate: false,
      hideToDate: false,
      formatedFromDate: '',
      formatedToDate: '',
      batchTemplate: '',
      programEntity: '',
      status: '',
      selectedProgramEntity: '',
      businessEntityId: null,
      filterObject: {},
      batchTemplateId: 0,
    };
  },
  computed: {
    ...mapState('batchImportModule', [
      'batchImportList',
      'batchImportFilter',
      'businessEntities',
      'batchImportSwitchFilesFilter',
      'batchTemplates',
      'allFiles'
    ]),
    disabled () {
      return !this.businessEntities.length || !this.businessEntityId;
    },
    label () {
      if (!this.businessEntities.length) return this.$t('noEntities');

      return this.$t('selectEntityType');
    },
    isAdminUser () {
      return this.$globalStore.state.isAdminUser;
    },
    checkRecords () {
      if (this.toggleSwitchAllFiles) {
        return !this.allFiles || !this.allFiles.length;
      }
      return !this.batchImportList.length;
    }
  },
  methods: {
    createBatchImport () {
      const businessEntity = {
        businessEntityId: this.businessEntityId,
        businessEntityName: this.businessEntities.filter(
          x => x.businessEntityId === this.businessEntityId
        )[0].name
      };
      this.$store.commit(
        'batchImportModule/setSelectedBusinessEntity',
        businessEntity
      );
      this.$store.dispatch('batchImportModule/resetBatchImportStep');
      this.$router.push('/loyaltyadmin/addBatchImport');
    },
    dateFormat (date) {
      if (!formatDate) return null;
      const [year, month, day] = date.split('-');
      return `${month}/${day}/${year}`;
    },
    resetButton () {
      this.fromDate = null;
      this.toDate = null;
      this.fromDateMenu = false;
      this.toDateMenu = false;
      this.hideFromDate = false;
      this.hideToDate = false;
      this.formatedFromDate = '';
      this.formatedToDate = '';
      this.selectedProgramEntity = '';
      this.status = '';
      this.batchTemplateId = 0;
    },
    saveButton () {
      if (this.toggleSwitchAllFiles) {
        this.filterObject = { ...this.batchImportSwitchFilesFilter };
      } else {
        this.filterObject = { ...this.batchImportFilter };
      }
      this.filterObject.fromDate = this.formatedFromDate;
      this.filterObject.toDate = this.formatedToDate;
      this.filterObject.programEntity = this.selectedProgramEntity;
      this.filterObject.templateId = this.batchTemplateId;
      this.filterObject.status = this.status;
      if (this.toggleSwitchAllFiles) {
        this.$store.dispatch(
          'batchImportModule/batchImportSwitchFilesFilters',
          this.filterObject
        );
      } else {
        this.$store.dispatch(
          'batchImportModule/batchImportFilters',
          this.filterObject
        );
      }
      this.showFiltersCard = false;
    },
    switchAllFiles () {
      this.resetButton();
      this.toggleSwitchAllFiles = !this.toggleSwitchAllFiles;
      if (this.toggleSwitchAllFiles) {
        this.filterObject = { ...this.batchImportSwitchFilesFilter };
      } else {
        this.filterObject = { ...this.batchImportFilter };
      }
      this.formatedFromDate = this.filterObject.fromDate;
      this.formatedToDate = this.filterObject.toDate;
      this.selectedProgramEntity = this.filterObject.programEntity;
      this.batchTemplateId = this.filterObject.templateId;
      this.status = this.filterObject.status;
      this.showFiltersCard = false;
    },
    getSearchText (value) {
      this.$store.dispatch('batchImportModule/getSearchText', value);
    }
  },
  mounted () {
    if (this.$route.query.showAllFiles || !this.isAdminUser) {
      this.toggleSwitchAllFiles = true;
    }
    if (this.toggleSwitchAllFiles) {
      this.filterObject = { ...this.batchImportSwitchFilesFilter };
    } else {
      this.filterObject = { ...this.batchImportFilter };
    }
    if (this.filterObject['fromDate'] !== undefined) {
      this.formatedFromDate = this.filterObject.fromDate;
      this.formatedToDate = this.filterObject.toDate;
      this.selectedProgramEntity = this.filterObject.programEntity;
      this.batchTemplateId = this.filterObject.templateId;
      this.status = this.filterObject.status;
    }
    this.$store.dispatch('batchImportModule/getBusinessEntities');
    window.scrollTo(0, 0);
  },
  watch: {
    fromDate (value) {
      if (value !== null) {
        this.hideFromDate = true;
        this.formatedFromDate = this.dateFormat(this.fromDate);
      }
    },
    toDate (value) {
      if (value !== null) {
        this.hideToDate = true;
        this.formatedToDate = this.dateFormat(this.toDate);
      }
    },
    fromDateMenu () {
      this.hideFromDate = false;
    },
    toDateMenu () {
      this.hideToDate = false;
    }
  }
};
</script>
<style lang="scss" scoped>
.batch-imports-actions {
  min-height: 60px;
  margin-top: -20px;
}
</style>
