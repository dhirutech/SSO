<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <v-row class="gen2-search-filter" no-gutters>
        <v-col class="text-left label-text bpt1" cols="6">
          {{ $t("encryptionListText") }}
        </v-col>
        <v-col cols="6" class="text-right align-self-center">
          <div class="bmr1 d-inline-block">
            <brierley-view-option
              :viewList="cardlist"
              @viewChanged="viewType = $event"
            ></brierley-view-option>
          </div>
          <div class="d-inline-block">
            <brierley-icon-with-head
              class="loyalty-users-common__create-user"
              :iconTitle="$t('addEncryptionKeyText')"
              :isDisabled="encryptionKeysList.length > 0"
              @clicked="createEncryptionKey()"
              iconName="add_circle"
            ></brierley-icon-with-head>
          </div>
        </v-col>
      </v-row>
    </v-col>
    <v-col v-if="viewType == 'card_view'">
      <encryption-keys-card-view :encryptionKeys="encryptionKeysList" />
    </v-col>
    <v-col v-if="viewType == 'grid_view'">
      <encryption-keys-grid-view :encryptionKeys="encryptionKeysList" />
    </v-col>
    <v-col v-if="viewType == 'table_view'">
      <encryption-keys-table-view :encryptionKeys="encryptionKeysList" />
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyIconWithHead,
  BrierleyViewOption
} from '@brierley/SharedComponents';
import EncryptionKeysCardView from './child/EncryptionKeysCardView';
import EncryptionKeysGridView from './child/EncryptionKeysGridView';
import EncryptionKeysTableView from './child/EncryptionKeysTableView';
import { mapState } from 'vuex';
import { encryptionKeyObj } from '../../../i18n/language';
export default {
  i18n: encryptionKeyObj,
  components: {
    BrierleyIconWithHead,
    BrierleyViewOption,
    EncryptionKeysCardView,
    EncryptionKeysGridView,
    EncryptionKeysTableView
  },
  data () {
    return {
      viewType: 'grid_view',
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('gridViewText')
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('tableViewText')
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('cardViewText')
        }
      ]
    };
  },
  created () {
    window.scrollTo(0, 0);
  },
  computed: {
    ...mapState('batchImportModule', ['encryptionKeysList'])
  },
  methods: {
    createEncryptionKey () {
      this.$store.dispatch('batchImportModule/getEncryptionKey', {
        encryptionKeyName: '',
        encryptionKeyDescription: '',
        algorithm: 'RSA',
        keySize: 4096,
        expiration: 'Never',
        passphrase: '',
        publicKey: '',
        privateKey: '',
        isEdit: false
      });
      this.$router.push({
        name: 'createEncryption'
      });
    }
  }
};
</script>
<style lang="scss">
.download-lock {
  display: inline-block;
  color: #4b9609;
  position: relative;
  &__icon {
    position: absolute !important;
    font-size: 10px !important;
    right: 2px;
    bottom: 1px;
  }
}
.primaryctabtn {
  &.large {
    min-width: 240px !important;
  }
}
</style>
