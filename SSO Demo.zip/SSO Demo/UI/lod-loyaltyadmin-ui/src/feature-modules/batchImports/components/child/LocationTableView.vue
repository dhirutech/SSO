<template>
  <v-row class="flex-column" no-gutter>
    <brierley-table-module v-if="locations.length">
      <template v-slot:tablehead>
        <tr class="text-left">
          <th
            v-for="item in header"
            :key="item.name"
            class="text-left"
            :width="item.width"
          >{{ item.text }}
          </th>
        </tr>
      </template>
      <template v-slot:tablebody>
        <tr v-for="(location, i) in locations" :key="i">
          <td>
            <v-row
              class="d-flex head-name"
              :title="location.locationName"
              no-gutters
            >
              <v-col
                class="elipsis-twoline max-width-full"
                :title="location.locationName"
                >{{ location.locationName }}</v-col
              >
            </v-row>
          </td>
          <td>{{ location.locationType }}</td>
          <td>
            <span class="elipsis-twoline" :title="location.hostname">{{
              location.hostname
            }}</span>
          </td>
          <td>
            <div
              :title="location.locationDescription"
              class="elipsis-description"
            >
              {{ location.locationDescription }}
            </div>
          </td>
          <td class="text-nowrap">
            {{ format_date(location.createdDate)[0] }}<br />{{
              format_date(location.createdDate)[1]
            }}
          </td>
          <td class="text-nowrap">
            {{ format_date(location.updatedDate)[0] }}<br />{{
              format_date(location.updatedDate)[1]
            }}
          </td>
          <td>
            <brierleyStatus status="Active"></brierleyStatus>
            <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
              <v-col>
                <brierleyCardIcons>
                  <template v-slot:action-icons>
                    <span
                      class="active"
                      :id="`batch_location_table_edit_${i}`"
                      @click="editLocation(location)"
                    >
                      <v-icon :title="$t('edit')" class="blackicon"
                        >fe fe-edit</v-icon
                      >
                      <span class="edit-icon">{{ $t("edit") }}</span>
                    </span>
                    <span
                      @click="deletePopup(location.locationId, i)"
                      :id="`batch_location_table_delete_${i}`"
                    >
                      <v-icon :title="$t('delete')" class="blackicon"
                        >fe-trash-2</v-icon
                      >
                      <span class="delete-icon">{{ $t("delete") }}</span>
                    </span>
                  </template>
                </brierleyCardIcons>
              </v-col>
            </v-row>
          </td>
        </tr>
      </template>
    </brierley-table-module>
  </v-row>
</template>

<script>
import {
  BrierleyStatus,
  BrierleyCardIcons,
  BrierleyTableModule
} from '@brierley/SharedComponents';
import moment from 'moment';
import { locationsCardViewObj } from '../../../../i18n/language';

export default {
  i18n: locationsCardViewObj,
  data () {
    return {
      sortKey: ['name'],
      sortOrder: ['asc'],
      isToggled: false,
      changeColor: false,

      header: [
        { name: 'locationName', text: this.$t('locationName'), sort: 'asc' },
        { name: 'locationType', text: this.$t('locationType'), sort: '' },
        { name: 'hostname', text: this.$t('hostName'), sort: '' },
        {
          name: 'locationDescription',
          text: this.$t('description'),
          sort: '',
          width: '215'
        },
        {
          name: 'createdDate',
          text: this.$t('createdDate'),
          sort: '',
          width: '150'
        },
        {
          name: 'updatedDate',
          text: this.$t('lastEditedDate'),
          sort: '',
          width: '160'
        },
        { name: 'status', text: this.$t('status'), sort: '', width: '180' }
      ]
    };
  },
  components: {
    BrierleyStatus,
    BrierleyCardIcons,
    BrierleyTableModule
  },
  props: {
    locations: {
      type: Array,
      default: () => []
    }
  },
  methods: {
    format_date (value) {
      if (value) {
        let date = moment(value).format('MMM Do YYYY');
        let time = moment(value).format('hh:mm A');
        return [date, time];
      }
    },
    deletePopup (id, index) {
      this.$emit('deleteLocation', id, index);
    },
    editLocation (location) {
      this.$store.commit('batchImportModule/updateLocationInfo', location);
      this.$router.push({
        name: 'editLocation',
        params: { id: location.locationId }
      });
    }
  }
};
</script>
