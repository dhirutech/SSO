<template>
  <v-col>
    <v-row no-gutters>
      <v-col cols="12">
        <h3 class="fbold font24 bmt1">{{$t("batchImportDetailedText")}}</h3>
        <v-row no-gutters class="bmt4">
          <v-col cols="12" md="4">
            <p>
              <strong class="d-block">{{$t("batchTemplateText")}}</strong>
              <span>{{batchImportItem.serviceName}}</span>
            </p>
            <p>
              <strong class="d-block">{{$t("fileLocation")}}</strong>
              <span>{{batchImportItem.locationPath}}</span>
            </p>
            <p>
              <strong class="d-block">{{$t("description")}}</strong>
              <span>{{batchImportItem.description}}</span>
            </p>
          </v-col>
          <v-col cols="12" md="4" class="bpl3">
            <p>
              <strong class="d-block">{{$t("fileEncryptionText")}}</strong>
              <span>{{batchImportItem.fileEncryptionId}}</span>
            </p>
            <p>
              <strong class="d-block">{{$t("createdDate")}}:</strong>
              <span>{{format_date(batchImportItem.createdDate)[0]}} {{format_date(batchImportItem.createdDate)[1]}}</span>
            </p>
          </v-col>
        </v-row>
        <v-divider class="bmy4 divider dashed"></v-divider>
        <v-row no-gutters>
          <v-col cols="12" md="5">
            <brierley-grid-search
              :labelText="$t('search')"
              data-qe-id="batch_import_detailed_view_search"
              icon="mdi-magnify"
              @SearchInit="getSearch"
            >
            </brierley-grid-search>
          </v-col>
          <v-col
            cols="12"
            md="2" offset-md="5"
            class="text-right"
            data-qe-id="batch_import_detailed_view_filter_btn"
            @click="showFiltersCard = !showFiltersCard">
            <brierley-filter></brierley-filter>
          </v-col>
        </v-row>
        <brierley-filter-result v-if="showFiltersCard" class="bmt1 bpx4 bpt3">
          <template v-slot:body-content>
            <v-row no-gutters class="bmb6">
              <v-col sm="3" class="todate">
                <h3>{{ $t('dateRangeText') }}</h3>
                <v-menu
                  ref="fromDate"
                  data-qe-id="batch_import_from_date_range_menu"
                  v-model="fromDateMenu"
                  :close-on-content-click="hideFromDate"
                  transition="scale-transition"
                  offset-y
                  min-width="290px"
                >
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      clearable
                      v-model="formatedFromDate"
                      :label="$t('fromText')"
                      v-validate="'date_format:dd/MM/yyyy'"
                      data-qe-id="batch_import_filter_from_date"
                      append-icon="event"
                      v-on="on"
                      class="darktxtfield__light"
                      filled
                    ></v-text-field>
                  </template>
                  <v-date-picker
                    data-qe-id="batch_import_from_date_picker"
                    v-model="fromDate"
                    no-title
                    scrollable
                    actions
                    @input="fromDateMenu = false"
                  >
                  </v-date-picker>
                </v-menu>
                <v-menu
                  ref="toDate"
                  data-qe-id="batch_import_to_date_range_menu"
                  v-model="toDateMenu"
                  :close-on-content-click="hideToDate"
                  transition="scale-transition"
                  offset-y
                  min-width="290px"
                >
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      clearable
                      v-model="formatedToDate"
                      :label="$t('toText')"
                      data-qe-id="batch_import_filter_to_date"
                      append-icon="event"
                      v-on="on"
                      class="darktxtfield__light"
                      filled
                    ></v-text-field>
                  </template>
                  <v-date-picker
                    v-model="toDate"
                    data-qe-id="batch_import_from_date_picker"
                    no-title
                    actions
                    scrollable
                    @input="toDateMenu = false"
                  >
                  </v-date-picker>
                </v-menu>
              </v-col>
              <v-col sm="3" offset-sm="1">
                <h3>Status</h3>
                <v-checkbox
                  class="mx-2 checkbox-custom checkbox-custom__light"
                  data-qe-id="batch_import_status_processed"
                  v-model="status.processed"
                  :label="$t('processed')"
                ></v-checkbox>
                <v-checkbox
                  class="mx-2 checkbox-custom checkbox-custom__light"
                  data-qe-id="batch_import_status_failed"
                  v-model="status.failed"
                  :label="$t('failed')"
                ></v-checkbox>
              </v-col>
            </v-row>
          </template>
          <template v-slot:footer>
            <v-btn
              text
              class="mr-5 bmb5 cancel bmt3"
              data-qe-id="batch_import_filter_reset_button"
              @click="resetButton"
              >{{ $t('resetBtn') }}</v-btn
            >
            <v-btn
              depressed
              class="next bmt3 bmb5 primaryctabtn"
              data-qe-id="batch_import_filter_save_button"
              @click="saveButton"
              >{{ $t('saveBtn') }}
            </v-btn>
          </template>
        </brierley-filter-result>
        <brierley-table-module class="bmr0 ml-n2">
          <template v-slot:tablehead>
            <tr class="text-left">
              <th v-for="item in header" :key="item.name">
                {{ item.text }}
              </th>
            </tr>
          </template>
          <template v-slot:tablebody>
            <tr v-for="(importItem, i) in filteredBatchImportList" :key="i">
              <td>{{ importItem.fileName }}</td>
              <td class="text-nowrap">
              <span v-if="importItem.fileUploadedDate">
                {{ format_date(importItem.fileUploadedDate)[0] }}<br />{{
                format_date(importItem.fileUploadedDate)[1]
                }}
              </span>
              </td>
              <td class="text-nowrap">
              <span v-if="importItem.fileProcessingEndDate">
                {{ format_date(importItem.fileProcessingEndDate)[0] }}<br />{{
                format_date(importItem.fileProcessingEndDate)[1]
                }}
              </span>
              </td>
              <td>
                <brierley-status v-if="importItem.fileProcessingStatus === 'Processed'" status="Processed">
                </brierley-status>
                <brierley-status v-if="importItem.fileProcessingStatus === 'Failed'" status="Failed">
                </brierley-status>
              </td>
              <td>
                <v-btn text class="no-ripple btn-hover-none bpx0" data-qe-id="batch_import_detailed_view_download_btn">
                  <span class="fbold primary-text">
                    <span class="download-lock">
                    <v-icon>get_app</v-icon>
                    <v-icon class="download-lock__icon">lock</v-icon>
                    </span>
                    Download
                  </span>
                </v-btn>
              </td>
            </tr>
          </template>
        </brierley-table-module>
      </v-col>
    </v-row>
  </v-col>
</template>

<script>
import { BrierleyTableModule,
  BrierleyStatus,
  BrierleyFilter,
  BrierleyGridSearch,
  BrierleyFilterResult } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { formatDate } from '../../../role/components/listing/utilities';
import { batchImportViewDetailsObj } from '../../../../i18n/language';
import moment from 'moment';
export default {
  i18n: batchImportViewDetailsObj,
  components: {
    BrierleyTableModule,
    BrierleyStatus,
    BrierleyFilter,
    BrierleyGridSearch,
    BrierleyFilterResult
  },
  data () {
    return {
      header: [
        { name: 'fileName', text: this.$t('fileName'), sort: 'asc' },
        { name: 'uploadDate', text: this.$t('uploadedDate'), sort: '', width: '' },
        { name: 'processedDate', text: this.$t('processedDate'), sort: '', width: '' },
        { name: 'status', text: this.$t('status'), sort: '', width: '' },
        { name: 'failedRecords', text: this.$t('failedRecords'), sort: '', width: '' }
      ],
      batchImportDetailedList: [
        {
          fileName: 'Product_202010081740',
          templateName: 'Product',
          uploadDate: 'Jan 31st 2019',
          recordsLoaded: 30436,
          recordsFailed: 234,
          processedDate: 'Jan 31st 2019',
          status: 'Processed',
          failedRecords: 'Download'
        }
      ],
      search: '',
      showFiltersCard: false,
      fromDate: null,
      toDate: null,
      fromDateMenu: false,
      toDateMenu: false,
      hideFromDate: false,
      hideToDate: false,
      formatedFromDate: null,
      formatedToDate: null,
      batchTemplate: '',
      programEntity: '',
      status: {
        processed: false,
        failed: false
      },
    };
  },
  methods: {
    getSearch (value) {
      this.search = value;
    },
    dateFormat (date) {
      if (!formatDate) return null;
      const [year, month, day] = date.split('-');
      return `${month}/${day}/${year}`;
    },
    resetButton () {
      this.fromDate = null;
      this.toDate = null;
      this.fromDateMenu = false;
      this.toDateMenu = false;
      this.hideFromDate = false;
      this.hideToDate = false;
      this.formatedFromDate = null;
      this.formatedToDate = null;
      this.status.processed = false;
      this.status.failed = false;
      this.batchImportDetailedViewFilters.fromDate = '';
      this.batchImportDetailedViewFilters.toDate = '';
      this.batchImportDetailedViewFilters.searchText = '';
      this.batchImportDetailedViewFilters.status = '';
      this.batchImportDetailedViewFilters.batchImportId = this.batchImportItem.batchImportId;
      this.$store.dispatch(
        'batchImportModule/batchImportDetailedViewFilters',
        this.batchImportDetailedViewFilters
      );
      this.$store.dispatch(
        'batchImportModule/getBatchImportFiles',
        this.batchImportDetailedViewFilters
      );
    },
    saveButton () {
      this.batchImportDetailedViewFilters.fromDate = this.formatedFromDate ?? '';
      this.batchImportDetailedViewFilters.toDate = this.formatedToDate ?? '';
      this.batchImportDetailedViewFilters.searchText = '';
      this.batchImportDetailedViewFilters.batchImportId = this.batchImportItem.batchImportId;
      if(this.status.processed){
          this.batchImportDetailedViewFilters.status = 'processed';
      }
      if(this.status.failed){
          this.batchImportDetailedViewFilters.status = 'failed';
      }
      if(this.status.processed && this.status.failed){
          this.batchImportDetailedViewFilters.status = 'all';
      }
      this.$store.dispatch(
        'batchImportModule/batchImportDetailedViewFilters',
        this.batchImportDetailedViewFilters
      );
      this.$store.dispatch(
        'batchImportModule/getBatchImportFiles',
        this.batchImportDetailedViewFilters
      );
      this.showFiltersCard = false;
    },
    switchAllFiles () {
      this.toggleSwitchAllFiles = !this.toggleSwitchAllFiles;
    },
    getSearchText (value) {
      this.$store.dispatch('batchImportModule/getSearchText', value);
    },
    format_date (value) {
      if (value) {
        let date = moment(value).format('MMM Do YYYY');
        let time = moment(value).format('hh:mm A');
        return [date, time];
      }
    }
  },
  mounted () {
    if (this.batchImportDetailedViewFilters['fromDate'] !== undefined) {
      this.formatedFromDate = this.batchImportDetailedViewFilters.fromDate;
      this.formatedToDate = this.batchImportDetailedViewFilters.batchTemplate;
      this.status.processed = this.batchImportDetailedViewFilters.processed;
      this.status.failed = this.batchImportDetailedViewFilters.failed;
    }
  },
  computed: {
    filteredBatchImportList: function () {
      if(this.batchImportFiles){
      return this.batchImportFiles.filter ((importItem) => {
        return importItem.fileName.toLowerCase().match(this.search);
      });
      }else{
        return [];
      }
    },
    ...mapState('batchImportModule', ['batchImportDetailedViewFilters', 'batchImportItem', 'batchImportFiles'])
  },
  watch: {
    fromDate (value) {
      if (value !== null) {
        this.hideFromDate = true;
        this.formatedFromDate = this.dateFormat(this.fromDate);
      }
    },
    toDate (value) {
      if (value !== null) {
        this.hideToDate = true;
        this.formatedToDate = this.dateFormat(this.toDate);
      }
    },
    fromDateMenu () {
      this.hideFromDate = false;
    },
    toDateMenu () {
      this.hideToDate = false;
    }
  }
};
</script>
