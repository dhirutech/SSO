<template>
  <brierley-inner-view>
    <template v-slot:header>
      <v-flex class="toggle-menu-custom">
        <v-btn class="no-ripple iconbtn" text @click="menutoggle = !menutoggle">
          <v-icon>
            fe-menu
          </v-icon>
        </v-btn>
        <brierley-toggle-menu v-if="menutoggle"></brierley-toggle-menu>
      </v-flex>
      <span class="inner-head text-uppercase">
        <small class="white-text" data-qe-id="edit_encrYption_btn"
          >{{ $t("batchImportText") }}
        </small>
        / {{ $t("editEncrYption") }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        data-qe-id="back_btn"
        text
        @click.native="backNavigation"
      >
        <v-icon>arrow_back</v-icon>{{ $t("back") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <brierley-form-title
        class="bmt3"
        :formTitle="$t('reviewText')"
        :infoText="$t('reviewInfo')"
        :showSteps="false"
      ></brierley-form-title>
      <div class="bmt5">
        <v-row no-gutters>
          <v-col
            ><p class="text-uppercase f600 font18">
              {{ $t("basicInformation") }}
            </p>
          </v-col>
          <v-col cols="12" sm="2" class="text-right">
            <v-btn
              text
              class="no-ripple btn-hover-none bpx0"
              @click.native="editEncryption"
            >
              <span class="f600 primary-text"
                ><v-icon class="body-text">edit</v-icon
                >{{ $t("editText") }}</span
              >
            </v-btn>
          </v-col>
        </v-row>
        <v-divider></v-divider>
        <v-row no-gutters class="bmt5">
          <v-col>
            <p>
              <strong>{{ $t("encryptionKeyName") }}:</strong>
              {{ encryptionKey.encryptionKeyName }}
            </p>
            <p>
              <strong>{{ $t("encryptionKeyDescription") }}:</strong>
              {{ encryptionKey.encryptionKeyDescription }}
            </p>
            <p>
              <strong>{{ $t("algorithm") }}</strong>
              {{ encryptionKey.algorithm }}
            </p>
            <p>
              <strong> {{ $t("keySize") }}:</strong> {{ encryptionKey.keySize }}
            </p>
            <p>
              <strong>{{ $t("expiration") }}:</strong>
              {{ encryptionKey.expiration }}
            </p>
            <p>
              <strong>{{ $t("passphrase") }}:</strong>
              {{ encryptionKey.passphrase.replace(/[^\s]/g, "*") }}
            </p>
          </v-col>
        </v-row>
        <brierley-dialogbox :dialog="dialog" @closeMe="dialog = $event">
          <template v-slot:dialog-header>
            <v-card-title class="gen2-dialog-title text-uppercase">
              {{ $t("regeneratekey") }}</v-card-title
            >
          </template>

          <template v-slot:dialog-body-description>
            <v-col>
              <v-row no-gutters>
                <v-col cols="12">
                  <brierley-alert
                    alertType="warning"
                    :alertBody="$t('alertBodyMessage')"
                    :alertHeader="$t('alertHeader')"
                    icon="notifications_active"
                  ></brierley-alert>
                </v-col>
                <v-col cols="12" class="bmt2">
                  <p>{{ $t("confirmMessage") }}</p>
                </v-col>
                <v-col cols="12" class="text-right bmt6">
                  <v-btn
                    text
                    class="cancel no-ripple bmr6"
                    @click="dialog = false"
                    >{{ $t("no") }}</v-btn
                  >
                  <v-btn
                    text
                    class="primaryctabtn no-ripple"
                    data-qe-id="alert_yes_btn"
                    @click.native="generateKey"
                  >
                    {{ $t("yes") }}
                  </v-btn>
                </v-col>
              </v-row>
            </v-col>
          </template>
        </brierley-dialogbox>
      </div>
    </template>

    <template v-slot:footer>
      <v-btn text class="cancel no-ripple bmr6" data-qe-id="alert_cancel_btn">{{
        $t("cancel")
      }}</v-btn>
      <v-btn
        text
        class="primaryctabtn no-ripple large"
        data-qe-id="encrYption_register_key_btn"
        @click="dialog = true"
        >{{ $t("regeneratekey") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>

<script>
import {
  BrierleyInnerView,
  BrierleyToggleMenu,
  BrierleyFormTitle,
  BrierleyDialogbox,
  brierleyAlert
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { editEncryptionObj } from '../../../i18n/language';

export default {
  i18n: editEncryptionObj,
  components: {
    BrierleyInnerView,
    BrierleyToggleMenu,
    BrierleyFormTitle,
    BrierleyDialogbox,
    brierleyAlert
  },
  data () {
    return {
      menutoggle: false,
      dialog: false
    };
  },
  created () {
    window.scrollTo(0, 0);
  },
  computed: {
    ...mapState('batchImportModule', ['encryptionKey'])
  },
  methods: {
    generateKey () {
      if (this.encryptionKey.isEdit) {
        this.updateKey();
      } else {
        this.createKey();
      }
    },
    createKey () {
      let encryptionObj = { ...this.encryptionKey };
      delete encryptionObj.isEdit;
      this.$store.dispatch(
        'batchImportModule/createEncryptionKeySetup',
        encryptionObj
      );
      this.$router.push('/loyaltyadmin/successEncryption');
    },
    updateKey () {
      let encryptionObj = { ...this.encryptionKey };
      delete encryptionObj.isEdit;
      this.$store.dispatch(
        'batchImportModule/updateEncryptionKey',
        encryptionObj
      );
      this.$router.push('/loyaltyadmin/successEncryption');
    },
    editEncryption () {
      if (this.encryptionKey.isEdit) {
        this.$router.push({
          name: 'editEncryption',
          params: { id: this.encryptionKey.encryptionId }
        });
      } else {
        this.$router.push({
          name: 'createEncryption'
        });
      }
    },
    backNavigation () {
      if (this.encryptionKey.isEdit) {
        this.$router.push({
          name: 'editEncryption',
          params: { id: this.encryptionKey.encryptionId }
        });
      } else {
        this.$router.push({
          name: 'createEncryption'
        });
      }
    }
  }
};
</script>
