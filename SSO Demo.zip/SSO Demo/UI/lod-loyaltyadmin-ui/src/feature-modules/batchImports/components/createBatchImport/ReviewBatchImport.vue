<template>
  <div>
    <brierley-form-title
      class="bmt3"
      :formTitle="$t('reviewText')"
      :infoText="$t('reviewInfoText')"
      :showSteps="false"
    ></brierley-form-title>
    <div class="bmt5">
      <v-row no-gutters>
        <v-col
          ><p class="text-uppercase f600 font18">{{ $t("basicInfoText") }}</p>
        </v-col>
        <v-col cols="12" sm="2" class="text-right">
          <v-btn
            text
            class="no-ripple btn-hover-none bpx0"
            data-qe-id="create_batch_edit_btn"
            @click="goToCreate()"
          >
            <span class="f600 primary-text"
              ><v-icon class="body-text">edit</v-icon> {{ $t("edit") }}</span
            >
          </v-btn>
        </v-col>
      </v-row>
      <v-divider></v-divider>
      <v-row class="flex-column bmt4" no-gutters>
        <v-col>
          <p class="text-uppercase f600 font18 bmb3">
            {{ $t("batchImportDetails") }}
          </p>
          <p>
            <strong>{{ $t("batchName") }}:</strong>
            {{ batchImportInfo.batchImportName }}
          </p>
          <p>
            <strong>{{ $t("batchTemplateText") }}:</strong>
            {{ batchImportInfo.serviceName }}
          </p>
          <p>
            <strong>{{ $t("selectProgramText") }}:</strong>
            {{ batchImportInfo.programName }}
          </p>
          <p>
            <strong>{{ $t("fileLocationText") }}:</strong>
            {{ batchImportInfo.locationPath }}
          </p>
          <p>
            <strong>{{ $t("namingConvention") }}:</strong>
            {{ getNamingConvention }}
          </p>
          <v-divider class="dashed-border"></v-divider>
        </v-col>
        <v-col>
          <p class="text-uppercase f600 font18 bmb3">
            {{ $t("emailNotificationText") }}
          </p>
          <p>
            <strong>{{ $t("emailNotificationMessage") }}:</strong>
            {{ batchImportInfo.fileReceiptNotificationEmail }}
          </p>
          <p>
            <strong>{{ $t("emailNotificationProcessFails") }}:</strong>
            {{ batchImportInfo.fileProcessFailureNotificationEmail }}
          </p>
          <p>
            <strong>{{ $t("emailNotificationComplete") }}:</strong>
            {{ batchImportInfo.fileProcessCompletionNotificationEmail }}
          </p>
          <v-divider class="dashed-border"></v-divider>
        </v-col>
        <v-col>
          <p class="text-uppercase f600 font18 bmb3">
            {{ $t("encryptionKey") }}
          </p>
          <p>
            <strong>{{ $t("fileEncryptionKeyText") }}:</strong>
            {{ batchImportInfo.encryptionKeyName }}
          </p>
          <!-- <v-divider class="dashed-border"></v-divider> -->
        </v-col>
        <!-- <v-col>
          <p class="text-uppercase f600 font18 bmb3">
            {{ $t("setDeliveryTime") }}
          </p>
          <p>
            <strong>{{ $t("setDeliveryTime") }}:</strong> Yes
          </p>
          <p>
            <strong>{{ $t("expectedDeliveryby") }}:</strong> Monthly
          </p>
          <p>
            <strong>{{ $t("SelectedDaysoftheMonth") }}:</strong> 10, 15
          </p>
          <v-divider class="dashed-border"></v-divider>
        </v-col>
        <v-col>
          <p class="text-uppercase f600 font18 bmb3">{{ $t("timeZone") }}</p>
          <p>
            <strong>{{ $t("selectedTime") }}:</strong> 12:00 AM
          </p>
          <p>
            <strong>{{ $t("gracePeriod") }}:</strong> 3 Hours
          </p>
          <p>
            <strong>{{ $t("timeZoneText") }}:</strong> (UTC- 6:00) Central
            America
          </p>
          <v-divider class="dashed-border"></v-divider>
        </v-col>
        <v-col>
          <p class="text-uppercase f600 font18 bmb3">{{ $t("emailAlert") }}</p>
          <p><strong>Email:</strong> {{ batchImportInfo.email }}</p>
          <v-divider class="dashed-border"></v-divider>
        </v-col>
        <v-col>
          <p class="text-uppercase f600 font18 bmb3">
            {{ $t("processDuplicateFiles") }}
          </p>
          <p>
            <strong>{{ $t("duplicateFiles") }}:</strong>
            {{ batchImportInfo.addDuplicate }}
          </p>
          <v-divider class="dashed-border"></v-divider>
        </v-col>
        <v-col>
          <p class="text-uppercase f600 font18 bmb3">
            {{ $t("rejectedFiles") }}
          </p>
          <p>
            <strong>{{ $t("rejectedFiles") }}:</strong>
            {{ batchImportInfo.rejectFile }}
          </p>
        </v-col> -->
      </v-row>
    </div>
  </div>
</template>

<script>
import { BrierleyFormTitle } from '@brierley/SharedComponents';
import { basicInforimationObj } from '../../../../i18n/language';

export default {
  i18n: basicInforimationObj,
  components: {
    BrierleyFormTitle
  },
  data () {
    return {};
  },
  props: {
    batchImportInfo: {
      type: Object
    }
  },
  computed: {
    getNamingConvention () {
      return `${
        this.batchImportInfo.namingConvention
      }_${this.batchImportInfo.businessEntityName.split(' ').join('')}`;
    }
  },
  methods: {
    goToCreate () {
      this.$emit('openCreatePage');
    },
    saveBatchImport () {
      this.batchImportInfo.isReview = false;
      this.batchImportInfo.namingConvention = this.getNamingConvention;
      if (this.batchImportInfo.batchImportId) {
        this.$store.dispatch(
          'batchImportModule/updateBatchImport',
          this.batchImportInfo
        );
      } else {
        this.$store.dispatch(
          'batchImportModule/createBatchImport',
          this.batchImportInfo
        );
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.dashed-border {
  border: 1px dashed rgba(102, 102, 102, 0.3);
  margin: 24px 0;
}
</style>
