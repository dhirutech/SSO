<template>
  <div>
    <brierley-form-title
      class="bmt3"
      :formTitle="$t('basicInfoText')"
      :infoText="$t('basicInfoMessage')"
      :showSteps="false"
    ></brierley-form-title>
    <div class="bmt5">
      <v-row>
        <v-col sm="12" class="bmb3" v-if="importError">
          <brierley-alert
            class="bmb0"
            :isSiteLevel="true"
            alertType="error"
            :alertBody="importError"
            alertHeader="Error"
            icon="notifications_active"
          ></brierley-alert>
        </v-col>
        <v-col cols="12" sm="8" class="gen2-forms form-light-bg">
          <p>
            <strong class="text-uppercase">{{
              $t("batchImportDetails")
            }}</strong>
          </p>
          <v-row no-gutters>
            <v-col cols="12" md="6">
              <validation-provider
                rules="required|alphaNumericOnly"
                v-slot="{ errors }"
              >
                <v-text-field
                  data-qe-id="create_batch_name"
                  :label="$t('batchName')"
                  filled
                  :disabled="!canCreate"
                  v-model="batchImportInfo.batchImportName"
                />
                <p
                  v-if="errors[0] === 'This field is required'"
                  class="custom-error-msg"
                >
                  {{ $t("batchNameMessage") }}
                </p>
                <p v-else class="custom-error-msg">
                  {{ errors[0] }}
                </p>
              </validation-provider>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="12" md="9">
              <validation-provider rules="required" v-slot="{ errors }">
                <v-textarea
                  data-qe-id="create_batch_description"
                  :label="$t('batchDescription')"
                  filled
                  auto-grow
                  v-model="batchImportInfo.description"
                >
                </v-textarea>
                <p
                  v-if="errors[0] === 'This field is required'"
                  class="custom-error-msg"
                >
                  {{ $t("batchDescriptionMessage") }}
                </p>
              </validation-provider>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="12" md="6">
              <validation-provider rules="required" v-slot="{ errors }">
                <v-select
                  data-qe-id="create_batch_template"
                  :items="batchTemplates"
                  filled
                  :label="$t('batchTemplate')"
                  item-text="serviceName"
                  item-value="serviceId"
                  attach
                  offset-y
                  append-icon="expand_more"
                  class="gen2select gen2select__dark"
                  v-model="batchImportInfo.serviceId"
                  :disabled="!canCreate"
                  @change="setServiceName(batchImportInfo.serviceId)"
                ></v-select>
                <p
                  v-if="errors[0] === 'This field is required'"
                  class="custom-error-msg"
                >
                  {{ $t("batchTemplateMessage") }}
                </p>
              </validation-provider>
              <validation-provider rules="required" v-slot="{ errors }">
                <v-select
                  data-qe-id="create_batch_program"
                  :items="getPrograms"
                  filled
                  :label="$t('selectProgram')"
                  item-text="name"
                  item-value="programId"
                  attach
                  offset-y
                  append-icon="expand_more"
                  class="gen2select gen2select__dark"
                  v-model="batchImportInfo.programId"
                  :disabled="!canCreate"
                  @change="setProgramName(batchImportInfo.programId)"
                ></v-select>
                <p
                  v-if="errors[0] === 'This field is required'"
                  class="custom-error-msg"
                >
                  {{ $t("selectProgramMessage") }}
                </p>
              </validation-provider>
              <validation-provider rules="required" v-slot="{ errors }">
                <v-select
                  data-qe-id="create_batch_location"
                  :items="locations"
                  filled
                  :label="$t('fileLocation')"
                  attach
                  offset-y
                  item-text="locationName"
                  item-value="locationId"
                  append-icon="expand_more"
                  class="gen2select gen2select__dark"
                  v-model="batchImportInfo.locationId"
                  @change="setLocationName(batchImportInfo.locationId)"
                ></v-select>
                <p
                  v-if="errors[0] === 'This field is required'"
                  class="custom-error-msg"
                >
                  {{ $t("fileLocationMessage") }}
                </p>
              </validation-provider>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="12" md="4">
              <validation-provider
                rules="required|alpha_dash"
                v-slot="{ errors }"
              >
                <v-text-field
                  data-qe-id="create_batch_naming_convention"
                  :label="$t('namingConventionPrefix')"
                  filled
                  v-model="batchImportInfo.namingConvention"
                  class="v-text-field-small"
                />
                <p
                  v-if="errors[0] === 'This field is required'"
                  class="custom-error-msg"
                >
                  {{ $t("namingConventionPrefixMessage") }}
                </p>
                <p
                  v-if="errors[0] === '{field} is not valid.'"
                  class="custom-error-msg"
                >
                  {{ $t("namingConventionPrefixMessageAlph") }}
                </p>
              </validation-provider>
            </v-col>
            <v-col cols="12" md="8">
              <span class="d-inline-block bmt2 bpl2">
                {{ $t("csvNamingConvention") }}</span
              >
            </v-col>
            <v-col cols="12" md="6">
              <span class="d-inline-block">
                <strong class="f600">{{ $t("example") }}</strong>
                {{ $t("exampleNamingConvention") }}</span
              >
            </v-col>
          </v-row>
          <v-divider class="dashed-border" bmy4></v-divider>
          <v-row no-gutters>
            <v-col cols="12" md="6">
              <p>
                <strong class="text-uppercase">{{
                  $t("emailNotificationText")
                }}</strong>
              </p>
              <validation-provider rules="required|email" v-slot="{ errors }">
                <v-text-field
                  data-qe-id="create_batch_email_notification"
                  :label="$t('emailNotificationMessage')"
                  v-model="batchImportInfo.fileReceiptNotificationEmail"
                  filled
                />
                <p
                  v-if="errors[0] === 'This field is required'"
                  class="custom-error-msg"
                >
                  {{ $t("fileReceiptNotificationEmail") }}
                </p>
                <p v-else-if="errors[0]" class="custom-error-msg">
                  {{ $t("validEmailAddress") }}
                </p>
              </validation-provider>
            </v-col>
            <v-col cols="12" md="4" class="bpl5">
              <p class="bmb4">
                <strong class="text-uppercase">{{ $t("optIn") }}</strong>
              </p>
              <v-checkbox
                class="mx-2 checkbox-custom"
                data-qe-id="create_batch_opt_in"
                v-model="batchImportInfo.fileReceiptNotificationOption"
              ></v-checkbox>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="12" md="6">
              <validation-provider rules="required|email" v-slot="{ errors }">
                <v-text-field
                  data-qe-id="create_batch_email_processed_fails"
                  :label="$t('emailNotificationFails')"
                  v-model="batchImportInfo.fileProcessFailureNotificationEmail"
                  filled
                />
                <p
                  v-if="errors[0] === 'This field is required'"
                  class="custom-error-msg"
                >
                  {{ $t("fileProcessFailureNotificationEmail") }}
                </p>
                <p v-else-if="errors[0]" class="custom-error-msg">
                  {{ $t("validEmailAddress") }}
                </p>
              </validation-provider>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="12" md="6">
              <validation-provider rules="required|email" v-slot="{ errors }">
                <v-text-field
                  data-qe-id="create_batch_email_processed_complete"
                  :label="$t('emailNotificationComplete')"
                  v-model="
                    batchImportInfo.fileProcessCompletionNotificationEmail
                  "
                  filled
                />
                <p
                  v-if="errors[0] === 'This field is required'"
                  class="custom-error-msg"
                >
                  {{ $t("fileProcessCompletionNotificationEmail") }}
                </p>
                <p v-else-if="errors[0]" class="custom-error-msg">
                  {{ $t("validEmailAddress") }}
                </p>
              </validation-provider>
            </v-col>
            <v-col cols="12" md="4" class="bpl5 bmt2">
              <v-checkbox
                class="mx-2 checkbox-custom"
                data-qe-id="create_batch_email_complete_checkbox"
                v-model="
                  batchImportInfo.fileProcessCompletionNotificationOption
                "
              ></v-checkbox>
            </v-col>
          </v-row>
          <v-divider class="dashed-border"></v-divider>
          <v-row no-gutters>
            <v-col cols="12" md="6">
              <p>
                <strong class="text-uppercase">{{
                  $t("encryptionKey")
                }}</strong>
              </p>
              <validation-provider rules="required" v-slot="{ errors }">
                <v-select
                  data-qe-id="create_batch_encryption_key"
                  :items="encryptionKeys"
                  filled
                  :label="$t('fileEncryptionKey')"
                  item-text="encryptionKeyName"
                  item-value="encryptionId"
                  attach
                  offset-y
                  append-icon="expand_more"
                  class="gen2select gen2select__dark"
                  v-model="batchImportInfo.fileEncryptionId"
                  @change="
                    setEncryptionKeyName(batchImportInfo.fileEncryptionId)
                  "
                ></v-select>
                <p
                  v-if="errors[0] === 'This field is required'"
                  class="custom-error-msg"
                >
                  {{ $t("fileEncryptionKeyMessage") }}
                </p>
              </validation-provider>
            </v-col>
          </v-row>
          <!-- TODO -->
          <!-- <v-divider class="dashed-border" bmy4></v-divider>
          <v-row no-gutters>
            <v-col cols="12" md="8">
              <p>
                <strong class="text-uppercase">{{
                  $t("setDeliveryTime")
                }}</strong>
              </p>
              <v-radio-group
                row
                v-model="expDelDate"
                hide-details
                class="radiolight radiolight__dark"
                data-qe-id="create_batch_expected_delivery"
              >
                <v-radio :label="$t('yes')" value="yes"></v-radio>
                <v-radio :label="$t('no')" value="no"></v-radio>
              </v-radio-group>
            </v-col>
          </v-row>
          <v-row no-gutters v-show="expDelDate === 'yes'">
            <v-col> <expected-delivery-time></expected-delivery-time> </v-col>
            <v-col cols="12">
              <p>
                <strong class="text-uppercase">{{ $t("timeZone") }} </strong>
                <column-tooltip
                  :header="$t('timeZone')"
                  :content="$t('timeZoneMessage')"
                />
              </p>
              <v-row no-gutters class="bmt2">
                <v-col sm="3" class="today">
                  <v-menu
                    ref="clockmenu"
                    v-model="clockmenu"
                    :close-on-content-click="false"
                    :return-value.sync="timepicker"
                    transition="scale-transition"
                    offset-y
                    min-width="290px"
                  >
                    <template v-slot:activator="{ on }">
                      <v-text-field
                        v-model="timepicker"
                        :label="$t('startTime')"
                        append-icon="schedule"
                        v-on="on"
                        class="darktxtfield__light v-text-field-small"
                        filled
                        readonly
                        data-qe-id="create_batch_schedule"
                      ></v-text-field>
                    </template>
                    <v-time-picker v-model="timepicker">
                      <v-spacer></v-spacer>
                      <v-btn text color="primary" @click="clockmenu = false">{{
                        $t("cancel")
                      }}</v-btn>
                      <v-btn
                        text
                        color="primary"
                        @click="$refs.clockmenu.save(timepicker)"
                        >{{ $t("ok") }}</v-btn
                      >
                    </v-time-picker>
                  </v-menu>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col sm="6">
                  <v-select
                    data-qe-id="create_batch_grace_period"
                    :items="['3 Hours', '3 Hours']"
                    filled
                    :label="$t('gracePeriod')"
                    attach
                    offset-y
                    append-icon="expand_more"
                    class="gen2select gen2select__dark"
                  ></v-select>
                  <v-select
                    data-qe-id="create_batch_time_zone"
                    :items="['(UTC - 06:00) Central America', '02']"
                    filled
                    :label="$t('timeZoneText')"
                    attach
                    offset-y
                    append-icon="expand_more"
                    class="gen2select gen2select__dark"
                  ></v-select>
                </v-col>
              </v-row>
              <v-row no-gutters class="flex-column" bmt1>
                <v-col sm="6">
                  <p>
                    <strong class="text-uppercase"
                      >{{ $t("emailAlert") }}
                    </strong>
                    <column-tooltip
                      :header="$t('emailAlert')"
                      :content="$t('emailAlertInfo')"
                    />
                  </p>
                  <v-text-field
                    :label="$t('emailAddress')"
                    filled
                    data-qe-id="create_batch_expected_delivery_email_address"
                  />
                </v-col>
              </v-row>
            </v-col>
          </v-row>
          <v-divider class="dashed-border"></v-divider>
          <v-row no-gutters>
            <v-col cols="12" md="6">
              <p>
                <strong class="text-uppercase">{{
                  $t("processDuplicateFiles")
                }}</strong>
              </p>
              <v-radio-group
                row
                class="radiolight radiolight__dark"
                v-model="batchImportInfo.addDuplicate"
                data-qe-id="create_batch_add_duplicate"
              >
                <v-radio :label="$t('yes')" value="Yes"></v-radio>
                <v-radio :label="$t('no')" value="No"></v-radio>
              </v-radio-group>
              <p>
                <strong class="text-uppercase">{{ $t("emailAlert") }} </strong>
                <column-tooltip
                  :header="$t('emailAlert')"
                  :content="$t('emailAlertInfo')"
                />
              </p>
              <validation-provider rules="required" v-slot="{ errors }">
                <v-select
                  data-qe-id="create_batch_email_address"
                  :items="['abc@gmail.com', 'def@gmail.com']"
                  filled
                  :label="$t('emailAddressReq')"
                  attach
                  offset-y
                  append-icon="expand_more"
                  class="gen2select gen2select__dark"
                  v-model="batchImportInfo.email"
                ></v-select>
                <p
                  v-if="errors[0] === 'This field is required'"
                  class="custom-error-msg"
                >
                  {{ $t("emailAddressReqMessage") }}
                </p>
              </validation-provider>
            </v-col>
          </v-row>
          <v-divider class="dashed-border"></v-divider>
          <v-row no-gutters>
            <v-col cols="12" md="6">
              <p>
                <strong class="text-uppercase">{{ $t("rejectFile") }}</strong>
              </p>
              <v-radio-group
                row
                class="radiolight radiolight__dark"
                v-model="batchImportInfo.rejectFile"
                data-qe-id="create_batch_reject_file"
              >
                <v-radio
                  :label="$t('topicText')"
                  value="Topics (Kafka)"
                ></v-radio>
                <v-radio
                  :label="$t('fileExport')"
                  value="File Export"
                ></v-radio>
              </v-radio-group>
            </v-col>
          </v-row> -->
        </v-col>
        <v-col cols="12" sm="4" class="">
          <brierley-info-side>
            <template v-slot:info-side-header>
              <div class="info_title">
                <v-icon>info</v-icon>{{ $t("helpTopics") }}
              </div>
            </template>
            <template v-slot:info-side-body>
              <div v-if="!disabled">
                <h3 class="bmt3">{{ $t("downloadTemplate") }}</h3>
                <p class="bmt2">
                  {{ $t("batchProcessText") }}
                </p>
                <v-btn
                  text
                  class="no-ripple btn-hover-none bpx0"
                  data-qe-id="create_batch_download_template"
                  @click="downloadTemplate()"
                >
                  <span class="fbold primary-text font12">
                    {{ $t("downloadTemplate") }}</span
                  >
                </v-btn>
              </div>
              <div>
                <h3 class="bmt3">{{ $t("locationsText") }}</h3>
                <p class="bmt2">
                  {{ $t("fileSetupText") }}
                </p>
                <v-btn
                  text
                  class="no-ripple btn-hover-none bpx0"
                  data-qe-id="create_batch_manage_location"
                >
                  <span
                    class="fbold primary-text font12"
                    @click="openLocations()"
                  >
                    {{ $t("manageLocations") }}</span
                  >
                </v-btn>
              </div>
              <div>
                <h3 class="bmt3">{{ $t("namingConvention") }}</h3>
                <p class="bmt2">
                  {{ $t("namingConventionText") }}
                </p>
              </div>
              <div>
                <h3 class="bmt3">{{ $t("encryptionsText") }}</h3>
                <p class="bmt2">
                  {{ $t("encryptionsTextMessage") }}
                </p>
                <v-btn
                  text
                  class="no-ripple btn-hover-none bpx0"
                  data-qe-id="create_batch_manage_encryption"
                >
                  <span
                    class="fbold primary-text font12"
                    @click="openEncryptions()"
                  >
                    {{ $t("manageEncryptions") }}</span
                  >
                </v-btn>
              </div>
            </template>
          </brierley-info-side>
        </v-col>
      </v-row>
    </div>
  </div>
</template>

<script>
import {
  BrierleyFormTitle,
  BrierleyInfoSide,
  brierleyAlert
} from '@brierley/SharedComponents';
// import ExpectedDeliveryTime from './ExpectedDeliveryTime';
// import ColumnTooltip from '../child/ColumnTooltip';
import { basicInforimationObj } from '../../../../i18n/language';
import { mapState } from 'vuex';

export default {
  i18n: basicInforimationObj,
  components: {
    BrierleyFormTitle,
    BrierleyInfoSide,
    brierleyAlert
    // ExpectedDeliveryTime,
    // ColumnTooltip
  },
  data () {
    return {
      expDelDate: 'no',
      clockmenu: false,
      timepicker: null
    };
  },
  props: {
    batchImportInfo: {
      type: Object
    }
  },
  mounted () {
    this.setEditValues();
  },
  beforeUpdate () {
    this.setEditValues();
  },
  computed: {
    ...mapState('batchImportModule', [
      'locationList',
      'encryptionKeysList',
      'batchTemplates',
      'selectedBusinessEntity',
      'importError',
      'businessEntities'
    ]),
    getPrograms () {
      return this.$root.GlobalStoreEventStore.state.programList;
    },
    disabled () {
      return !this.batchImportInfo.serviceId;
    },
    locations () {
      return this.locationList || this.locationList.length
        ? this.locationList
        : [];
    },
    encryptionKeys () {
      return this.encryptionKeysList || this.encryptionKeysList.length
        ? this.encryptionKeysList
        : [];
    },
    canCreate () {
      return this.$route && this.$route.path.includes('addBatchImport');
    }
  },
  methods: {
    openLocations () {
      this.$store.commit('batchImportModule/setImportTab', 1);
      this.$router.push('/loyaltyadmin/batchImport');
    },
    openEncryptions () {
      this.$store.commit('batchImportModule/setImportTab', 2);
      this.$router.push('/loyaltyadmin/batchImport');
    },
    setLocationName (locationId) {
      this.batchImportInfo.locationPath = this.locationList.filter(
        x => x.locationId === locationId
      )[0].locationName;
    },
    setServiceName (serviceId) {
      this.batchImportInfo.serviceName = this.batchTemplates.filter(
        x => x.serviceId === serviceId
      )[0].serviceName;
    },
    setEncryptionKeyName (encryptionId) {
      this.batchImportInfo.encryptionKeyName = this.encryptionKeysList.filter(
        x => x.encryptionId === encryptionId
      )[0].encryptionKeyName;
    },
    setProgramName (programId) {
      this.batchImportInfo.programName = this.getPrograms.filter(
        x => x.programId === programId
      )[0].name;
    },
    reviewBatchImport () {
      this.batchImportInfo.businessEntityId = this.selectedBusinessEntity.businessEntityId;
      this.batchImportInfo.businessEntityName = this.selectedBusinessEntity.businessEntityName;
      this.batchImportInfo.isReview = true;
      this.$store.dispatch(
        'batchImportModule/createBatchImport',
        this.batchImportInfo
      );
    },
    downloadTemplate () {
      this.$store.dispatch(
        'batchImportModule/downloadTemplate',
        this.batchImportInfo.serviceName
      );
    },
    setEditValues () {
      if (!this.canCreate) {
        const namingConvention = this.batchImportInfo.namingConvention;
        const index = namingConvention.lastIndexOf(
          '_',
          namingConvention.lastIndexOf('_') - 1
        );
        this.batchImportInfo.namingConvention =
          index > -1 ? namingConvention.substring(0, index) : namingConvention;
        this.batchImportInfo.businessEntityName = this.businessEntities.filter(
          x => x.businessEntityId === this.batchImportInfo.businessEntityId
        )[0].name;
        this.setEncryptionKeyName(this.batchImportInfo.fileEncryptionId);
      }
    }
  }
};
</script>
