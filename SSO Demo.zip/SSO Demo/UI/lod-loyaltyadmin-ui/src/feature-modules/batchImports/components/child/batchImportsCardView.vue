<template>
  <v-row>
    <v-col
      md="6"
      sm="12"
      xs="12"
      v-for="(batchImportItem, i) in batchImportList"
      :key="i"
    >
      <brierley-card>
        <template v-slot:header>
          <h2 class="bmb3">{{ batchImportItem.batchImportName }}</h2>
        </template>
        <template v-slot:body>
          <p class="bmt3">
            <strong>{{ $t("batchTemplate") }}:</strong>
            <span>{{ batchImportItem.serviceName }}</span>
          </p>
          <p class="bmt2">
            <strong>{{ $t("fileEncryptionKey") }}:</strong>
            <span>{{ batchImportItem.fileEncryptionId }}</span>
          </p>
          <p class="bmt2">
            <strong>{{ $t("fileLocation") }}:</strong>
            <span>{{ batchImportItem.locationPath }}</span>
          </p>
          <p class="bmb0 bmt2">
            <strong>{{ $t("description") }}</strong>
          </p>
          <p class="elipsis-twoline">
            {{ batchImportItem.description }}
          </p>
        </template>

        <template v-slot:footer>
          <v-col>
            <p>
              <strong>{{ $t("createdDate") }}: </strong><br />
              <span>
                {{ format_date(batchImportItem.createdDate)[0] }}<br />
                {{ format_date(batchImportItem.createdDate)[1] }}
              </span>
            </p>
          </v-col>
          <v-col>
            <p>
              <strong>{{ $t("lastEditedDate") }}:</strong><br />
              <span>
                {{ format_date(batchImportItem.updatedDate)[0] }}<br />
                {{ format_date(batchImportItem.updatedDate)[1] }}
              </span>
            </p>
          </v-col>
          <v-col sm="12">
            <brierleyCardIcons>
              <template v-slot:action-icons>
                <span :title="$t('viewDetails')" class="active">
                  <v-icon>fe fe-eye</v-icon>
                  <span
                    class="viewdetails-icon"
                    @click="viewDetailsDialog = true; viewDetails(batchImportItem);"
                    >{{ $t("viewDetails") }}</span
                  >
                </span>
                <span
                  :title="$t('edit')"
                  data-qe-id="edit_btn"
                  @click="editBatchImport(batchImportItem)"
                >
                  <v-icon id="viewuser_edit-icon" class="blackicon"
                    >fe fe-edit
                  </v-icon>
                  <span class="edit-icon" id="viewuser-edit">{{
                    $t("edit")
                  }}</span>
                </span>
                <span
                  :title="$t('copy')"
                  data-qe-id="copy_btn"
                  @click="cloneBatchImport(batchImportItem)"
                >
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >feather-icon fe fe-copy</v-icon
                  >
                  <span class="copy-icon">
                    {{ $t("copy") }}
                  </span>
                </span>
                <span
                  :title="$t('delete')"
                  data-qe-id="delete_btn"
                  @click="deleteBatchImportItem(i, batchImportItem)"
                >
                  <v-icon>fe fe-trash-2</v-icon>
                  <span class="delete-icon">{{ $t("delete") }}</span>
                </span>
              </template>
            </brierleyCardIcons>
          </v-col>
        </template>
      </brierley-card>
    </v-col>
    <brierley-dialogbox
      :dialog="viewDetailsDialog"
      @closeMe="viewDetailsDialog = $event"
      class="custom-dialog__large"
    >
      <template v-slot:dialog-header>
        <v-card-title class="gen2-dialog-title text-uppercase">
          batch import name</v-card-title
        >
      </template>
      <template v-slot:dialog-body-description>
        <batch-import-view-details></batch-import-view-details>
      </template>
      <template v-slot:dialog-footer> </template>
    </brierley-dialogbox>
  </v-row>
</template>

<script>
import {
  BrierleyCardIcons,
  BrierleyCard,
  BrierleyDialogbox
} from '@brierley/SharedComponents';
import { batchImportCardViewObj } from '../../../../i18n/language';
import BatchImportViewDetails from './BatchImportViewDetails';
import moment from 'moment';
import { mapState } from 'vuex';

export default {
  i18n: batchImportCardViewObj,
  components: {
    BrierleyCardIcons,
    BrierleyCard,
    BrierleyDialogbox,
    BatchImportViewDetails
  },
  data () {
    return {
      viewDetailsDialog: false,
      deleteIndex: -1
    };
  },
  props: {
    batchImportList: {
      type: Array,
      default: () => []
    }
  },
  methods: {
    format_date (value) {
      if (value) {
        let date = moment(value).format('MMM Do YYYY');
        let time = moment(value).format('hh:mm A');
        return [date, time];
      }
    },
    deleteBatchImportItem (index, batchImportItem) {
      this.deleteIndex = index;
      this.$store.dispatch(
        'batchImportModule/deleteBatchImport',
        batchImportItem.batchImportId
      );
    },
    cloneBatchImport (batchImportItem) {
      let batchImportObj = { ...batchImportItem };
      batchImportObj.isReview = false;
      delete batchImportObj.batchImportId;
      batchImportObj.batchImportName = `${batchImportObj.batchImportName}Copy`;
      this.$store.dispatch(
        'batchImportModule/createBatchImport',
        batchImportObj
      );
    },
    editBatchImport (batchImport) {
      this.$store.commit(
        'batchImportModule/updateBatchImportInfo',
        batchImport
      );
      this.$router.push({
        name: 'editBatchImport',
        params: { id: batchImport.batchImportId }
      });
    },
    viewDetails (batchImportItem) {
      this.$store.dispatch('batchImportModule/getBatchImportItem', batchImportItem);
      this.batchImportDetailedViewFilters.batchImportId = batchImportItem.batchImportId;
      this.$store.dispatch('batchImportModule/getBatchImportFiles',this.batchImportDetailedViewFilters);
    }
  },
  watch: {
    '$store.state.batchImportModule.createImportStatus' (newVal) {
      if (newVal === 'Success') {
        this.batchImportList.push(this.batchImportItem);
        this.$store.dispatch('batchImportModule/getBatchImportItem', '');
        this.$store.dispatch('batchImportModule/resetCreateImportStatus', '');
      }
    },
    '$store.state.batchImportModule.batchImportDeleteStatus' (newVal) {
      if (newVal) {
        this.batchImportList.splice(this.deleteIndex, 1);
        this.deleteIndex = -1;
        this.$store.dispatch(
          'batchImportModule/resetBatchImportDeleteStatus',
          false
        );
      }
    }
  },
  computed: {
    ...mapState('batchImportModule', ['batchImportItem', 'batchImportDetailedViewFilters'])
  }
};
</script>
