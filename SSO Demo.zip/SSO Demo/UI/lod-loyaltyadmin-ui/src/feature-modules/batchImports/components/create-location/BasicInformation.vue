<template>
  <v-row class="flex-column bpt5" no-gutters>
    <v-col>
      <brierley-form-title
        :formTitle="$t('basicInfo')"
        :infoText="$t('basicInfoMessage')"
      />
    </v-col>
    <v-col>
      <v-row class="bmt5" no-gutters>
        <v-col sm="7" class="gen2-forms form-light-bg">
          <v-row class="flex-column" no-gutters>
            <v-col class="label-text">
              {{ $t("fileLocationDetails") }}
            </v-col>
            <v-col sm="6">
              <validation-provider rules="required" v-slot="{ errors }">
                <v-text-field
                  :label="$t('fileLocationName')"
                  filled
                  id="batch_create_location_name_txt"
                  :class="{ 'error--text': errors[0] }"
                  v-model="location.locationName"
                ></v-text-field>
                <p class="custom-error-msg">{{ errors[0] }}</p>
              </validation-provider>
            </v-col>
            <v-col sm="9">
              <validation-provider rules="required" v-slot="{ errors }">
                <v-textarea
                  filled
                  :label="$t('fileLocationDescription')"
                  id="batch_create_location_desc_txt"
                  :class="{ 'error--text': errors[0] }"
                  v-model="location.locationDescription"
                ></v-textarea>
                <p class="custom-error-msg">{{ errors[0] }}</p>
              </validation-provider>
            </v-col>
            <v-col sm="6">
              <v-text-field
                :label="$t('fileLocationType')"
                :disabled="true"
                filled
                value="Object Store"
                id="batch_create_location_type_txt"
              ></v-text-field>
            </v-col>
            <v-divider class="dashed bmt3 bmb5"></v-divider>
          </v-row>
        </v-col>
        <v-col sm="5">
          <brierley-info-side>
            <template v-slot:info-side-header>
              <div class="info_title">
                <v-icon>info</v-icon>{{ $t("infoText") }}
              </div>
            </template>
            <template v-slot:info-side-body>
              <div>
                {{ $t("basicInfoMessage") }}
              </div>
            </template>
          </brierley-info-side>
        </v-col>
        <v-col xs="12">
          <v-row class="flex-column" no-gutters>
            <v-col class="label-text">
              {{ $t("objectStoreDetails") }}
            </v-col>
            <v-col>
              <brierley-alert
                :isSiteLevel="true"
                :alertHeader="$t('headerInfoText')"
                alertType="info"
                :alertBody="$t('headerInfoBodyText')"
              ></brierley-alert>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyFormTitle,
  brierleyAlert,
  BrierleyInfoSide
} from '@brierley/SharedComponents';
import { locationBasicInfoObj } from '../../../../i18n/language';

export default {
  i18n: locationBasicInfoObj,
  components: {
    BrierleyFormTitle,
    brierleyAlert,
    BrierleyInfoSide
  },
  data () {
    return {};
  },
  props: {
    location: {
      type: Object
    }
  }
};
</script>
