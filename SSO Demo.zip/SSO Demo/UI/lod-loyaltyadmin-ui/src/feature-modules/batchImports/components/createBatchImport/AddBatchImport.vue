<template>
  <brierley-inner-view>
    <template v-slot:header>
      <v-flex class="toggle-menu-custom">
        <v-btn
          data_qe_id="create_batch_menu_toggle"
          class="no-ripple iconbtn"
          text
          @click="menutoggle = !menutoggle"
        >
          <v-icon>
            fe-menu
          </v-icon>
        </v-btn>
        <brierley-toggle-menu v-if="menutoggle"></brierley-toggle-menu>
      </v-flex>
      <span class="inner-head text-uppercase">
        <small class="white-text">{{ $t("batchImportText") }} </small>
        / {{ getImportText }} {{ $t("batchImportText") }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        data-qe-id="batch_add_import_back_btn"
        text
        @click="navigateToPreviousPage()"
      >
        <v-icon v-if="createImportStatus !== ''">mdi-close</v-icon>
        <v-icon v-else>arrow_back</v-icon>
        {{ createImportStatus !== "" ? $t("close") : $t("back") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <Validation-Observer
        ref="basicInfoForm"
        v-if="currentStepInfo === 1"
        v-slot="{ handleSubmit }"
      >
        <form id="my-form" @submit.prevent="handleSubmit(btnNextClick)">
          <basic-information
            ref="basicBatch"
            :batchImportInfo="batchImportInfo"
          ></basic-information>
        </form>
      </Validation-Observer>
      <review-batch-import
        :batchImportInfo="batchImportInfo"
        v-if="currentStepInfo === 2 && !createImportStatus"
        @openCreatePage="goToCreate"
        ref="reviewBatchImport"
      ></review-batch-import>
      <batch-import-status
        v-if="createImportStatus !== ''"
      ></batch-import-status>
    </template>
    <template
      v-slot:footer-changes-saved
      v-if="
        (currentStepInfo === 1 || currentStepInfo === 2) && !createImportStatus
      "
    >
      <v-icon class="pr-2">mdi-check</v-icon>
      <span>{{ $t("changesText") }}</span>
    </template>
    <template
      v-slot:footer
      v-if="
        (currentStepInfo === 1 || currentStepInfo === 2) && !createImportStatus
      "
    >
      <v-btn
        :title="$t('cancel')"
        text
        class="cancel no-ripple bmr6"
        data-qe-id="batch_add_import_cancel_btn"
        @click="closeAddImport()"
        >{{ $t("cancel") }}</v-btn
      >
      <v-btn
        :title="getCreateBtn()"
        text
        class="primaryctabtn no-ripple large"
        type="invalid"
        data-qe-id="batch_add_import_create_btn"
        :loading="loading"
        @click="btnNextClick()"
        >{{ getCreateBtn() }}</v-btn
      >
    </template>
    <template v-slot:footer-previous v-if="createImportStatus !== ''">
      <v-btn
        class="primaryctabtn"
        data-qe-id="batch_add_import_close_btn"
        @click="closeAddImport()"
        >{{ $t("close") }}</v-btn
      >
    </template>
    <template v-slot:footer-belowtext v-if="createImportStatus !== ''">
      <p class="label-text bmt4">{{ $t("addNewImportText") }}</p>
      <p class="bmb0">
        {{ $t("askNewText") }}
        <strong
          class="primary-text cursor-p"
          data-qe-id="batch_add_import_click_btn"
          @click="addNewImport()"
          >{{ $t("clickHereText") }}</strong
        >
      </p>
    </template>
  </brierley-inner-view>
</template>

<script>
import {
  BrierleyInnerView,
  BrierleyToggleMenu
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import BasicInformation from './BasicInformation';
import ReviewBatchImport from './ReviewBatchImport';
import BatchImportStatus from './BatchImportStatus';
import { addBatchImportObj } from '../../../../i18n/language';

export default {
  i18n: addBatchImportObj,
  components: {
    BrierleyInnerView,
    BrierleyToggleMenu,
    BasicInformation,
    ReviewBatchImport,
    BatchImportStatus
  },
  data () {
    return {
      menutoggle: false,
      currentStepInfo: 1,
      loading: false
    };
  },
  created () {
    this.setWindowScrollTop();
    this.$store.dispatch('batchImportModule/getBatchTemplates');
    if (!this.batchImportList.length && !this.canCreate) {
      this.$store.dispatch('batchImportModule/getLocationList');
      this.$store.dispatch('batchImportModule/getEncryptionKeyList');
      this.$store.dispatch('batchImportModule/getBatchImportList');
      this.$store.dispatch('batchImportModule/getBusinessEntities');
    }
  },
  computed: {
    ...mapState('batchImportModule', [
      'batchImportInfo',
      'createImportStatus',
      'importError',
      'batchImportList'
    ]),
    getImportText () {
      return this.canCreate ? this.$t('new') : this.$t('edit');
    },
    canCreate () {
      return this.$route && this.$route.path.includes('addBatchImport');
    }
  },
  methods: {
    goToCreate () {
      this.currentStepInfo = 1;
      this.$store.commit('batchImportModule/setImportError', null);
    },
    getCreateBtn () {
      let text = null;
      switch (this.currentStepInfo) {
      case 1:
        text = this.$t('nextText');
        break;
      case 2:
        text = this.canCreate ? this.$t('createText') : this.$t('edit');
        break;
      }
      return text;
    },
    btnNextClick () {
      let activeElement = document.activeElement;
      if (
        activeElement &&
        (activeElement.tagName.toLowerCase() === 'input' ||
          activeElement.tagName.toLowerCase() === 'textarea' ||
          activeElement.tagName.toLowerCase() === 'select')
      ) {
        event.preventDefault();
        return false;
      }
      if (this.currentStepInfo === 1) {
        const s = this;
        s.$refs.basicInfoForm.validate().then(res => {
          if (res) {
            s.loading = true;
            if (s.canCreate) {
              s.$refs.basicBatch.reviewBatchImport();
            } else {
              s.loading = false;
              s.currentStepInfo = s.currentStepInfo + 1;
            }
          }
        });
      } else if (this.currentStepInfo === 2) {
        this.loading = true;
        this.$refs.reviewBatchImport.saveBatchImport();
      }
    },
    closeAddImport () {
      this.$store.commit('batchImportModule/setImportTab', 0);
      this.$router.go(-1);
      this.resetStepperInfo();
    },
    resetStepperInfo () {
      this.$store.dispatch('batchImportModule/resetBatchImportStep');
    },
    setWindowScrollTop () {
      window.scrollTo({ top: 0, behavior: 'auto' });
    },
    navigateToPreviousPage () {
      if (this.currentStepInfo === 1 || this.createImportStatus !== '') {
        this.closeAddImport();
        return;
      }
      this.goToCreate();
    },
    addNewImport () {
      this.$store.dispatch('batchImportModule/resetBatchImportStep');
      this.currentStepInfo = 1;
      this.loading = false;
    }
  },
  watch: {
    currentStepInfo () {
      this.setWindowScrollTop();
    },
    importError (val) {
      if (val === '') {
        this.currentStepInfo = this.currentStepInfo + 1;
      } else {
        this.setWindowScrollTop();
      }
      this.loading = false;
    },
    batchImportList (val) {
      if (val.length) {
        const batchImport = val.filter(
          x => x.batchImportId === this.$route.params.id
        )[0];
        this.$store.commit(
          'batchImportModule/updateBatchImportInfo',
          batchImport
        );
      }
    }
  }
};
</script>
<style lang="scss">
.dashed-border {
  border: 1px dashed rgba(102, 102, 102, 0.3);
  margin: 24px 0;
}
.v-text-field-small {
  min-width: inherit !important;
}
</style>
