<template>
  <v-row>
    <v-col cols="12" v-for="(encryptionKey, i) in encryptionKeys" :key="i">
      <v-card class="gen2-card gen2-typo3">
        <v-row no-gutters>
          <v-col md="3" sm="12" xs="12">
            <v-card-title class="elipsis-fullwidth">
              {{ encryptionKey.encryptionKeyName }}
            </v-card-title>
            <div class="gen2-card-copy">
              <p class="elipsis-fullwidth bmb1" id="viewuser_email">
                <strong>{{ $t("algorithm") }}: </strong>
                {{ encryptionKey.algorithm }}
              </p>
              <p>
                <strong>{{ $t("keySize") }}: </strong>
                {{ `${encryptionKey.keySize} Bits (Secure)` }}
              </p>
            </div>
          </v-col>
          <v-col md="3" sm="12" xs="12" class="">
            <v-row no-gutters class="flex-column">
              <v-col>
                <p class="bmt0">
                  <strong>{{ $t("description") }}</strong>
                </p>
                <p>{{ encryptionKey.encryptionKeyDescription }}</p>
              </v-col>
              <v-col class="elipsis-twoline"> </v-col>
            </v-row>
          </v-col>
          <v-col md="4" sm="12" xs="12" class="bpr6 bpl6">
            <v-row no-gutters class="pr-3 bmb1">
              <v-col class="text-xs-left">
                <p class="bmt0">
                  <strong>{{ $t("createdDate") }}: </strong>
                </p>
              </v-col>
              <v-col class="text-xs-right">
                <p class="bmt0">
                  {{ format_date(encryptionKey.createdDate)[0] }}<br />
                  {{ format_date(encryptionKey.createdDate)[1] }}
                </p>
              </v-col>
            </v-row>
            <v-row no-gutters class="pr-3">
              <v-col class="text-xs-left">
                <p>
                  <strong>{{ $t("expiration") }}:</strong>
                </p>
              </v-col>
              <v-col class="text-xs-right bpr3 bpl3">
                <p>
                  {{ encryptionKey.expiration }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col>
            <p class="bmt0">
              <strong>{{ $t("encryptionKey") }}</strong>
            </p>
            <v-btn
              text
              class="no-ripple btn-hover-none bpx0"
              @click="dowloadKey(encryptionKey)"
              data-qe-id="download_encryption_key_btn">
              <span class="fbold primary-text">
                <span class="download-lock"
                  ><v-icon>get_app</v-icon
                  ><v-icon class="download-lock__icon">lock</v-icon></span
                >
                {{ $t("downloadkey") }}
              </span>
            </v-btn>
          </v-col>
          <v-col sm="12" class="bmt1">
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span
                  :title="$t('edit')"
                  data-qe-id="edit_btn"
                  @click="editNav(encryptionKey)"
                >
                  <v-icon id="viewuser_edit-icon" class="blackicon"
                    >fe fe-edit</v-icon
                  >
                  <span class="edit-icon" id="viewuser-edit">{{
                    $t("edit")
                  }}</span>
                </span>
                <span
                  :title="$t('delete')"
                  data-qe-id="delete_btn"
                  @click="deleteKey(encryptionKey, i)"
                >
                  <v-icon>fe fe-trash-2</v-icon>
                  <span class="delete-icon">{{ $t("delete") }}</span>
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
        </v-row>
      </v-card>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyCardIcons } from '@brierley/SharedComponents';
import moment from 'moment';
import { encryptionGridViewObj } from '../../../../i18n/language';
export default {
  i18n: encryptionGridViewObj,
  components: {
    BrierleyCardIcons
  },
  data () {
    return {
      deleteIndex: -1
    };
  },
  props: {
    encryptionKeys: {
      type: Array,
      default: () => []
    }
  },
  methods: {
    editNav (encryptionItem) {
      encryptionItem.isEdit = true;
      this.$store.dispatch(
        'batchImportModule/getEncryptionKey',
        encryptionItem
      );
      this.$router.push({
        name: 'editEncryption',
        params: { id: encryptionItem.encryptionId }
      });
    },
    format_date (value) {
      if (value) {
        let date = moment(value).format('MMM Do YYYY');
        let time = moment(value).format('hh:mm A');
        return [date, time];
      }
    },
    deleteKey (item, index) {
      this.deleteIndex = index;
      this.$store.dispatch(
        'batchImportModule/deleteEncryptionKey',
        item.encryptionId
      );
    },
    dowloadKey (item) {
      this.$store.dispatch(
        'batchImportModule/downloadEncryptionKeys',
        item.encryptionKeyName
      );
    }
  },
  watch: {
    '$store.state.batchImportModule.deleteEncryptionKeyStatus' (newVal) {
      if (newVal) {
        this.encryptionKeys.splice(this.deleteIndex, 1);
        this.deleteIndex = -1;
        this.$store.dispatch('batchImportModule/resetDeleteStatus', false);
      }
    }
  }
};
</script>
