<template>
  <brierley-dialogbox
    :dialog="deleteLocationDialog"
    @closeMe="cancelPopup"
    :persistent="false"
  >
    <template v-slot:dialog-header>
      <v-card-title class="gen2-dialog-title text-uppercase">
        {{ $t("deleteLocation") }}
      </v-card-title>
    </template>
    <template v-slot:dialog-body-alert>
      <brierley-alert
        alertType="warning"
        :alertBody="$t('infoText')"
      ></brierley-alert>
    </template>
    <template v-slot:dialog-footer>
      <v-btn
        data-qe-id="batch_import_delete_location_no"
        text
        class="cancel no-ripple btn-hover-none"
        @click="cancelPopup"
        >{{ $t("no") }}</v-btn
      >
      <v-btn
        data-qe-id="batch_import_delete_location_yes"
        class="primaryctabtn"
        :title="$t('yes')"
        @click="deleteLocation()"
        >{{ $t("yes") }}</v-btn
      >
    </template>
  </brierley-dialogbox>
</template>

<script>
import { brierleyAlert, BrierleyDialogbox } from '@brierley/SharedComponents';
import * as api from '../../api/batchImport.api';
import { deleteLocationObj } from '../../../../i18n/language';

export default {
  i18n: deleteLocationObj,
  components: {
    brierleyAlert,
    BrierleyDialogbox
  },
  mounted () {
    this.deleteLocationDialog = this.dialog;
  },
  data () {
    return {
      deleteLocationDialog: false
    };
  },
  props: {
    dialog: {
      type: Boolean,
      default: () => false
    },
    locationId: {
      type: String
    },
    locationIndex: {
      type: Number,
      default: () => 0
    },
    locations: {
      type: Array,
      default: () => []
    }
  },
  methods: {
    cancelPopup () {
      this.deleteDialog = false;
      this.$emit('deleteDialog', false);
    },
    async deleteLocation () {
      await api
        .deleteLocationAsync(this.locationId)
        .then(() => {
          this.locations.splice(this.locationIndex, 1);
          this.$store.commit(
            'batchImportModule/setLocationList',
            this.locations
          );
          this.cancelPopup();
        })
        .catch(err => {
          console.error(err);
        });
    }
  }
};
</script>
