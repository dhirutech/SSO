<template>
  <v-row>
    <v-col
      md="6"
      sm="12"
      xs="12"
      v-for="(encryptionKey, i) in encryptionKeys"
      :key="i"
    >
      <brierley-card>
        <template v-slot:header>
          <h2 class="bmb3">{{ encryptionKey.encryptionKeyName }}</h2>
        </template>
        <template v-slot:body>
          <p class="bmb3">
            <strong>{{ $t("algorithm") }}</strong>
            <span>{{ encryptionKey.algorithm }}</span>
          </p>
          <p>
            <strong>{{ $t("keySize") }}:</strong>
            <span>{{ `${encryptionKey.keySize} Bits (Secure)` }}</span>
          </p>
          <p class="bmb0 bmt3">
            <strong>{{ $t("description") }}</strong>
          </p>
          <p class="elipsis-twoline">
            {{ encryptionKey.encryptionKeyDescription }}
          </p>
        </template>

        <template v-slot:footer>
          <v-col>
            <p>
              <strong>{{ $t("createdDate") }}: </strong><br />
              <span>
                {{ format_date(encryptionKey.createdDate)[0] }}<br />
                {{ format_date(encryptionKey.createdDate)[1] }}
              </span>
            </p>
          </v-col>
          <v-col>
            <p>
              <strong>{{ $t("expiration") }}:</strong><br />
              <span>{{ encryptionKey.expiration }}</span>
            </p>
          </v-col>
          <v-col sm="12">
            <p class="bmb0 bmt3">
              <strong>{{ $t("encryptionKey") }}</strong>
            </p>
            <v-btn
              text
              class="no-ripple btn-hover-none bpx0"
              @click="dowloadKey(encryptionKey)"
              data-qe-id="download_encryption_key_btn">
              <span class="fbold primary-text">
                <span class="download-lock"
                  ><v-icon>get_app</v-icon
                  ><v-icon class="download-lock__icon">lock</v-icon></span
                >
                {{ $t("downloadkey") }}
              </span>
            </v-btn>
          </v-col>
          <v-col sm="12">
            <brierleyCardIcons>
              <template v-slot:action-icons>
                <span
                  :title="$t('edit')"
                  data-qe-id="edit_btn"
                  @click="editNav(encryptionKey)"
                >
                  <v-icon id="viewuser_edit-icon" class="blackicon"
                    >fe fe-edit
                  </v-icon>
                  <span class="edit-icon" id="viewuser-edit">{{
                    $t("edit")
                  }}</span>
                </span>
                <span
                  :title="$t('delete')"
                  data-qe-id="delete_btn"
                  @click="deleteKey(encryptionKey, i)"
                >
                  <v-icon>fe fe-trash-2</v-icon>
                  <span class="delete-icon">{{ $t("delete") }}</span>
                </span>
              </template>
            </brierleyCardIcons>
          </v-col>
        </template>
      </brierley-card>
    </v-col>
  </v-row>
</template>

<script>
import { BrierleyCardIcons, BrierleyCard } from '@brierley/SharedComponents';
import moment from 'moment';
import { encryptionGridViewObj } from '../../../../i18n/language';
export default {
  i18n: encryptionGridViewObj,
  components: {
    BrierleyCardIcons,
    BrierleyCard
  },
  data () {
    return {
      deleteIndex: -1
    };
  },
  props: {
    encryptionKeys: {
      type: Array,
      default: () => []
    }
  },
  methods: {
    editNav (encryptionItem) {
      encryptionItem.isEdit = true;
      this.$store.dispatch(
        'batchImportModule/getEncryptionKey',
        encryptionItem
      );
      this.$router.push({
        name: 'editEncryption',
        params: { id: encryptionItem.encryptionId }
      });
    },
    format_date (value) {
      if (value) {
        let date = moment(value).format('MMM Do YYYY');
        let time = moment(value).format('hh:mm A');
        return [date, time];
      }
    },
    deleteKey (item, index) {
      this.deleteIndex = index;
      this.$store.dispatch(
        'batchImportModule/deleteEncryptionKey',
        item.encryptionId
      );
    },
    dowloadKey (item) {
      this.$store.dispatch(
        'batchImportModule/downloadEncryptionKeys',
        item.encryptionKeyName
      );
    }
  },
  watch: {
    '$store.state.batchImportModule.deleteEncryptionKeyStatus' (newVal) {
      if (newVal) {
        this.encryptionKeys.splice(this.deleteIndex, 1);
        this.deleteIndex = -1;
        this.$store.dispatch('batchImportModule/resetDeleteStatus', false);
      }
    }
  }
};
</script>
