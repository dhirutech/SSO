<template>
  <v-row>
    <v-col md="6" sm="12" xs="12" v-for="(location, i) in locations" :key="i">
      <brierley-card>
        <template v-slot:header>
          <h2 class="bmb3">{{ location.locationName }}</h2>
        </template>
        <template v-slot:body>
          <p class="bmb3">
            <strong>{{ $t("locationType") }}: </strong>
            <span>{{ location.locationType }}</span>
          </p>
          <p>
            <strong>{{ $t("hostName") }}: </strong>
            <span>{{ location.hostname }}</span>
          </p>
          <p class="bmb0 bmt3">
            <strong>{{ $t("description") }}: </strong>
          </p>
          <p class="elipsis-twoline">
            {{ location.locationDescription }}
          </p>
        </template>

        <template v-slot:footer>
          <v-col>
            <p>
              <strong>{{ $t("createdDate") }}: </strong><br />
              <span>{{ format_date(location.createdDate) }}</span>
            </p>
          </v-col>
          <v-col>
            <p>
              <strong>{{ $t("lastEditedDate") }}:</strong><br />
              <span>{{ format_date(location.updatedDate) }}</span>
            </p>
          </v-col>
          <v-col sm="12">
            <p class="bmb0 bmt3">{{ $t("status") }}:</p>
            <brierley-status status="Active"></brierley-status>
          </v-col>
          <v-col sm="12">
            <brierleyCardIcons>
              <template v-slot:action-icons>
                <span
                  class="active"
                  :id="`batch_location_card_edit_${i}`"
                  @click="editLocation(location)"
                >
                  <v-icon class="blackicon" :title="$t('edit')"
                    >fe fe-edit</v-icon
                  >
                  <span class="edit-icon">{{ $t("edit") }}</span>
                </span>
                <span
                  @click="deletePopup(location.locationId, i)"
                  :id="`batch_location_card_delete_popup_${i}`"
                >
                  <v-icon class="blackicon" :title="$t('delete')"
                    >fe-trash-2</v-icon
                  >
                  <span class="delete-icon">{{ $t("delete") }}</span>
                </span>
              </template>
            </brierleyCardIcons>
          </v-col>
        </template>
      </brierley-card>
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyStatus,
  BrierleyCardIcons,
  BrierleyCard
} from '@brierley/SharedComponents';
import moment from 'moment';
import { locationsCardViewObj } from '../../../../i18n/language';

export default {
  i18n: locationsCardViewObj,
  components: {
    BrierleyStatus,
    BrierleyCardIcons,
    BrierleyCard
  },
  data () {
    return {};
  },
  props: {
    locations: {
      type: Array,
      default: () => []
    }
  },
  methods: {
    format_date (value) {
      if (value) {
        let date = moment(value).format('MMM Do YYYY');
        let time = moment(value).format('hh:mm A');
        return `${date} ${time}`;
      }
    },
    deletePopup (id, index) {
      this.$emit('deleteLocation', id, index);
    },
    editLocation (location) {
      this.$store.commit('batchImportModule/updateLocationInfo', location);
      this.$router.push({
        name: 'editLocation',
        params: { id: location.locationId }
      });
    }
  }
};
</script>
