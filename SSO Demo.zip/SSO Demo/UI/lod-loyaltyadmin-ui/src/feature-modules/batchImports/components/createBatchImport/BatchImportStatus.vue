<template>
  <v-row class="flex-column bpt5" no-gutters>
    <v-col>
      <brierley-form-title
        :formTitle="importStatus"
        :infoText="getAlertMessage"
        :showSteps="false"
      ></brierley-form-title>
      <v-row class="batch-import-success" no-gutters>
        <v-col>
          <brierley-alert
            :isSiteLevel="true"
            :alertHeader="importStatus"
            :alertType="getAlertType"
            :alertBody="getAlertMessage"
            :icon="checkIcon"
          ></brierley-alert>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>

<script>
import { BrierleyFormTitle, brierleyAlert } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { batchImportStatusObj } from '../../../../i18n/language';

export default {
  i18n: batchImportStatusObj,
  components: {
    BrierleyFormTitle,
    brierleyAlert
  },
  data () {
    return {};
  },
  mounted () {
    window.scrollTo(0, 0);
  },
  computed: {
    ...mapState({
      importStatus: state => state.batchImportModule.createImportStatus
    }),
    getFormTitle () {
      if (this.importStatus === 'Success') {
        return this.$t('successImpText');
      }
      return this.$t('errorImpText');
    },
    getAlertType () {
      if (this.importStatus === 'Success') {
        return 'success';
      }
      return 'error';
    },
    checkIcon () {
      if (this.importStatus === 'Success') {
        return 'done';
      }
      return '';
    },
    getAlertMessage () {
      if (this.importStatus === 'Success') {
        return this.canCreate
          ? this.$t('successMessage')
          : this.$t('successUpdateMessage');
      }
      return this.canCreate
        ? this.$t('errorMessage')
        : this.$t('errorUpdateMessage');
    },
    canCreate () {
      return this.$route && this.$route.path.includes('addBatchImport');
    }
  }
};
</script>
<style lang="scss" scoped>
.batch-import-success {
  margin-top: 24px;
  margin-bottom: -80px;
}
</style>
