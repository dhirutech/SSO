<template>
  <brierley-inner-view :showFooter="false">
    <template v-slot:header>
      <v-flex class="toggle-menu-custom">
        <v-btn class="no-ripple iconbtn" text @click="menutoggle = !menutoggle">
          <v-icon>
            fe-menu
          </v-icon>
        </v-btn>
        <brierley-toggle-menu v-if="menutoggle"></brierley-toggle-menu>
      </v-flex>
      <span class="inner-head text-uppercase">
        <small class="white-text" data-qe-id="edit_encrYption_btn"
          >{{ $t("batchImportText") }}
        </small>
        / {{ $t("editEncrYption") }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        data-qe-id="back_btn"
        text
        @click.native="closeButton"
      >
        <v-icon>mdi-close</v-icon>{{ $t("close") }}
      </v-btn>
    </template>
    <template
      v-slot:body-container
      v-if="getStatus === 'Success' || getStatus === 'Error'"
    >
      <brierley-form-title
        class="bmt3"
        :formTitle="getStatus"
        :infoText="getAlertMessage"
        :showSteps="false"
      ></brierley-form-title>
      <div class="bmt5">
        <v-row no-gutters class="bmt5">
          <v-col>
            <brierley-alert
              style="max-width:100%"
              :isSiteLevel="true"
              :alertType="getAlertType"
              :alertBody="getAlertMessage"
              :alertHeader="getStatus"
              :icon="checkIcon"
            ></brierley-alert>
          </v-col>
          <v-col cols="12" class="bmt5">
            <v-divider></v-divider>
            <v-btn
              text
              class="primaryctabtn no-ripple large bmt3"
              data-qe-id="close_btn"
              @click.native="closeButton"
              >{{ $t("close") }}</v-btn
            >
          </v-col>
          <v-col cols="12" class="bmt3">
            <p class="bmb1">
              <strong
                class="text-uppercase"
                data-qe-id="create_another_encrYption_key_btn"
                >{{ $t("newKayGen") }}</strong
              >
            </p>
            <p>
              {{ $t("newKeyGenMessage") }}
              <strong class="primary-text cursor-p" @click="addNewEncryption">{{
                $t("clickText")
              }}</strong>
            </p>
          </v-col>
        </v-row>
      </div>
    </template>
  </brierley-inner-view>
</template>

<script>
import {
  BrierleyInnerView,
  BrierleyToggleMenu,
  BrierleyFormTitle,
  brierleyAlert
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { SuccessEncryptionObj } from '../../../i18n/language';

export default {
  i18n: SuccessEncryptionObj,
  components: {
    BrierleyInnerView,
    BrierleyToggleMenu,
    BrierleyFormTitle,
    brierleyAlert
  },
  data () {
    return {
      menutoggle: false,
      dialog: false
    };
  },
  computed: {
    ...mapState({
      encryptionSetup: state =>
        state.batchImportModule.createEncryptionSetupStatus
    }),
    getStatus () {
      if (this.encryptionSetup === 'Success') {
        return this.$t('successText');
      } else if (this.encryptionSetup === '') {
        return '';
      }
      return this.$t('errorText');
    },
    checkIcon () {
      if (this.encryptionSetup === 'Success') {
        return 'check';
      }
      return '';
    },
    getAlertMessage () {
      if (this.encryptionSetup === 'Success') {
        return this.$t('successMessage');
      } else if (this.encryptionSetup === 409) {
        return this.$t('duplicateKeyMessage');
      } else if (this.encryptionSetup === '') {
        return '';
      }
      return this.$t('errorMessage');
    }
  },

  methods: {
    addNewEncryption () {
      this.$store.dispatch('batchImportModule/resetEncryptionKeyStatus', '');
      this.$store.dispatch('batchImportModule/getEncryptionKey', {
        encryptionKeyName: '',
        encryptionKeyDescription: '',
        algorithm: 'RSA',
        keySize: 4096,
        expiration: 'Never',
        passphrase: '',
        publicKey: '',
        privateKey: '',
        isEdit: false
      });
      this.$router.push({
        name: 'createEncryption'
      });
    },
    closeButton () {
      this.$store.commit('batchImportModule/setImportTab', 2);
      this.$store.dispatch('batchImportModule/resetEncryptionKeyStatus', '');
      this.$router.push('/loyaltyadmin/batchImport');
    }
  }
};
</script>
