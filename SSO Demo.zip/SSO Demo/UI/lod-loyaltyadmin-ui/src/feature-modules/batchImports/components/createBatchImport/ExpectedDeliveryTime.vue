<template>
  <brierleyTabs class="exp-del-time-block bpt2">
    <template v-slot:tabs-header>
      <v-tab>{{ $t("weekly") }}</v-tab>
      <v-tab>{{ $t("monthly") }}</v-tab>
    </template>
    <template v-slot:tabs-body>
      <v-tab-item>
        <v-row no-gutters class="weekly-block">
          <v-col class="every-day">
            <v-checkbox hide-details class="gen2-search-card v-card">
              <template v-slot:label>
                <div class="every-day-block">
                  <v-icon>check_circle</v-icon>
                  <h4 class="text-uppercase font15 fbold">
                    {{ $t("everyDay") }}
                  </h4>
                </div>
              </template>
            </v-checkbox>
          </v-col>
          <v-col>
            <v-checkbox hide-details class="gen2-search-card v-card">
              <template v-slot:label>
                <div>
                  <v-icon>check_circle</v-icon>
                  <h4 class="text-uppercase font15 fbold">
                    Sun
                  </h4>
                </div>
              </template>
            </v-checkbox>
          </v-col>
          <v-col>
            <v-checkbox hide-details class="gen2-search-card v-card">
              <template v-slot:label>
                <div>
                  <v-icon>check_circle</v-icon>
                  <h4 class="text-uppercase font15 fbold">
                    Mon
                  </h4>
                </div>
              </template>
            </v-checkbox>
          </v-col>
          <v-col>
            <v-checkbox hide-details class="gen2-search-card v-card">
              <template v-slot:label>
                <div>
                  <v-icon>check_circle</v-icon>
                  <h4 class="text-uppercase font15 fbold">
                    Tue
                  </h4>
                </div>
              </template>
            </v-checkbox>
          </v-col>
          <v-col>
            <v-checkbox hide-details class="gen2-search-card v-card">
              <template v-slot:label>
                <div>
                  <v-icon>check_circle</v-icon>
                  <h4 class="text-uppercase font15 fbold">
                    Wed
                  </h4>
                </div>
              </template>
            </v-checkbox>
          </v-col>
          <v-col>
            <v-checkbox hide-details class="gen2-search-card v-card">
              <template v-slot:label>
                <div>
                  <v-icon>check_circle</v-icon>
                  <h4 class="text-uppercase font15 fbold">
                    Thu
                  </h4>
                </div>
              </template>
            </v-checkbox>
          </v-col>
          <v-col>
            <v-checkbox hide-details class="gen2-search-card v-card">
              <template v-slot:label>
                <div>
                  <v-icon>check_circle</v-icon>
                  <h4 class="text-uppercase font15 fbold">
                    Fri
                  </h4>
                </div>
              </template>
            </v-checkbox>
          </v-col>
          <v-col>
            <v-checkbox hide-details class="gen2-search-card v-card">
              <template v-slot:label>
                <div>
                  <v-icon>check_circle</v-icon>
                  <h4 class="text-uppercase font15 fbold">
                    Sat
                  </h4>
                </div>
              </template>
            </v-checkbox>
          </v-col>
        </v-row>
      </v-tab-item>
      <v-tab-item>
        <v-radio-group column class="radiolight radiolight__dark"
          ><v-radio value="radio-1" class="bmb1">
            <template v-slot:label>
              <v-row no-gutters class="bpl2">
                <v-col cols="12" sm="12" md="6">
                  <v-select
                    :items="['01', '02']"
                    filled
                    :label="$t('daysoftheMonth')"
                    attach
                    offset-y
                    append-icon="expand_more"
                    class="gen2select gen2select__dark"
                  ></v-select>
                </v-col>
              </v-row>
            </template>
          </v-radio>
          <v-radio value="radio-2">
            <template v-slot:label>
              <v-row class="select-months-row no-gutters bpl2">
                <v-col cols="12">
                  <span class="bpl0"> The </span>
                  <span class="select-lg">
                    <v-select
                      :items="['01', '02']"
                      filled
                      :label="$t('select')"
                      attach
                      offset-y
                      append-icon="expand_more"
                      class="gen2select gen2select__dark"
                    ></v-select>
                  </span>
                  <span class="select-lg">
                    <v-select
                      :items="['01', '02']"
                      filled
                      :label="$t('selectDay')"
                      attach
                      offset-y
                      append-icon="expand_more"
                      class="gen2select gen2select__dark"
                    ></v-select>
                  </span>
                  <span> of every </span>
                  <span class="select-small">
                    <v-text-field label="0" filled />
                  </span>
                  <span> {{ $t("monthText") }} </span>
                </v-col>
              </v-row>
            </template>
          </v-radio>
        </v-radio-group>
      </v-tab-item>
    </template>
  </brierleyTabs>
</template>

<script>
import { BrierleyTabs } from '@brierley/SharedComponents';
import { expectedDeliveryTimeObj } from '../../../../i18n/language';

export default {
  i18n: expectedDeliveryTimeObj,
  components: {
    BrierleyTabs
  },
  data () {
    return {};
  }
};
</script>
<style lang="scss">
.dashed-border {
  border: 1px dashed rgba(102, 102, 102, 0.3);
  margin: 24px 0;
}
.exp-del-time-block {
  .radiolight {
    margin-top: 0 !important;
    .v-radio {
      .v-label {
        .v-input__slot {
          padding: 0 16px !important;
        }
        &--active {
          left: -24px !important;
        }
      }
    }
    .v-input--radio-group__input {
      .v-radio {
        margin-bottom: 8px !important;
      }
    }
  }
}

.weekly-block {
  padding-bottom: 32px;
  .col {
    width: 60px;
    max-width: 60px;
    margin-right: 8px;
    &.every-day {
      max-width: 108px;
      width: 108px;
    }
    &:last-child {
      margin-right: 0;
    }
  }
  .gen2-search-card {
    &.v-card {
      box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.15) !important;
      padding: 0 !important;
    }
    .v-icon {
      position: absolute;
      top: 6px;
      right: 8px;
      opacity: 0;
      visibility: hidden;
      font-size: 12px !important;
      color: #000;
    }
    .v-label {
      text-align: center;
      height: 60px;
      div {
        width: 60px;
        height: 60px;
        display: flex;
        align-items: center;
        justify-content: center;
        &.every-day-block {
          max-width: 100px;
          width: 108px;
        }
      }
    }

    &.v-input--checkbox {
      background: #f5f5f5;
      min-width: inherit;
      .v-input__slot {
        margin-bottom: 0 !important;
        padding: 0px !important;
      }
      .v-input--selection-controls__input {
        display: none;
      }
    }
    &.v-input--is-label-active {
      background: #e7f4f7;
      .v-icon {
        opacity: 1;
        visibility: visible;
      }
    }
  }
}
.select-months-row {
  span {
    display: inline-block;
    padding-left: 16px;
    .v-input {
      min-width: inherit;
    }
    &.select {
      &-lg {
        width: 180px;
      }
      &-small {
        width: 100px;
      }
    }
  }
}
</style>
