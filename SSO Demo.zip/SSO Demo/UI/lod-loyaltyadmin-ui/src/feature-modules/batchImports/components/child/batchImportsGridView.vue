<template>
  <v-row>
    <v-col cols="12" v-for="(batchImportItem, i) in batchImportList" :key="i">
      <v-card class="gen2-card gen2-typo3">
        <v-row no-gutters>
          <v-col md="4" sm="12" xs="12">
            <v-card-title class="elipsis-fullwidth">
              {{ batchImportItem.batchImportName }}
            </v-card-title>
            <div class="gen2-card-copy">
              <p class="elipsis-fullwidth bmb1" id="viewuser_email">
                <strong>{{ $t("batchTemplate") }}: </strong>
                {{ batchImportItem.serviceName }}
              </p>
              <p>
                <strong>{{ $t("fileEncryptionKey") }}: </strong>
                {{ batchImportItem.fileEncryptionId }}
              </p>
              <p>
                <strong>{{ $t("fileLocation") }}: </strong>
                {{ batchImportItem.locationPath }}
              </p>
            </div>
          </v-col>
          <v-col md="4" sm="12" xs="12" class="bpx4">
            <v-row no-gutters class="flex-column">
              <v-col>
                <p class="bmt0">
                  <strong>{{ $t("description") }}</strong>
                </p>
                <p>{{ batchImportItem.description }}</p>
              </v-col>
              <v-col class="elipsis-twoline"> </v-col>
            </v-row>
          </v-col>
          <v-col md="4" sm="12" xs="12" class="bpr6 bpl6">
            <v-row no-gutters class="pr-3 bmb1">
              <v-col class="text-xs-left">
                <p class="bmt0">
                  <strong>{{ $t("createdDate") }}: </strong>
                </p>
              </v-col>
              <v-col class="text-xs-right">
                <p class="bmt0">
                  {{ format_date(batchImportItem.createdDate)[0] }}<br />
                  {{ format_date(batchImportItem.createdDate)[1] }}
                </p>
              </v-col>
            </v-row>
            <v-row no-gutters class="pr-3">
              <v-col class="text-xs-left">
                <p>
                  <strong>{{ $t("lastEditedDate") }}</strong>
                </p>
              </v-col>
              <v-col class="text-xs-right bpr3 bpl3">
                <p>
                  {{ format_date(batchImportItem.updatedDate)[0] }}<br />
                  {{ format_date(batchImportItem.updatedDate)[1] }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col sm="12" class="bmt1">
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span :title="$t('viewDetails')" class="active">
                  <v-icon>fe fe-eye</v-icon>
                  <span
                    class="viewdetails-icon"
                    @click="viewDetailsDialog = true; viewDetails(batchImportItem);"
                    >{{ $t("viewDetails") }}</span
                  >
                </span>
                <span
                  :title="$t('edit')"
                  data-qe-id="edit_btn"
                  @click="editBatchImport(batchImportItem)"
                >
                  <v-icon id="viewuser_edit-icon" class="blackicon"
                    >fe fe-edit</v-icon
                  >
                  <span class="edit-icon" id="viewuser-edit">{{
                    $t("edit")
                  }}</span>
                </span>
                <span
                  :title="$t('copy')"
                  data-qe-id="copy_btn"
                  @click="cloneBatchImport(batchImportItem)"
                >
                  <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                    >feather-icon fe fe-copy</v-icon
                  >
                  <span class="copy-icon">
                    {{ $t("copy") }}
                  </span>
                </span>
                <span
                  :title="$t('delete')"
                  data-qe-id="delete_btn"
                  @click="deleteBatchImportItem(i, batchImportItem)"
                >
                  <v-icon>fe fe-trash-2</v-icon>
                  <span class="delete-icon">{{ $t("delete") }}</span>
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
        </v-row>
      </v-card>
    </v-col>
    <brierley-dialogbox
      :dialog="viewDetailsDialog"
      @closeMe="viewDetailsDialog = $event"
      class="custom-dialog__large"
    >
      <template v-slot:dialog-header>
        <v-card-title class="gen2-dialog-title text-uppercase">
          batch import name</v-card-title
        >
      </template>
      <template v-slot:dialog-body-description>
        <batch-import-view-details></batch-import-view-details>
      </template>
      <template v-slot:dialog-footer> </template>
    </brierley-dialogbox>
  </v-row>
</template>
<script>
import {
  BrierleyCardIcons,
  BrierleyDialogbox
} from '@brierley/SharedComponents';
import { batchImportCardViewObj } from '../../../../i18n/language';
import BatchImportViewDetails from './BatchImportViewDetails';
import moment from 'moment';
import { mapState } from 'vuex';

export default {
  i18n: batchImportCardViewObj,
  components: {
    BrierleyCardIcons,
    BrierleyDialogbox,
    BatchImportViewDetails
  },
  data () {
    return {
      viewDetailsDialog: false,
      deleteIndex: -1
    };
  },
  props: {
    batchImportList: {
      type: Array,
      default: () => []
    }
  },
  methods: {
    deleteBatchImportItem (index, batchImportItem) {
      this.deleteIndex = index;
      this.$store.dispatch(
        'batchImportModule/deleteBatchImport',
        batchImportItem.batchImportId
      );
    },
    format_date (value) {
      if (value) {
        let date = moment(value).format('MMM Do YYYY');
        let time = moment(value).format('hh:mm A');
        return [date, time];
      }
    },
    cloneBatchImport (batchImportItem) {
      let batchImportObj = { ...batchImportItem };
      batchImportObj.isReview = false;
      delete batchImportObj.batchImportId;
      batchImportObj.batchImportName = `${batchImportObj.batchImportName}Copy`;
      this.$store.dispatch(
        'batchImportModule/createBatchImport',
        batchImportObj
      );
    },
    editBatchImport (batchImport) {
      this.$store.commit(
        'batchImportModule/updateBatchImportInfo',
        batchImport
      );
      this.$router.push({
        name: 'editBatchImport',
        params: { id: batchImport.batchImportId }
      });
    },
    viewDetails (batchImportItem) {
      this.$store.dispatch('batchImportModule/getBatchImportItem', batchImportItem);
      this.batchImportDetailedViewFilters.batchImportId = batchImportItem.batchImportId;
      this.$store.dispatch('batchImportModule/getBatchImportFiles',this.batchImportDetailedViewFilters);
    }
  },
  computed: {
    ...mapState('batchImportModule', ['batchImportItem', 'batchImportDetailedViewFilters'])
  },
  watch: {
    '$store.state.batchImportModule.createImportStatus' (newVal) {
      if (newVal === 'Success') {
        this.batchImportList.push(this.batchImportItem);
        this.$store.dispatch('batchImportModule/getBatchImportItem', '');
        this.$store.dispatch('batchImportModule/resetCreateImportStatus', '');
      }
    },
    '$store.state.batchImportModule.batchImportDeleteStatus' (newVal) {
      if (newVal) {
        this.batchImportList.splice(this.deleteIndex, 1);
        this.deleteIndex = -1;
        this.$store.dispatch(
          'batchImportModule/resetBatchImportDeleteStatus',
          false
        );
      }
    }
  }
};
</script>
