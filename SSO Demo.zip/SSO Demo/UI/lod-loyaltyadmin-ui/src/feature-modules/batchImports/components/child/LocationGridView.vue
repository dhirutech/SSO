<template>
  <v-row>
    <v-col cols="12" v-for="(location, i) in locations" :key="i">
      <v-card class="gen2-card gen2-typo3">
        <v-row no-gutters>
          <v-col md="3" sm="12" xs="12">
            <v-card-title class="elipsis-fullwidth">
              {{ location.locationName }}
            </v-card-title>
            <div class="gen2-card-copy">
              <p class="elipsis-fullwidth bmb1" id="viewuser_email">
                <strong>{{ $t("locationType") }}: </strong>
                {{ location.locationType }}
              </p>
              <p class="elipsis-twoline" :title="location.hostname">
                <strong>{{ $t("hostName") }}: </strong>
                {{ location.hostname }}
              </p>
            </div>
          </v-col>
          <v-col md="3" sm="12" xs="12" class="">
            <v-row no-gutters class="flex-column">
              <v-col>
                <p class="bmt0">
                  <strong>{{ $t("description") }}</strong>
                </p>
                <p>{{ location.locationDescription }}</p>
              </v-col>
              <v-col class="elipsis-twoline"> </v-col>
            </v-row>
          </v-col>
          <v-col md="4" sm="12" xs="12" class="bpr6 bpl6">
            <v-row no-gutters class="pr-3 bmb1">
              <v-col class="text-xs-left">
                <p class="bmt0">
                  <strong>{{ $t("createdDate") }}: </strong>
                </p>
              </v-col>
              <v-col class="text-xs-right">
                <p class="bmt0">
                  {{ format_date(location.createdDate)[0] }}<br />
                  {{ format_date(location.createdDate)[1] }}
                </p>
              </v-col>
            </v-row>
            <v-row no-gutters class="pr-3">
              <v-col class="text-xs-left">
                <p>
                  <strong>{{ $t("lastEditedDate") }}:</strong>
                </p>
              </v-col>
              <v-col class="text-xs-right bpr3 bpl3">
                <p>
                  {{ format_date(location.updatedDate)[0] }}<br />
                  {{ format_date(location.updatedDate)[1] }}
                </p>
              </v-col>
            </v-row>
          </v-col>
          <v-col class="gen2-card-status">
            <p class="bmt0">
              <strong>{{ $t("status") }}</strong>
            </p>
            <brierley-status status="Active"></brierley-status>
          </v-col>
          <v-col sm="12">
            <brierley-card-icons>
              <template v-slot:action-icons>
                <span
                  :title="$t('edit')"
                  class="active"
                  :id="`batch_location_grid_edit_${i}`"
                  @click="editLocation(location)"
                >
                  <v-icon id="viewuser_edit-icon" class="blackicon"
                    >fe fe-edit</v-icon
                  >
                  <span class="edit-icon" id="viewuser-edit">{{
                    $t("edit")
                  }}</span>
                </span>
                <span
                  @click="deletePopup(location.locationId, i)"
                  :id="`batch_location_grid_delete_${i}`"
                >
                  <v-icon :title="$t('delete')" class="blackicon"
                    >fe-trash-2</v-icon
                  >
                  <span class="delete-icon">{{ $t("delete") }}</span>
                </span>
              </template>
            </brierley-card-icons>
          </v-col>
        </v-row>
      </v-card>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyStatus, BrierleyCardIcons } from '@brierley/SharedComponents';
import moment from 'moment';
import { locationsCardViewObj } from '../../../../i18n/language';

export default {
  i18n: locationsCardViewObj,
  components: {
    BrierleyStatus,
    BrierleyCardIcons
  },
  data () {
    return {
      noResultsMessage: ''
    };
  },
  props: {
    locations: {
      type: Array,
      default: () => []
    }
  },
  methods: {
    format_date (value) {
      if (value) {
        let date = moment(value).format('MMM Do YYYY');
        let time = moment(value).format('hh:mm A');
        return [date, time];
      }
    },
    deletePopup (id, index) {
      this.$emit('deleteLocation', id, index);
    },
    editLocation (location) {
      this.$store.commit('batchImportModule/updateLocationInfo', location);
      this.$router.push({
        name: 'editLocation',
        params: { id: location.locationId }
      });
    }
  }
};
</script>
