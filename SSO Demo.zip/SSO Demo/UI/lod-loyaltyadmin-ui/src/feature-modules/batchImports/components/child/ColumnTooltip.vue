<template>
  <v-menu open-on-hover bottom offset-y>
    <template v-slot:activator="{ on, attrs }">
      <v-icon v-bind="attrs" v-on="on" class="primary-text"
        >mdi-information-outline</v-icon
      >
    </template>
    <v-row class="table-custom-tooltip flex-column" no-gutters>
      <v-col class="table-custom-tooltip__head text-uppercase">
        <v-icon class="font24 bmr1">info</v-icon>
        {{ header }}
      </v-col>
      <v-col class="table-custom-tooltip__content">
        {{ content }}
      </v-col>
    </v-row>
  </v-menu>
</template>
<script>
export default {
  props: {
    header: String,
    content: String
  }
};
</script>
