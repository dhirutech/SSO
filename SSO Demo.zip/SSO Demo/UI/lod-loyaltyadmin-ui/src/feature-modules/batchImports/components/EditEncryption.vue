<template>
  <brierley-inner-view>
    <template v-slot:header>
      <v-flex class="toggle-menu-custom">
        <v-btn class="no-ripple iconbtn" text @click="menutoggle = !menutoggle">
          <v-icon>
            fe-menu
          </v-icon>
        </v-btn>
        <brierley-toggle-menu v-if="menutoggle"></brierley-toggle-menu>
      </v-flex>
      <span class="inner-head text-uppercase">
        <small class="white-text">{{ $t("batchImportText") }}</small>
        / {{ encryptionPathText }} {{ $t("encryptionText") }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        data-qe-id="encryption_close_btn"
        class="no-ripple"
        text
        @click.native="closeEncryption()"
      >
        <v-icon>arrow_back</v-icon>{{ $t("back") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <brierley-form-title
        class="bmt3"
        :formTitle="$t('basicInformation')"
        :infoText="$t('infoText')"
        :showSteps="false"
      ></brierley-form-title>
      <div class="bmt5">
        <v-row no-gutters>
          <v-col cols="12" sm="6" class="gen2-forms form-light-bg">
            <p>
              <strong class="text-uppercase">{{
                $t("encryptionDetails")
              }}</strong>
            </p>
            <v-row no-gutters>
              <v-col cols="12" md="8">
                <validation-provider rules="required" v-slot="{ errors }">
                  <v-text-field
                    data-qe-id="encryption_key_name_text_field"
                    :label="$t('encryptionKeyName')"
                    v-model="encryptionKeyObj.encryptionKeyName"
                    filled
                  />
                  <p
                    v-if="errors[0] === 'This field is required'"
                    class="custom-error-msg"
                  >
                    {{ $t("encryptionKeyNameMessage") }}
                  </p>
                </validation-provider>
              </v-col>
            </v-row>
            <validation-provider rules="required" v-slot="{ errors }">
              <v-textarea
                data-qe-id="encryption_key_description_text_field"
                :label="$t('encryptionKeyDescription')"
                v-model="encryptionKeyObj.encryptionKeyDescription"
                filled
                auto-grow
              >
              </v-textarea>
              <p
                v-if="errors[0] === 'This field is required'"
                class="custom-error-msg"
              >
                {{ $t("encryptionKeyDescriptionMessage") }}
              </p>
            </validation-provider>
            <v-row no-gutters>
              <v-col cols="12" md="8">
                <v-text-field
                  data-qe-id="encryption_key_algorithm_text_field"
                  :label="$t('algorithm')"
                  v-model="encryptionKeyObj.algorithm"
                  disabled
                  filled
                  auto-grow
                />
                <v-text-field
                  data-qe-id="encryption_key_keySize_text_field"
                  :label="$t('keySize')"
                  v-model="encryptionKeyObj.keySize"
                  disabled
                  filled
                  auto-grow
                />
                <v-text-field
                  data-qe-id="encryption_key_expiration_text_field"
                  :label="$t('expiration')"
                  v-model="encryptionKeyObj.expiration"
                  disabled
                  filled
                  auto-grow
                />
                <validation-provider rules="required" v-slot="{ errors }">
                  <v-text-field
                    v-model="encryptionKeyObj.passphrase"
                    data-qe-id="passphrase_text_field"
                    :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
                    :type="showPassword ? 'text' : 'password'"
                    :label="passphrase"
                    counter
                    @click:append="showPassword = !showPassword"
                    filled
                  ></v-text-field>
                  <p
                    v-if="errors[0] === 'This field is required'"
                    class="custom-error-msg"
                  >
                    {{ $t("passphraseMessage") }}
                  </p>
                </validation-provider>
              </v-col>
            </v-row>
          </v-col>
          <v-col offset-sm="2" cols="12" sm="4" class="">
            <brierley-info-side>
              <template v-slot:info-side-header>
                <div class="info_title"><v-icon>info</v-icon>{{ $t("infoTitle") }}</div>
              </template>
              <template v-slot:info-side-body>
                <p>
                  {{ $t("infoText") }}
                </p>
              </template>
            </brierley-info-side>
          </v-col>
        </v-row>
      </div>
    </template>

    <template v-slot:footer>
      <v-btn text class="cancel no-ripple bmr6" data-qe-id="cancel_btn">{{
        $t("cancel")
      }}</v-btn>
      <v-btn
        text
        class="primaryctabtn no-ripple large"
        data-qe-id="next_review_btn"
        :disabled="
          encryptionKeyObj.passphrase === '' ||
            encryptionKeyObj.encryptionKeyName === '' ||
            encryptionKeyObj.encryptionKeyDescription === '' ||
            isUpdated
        "
        @click.native="review"
        >{{ $t("nextbtn") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>

<script>
import {
  BrierleyInnerView,
  BrierleyToggleMenu,
  BrierleyFormTitle,
  BrierleyInfoSide
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { editEncryptionObj } from '../../../i18n/language';

export default {
  i18n: editEncryptionObj,
  components: {
    BrierleyInnerView,
    BrierleyToggleMenu,
    BrierleyFormTitle,
    BrierleyInfoSide
  },
  data () {
    return {
      menutoggle: false,
      items: ['OPtion-1', 'Options-2'],
      password: 'Password',
      showPassword: false,
      selectedAlgorithm: 'RSA',
      encryptionKeyObj: {},
      currentStep: 1,
      isUpdated: false
    };
  },
  created () {
    window.scrollTo(0, 0);
  },
  methods: {
    review () {
      this.$store.dispatch(
        'batchImportModule/getEncryptionKey',
        this.encryptionKeyObj
      );
      this.$router.push({
        name: 'reviewEncryption'
      });
    },
    isEncryptionKeyUpdated () {
      if (this.encryptionKey.isEdit) {
        if (
          this.encryptionKey.encryptionKeyName !==
            this.encryptionKeyObj.encryptionKeyName ||
          this.encryptionKey.encryptionKeyDescription !==
            this.encryptionKeyObj.encryptionKeyDescription ||
          this.encryptionKey.passphrase !== this.encryptionKeyObj.passphrase
        ) {
          this.isUpdated = false;
        } else {
          this.isUpdated = true;
        }
      }
    },
    closeEncryption () {
      this.$store.commit('batchImportModule/setImportTab', 2);
      this.$router.push('/loyaltyadmin/batchImport');
    }
  },
  watch: {
    'encryptionKeyObj.encryptionKeyName' () {
      this.isEncryptionKeyUpdated();
    },
    'encryptionKeyObj.encryptionKeyDescription' () {
      this.isEncryptionKeyUpdated();
    },
    'encryptionKeyObj.passphrase' () {
      this.isEncryptionKeyUpdated();
    }
  },
  computed: {
    ...mapState('batchImportModule', ['encryptionKey']),
    encryptionPathText () {
      return this.$route && this.$route.path.includes('createEncryption')
        ? this.$t('newText')
        : this.$t('editText');
    }
  },
  mounted () {
    this.encryptionKeyObj = { ...this.encryptionKey };
  }
};
</script>
<style lang="scss" scoped>
.dashed-border {
  border: 1px dashed rgba(102, 102, 102, 0.3);
  margin: 24px 0;
}
.download-public-key {
  position: relative;
  border: 2px dashed rgba(102, 102, 102, 0.3);
  &:before {
    content: "";
    position: absolute;
    left: -1px;
    top: -1px;
    right: -1px;
    bottom: -1px;
    border: 1px solid white;
    z-index: 1;
  }
  .v-icon {
    font-size: 40px !important;
    display: block;
    color: rgba(102, 102, 102, 0.5);
  }
  .v-btn {
    position: relative;
    z-index: 1;
    width: 100%;
    padding: 64px 0;
    text-transform: inherit;
  }
}
</style>
