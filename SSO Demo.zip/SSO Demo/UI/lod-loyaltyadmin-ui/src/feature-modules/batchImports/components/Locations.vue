<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <v-row class="gen2-search-filter" no-gutters>
        <v-col class="text-left label-text bpt1" cols="6">
          {{ $t("locationListText") }}
        </v-col>
        <v-col cols="6" class="text-right align-self-center">
          <div class="bmr1 d-inline-block">
            <brierley-view-option
              :isDisabled="!locations.length"
              :viewList="cardlist"
              @viewChanged="viewType = $event"
            ></brierley-view-option>
          </div>
          <brierley-icon-with-head
            class="loyalty-users-common__create-user"
            :isDisabled="locations.length > 0"
            :iconTitle="$t('addNewLocationText')"
            iconName="add_circle"
            @clicked="addNewLocation()"
          ></brierley-icon-with-head>
        </v-col>
        <v-col cols="12" class="filter-dropdown bmt1">
          <!-- <brierley-filter-result v-if="isHidden">
            <template v-slot:body-content>
            </template>
            <template v-slot:footer>
              <v-btn
                text
                title="Clear & Close"
                class="mr-5 cancel bmt3"
                id="viewuser_btn_clear"
                >{{ $t('clearBtnText') }}</v-btn
              >
              <v-btn
                title="Apply Filters"
                depressed
                class="next bmt3 primaryctabtn"
                >{{ $t('filterBtnText') }}</v-btn
              >
            </template>
          </brierley-filter-result> -->
        </v-col>
      </v-row>
    </v-col>
    <v-col v-if="viewType == 'card_view'">
      <location-card-view
        :locations="locations"
        @deleteLocation="deleteLocation"
      />
    </v-col>
    <v-col v-if="viewType == 'grid_view'">
      <location-grid-view
        :locations="locations"
        @deleteLocation="deleteLocation"
      />
    </v-col>
    <v-col v-if="viewType == 'table_view'">
      <location-table-view
        :locations="locations"
        @deleteLocation="deleteLocation"
      />
    </v-col>
    <brierley-no-result
      v-if="!locations.length"
      :no-result-message="noResultsMessage"
    ></brierley-no-result>
    <!-- delete location dialog box -->
    <delete-location
      v-if="deleteDialogPopup"
      :dialog="deleteDialogPopup"
      :locationId="locationId"
      :locationIndex="locationIndex"
      :locations="locations"
      @deleteDialog="deleteDialogPopup = false"
    >
    </delete-location>
  </v-row>
</template>

<script>
import {
  BrierleyIconWithHead,
  BrierleyViewOption,
  BrierleyNoResult
} from '@brierley/SharedComponents';
import LocationCardView from './child/LocationCardView';
import LocationGridView from './child/LocationGridView';
import LocationTableView from './child/LocationTableView';
import DeleteLocation from './actions/DeleteLocation';
import { mapState } from 'vuex';
import { locationsObj } from '../../../i18n/language';

export default {
  i18n: locationsObj,
  components: {
    BrierleyIconWithHead,
    BrierleyViewOption,
    LocationCardView,
    LocationGridView,
    LocationTableView,
    DeleteLocation,
    BrierleyNoResult
  },
  data () {
    return {
      viewType: 'grid_view',
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('gridViewText')
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('tableViewText')
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('cardViewText')
        }
      ],
      deleteDialogPopup: false,
      locationIndex: 0,
      locationId: null,
      noResultsMessage: ''
    };
  },
  created () {
    window.scrollTo(0, 0);
  },
  computed: {
    ...mapState('batchImportModule', ['locationList']),
    locations () {
      return this.locationList || this.locationList.length
        ? this.locationList
        : [];
    }
  },
  methods: {
    deleteLocation (id, index) {
      this.locationId = id;
      this.locationIndex = index;
      this.deleteDialogPopup = true;
    },
    addNewLocation () {
      this.$router.push('/loyaltyadmin/batchImport/createLocation');
    }
  }
};
</script>
