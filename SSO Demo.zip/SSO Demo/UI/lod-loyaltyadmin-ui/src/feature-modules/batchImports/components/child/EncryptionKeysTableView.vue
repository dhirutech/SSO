<template>
  <v-row class="flex-column" no-gutter>
    <brierley-table-module>
      <template v-slot:tablehead>
        <tr class="text-left">
          <th
            id="table_row_encryption_header_name"
            v-for="item in header"
            :key="item.name"
            class="text-left"
            :width="item.width"
          >
            {{ item.text }}
          </th>
        </tr>
      </template>
      <template v-slot:tablebody>
        <tr v-for="(encryptionKey, i) in encryptionKeys" :key="i">
          <td>
            <h4
              class="primary-text font15 text-uppercase fbold elipsis-fullwidth"
            >
              {{ encryptionKey.encryptionKeyName }}
            </h4>
          </td>
          <td>
            <div
              :title="encryptionKey.encryptionKeyDescription"
              class="elipsis-description"
            >
              {{ encryptionKey.encryptionKeyDescription }}
            </div>
          </td>
          <td>{{ encryptionKey.algorithm }}</td>
          <td>{{ `${encryptionKey.keySize} Bits (Secure)` }}</td>
          <td>{{ encryptionKey.expiration }}</td>
          <td>
            {{ format_date(encryptionKey.createdDate)[0] }}<br />
            {{ format_date(encryptionKey.createdDate)[1] }}
          </td>
          <td>
            <v-btn
              text
              class="no-ripple btn-hover-none bpx0"
              @click="dowloadKey(encryptionKey)"
              data-qe-id="download_encryption_key_btn">
              <span class="fbold primary-text">
                <span class="download-lock"
                  ><v-icon>get_app</v-icon
                  ><v-icon class="download-lock__icon">lock</v-icon></span
                >
                {{ $t("downloadkey") }}
              </span>
            </v-btn>
            <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
              <v-col>
                <brierleyCardIcons>
                  <template v-slot:action-icons>
                    <span
                      :title="$t('edit')"
                      data-qe-id="edit_btn"
                      @click="editNav(encryptionKey)"
                    >
                      <v-icon id="viewuser_edit-icon" class="blackicon"
                        >fe fe-edit</v-icon
                      >
                      <span class="edit-icon" id="viewuser-edit">{{
                        $t("edit")
                      }}</span>
                    </span>
                    <span
                      :title="$t('delete')"
                      data-qe-id="delete_btn"
                      @click="deleteKey(encryptionKey, i)"
                    >
                      <v-icon>fe fe-trash-2</v-icon>
                      <span class="delete-icon">{{ $t("delete") }}</span>
                    </span>
                  </template>
                </brierleyCardIcons>
              </v-col>
            </v-row>
          </td>
        </tr>
      </template>
    </brierley-table-module>
  </v-row>
</template>

<script>
import _ from 'lodash';
import {
  BrierleyCardIcons,
  BrierleyTableModule
} from '@brierley/SharedComponents';
import moment from 'moment';
import { encryptionGridViewObj } from '../../../../i18n/language';
export default {
  i18n: encryptionGridViewObj,
  data () {
    return {
      sortKey: ['name'],
      sortOrder: ['asc'],
      isToggled: false,
      changeColor: false,

      header: [
        {
          name: 'encryptionKeyName',
          text: this.$t('encryptionName'),
          sort: 'asc'
        },
        {
          name: 'encryptionKeyDescription',
          text: this.$t('description'),
          sort: '',
          width: '210'
        },
        {
          name: 'algorithm',
          text: this.$t('algorithm'),
          sort: '',
          width: '130'
        },
        { name: 'keySize', text: this.$t('keySize'), sort: '', width: '130' },
        {
          name: 'expiration',
          text: this.$t('expiration'),
          sort: '',
          width: '135'
        },
        {
          name: 'createdDate',
          text: this.$t('createdDate'),
          sort: '',
          width: '160'
        },
        { name: 'encryptionKey', text: this.$t('encryptionKey'), sort: '' }
      ],
      deleteIndex: -1
    };
  },
  components: {
    BrierleyCardIcons,
    BrierleyTableModule
  },
  methods: {
    sortBy: function (item) {
      let i = this.header.indexOf(item);
      for (let j = 0; j < this.header.length; j++) {
        if (j === i) {
          this.header[j].sort =
            this.header[j].sort === '' || this.header[j].sort === 'desc'
              ? 'asc'
              : 'desc';
        } else {
          this.header[j].sort = '';
        }
      }
      this.sortKey = this.header[i].name;
      this.sortOrder = this.header[i].sort;
    },
    deleteKey (item, index) {
      this.deleteIndex = index;
      this.$store.dispatch(
        'batchImportModule/deleteEncryptionKey',
        item.encryptionId
      );
    },
    editNav (encryptionItem) {
      encryptionItem.isEdit = true;
      this.$store.dispatch(
        'batchImportModule/getEncryptionKey',
        encryptionItem
      );
      this.$router.push({
        name: 'editEncryption',
        params: { id: encryptionItem.encryptionId }
      });
    },
    format_date (value) {
      if (value) {
        let date = moment(value).format('MMM Do YYYY');
        let time = moment(value).format('hh:mm A');
        return [date, time];
      }
    },
    dowloadKey (item) {
      this.$store.dispatch(
        'batchImportModule/downloadEncryptionKeys',
        item.encryptionKeyName
      );
    }
  },
  computed: {
    campaigns: function () {
      return _.orderBy(this.encryptionKeys, this.sortKey, this.sortOrder);
    }
  },
  props: {
    encryptionKeys: {
      type: Array,
      default: () => []
    }
  },
  watch: {
    '$store.state.batchImportModule.deleteEncryptionKeyStatus' (newVal) {
      if (newVal) {
        this.encryptionKeys.splice(this.deleteIndex, 1);
        this.deleteIndex = -1;
        this.$store.dispatch('batchImportModule/resetDeleteStatus', false);
      }
    }
  }
};
</script>
