<template>
  <v-row class="flex-column" no-gutter>
    <brierley-table-module>
      <template v-slot:tablehead>
        <tr class="text-left">
          <th
            v-for="item in header"
            id="batch_import_sort_arrow"
            :key="item.name"
            @click="
              sortBy(item);
              arrowToggle();
            "
            class="text-left"
            :width="item.width"
          >
            {{ item.text
            }}<v-icon
              v-if="item.sort != ''"
              small
              v-bind:class="{
                down: item.sort === 'asc',
                up: item.sort === 'desc'
              }"
              class="arrow uparw"
              >arrow_drop_up</v-icon
            >
          </th>
        </tr>
      </template>
      <template v-slot:tablebody>
        <tr v-for="(batchImportItem, i) in batchImportList" :key="i">
          <td>
            <h4
              class="primary-text font15 text-uppercase fbold elipsis-fullwidth"
            >
              {{ batchImportItem.batchImportName }}
            </h4>
          </td>
          <td>
            {{ batchImportItem.serviceName }}
          </td>
          <td>{{ batchImportItem.fileEncryptionId }}</td>
          <td class="elipsis-fullwidth" :title="batchImportItem.locationPath">
            {{ batchImportItem.locationPath }}
          </td>
          <td>
            <div
              :title="batchImportItem.description"
              class="elipsis-description"
            >
              {{ batchImportItem.description }}
            </div>
          </td>
          <td>
            {{ format_date(batchImportItem.createdDate)[0] }}<br />
            {{ format_date(batchImportItem.createdDate)[1] }}
          </td>
          <td>
            {{ format_date(batchImportItem.updatedDate)[0] }}<br />
            {{ format_date(batchImportItem.updatedDate)[1] }}
            <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
              <v-col>
                <brierleyCardIcons>
                  <template v-slot:action-icons>
                    <span :title="$t('viewDetails')" class="active">
                      <v-icon>fe fe-eye</v-icon>
                      <span
                        class="viewdetails-icon"
                        @click="viewDetailsDialog = true; viewDetails(batchImportItem);"
                        >{{ $t("viewDetails") }}</span
                      >
                    </span>
                    <span
                      :title="$t('edit')"
                      data-qe-id="edit_btn"
                      @click="editBatchImport(batchImportItem)"
                    >
                      <v-icon id="viewuser_edit-icon" class="blackicon"
                        >fe fe-edit</v-icon
                      >
                      <span class="edit-icon" id="viewuser-edit">{{
                        $t("edit")
                      }}</span>
                    </span>
                    <span
                      :title="$t('copy')"
                      data-qe-id="copy_btn"
                      @click="cloneBatchImport(batchImportItem)"
                    >
                      <v-icon id="viewuser_copy-icon" class="blackicon cursor-p"
                        >feather-icon fe fe-copy</v-icon
                      >
                      <span class="copy-icon">
                        {{ $t("copy") }}
                      </span>
                    </span>
                    <span
                      :title="$t('delete')"
                      data-qe-id="delete_btn"
                      @click="deleteBatchImportItem(i, batchImportItem)"
                    >
                      <v-icon>fe fe-trash-2</v-icon>
                      <span class="delete-icon">{{ $t("delete") }}</span>
                    </span>
                  </template>
                </brierleyCardIcons>
              </v-col>
            </v-row>
          </td>
        </tr>
      </template>
    </brierley-table-module>
    <brierley-dialogbox
      :dialog="viewDetailsDialog"
      @closeMe="viewDetailsDialog = $event"
      class="custom-dialog__large"
    >
      <template v-slot:dialog-header>
        <v-card-title class="gen2-dialog-title text-uppercase">
          batch import name</v-card-title
        >
      </template>
      <template v-slot:dialog-body-description>
        <batch-import-view-details></batch-import-view-details>
      </template>
      <template v-slot:dialog-footer> </template>
    </brierley-dialogbox>
  </v-row>
</template>

<script>
import _ from 'lodash';
import {
  BrierleyCardIcons,
  BrierleyTableModule,
  BrierleyDialogbox
} from '@brierley/SharedComponents';
import { batchImportCardViewObj } from '../../../../i18n/language';
import BatchImportViewDetails from './BatchImportViewDetails';
import moment from 'moment';
import { mapState } from 'vuex';

export default {
  i18n: batchImportCardViewObj,
  data () {
    return {
      sortKey: ['name'],
      sortOrder: ['asc'],
      isToggled: false,
      changeColor: false,
      viewDetailsDialog: false,
      header: [
        {
          name: 'batchImportName',
          text: this.$t('batchImportName'),
          sort: 'asc'
        },
        {
          name: 'serviceName',
          text: this.$t('batchTemplate'),
          sort: '',
          width: ''
        },
        {
          name: 'fileEncryptionId',
          text: this.$t('fileEncryptionKey'),
          sort: '',
          width: ''
        },
        {
          name: 'locationPath',
          text: this.$t('fileLocation'),
          sort: '',
          width: ''
        },
        {
          name: 'description',
          text: this.$t('description'),
          sort: '',
          width: ''
        },
        {
          name: 'createdDate',
          text: this.$t('createdDate'),
          sort: '',
          width: ''
        },
        { name: 'updatedDate', text: this.$t('lastEditedDate'), sort: '' }
      ],
      deleteIndex: -1
    };
  },
  props: {
    batchImportList: {
      type: Array,
      default: () => []
    }
  },
  components: {
    BrierleyCardIcons,
    BrierleyTableModule,
    BrierleyDialogbox,
    BatchImportViewDetails
  },
  methods: {
    sortBy: function (item) {
      let i = this.header.indexOf(item);
      for (let j = 0; j < this.header.length; j++) {
        if (j === i) {
          this.header[j].sort =
            this.header[j].sort === '' || this.header[j].sort === 'desc'
              ? 'asc'
              : 'desc';
        } else {
          this.header[j].sort = '';
        }
      }
      this.sortKey = this.header[i].name;
      this.sortOrder = this.header[i].sort;
    },
    arrowToggle () {
      this.isToggled = !this.isToggled;
    },
    editNav (encryptionItem) {
      this.$store.dispatch(
        'batchImportModule/getEncryptionKey',
        encryptionItem
      );
      this.$router.push('/loyaltyadmin/editEncryption');
    },
    format_date (value) {
      if (value) {
        let date = moment(value).format('MMM Do YYYY');
        let time = moment(value).format('hh:mm A');
        return [date, time];
      }
    },
    deleteBatchImportItem (index, batchImportItem) {
      this.deleteIndex = index;
      this.$store.dispatch(
        'batchImportModule/deleteBatchImport',
        batchImportItem.batchImportId
      );
    },
    cloneBatchImport (batchImportItem) {
      let batchImportObj = { ...batchImportItem };
      batchImportObj.isReview = false;
      delete batchImportObj.batchImportId;
      batchImportObj.batchImportName = `${batchImportObj.batchImportName}Copy`;
      this.$store.dispatch(
        'batchImportModule/createBatchImport',
        batchImportObj
      );
    },
    editBatchImport (batchImport) {
      this.$store.commit(
        'batchImportModule/updateBatchImportInfo',
        batchImport
      );
      this.$router.push({
        name: 'editBatchImport',
        params: { id: batchImport.batchImportId }
      });
    },
    viewDetails (batchImportItem) {
      this.$store.dispatch('batchImportModule/getBatchImportItem', batchImportItem);
      this.batchImportDetailedViewFilters.batchImportId = batchImportItem.batchImportId;
      this.$store.dispatch('batchImportModule/getBatchImportFiles',this.batchImportDetailedViewFilters);
    }
  },
  computed: {
    campaigns: function () {
      return _.orderBy(this.batchImportList, this.sortKey, this.sortOrder);
    },
    ...mapState('batchImportModule', ['batchImportItem', 'batchImportDetailedViewFilters'])
  },
  watch: {
    '$store.state.batchImportModule.createImportStatus' (newVal) {
      if (newVal === 'Success') {
        this.batchImportList.push(this.batchImportItem);
        this.$store.dispatch('batchImportModule/getBatchImportItem', '');
        this.$store.dispatch('batchImportModule/resetCreateImportStatus', '');
      }
    },
    '$store.state.batchImportModule.batchImportDeleteStatus' (newVal) {
      if (newVal) {
        this.batchImportList.splice(this.deleteIndex, 1);
        this.deleteIndex = -1;
        this.$store.dispatch(
          'batchImportModule/resetBatchImportDeleteStatus',
          false
        );
      }
    }
  }
};
</script>
