<template>
  <brierley-inner-view :footerOnly="false">
    <template v-slot:header>
      <span class="inner-head text-uppercase">
        {{ $t("batchImportHeaderText") }}
      </span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        data-qe-id="batch_import_close_icon"
        @click.native="goToPreviousPage()"
      >
        <v-icon>mdi-close</v-icon>
        {{ $t("closeBtn") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row class="flex-column" no-gutters>
        <v-col class="loyalty-users-common">
          <v-row class="flex-column bpt4" no-gutters>
            <v-col>
              <brierley-form-title
                :formTitle="batchImportText"
                :infoText="$t('batchImportInfoText')"
              >
              </brierley-form-title>
            </v-col>
          </v-row>
        </v-col>
        <v-col class="bmt5">
          <brierleyTabs :selected="selectedImportTab" v-if="isAdminUser">
            <template v-slot:tabs-header>
              <v-tab>{{ $t("batchImportHeaderText") }}</v-tab>
              <v-tab>{{ $t("locationsTabText") }}</v-tab>
              <v-tab>{{ $t("encryptionTabText") }}</v-tab>
            </template>
            <template v-slot:tabs-body>
              <v-tab-item>
                <batch-imports-view ref="batchImport"></batch-imports-view>
              </v-tab-item>
              <v-tab-item>
                <Locations />
              </v-tab-item>
              <v-tab-item>
                <encryption-keys></encryption-keys>
              </v-tab-item>
            </template>
          </brierleyTabs>
          <batch-imports-view ref="batchImport" v-else></batch-imports-view>
        </v-col>
      </v-row>
    </template>
    <template v-slot:footer>
      <v-btn
        data-qe-id="batch_import_close_btn"
        text
        :title="$t('closeBtn')"
        class="primaryctabtn no-ripple"
        @click.native="goToPreviousPage()"
        >{{ $t("closeBtn") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyFormTitle,
  BrierleyInnerView,
  BrierleyTabs
} from '@brierley/SharedComponents';
import Locations from './Locations';
import EncryptionKeys from './EncryptionKeys';
import BatchImportsView from './batchImportsView';
import { mapState } from 'vuex';
import { batchImportObj } from '../../../i18n/language';

export default {
  i18n: batchImportObj,
  components: {
    BrierleyFormTitle,
    BrierleyInnerView,
    BrierleyTabs,
    Locations,
    EncryptionKeys,
    BatchImportsView
  },
  data () {
    return {
      batchImportText: this.$t('batchImportsText')
    };
  },
  computed: {
    ...mapState('batchImportModule', ['selectedImportTab', 'batchImportSwitchFilesFilter']),
    isAdminUser () {
      return this.$globalStore.state.isAdminUser;
    },
  },
  mounted () {
    this.$store.dispatch('batchImportModule/getLocationList');
    this.$store.dispatch('batchImportModule/getEncryptionKeyList');
    this.$store.dispatch('batchImportModule/getBatchImportList');
    this.$store.dispatch('batchImportModule/getBatchTemplates');
    if (this.$route.query.showAllFiles || !this.isAdminUser) {
      this.$store.dispatch('batchImportModule/getAllFiles', this.batchImportSwitchFilesFilter);
      this.batchImportText = this.$t('allFilesText');
    }
    this.$watch(() => {
      return this.$refs.batchImport.toggleSwitchAllFiles;
    },
    (val) => {
      if (val) {
        this.batchImportText = this.$t('allFilesText');
      } else {
        this.batchImportText = this.$t('batchImportsText');
      }
    });
  },
  methods: {
    goToPreviousPage () {
      if (this.$route.query.fromStore) {
        this.$router.push('/loyaltyadmin/stores/upload');
        return;
      }
      if (this.$route.query.fromProduct) {
        this.$router.push('/loyaltyadmin/products/upload');
        return;
      }
      this.$router.push('/gettingstarted');
    }
  }
};
</script>
