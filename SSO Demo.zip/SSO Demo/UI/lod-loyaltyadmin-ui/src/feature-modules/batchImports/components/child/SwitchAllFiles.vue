<template>
  <brierley-table-module class="bmr0 ml-n2">
    <template v-slot:tablehead>
      <tr class="text-left">
        <th v-for="item in header" :key="item.name" :width="item.width">
          {{ item.text }}
        </th>
      </tr>
    </template>
    <template v-slot:tablebody>
      <tr v-for="(importItem, i) in allFiles" :key="i">
        <td style="word-break: break-word;">
          {{ importItem.programName }}
        </td>
        <td>
          {{ importItem.serviceName }}
        </td>
        <td class="text-nowrap">
            {{ importItem.fileUploadedDate ? format_date(importItem.fileUploadedDate)[0] : ''}}<br />{{
              importItem.fileUploadedDate ? format_date(importItem.fileUploadedDate)[1] :''
            }}
        </td>
        <td>
          {{ importItem.numberofRecordsProcessed }}
        </td>
        <td>
          {{ importItem.numberofRecordsHavingErrors }}
        </td>
        <td class="text-nowrap">
            {{ importItem.fileProcessingEndDate ? format_date(importItem.fileProcessingEndDate)[0] : '' }}<br />{{
              importItem.fileProcessingEndDate ? format_date(importItem.fileProcessingEndDate)[1] : ''
            }}
        </td>
        <td>
          <brierley-status
            v-if="importItem.fileProcessingStatus === 'Processed'"
            status="Processed"
          >
          </brierley-status>
          <brierley-status
            v-if="importItem.fileProcessingStatus === 'Failed'"
            status="Failed"
          >
          </brierley-status>
        </td>
        <td>
          <v-btn
            text
            class="no-ripple btn-hover-none bpx0"
            data-qe-id="batch_import_detailed_view_download_btn"
          >
            <span class="fbold primary-text">
              <span class="download-lock"
                ><v-icon>get_app</v-icon
                ><v-icon class="download-lock__icon">lock</v-icon></span
              >
              {{ $t("download") }}
            </span>
          </v-btn>
        </td>
      </tr>
    </template>
  </brierley-table-module>
</template>

<script>
import { BrierleyTableModule, BrierleyStatus } from '@brierley/SharedComponents';
import { batchImportSwitchFilesObj } from '../../../../i18n/language';
import { mapState } from 'vuex';
import moment from 'moment';
export default {
  i18n: batchImportSwitchFilesObj,
  components: {
    BrierleyTableModule,
    BrierleyStatus
  },
  data () {
    return {
      header: [
        { name: 'programName', text: this.$t('fileName'), sort: 'asc', width: '15%' },
        { name: 'serviceName', text: this.$t('templateName'), sort: '', width: '10%' },
        { name: 'fileUploadedDate', text: this.$t('uploadDate'), sort: '' },
        { name: 'numberofRecordsProcessed', text: this.$t('processedRecordsText'), sort: '', width: '8%' },
        { name: 'recordsFailed', text: this.$t('failedRecordsText'), sort: '', width: '8%' },
        { name: 'numberofRecordsHavingErrors', text: this.$t('processedDate'), sort: '' },
        { name: 'fileProcessingStatus', text: this.$t('status'), sort: '' },
        { name: 'failedRecords', text: this.$t('failedRecords'), sort: '' }
      ],
      batchImportList: [
        {
          fileName: 'Store_202010081740',
          templateName: 'Store',
          uploadDate: 'Jan 31st 2019',
          recordsLoaded: 30436,
          recordsFailed: 234,
          processedDate: 'Jan 31st 2019',
          status: 'Processed',
          failedRecords: 'Download'
        },
        {
          fileName: 'Product_202010083456',
          templateName: 'Product',
          uploadDate: 'Jan 21st 2019',
          recordsLoaded: 60436,
          recordsFailed: 3234,
          processedDate: 'Jan 21st 2019',
          status: 'Processed',
          failedRecords: 'Download'
        },
        {
          fileName: 'Member_202010081740',
          templateName: 'Member',
          uploadDate: 'Jan 31st 2020',
          recordsLoaded: 20436,
          recordsFailed: 1234,
          processedDate: 'Jan 31st 2020',
          status: 'Processed',
          failedRecords: 'Download'
        },
        {
          fileName: 'Store_202010083446',
          templateName: 'Store',
          uploadDate: 'Jan 31st 2019',
          recordsLoaded: 20436,
          recordsFailed: 1234,
          processedDate: 'Jan 31st 2019',
          status: 'Failed',
          failedRecords: 'Download'
        },
        {
          fileName: 'Member_202010253546575',
          templateName: 'Member',
          uploadDate: 'Jan 31st 2019',
          recordsLoaded: 204536,
          recordsFailed: 7234,
          processedDate: 'Jan 31st 2019',
          status: 'Processed',
          failedRecords: 'Download'
        },
        {
          fileName: 'Product_2020109272',
          templateName: 'Product',
          uploadDate: 'Jan 31st 2019',
          recordsLoaded: 20256,
          recordsFailed: 6234,
          processedDate: 'Jan 31st 2019',
          status: 'Failed',
          failedRecords: 'Download'
        },
        {
          fileName: 'Store_2020104646778',
          templateName: 'Store',
          uploadDate: 'Jan 31st 2019',
          recordsLoaded: 20436,
          recordsFailed: 1234,
          processedDate: 'Jan 31st 2019',
          status: 'Failed',
          failedRecords: 'Download'
        },
        {
          fileName: 'Product_202010034450',
          templateName: 'Product',
          uploadDate: 'Jan 31st 2019',
          recordsLoaded: 203466,
          recordsFailed: 121,
          processedDate: 'Jan 31st 2019',
          status: 'Processed',
          failedRecords: 'Download'
        },
        {
          fileName: 'Store_202034464557',
          templateName: 'Store',
          uploadDate: 'Jan 31st 2019',
          recordsLoaded: 20436,
          recordsFailed: 1234,
          processedDate: 'Jan 31st 2019',
          status: 'Failed',
          failedRecords: 'Download'
        },
        {
          fileName: 'Member_202010036456',
          templateName: 'Member',
          uploadDate: 'Jan 31st 2019',
          recordsLoaded: 20436,
          recordsFailed: 1234,
          processedDate: 'Jan 31st 2019',
          status: 'Processed',
          failedRecords: 'Download'
        },
        {
          fileName: 'Product_2020100245345456',
          templateName: 'Product',
          uploadDate: 'Jan 31st 2019',
          recordsLoaded: 20436,
          recordsFailed: 1234,
          processedDate: 'Jan 31st 2019',
          status: 'Failed',
          failedRecords: 'Download'
        },
      ],
      search: ''
    };
  },
  watch: {
    '$store.state.batchImportModule.searchText' (newValue) {
      this.search = newValue;
    },
    '$store.state.batchImportModule.batchImportSwitchFilesFilter' (newValue) {
      this.$store.dispatch('batchImportModule/getAllFiles', this.batchImportSwitchFilesFilter);
    }
  },
  computed: {
    ...mapState('batchImportModule', ['allFiles', 'batchImportSwitchFilesFilter']),
    filteredBatchImportList: function () {
      return this.batchImportList.filter(importItem => {
        return importItem.fileName.toLowerCase().match(this.search);
      });
    }
  },
  created () {
    this.$store.dispatch('batchImportModule/getAllFiles', this.batchImportSwitchFilesFilter);
  },
  methods: {
    format_date (value) {
      if (value) {
        let date = moment(value).format('MMM Do YYYY');
        let time = moment(value).format('hh:mm A');
        return [date, time];
      }
    }
  }
};
</script>
