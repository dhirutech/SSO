<template>
  <brierley-inner-view class="gen2-container-py0">
    <template v-slot:header>
      <span class="inner-head text-uppercase"
        ><span class="font15 white--text opacity75 bpr1"
          >{{ $t("batchImport") }} &nbsp;</span
        >
        / {{ getLocationText }} {{ $t("fileLocation") }}</span
      >
    </template>
    <template v-slot:headerclose>
      <v-btn
        data-qe-id="batch_create_location_close_icon"
        class="no-ripple"
        href
        target="_blank"
        text
        @click.native="navigateToPreviousPage()"
      >
        <v-icon v-if="createLocationStatus !== ''">mdi-close</v-icon>
        <v-icon v-else>arrow_back</v-icon>
        {{ createLocationStatus !== "" ? $t("close") : $t("back") }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <Validation-Observer
        ref="basicInfoForm"
        v-if="currentStepInfo === 1"
        v-slot="{ handleSubmit }"
      >
        <form id="my-form" @submit.prevent="handleSubmit(btnNextClick)">
          <basic-information
            :location="locationInfo"
            ref="basicInformation"
          ></basic-information>
        </form>
      </Validation-Observer>
      <review-location
        v-if="currentStepInfo === 2 && !createLocationStatus"
        :location="locationInfo"
        @openCreatePage="goToCreate"
        ref="reviewLocation"
      ></review-location>
      <add-location-status
        v-if="createLocationStatus !== ''"
      ></add-location-status>
    </template>
    <template
      v-slot:footer-changes-saved
      v-if="
        (currentStepInfo === 1 || currentStepInfo === 2) &&
          !createLocationStatus
      "
    >
      <div style="margin-top: -5px !important;margin-bottom: -14px !important;">
        <v-icon class="pr-2" style="font-size: 15px !important;"
          >mdi-check</v-icon
        >
        <span id="LabelChangesSaved">{{ $t("changesSavedText") }}</span>
      </div>
    </template>
    <template
      v-slot:footer
      v-if="
        (currentStepInfo === 1 || currentStepInfo === 2) &&
          !createLocationStatus
      "
    >
      <v-btn
        :title="$t('cancel')"
        text
        class="cancel no-ripple bmt2 bmr5"
        data-qe-id="batch_create_location_cancel_btn"
        @click="closeLocation()"
        >{{ $t("cancel") }}</v-btn
      >
      <v-btn
        data-qe-id="batch_create_location_create_btn"
        :title="getCreateBtn()"
        class="primaryctabtn bmt2 bml2"
        type="invalid"
        form="product_definition_form"
        @click="btnNextClick()"
        >{{ getCreateBtn() }}</v-btn
      >
    </template>
    <template v-slot:footer-previous v-if="createLocationStatus !== ''">
      <v-btn
        class="primaryctabtn"
        data-qe-id="batch_create_location_close_btn"
        @click="closeLocation()"
        >{{ $t("close") }}</v-btn
      >
    </template>
    <!-- For future implementation -->
    <!-- <template v-slot:footer-belowtext v-if="createLocationStatus !== ''">
      <p class="label-text bmt4">add another location?</p>
      <p class="bmb0">
        Would you like to add another location?
        <strong class="primary-text cursor-p"  @click="navigate()">Click here</strong>
      </p>
    </template> -->
  </brierley-inner-view>
</template>
<script>
import { BrierleyInnerView } from '@brierley/SharedComponents';
import BasicInformation from '../create-location/BasicInformation';
import ReviewLocation from '../create-location/ReviewLocation';
import AddLocationStatus from '../create-location/AddLocationStatus';
import { mapState } from 'vuex';
import { locationBasicInfoObj } from '../../../../i18n/language';

export default {
  i18n: locationBasicInfoObj,
  components: {
    BrierleyInnerView,
    BasicInformation,
    ReviewLocation,
    AddLocationStatus
  },
  data () {
    return {
      currentStepInfo: 1
    };
  },
  created () {
    window.scrollTo(0, 0);
    if (!this.locationList.length) {
      this.$store.dispatch('batchImportModule/getLocationList');
    }
    if (this.$route && this.$route.path.includes('createLocation')) {
      this.resetStepperInfo();
      if (this.locationList.length) {
        this.closeLocation();
      }
    }
  },
  computed: {
    ...mapState('batchImportModule', [
      'locationInfo',
      'createLocationStatus',
      'locationList'
    ]),
    getLocationText () {
      return this.$route && this.$route.path.includes('createLocation')
        ? this.$t('newText')
        : this.$t('editText');
    }
  },
  methods: {
    goToCreate () {
      this.currentStepInfo = 1;
    },
    getCreateBtn () {
      let text = null;
      switch (this.currentStepInfo) {
      case 1:
        text = this.$t('reviewBtnText');
        break;
      case 2:
        text = this.$route.path.includes('createLocation')
          ? this.$t('createText')
          : this.$t('editText');
        break;
      }
      return text;
    },
    btnNextClick () {
      let activeElement = document.activeElement;
      if (
        activeElement &&
        (activeElement.tagName.toLowerCase() === 'input' ||
          activeElement.tagName.toLowerCase() === 'textarea' ||
          activeElement.tagName.toLowerCase() === 'select')
      ) {
        event.preventDefault();
        return false;
      }
      if (this.currentStepInfo === 1) {
        this.$refs.basicInfoForm.validate().then(res => {
          if (res) {
            this.currentStepInfo = this.currentStepInfo + 1;
          }
        });
      } else if (this.currentStepInfo === 2) {
        this.$refs.reviewLocation.saveLocation();
      }
    },
    closeLocation () {
      this.$store.commit('batchImportModule/setImportTab', 1);
      this.$router.push('/loyaltyadmin/batchImport');
      this.resetStepperInfo();
    },
    resetStepperInfo () {
      this.$store.dispatch('batchImportModule/resetLocationStep');
    },
    setWindowScrollTop () {
      window.scrollTo({ top: 0, behavior: 'auto' });
    },
    navigateToPreviousPage () {
      if (this.currentStepInfo === 1 || this.createLocationStatus !== '') {
        this.closeLocation();
        return;
      }
      this.goToCreate();
    }
  },
  watch: {
    currentStepInfo () {
      this.setWindowScrollTop();
    },
    locationList (val) {
      if (val.length) {
        if (this.$route.name.includes('createLocation')) {
          this.closeLocation();
        } else {
          this.$store.commit(
            'batchImportModule/updateLocationInfo',
            this.locationList[0]
          );
        }
      }
    }
  }
};
</script>
<style lang="scss">
.opacity75 {
  opacity: 0.75;
}
</style>
