<template>
  <v-row class="flex-column bpt5" no-gutters>
    <v-col>
      <brierley-form-title
        :formTitle="$t('reviewText')"
        :infoText="$t('reviewInfoText')"
      />
    </v-col>
    <v-col>
      <v-row justify="space-between">
        <v-col class="bmt3" xs="11" sm="11" md="11">
          <h3 class="fbold">{{ $t("basicInfo") }}</h3>
        </v-col>
        <v-col class="hoverEdit bmt3">
          <span
            class="primary-text fbold cursor-p text-right text-uppercase"
            @click="goToCreate()"
          >
            <v-icon class="bpr1" color="#000">create</v-icon
            >{{ $t("editText") }}
          </span>
        </v-col>
      </v-row>
    </v-col>
    <v-col>
      <v-row no-gutters>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
    </v-col>
    <v-col class="bpt5">
      <h3 class="font18 f600 bmb3">{{ $t("fileLocationDetails") }}</h3>
      <p>
        <strong>{{ $t("fileLocationName") }}: </strong>
        {{ location.locationName }}
      </p>
      <p class="elipsis-fullwidth">
        <strong>{{ $t("fileLocationDescription") }}: </strong>
        {{ location.locationDescription }}
      </p>
      <p>
        <strong>{{ $t("fileLocationType") }}: </strong>
        {{ location.locationType }}
      </p>
    </v-col>
  </v-row>
</template>

<script>
import { BrierleyFormTitle } from '@brierley/SharedComponents';
import { locationBasicInfoObj } from '../../../../i18n/language';

export default {
  i18n: locationBasicInfoObj,
  components: {
    BrierleyFormTitle
  },
  data () {
    return {};
  },
  props: {
    location: {
      type: Object
    }
  },
  methods: {
    goToCreate () {
      this.$emit('openCreatePage');
    },
    saveLocation () {
      this.location.locationTypeId = 1;
      if (this.location.locationId) {
        this.$store.dispatch('batchImportModule/updateLocation', this.location);
      } else {
        this.$store.dispatch('batchImportModule/createLocation', this.location);
      }
    }
  }
};
</script>
