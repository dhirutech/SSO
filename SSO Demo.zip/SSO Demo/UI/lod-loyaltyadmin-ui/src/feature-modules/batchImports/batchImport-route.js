import batchImport from './components/batchImport.vue';
import createLocation from './components/create-location/CreateLocation.vue';
import editEncryption from './components/EditEncryption.vue';
import reviewEncryption from './components/ReviewEncryption.vue';
import successEncryption from './components/SuccessEncryption.vue';
import addBatchImport from './components/createBatchImport/AddBatchImport.vue';

const batchImportRoutes = [
  {
    path: '/loyaltyadmin/batchImport',
    name: 'batchImport',
    component: batchImport,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/batchImport/createLocation',
    name: 'createLocation',
    component: createLocation,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/batchImport/editLocation/:id',
    name: 'editLocation',
    component: createLocation,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/batchImport/createEncryption',
    name: 'createEncryption',
    component: editEncryption,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/editEncryption/:id',
    name: 'editEncryption',
    component: editEncryption,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/batchImport/reviewEncryption',
    name: 'reviewEncryption',
    component: reviewEncryption,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/successEncryption',
    name: 'successEncryption',
    component: successEncryption,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/addBatchImport',
    name: 'addBatchImport',
    component: addBatchImport,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/editBatchImport/:id',
    name: 'editBatchImport',
    component: addBatchImport,
    meta: {
      showNavigation: false
    }
  }
];

export default batchImportRoutes;
