import Vue from 'vue';

const getLocationListAsync = async () => {
  return await Vue.prototype.$http.get(
    '/contentservice/api/batchImportLocation'
  );
};

const deleteLocationAsync = async locationId => {
  return await Vue.prototype.$http.delete(
    `/contentservice/api/batchImportLocation/Delete?locationId=${locationId}`
  );
};

const createLocationAsync = async requestBody => {
  return await Vue.prototype.$http
    .post('/contentservice/api/batchImportLocation/create', requestBody)
    .then(res => {
      return res;
    })
    .catch(error => {
      return error.response;
    });
};

const updateLocationAsync = async requestBody => {
  return await Vue.prototype.$http
    .put(
      `/contentservice/api/batchImportLocation/${requestBody.locationId}`,
      requestBody
    )
    .then(res => {
      return res;
    })
    .catch(error => {
      return error.response;
    });
};

const createEncryptionKey = async requestBody => {
  return await Vue.prototype.$http
    .post('/contentservice/api/batchEncryptionFile/create', requestBody)
    .then(res => res)
    .catch(error => error.response);
};

const getEncryptionKeysList = async () => {
  return await Vue.prototype.$http.get(
    '/contentservice/api/batchFileEncryption'
  );
};
const updateEncryption = async requestBody => {
  return await Vue.prototype.$http
    .put(
      `/contentservice/api/batchFileEncryption/${requestBody.encryptionId}`,
      requestBody
    )
    .then(res => {
      return res;
    })
    .catch(error => {
      return error.response;
    });
};

const deleteEncryptionKeyAsync = async encryptionId => {
  return await Vue.prototype.$http.delete(
    `/contentservice/api/batchFileEncryption/Delete?encryptionId=${encryptionId}`
  );
};

const downloadEncryptionKeyAsync = async encryptionKeyName => {
  return await Vue.prototype.$http.get(
    `/contentservice/api/GetEncryptionKeyByName?encryptionKeyName=${encryptionKeyName}&isPrivateKey=true`
  ).then(res => {
    const blob = new Blob([res.data], { type: res.headers['content-type'] });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = `${encryptionKeyName}.asc`;
    link.click();
  })
    .catch(err => {
      throw err;
    });
};

const getBatchTemplateAsync = async () => {
  return await Vue.prototype.$http.get(
    '/contentservice/api/resources/services'
  );
};

const createBatchImportAsync = async requestBody => {
  return await Vue.prototype.$http
    .post(
      `/contentservice/api/batchImport/create?isReview=${requestBody.isReview}`,
      requestBody
    )
    .then(res => {
      return res;
    })
    .catch(error => {
      return error.response;
    });
};

const getBusinessEntitiesAsync = async () => {
  return await Vue.prototype.$http.get(
    '/loyaltyconfiguration/api/v1/businessEntities'
  );
};

const downloadTemplateAsync = async service => {
  return await Vue.prototype.$http
    .get(
      `/contentservice/api/batchImport/templateLayout?serviceName=${service}`
    )
    .then(res => {
      const blob = new Blob([res.data], { type: res.headers['content-type'] });
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = `${service}.csv`;
      link.click();
    })
    .catch(err => {
      throw err;
    });
};

const getBatchImportListAsync = async () => {
  return await Vue.prototype.$http.get('/contentservice/api/batchImport');
};

const getBatchImportFilesAsync = async (payload) => {
  return await Vue.prototype.$http.get(`/contentservice/api/batchImport/files?batchImportId=${payload.batchImportId}&ToDate=${payload.toDate}&FromDate=${payload.fromDate}&Status=${payload.status}`);
};

const deleteBatchImportAsync = async batchImportId => {
  return await Vue.prototype.$http.delete(
    `/contentservice/api/batchImport/delete?batchImportId=${batchImportId}`
  );
};

const updateBatchImportAsync = async requestBody => {
  return await Vue.prototype.$http
    .put('/contentservice/api/batchImport/update', requestBody)
    .then(res => {
      return res;
    })
    .catch(error => {
      return error.response;
    });
};

const getAllFilesAsync = async (payload) => {
  return await Vue.prototype.$http.get(`/contentservice/api/filterFiles?ToDate=${payload.toDate}&FromDate=${payload.fromDate}&TemplateId=${payload.templateId}&Status=${payload.status}`);
};

export {
  getLocationListAsync,
  deleteLocationAsync,
  createLocationAsync,
  updateLocationAsync,
  createEncryptionKey,
  getEncryptionKeysList,
  updateEncryption,
  deleteEncryptionKeyAsync,
  downloadEncryptionKeyAsync,
  getBatchTemplateAsync,
  createBatchImportAsync,
  getBusinessEntitiesAsync,
  downloadTemplateAsync,
  getBatchImportListAsync,
  deleteBatchImportAsync,
  updateBatchImportAsync,
  getAllFilesAsync,
  getBatchImportFilesAsync
};
