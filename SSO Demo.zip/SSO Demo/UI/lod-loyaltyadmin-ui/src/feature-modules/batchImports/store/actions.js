import * as api from '../api/batchImport.api';

const getLocationList = async ({ commit }) => {
  const response = await api.getLocationListAsync();
  commit('setLocationList', response.data);
};

const getEncryptionKey = ({ commit }, payload) => {
  commit('setEncryptionKey', payload);
};

const deleteLocation = async ({ params }) => {
  await api.deleteLocationAsync(params);
};

const createLocation = async ({ commit }, payload) => {
  const response = await api.createLocationAsync(payload);
  if (response.status >= 400) {
    commit('setCreateLocationStatus', 'Error');
    return;
  }
  commit('setCreateLocationStatus', 'Success');
};

const updateLocation = async ({ commit }, payload) => {
  const response = await api.updateLocationAsync(payload);
  if (response.status >= 400) {
    commit('setCreateLocationStatus', 'Error');
    return;
  }
  commit('setCreateLocationStatus', 'Success');
  commit('updateLocationInfo', response.data);
};

const resetLocationStep = async ({ commit }) => {
  commit('updateLocationInfo', {
    locationName: '',
    locationDescriptin: '',
    locationType: 'Object Store',
    locationTypeId: 0,
    status: ''
  });
  commit('setCreateLocationStatus', '');
};

const createEncryptionKeySetup = async ({ commit }, payload) => {
  const res = await api.createEncryptionKey(payload);
  if (res.status === 200) {
    commit('setEncryptionKeySetup', 'Success');
    return;
  }
  commit('setEncryptionKeySetup', res.status);
};

const getEncryptionKeyList = async ({ commit }) => {
  const res = await api.getEncryptionKeysList();
  commit('setEncryptionKeyList', res.data);
};

const getBatchImportItem = ({ commit }, payload) => {
  commit('setBatchImportItem', payload);
};

const resetEncryptionKeyStatus = ({ commit }, payload) => {
  commit('setEncryptionKeyStatus', payload);
};

const updateEncryptionKey = async ({ commit }, payload) => {
  const res = await api.updateEncryption(payload);
  if (res.status === 200) {
    commit('setEncryptionKeySetup', 'Success');
    return;
  }
  commit('setEncryptionKeySetup', res.status);
};

const deleteEncryptionKey = async ({ commit }, encryptionId) => {
  const res = await api.deleteEncryptionKeyAsync(encryptionId);
  if (res.status === 200) {
    commit('setDeleteEncryptionKeyStatus', true);
    return;
  }
  commit('setDeleteEncryptionKeyStatus', false);
};

const resetDeleteStatus = ({ commit }, status) => {
  if (!status) {
    commit('setDeleteEncryptionKeyStatus', status);
  }
};

const downloadEncryptionKeys = async ({ commit }, name) => {
  await api.downloadEncryptionKeyAsync(name);
};

const resetBatchImportStep = async ({ commit }) => {
  commit('updateBatchImportInfo', {
    batchImportName: '',
    description: '',
    businessEntityId: '',
    businessEntityName: '',
    programId: '',
    programName: '',
    namingConvention: '',
    serviceId: '',
    serviceName: '',
    locationId: '',
    locationPath: '',
    fileReceiptNotificationEmail: '',
    fileReceiptNotificationOption: false,
    fileProcessFailureNotificationEmail: '',
    fileProcessCompletionNotificationEmail: '',
    fileProcessCompletionNotificationOption: false,
    fileEncryptionId: '',
    addDuplicate: 'No',
    rejectFile: 'Topics (Kafka)'
  });
  commit('setCreateImportStatus', { status: '', res: null });
  commit('setImportError', null);
};

const batchImportFilters = ({ commit }, payload) => {
  commit('setBatchImportFilter', payload);
};

const getSearchText = ({ commit }, searchText) => {
  commit('setSearchText', searchText);
};

const getBatchTemplates = async ({ commit }) => {
  const response = await api.getBatchTemplateAsync();
  commit('setBatchTemplates', response.data);
};

const createBatchImport = async ({ commit }, payload) => {
  const response = await api.createBatchImportAsync(payload);
  if (response.status >= 400) {
    if (payload.isReview) {
      commit('setImportError', response.data);
      return;
    }
    commit('setCreateImportStatus', { status: 'Error', res: response });
    return;
  }
  if (!payload.isReview) {
    commit('setCreateImportStatus', { status: 'Success', res: response });
  }
  commit('setImportError', '');
};

const getBusinessEntities = async ({ commit }) => {
  const response = await api.getBusinessEntitiesAsync();
  commit('setBusinessEntities', response.data);
};

const downloadTemplate = async ({ commit }, service) => {
  await api.downloadTemplateAsync(service);
};

const batchImportDetailedViewFilters = ({ commit }, payload) => {
  commit('setBatchImportDetailedViewFilters', payload);
};

const getBatchImportList = async ({ commit }) => {
  const response = await api.getBatchImportListAsync();
  commit('setBatchImportList', response.data.data);
};

const resetCreateImportStatus = ({ commit }, status) => {
  commit('resetCreateImportStatus', status);
};

const deleteBatchImport = async ({ commit }, batchImportId) => {
  const res = await api.deleteBatchImportAsync(batchImportId);
  if (res.status === 200) {
    commit('setDeleteBatchImportStatus', true);
    return;
  }
  commit('setDeleteBatchImportStatus', false);
};

const resetBatchImportDeleteStatus = ({ commit }, status) => {
  commit('setDeleteBatchImportStatus', status);
};

const updateBatchImport = async ({ commit }, payload) => {
  const response = await api.updateBatchImportAsync(payload);
  if (response.status >= 400) {
    commit('setCreateImportStatus', { status: 'Error', res: response });
    return;
  }
  commit('setCreateImportStatus', { status: 'Success', res: response });
  commit('updateBatchImportInfo', response.data);
};

const getAllFiles = async ({ commit }, payload) => {
  const response = await api.getAllFilesAsync(payload);
  commit('setAllFiles', response.data.files);
};

const batchImportSwitchFilesFilters = ({ commit }, payload) => {
  commit('setBatchImportSwitchFilesFilter', payload);
};

const getBatchImportFiles = async ({ commit }, payload) => {
  const response = await api.getBatchImportFilesAsync(payload);
  commit('setBatchImportFiles', response.data.files);
};

export default {
  getLocationList,
  deleteLocation,
  getEncryptionKey,
  createLocation,
  updateLocation,
  resetLocationStep,
  createEncryptionKeySetup,
  getEncryptionKeyList,
  getBatchImportItem,
  resetEncryptionKeyStatus,
  updateEncryptionKey,
  deleteEncryptionKey,
  resetDeleteStatus,
  downloadEncryptionKeys,
  resetBatchImportStep,
  batchImportFilters,
  getSearchText,
  getBatchTemplates,
  createBatchImport,
  getBusinessEntities,
  downloadTemplate,
  batchImportDetailedViewFilters,
  getBatchImportList,
  resetCreateImportStatus,
  deleteBatchImport,
  resetBatchImportDeleteStatus,
  updateBatchImport,
  getAllFiles,
  batchImportSwitchFilesFilters,
  getBatchImportFiles
};
