export default {
  locationList: [],
  encryptionKey: {},
  locationInfo: {
    locationName: '',
    locationDescription: '',
    locationType: 'Object Store',
    locationTypeId: 0,
    status: ''
  },
  createLocationStatus: '',
  createEncryptionSetupStatus: '',
  encryptionKeysList: [],
  batchImportList: [],
  batchImportInfo: {
    batchImportName: '',
    description: '',
    businessEntityId: '',
    programId: '',
    programName: '',
    namingConvention: '',
    serviceId: '',
    serviceName: '',
    locationId: '',
    locationPath: '',
    fileReceiptNotificationEmail: '',
    fileReceiptNotificationOption: false,
    fileProcessFailureNotificationEmail: '',
    fileProcessCompletionNotificationEmail: '',
    fileProcessCompletionNotificationOption: false,
    fileEncryptionId: ''
  },
  createImportStatus: '',
  selectedImportTab: 0,
  deleteEncryptionKeyStatus: false,
  batchImportFilter: {},
  searchText: '',
  batchTemplates: [],
  businessEntities: [],
  selectedBusinessEntity: {
    businessEntityId: '',
    businessEntityName: ''
  },
  importError: null,
  batchImportDetailedViewFilters: {
    fromDate: '',
    toDate: '',
    status: '',
    searchText: '',
    batchImportId: ''
  },
  batchImportItem: {},
  batchImportDeleteStatus: false,
  allFiles: [],
  batchImportSwitchFilesFilter: {
    fromDate: '',
    toDate: '',
    templateId: 0,
    status: ''
  },
  batchImportFiles: []
};
