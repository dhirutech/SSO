const setLocationList = (state, payload) => {
  state.locationList = payload;
};

const setEncryptionKey = (state, payload) => {
  state.encryptionKey = payload;
};

const updateLocationInfo = (state, payload) => {
  state.locationInfo = payload;
};

const setCreateLocationStatus = (state, payload) => {
  state.createLocationStatus = payload;
};

const setEncryptionKeySetup = (state, payload) => {
  state.createEncryptionSetupStatus = payload;
};

const setEncryptionKeyList = (state, payload) => {
  state.encryptionKeysList = payload;
};

const setBatchImportItem = (state, payload) => {
  state.batchImportItem = payload;
};

const setEncryptionKeyStatus = (state, payload) => {
  state.createEncryptionSetupStatus = payload;
};

const setDeleteEncryptionKeyStatus = (state, payload) => {
  state.deleteEncryptionKeyStatus = payload;
};

const setCreateImportStatus = (state, payload) => {
  state.createImportStatus = payload.status;
  state.batchImportItem = payload.res?.data;
};

const setImportTab = (state, payload) => {
  state.selectedImportTab = payload;
};

const updateBatchImportInfo = (state, payload) => {
  state.batchImportInfo = payload;
};

const setBatchImportFilter = (state, payload) => {
  state.batchImportFilter = payload;
};

const setSearchText = (state, searchText) => {
  state.searchText = searchText;
};

const setBatchTemplates = (state, payload) => {
  state.batchTemplates = payload;
};

const setBusinessEntities = (state, payload) => {
  state.businessEntities = payload;
};

const setSelectedBusinessEntity = (state, payload) => {
  state.selectedBusinessEntity = payload;
};

const setImportError = (state, payload) => {
  state.importError = payload;
};

const setBatchImportDetailedViewFilters = (state, payload) => {
  state.batchImportDetailedViewFilters = payload;
};

const setBatchImportList = (state, response) => {
  state.batchImportList = response;
};

const resetCreateImportStatus = (state, response) => {
  state.createImportStatus = response;
};

const setDeleteBatchImportStatus = (state, status) => {
  state.batchImportDeleteStatus = status;
};

const setAllFiles = (state, payload) => {
  state.allFiles = payload;
};

const setBatchImportSwitchFilesFilter = (state, payload) => {
  state.batchImportSwitchFilesFilter = payload;
};

const setBatchImportFiles = (state, payload) => {
  state.batchImportFiles = payload;
};

export default {
  setLocationList,
  setEncryptionKey,
  updateLocationInfo,
  setCreateLocationStatus,
  setEncryptionKeySetup,
  setEncryptionKeyList,
  setBatchImportItem,
  setEncryptionKeyStatus,
  setDeleteEncryptionKeyStatus,
  setCreateImportStatus,
  setImportTab,
  updateBatchImportInfo,
  setBatchImportFilter,
  setSearchText,
  setBatchTemplates,
  setBusinessEntities,
  setSelectedBusinessEntity,
  setImportError,
  setBatchImportDetailedViewFilters,
  setBatchImportList,
  resetCreateImportStatus,
  setDeleteBatchImportStatus,
  setAllFiles,
  setBatchImportSwitchFilesFilter,
  setBatchImportFiles
};
