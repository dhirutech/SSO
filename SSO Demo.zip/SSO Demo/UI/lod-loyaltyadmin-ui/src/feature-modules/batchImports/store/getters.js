const getLocations = state => state.locationList;
const getLocationInfo = state => state.locationInfo;
const getCreateLocationStatus = state => state.createLocationStatus;
const getCreateEncryptionSetupStatus = state =>
  state.createEncryptionSetupStatus;
const getEncryptionKeyList = state => state.encryptionKeysList;
const getBatchImportInfo = state => state.batchImportInfo;
const getCreateImportStatus = state => state.createImportStatus;
const getSelectedImportTab = state => state.selectedImportTab;

export default {
  getLocations,
  getLocationInfo,
  getCreateLocationStatus,
  getCreateEncryptionSetupStatus,
  getEncryptionKeyList,
  getBatchImportInfo,
  getCreateImportStatus,
  getSelectedImportTab
};
