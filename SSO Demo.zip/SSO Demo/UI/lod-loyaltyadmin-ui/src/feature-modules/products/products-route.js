import ProductUpload from './components/ProductUpload';
import ProductList from './components/ProductList';

const productsRoutes = [
  {
    path: '/loyaltyadmin/products/upload',
    name: 'ProductUpload',
    component: ProductUpload,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/products/list',
    name: 'ProductList',
    component: ProductList,
    meta: {
      showNavigation: true
    }
  }
];

export default productsRoutes;
