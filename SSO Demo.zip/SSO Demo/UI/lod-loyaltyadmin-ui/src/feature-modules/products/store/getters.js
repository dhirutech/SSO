const getUploadProductStatus = state => state.uploadProductStatus;

export default {
  getUploadProductStatus
};
