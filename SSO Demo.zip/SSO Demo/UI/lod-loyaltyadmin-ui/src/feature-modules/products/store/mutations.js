const uploadProductStatus = (state, payload) => {
  state.uploadProductStatus = payload;
};

const getProductsListMutations = (state, payload) => {
  state.getProductsListMutations = payload;
};

const getProductsCount = (state, payload) => {
  state.getProductsCount = payload;
};

const selectedProductId = (state, payload) => {
  state.selectedProductId = payload;
};

const showViewDetailsPopup = (state, payload) => {
  state.showViewDetailsPopup = payload;
};

const getProductDetailsMutation = (state, payload) => {
  state.productdetailslist = payload;
};

const setProductTemplate = (state, payload) => {
  state.productTemplate = payload;
};

const setSelectedBusinessEntity = (state, payload) => {
  state.selectedBusinessEntity = payload;
};

const setBusinessEntities = (state, payload) => {
  state.businessEntities = payload;
};

export default {
  uploadProductStatus,
  getProductsListMutations,
  getProductsCount,
  selectedProductId,
  showViewDetailsPopup,
  getProductDetailsMutation,
  setProductTemplate,
  setSelectedBusinessEntity,
  setBusinessEntities
};
