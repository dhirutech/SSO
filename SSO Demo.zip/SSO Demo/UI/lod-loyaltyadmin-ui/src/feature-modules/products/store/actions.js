import * as api from '../api/product.api.js';

const uploadProduct = async ({ commit }, payload) => {
  await api
    .uploadProductAsync(payload)
    .then(() => {
      commit('uploadProductStatus', 'Success');
    })
    .catch(() => {
      commit('uploadProductStatus', 'Error');
    });
};

const getProductsListActions = async ({ commit }, payload) => {
  await api
    .getProductsList(payload)
    .then(res => {
      commit('getProductsListMutations', res.data.data.productsSearchResult);
      commit('getProductsCount', res.data.data.productsCount);
    })
    .catch(() => {
      commit('getProductsCount', 0);
      commit('getProductsListMutations', []);
    });
};

const productDetailsAction = async ({ commit }, payload) => {
  await api
    .getProductDetails(payload)
    .then(res => {
      commit('getProductDetailsMutation', res.data);
    })
    .catch(() => {
      commit('getProductDetailsMutation', 'Error');
    });
};

const downloadProductTemplate = async ({ commit }, request) => {
  let response = await api.downloadProductTemplateAsync(request);
  commit('setProductTemplate', response.data);
};

const getBusinessEntities = async ({ commit }, programId) => {
  let response = await api.getBusinessEntitiesByProgramIdAsync(programId);
  commit('setBusinessEntities', response);
};

export default {
  uploadProduct,
  getProductsListActions,
  productDetailsAction,
  downloadProductTemplate,
  getBusinessEntities
};
