export default {
  uploadProductStatus: '',
  getProductsListMutations: [],
  params: {
    searchText: '',
    pageSize: 10,
    pageNumber: 1,
    businessEntityId: 0
  },
  getProductsCount: 0,
  selectedProductId: null,
  showViewDetailsPopup: false,
  productdetailslist: [],
  productTemplate: '',
  selectedBusinessEntity: {
    businessEntityId: 0,
    businessEntityName: ''
  },
  businessEntities: []
};
