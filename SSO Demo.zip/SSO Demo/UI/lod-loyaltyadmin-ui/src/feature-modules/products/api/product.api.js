import Vue from 'vue';

const uploadProductAsync = async (request) => {
  return await Vue.prototype.$http.post(
    '/contentservice/api/upload/files',
    request
  );
};

const getProductsList = async (payload) => {
  if (payload.searchText !== null && payload.searchText !== '') {
    return await Vue.prototype.$http.get(
      'product/api/v1/products/getall?ProgramEntityId=' +
        payload.businessEntityId +
        '&PageSize=' +
        payload.pageSize +
        '&PageNumber=' +
        payload.pageNumber +
        '&SearchText=' +
        encodeURIComponent(payload.searchText)
    );
  } else {
    return await Vue.prototype.$http.get(
      'product/api/v1/products/getall?ProgramEntityId=' +
        payload.businessEntityId +
        '&PageSize=' +
        payload.pageSize +
        '&PageNumber=' +
        payload.pageNumber
    );
  }
};

const getProductDetails = (payload) => {
  return Vue.prototype.$http.get('product/api/v1/products/' + payload);
};

const downloadProductTemplateAsync = async () => {
  return await Vue.prototype.$http
    .get('/contentservice/api/batchImport/templateLayout?serviceName=Products')
    .then((response) => {
      return response;
    })
    .catch((err) => {
      throw err;
    });
};

const getBusinessEntitiesByProgramIdAsync = async (programId) => {
  return await Vue.prototype.$http
    .get('product/api/v1/products/businessentities/' + programId)
    .then((res) => {
      return res.data.data;
    })
    .catch((err) => {
      if (err.response.data.httpStatusCode === 404) {
        return err.response.data.data;
      }
      return err.response;
    });
};

export {
  uploadProductAsync,
  getProductsList,
  getProductDetails,
  downloadProductTemplateAsync,
  getBusinessEntitiesByProgramIdAsync
};
