<template>
  <v-row class="d-flex flex-column" no-gutter>
    <brierley-table-module v-if="productslistdata.length > 0">
      <template v-slot:tablehead>
        <tr class="text-left">
          <th
            v-for="item in header"
            :key="item.name"
            class="text-left"
            :width="item.width"
          >
            {{ item.text }}
          </th>
        </tr>
      </template>
      <template v-slot:tablebody>
        <tr v-for="(list, index) in productslistdata" :key="index">
          <td class="primary-text fbold elipsis-fullwidth" :title="list.name">
            {{ list.name }}
          </td>
          <td>{{ list.basePrice }}</td>
          <td class="elipsis-fullwidth" :title="list.externalId">
            {{ list.externalId }}
          </td>
          <td>
            <div class="elipsis-description">
              {{ list.description }}
            </div>
          </td>
          <td class="text-nowrap">
            {{ list.programEntityName }}
            <v-row class="d-flex d-inline-flex hover-actions" no-gutters>
              <v-col>
                <brierleyCardIcons>
                  <template v-slot:action-icons>
                    <span class="active" @click="viewDetails(list.productId)">
                      <v-icon :title="$t('viewDetails')">visibility</v-icon>
                      <span class="viewdetails-icon">{{
                        $t('viewDetails')
                      }}</span>
                    </span>
                    <!-- <span>
                      <v-icon title="Edit">mdi-pencil-box-outline</v-icon>
                      <span class="edit-icon">Edit</span>
                    </span>
                    <span>
                      <v-icon title="Copy">mdi-content-copy</v-icon>
                      <span class="copy-icon">Copy</span>
                    </span>
                    <span>
                      <v-icon title="Pause">mdi-pause</v-icon>
                      <span class="pause-icon">Pause</span>
                    </span>
                    <span>
                      <v-icon title="Delete">mdi-delete</v-icon>
                      <span class="delete-icon">Delete</span>
                    </span> -->
                  </template>
                </brierleyCardIcons>
              </v-col>
            </v-row>
          </td>
        </tr>
      </template>
    </brierley-table-module>
    <v-col>
      <product-view-details-pop-up v-if="details === true" />
    </v-col>
  </v-row>
</template>

<script>
import {
  BrierleyTableModule,
  BrierleyCardIcons
} from '@brierley/SharedComponents';
import ProductViewDetailsPopUp from '../ProductViewDetailsPopUp';
import { mapState } from 'vuex';
import { productListObj } from './../../../../i18n/language.js';
export default {
  props: {
    productslistdata: {
      type: Array,
      defualt: []
    }
  },
  i18n: productListObj,
  data () {
    return {
      header: [
        { name: 'name', text: this.$t('nameText'), sort: 'asc' },
        { name: 'id', text: this.$t('basePrice'), sort: '' },
        {
          name: 'description',
          text: this.$t('externalId'),
          sort: '',
          width: '215'
        },
        { name: 'startdate', text: this.$t('descriptionLabel'), sort: '' },
        { name: 'enddate', text: this.$t('programEntityLabel'), sort: '' }
      ]
    };
  },
  components: {
    BrierleyTableModule,
    BrierleyCardIcons,
    ProductViewDetailsPopUp
  },
  computed: {
    ...mapState('productModule', {
      details: (state) => {
        return state.showViewDetailsPopup;
      }
    })
  },
  methods: {
    viewDetails (id) {
      this.details = true;
      let content = document.querySelector('html');
      content.classList.add('overflow-y-hidden');
      this.$store.commit('productModule/selectedProductId', id);
      this.$store.commit('productModule/showViewDetailsPopup', true);
    }
  }
};
</script>
<style>
.arrow {
  transform: rotate(-180deg);
}
.arrow.down {
  transform: rotate(2deg);
}
</style>
