<template>
  <brierley-inner-view>
    <template v-slot:header>
      <span class="inner-head">
        <img
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAuCAYAAAC7zE4hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAPVSURBVHgB7ZlPTBNBFMYfxqMFjkIi9AInDARvkghn0Fi9iAnammDUeCA1sV5MCAZN8AByMRo80JgonrTG4hFq4MifBi7CwRaSws0WuK/zTTub2WVBEybpS5xfstnt62ba+fre7DevNY7jxMhyYmqEkA5ZTswpshjBCmkIK6QhrJCGsEIagq2QyY/pQ7Evsxlii8OQ38V9J9wRceYWljzxoBgXWPrIaZGNq+sblN/apc/vx9xYsXRAKZGVc19fEzdYljbK+tXzuLwulvblOTX7gyK9l+R1bnuHuMFOSAjWcb5VXg/dv0GTbz7R/MIy1dedoXBTAw0/GaTkhzSxw2FGz5UHzq98wX2NdTH28JknFhlIiHV0z+EEq4xEySLrcChi/X1ybdRjPV2dgU/1asJKyJGxdzR0r98Tg7hqnVREb/bR/OIKcYKNkBAst7Uj1scWbxyxthYh3LIbw3rpj1UbNvZnulKqMZFt/hjKOpXO0MSLuPseyv3arQQbK8QmI7Hm6SLqMayJue1dT4kjK4G/7KsFCyGReVGfiLA8+gNGWSEdWCF/rGo4DPBbHhAZeHwoBivkh4sVYrFGojzr60J/jeHBo2fpUfdVA/ufjSFsP9IQVkhDWCENYUTI4t6/eTnch92If0eiYqo9hvuUP1Rj+1tnQf4xaGz0NfWxFXhtsuNuREgYZ/VFcU7OfAu8b3VtwxVAn0Tq+7x8GtfXlk02OeROfmRsqvIZ3jGv304cEjMrRMMTfPLtjBvLLC7LGBrC+mdivHBTozFDb0RI7DIylUzILC4dey/ex4FJKNAJhwHPiXN5vBCV9g6kmLhvdX2TursuuPcnZ9I0PvpI/ADejMIPhbHVrgfU1YbkvtzfDGkW42bXfxqzTmZKW+x7m881iIkviXOjfH0UEAbZh8kp2sU1toJ6wyK3VRACFygq2mgjL6fkNlGBzEIWQ3zv2GWPGe2/HPjZea280Z7DdzXV+DCUkSE50YxobekTDqK9rVVUbo1nzcqubVb+p9l0Y8hACIKxO9pa3Th+rInROA0n7spDFwJCYny9hPPbBTk2yr37YjmrUc7xp+OV7DWTkf+1ITe5K7I7G0NYH2kIVh1yrJFqncQZMaxturVScOqOAzZCYuHHkxwWBuCMbs/V3m7XXyKmLA/e4wQbIWFF/MABlI35rszGrMjSlbVyxoabzrLpjoPTxATYFKJOaaZhX2BlICKyEcYZDCcGpXgo+5Lwqhz6kAo2QooesxQpIkr5OKSvFIcSlwvW/hjC2h9DWCENYYU0hBXSEFZIQ1ghDQEfeYcsJ+YPfxGcHgk/LlMAAAAASUVORK5CYII="
        />
        {{ $t('uploadProduct') }}</span
      >
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        data-qe-id="upload_Product_btn"
        @click.native="closeProductUpload()"
      >
        <v-icon>mdi-close</v-icon>{{ $t('close') }}
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row class="flex-column bpt5" no-gutters>
        <v-col>
          <brierley-form-title
            :formTitle="getFormTitle"
            :infoText="getInfoText"
          >
          </brierley-form-title>
        </v-col>
        <v-col class="bmt5">
          <v-row class="flex-column" no-gutters>
            <v-col v-if="uploadProductStatus === 'Success'">
              <v-row no-gutters>
                <v-col class="label-text">{{ $t('importing') }}</v-col>
                <v-col class="text-right">
                  <span>{{ Math.ceil(knowledge) }}{{ $t('completed') }}</span>
                </v-col>
              </v-row>
            </v-col>
            <v-col class="bmb5" v-if="uploadProductStatus === 'Success'">
              <v-progress-linear
                class="upload-file-progress"
                v-model="knowledge"
                height="10"
              >
              </v-progress-linear>
            </v-col>
            <v-col>
              <brierley-alert
                class="bmb5"
                :isSiteLevel="true"
                :alertHeader="`Import ${uploadProductStatus}`"
                :alertType="getAlertType"
                :icon="checkIcon"
                :alertBody="getStatusMessage"
              ></brierley-alert>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </template>
    <template v-slot:footer-previous>
      <v-btn class="primaryctabtn" @click="goToDashboard()">{{ $t('go_to_dashboard') }}</v-btn>
    </template>
    <template v-slot:footer-belowtext>
      <p class="label-text bmt4">{{ $t('uploadAnotherFile') }}</p>
      <p class="bmb0">
        {{ $t('addNewFile_Entity') }}
        <strong
          class="primary-text cursor-p"
          id="product_Upload_goTo_btn"
          @click="goToUploadProduct()"
          >{{ $t('clickHere') }}</strong
        >
      </p>
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyInnerView,
  BrierleyFormTitle,
  brierleyAlert
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { productUploadStatusObj } from '../../../i18n/language';

export default {
  i18n: productUploadStatusObj,
  components: {
    BrierleyInnerView,
    BrierleyFormTitle,
    brierleyAlert
  },
  data () {
    return {
      knowledge: 100
    };
  },
  mounted () {
    window.scrollTo(0, 0);
  },
  computed: {
    ...mapState('productModule', ['uploadProductStatus']),
    getFormTitle () {
      if (this.uploadProductStatus === 'Success') {
        return this.$t('success');
      }
      return this.$t('error');
    },
    getInfoText () {
      if (this.uploadProductStatus === 'Success') {
        return this.$t('successInfoText');
      }
      return this.$t('errorInfoText');
    },
    getStatusMessage () {
      if (this.uploadProductStatus === 'Success') {
        return this.$t('successMessage');
      }
      return this.$t('errorMessage');
    },
    getAlertType () {
      if (this.uploadProductStatus === 'Success') {
        return 'success';
      }
      return 'error';
    },
    checkIcon () {
      if (this.uploadProductStatus === 'Success') {
        return 'check';
      }
      return '';
    }
  },
  methods: {
    goToUploadProduct () {
      this.$parent.loading = false;
      this.$store.commit('productModule/uploadProductStatus', '');
      window.scrollTo(0, 0);
    },
    closeProductUpload () {
      this.$router.push('/loyaltyadmin/products/list');
      this.goToUploadProduct();
    },
    goToDashboard () {
      this.goToUploadProduct();
      this.$router.push({
        name: 'batchImport',
        query: {
          showAllFiles: true,
          fromProduct: true
        }
      });
    }
  }
};
</script>
