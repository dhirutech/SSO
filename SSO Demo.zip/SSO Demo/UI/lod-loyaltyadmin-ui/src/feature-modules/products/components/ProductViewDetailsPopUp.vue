<template>
  <v-row>
    <v-col sm="12">
      <brierley-dialogbox
        :dialog="ResDialog"
        @closeMe="closeDialog()"
        :persistent="false"
        class="custom-dialog__large"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">{{
            productdetailslist.name
          }}</v-card-title>
        </template>
        <template v-slot:dialog-body-description>
          <v-col cols="12" md="5" class="endless-tailored bmt3">
            <span class="endless-tailored__title">{{
              $t('productDetails')
            }}</span>
            <v-flex class="endless-tailored__section">
              <strong>{{ $t('productNameText') }}</strong>
              <small>{{ productdetailslist.name }}</small>
              <strong>{{ $t('descriptionLabel') }}</strong>
              <p>
                {{ productdetailslist.description }}
              </p>
            </v-flex>
            <v-flex class="endless-tailored__section">
              <v-row no-gutters>
                <v-col md="7">
                  <strong>{{ $t('externalId') }}</strong>
                  <small>{{ productdetailslist.externalId }}</small>
                </v-col>
                <v-col md="5">
                  <strong>{{ $t('basePrice') }}</strong>
                  <small>{{ productdetailslist.basePrice }}</small>
                </v-col>
              </v-row>
            </v-flex>
            <v-flex class="endless-tailored__section">
              <v-row no-gutters v-model="cols">
                <v-col
                  md="6"
                  style="float:left"
                  v-for="(value,
                  key,
                  index) in productdetailslist.extensionProperty"
                  :key="index"
                >
                  <strong>{{ key | uppercase }}</strong>
                  <small>{{ value }}</small>
                </v-col>
              </v-row>
            </v-flex>
          </v-col>
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>

<script>
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { productListObj } from '../../../i18n/language.js';
import { mapState } from 'vuex';
export default {
  components: {
    BrierleyDialogbox
  },
  i18n: productListObj,
  data () {
    return { dialog: false };
  },
  filters: {
    uppercase: function (string) {
      return string.charAt(0).toUpperCase() + string.slice(1);
    }
  },
  mounted () {
    this.$store.dispatch('productModule/productDetailsAction', this.productId);
  },
  methods: {
    closeDialog () {
      this.$store.commit('productModule/getProductDetailsMutation', {});
      let content = document.querySelector('html');
      content.classList.remove('overflow-y-hidden');
      this.$store.commit('productModule/showViewDetailsPopup', false);
      this.ResDialog = false;
    }
  },
  computed: {
    ...mapState('productModule', {
      productdetailslist: (state) => {
        return state.productdetailslist;
      },
      ResDialog: (state) => {
        return state.showViewDetailsPopup;
      },
      productId: (state) => {
        return state.selectedProductId;
      }
    })
  }
};
</script>
