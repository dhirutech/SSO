<template>
  <v-row>
    <v-col cols="12">
      <brierley-grid-card
        v-for="(list, index) in productslistdata"
        :key="index"
      >
        <template v-slot:grid-card-body>
          <v-col md="4" sm="12" xs="12">
            <v-card-title :title="list.name" class="elipsis-fullwidth">
              {{ list.name }}
            </v-card-title>
            <div class="gen2-card-copy">
              <p>
                <strong>{{ $t('basePrice') }}: </strong>{{ list.basePrice }}
              </p>
            </div>
          </v-col>
          <v-col md="4" sm="12" xs="12" class="pr-5">
            <p class="bmt0 elipsis-fullwidth" :title="list.externalId">
              <strong>{{ $t('externalId') }}: </strong>
              {{ list.externalId }}
            </p>
            <p>
              <strong>{{ $t('productDescription') }}:</strong>
            </p>
            <p class="discription bpr5 bmt0" :title="list.description">
              {{ list.description }}
            </p>
          </v-col>
          <v-col md="4" sm="12" xs="12" class="bpl6">
            <p class="bmt0">
              <strong>{{ $t('programEntityLabel') }}:</strong>
              {{ list.programEntityName }}
            </p>
          </v-col>
          <v-col md="12">
            <brierleyCardIcons>
              <template v-slot:action-icons>
                <span class="active" @click="viewDetails(list.productId)">
                  <v-icon :title="$t('viewDetails')">visibility</v-icon>
                  <span class="viewdetails-icon">{{ $t('viewDetails') }}</span>
                </span>
                <!-- <span>
                  <v-icon>mdi-pencil-box-outline</v-icon>
                  <span class="edit-icon">Edit</span>
                </span>
                <span>
                  <v-icon>mdi-content-copy</v-icon>
                  <span class="copy-icon">Copy</span>
                </span>
                <span>
                  <v-icon>mdi-pause</v-icon>
                  <span class="pause-icon">Pause</span>
                </span>
                <span>
                  <v-icon>mdi-delete</v-icon>
                  <span class="delete-icon">Delete</span>
                </span> -->
              </template>
            </brierleyCardIcons>
          </v-col>
        </template>
      </brierley-grid-card>
    </v-col>
    <v-col>
      <product-view-details-pop-up v-if="details === true" />
    </v-col>
  </v-row>
</template>
<script>
import ProductViewDetailsPopUp from '../ProductViewDetailsPopUp';
import { BrierleyCardIcons, BrierleyGridCard } from '@brierley/SharedComponents';
import { productListObj } from './../../../../i18n/language.js';
import { mapState } from 'vuex';
export default {
  components: {
    BrierleyCardIcons,
    BrierleyGridCard,
    ProductViewDetailsPopUp
  },
  i18n: productListObj,
  data () {
    return {};
  },
  props: {
    productslistdata: {
      type: Array,
      defualt: []
    }
  },
  computed: {
    ...mapState('productModule', {
      details: (state) => {
        return state.showViewDetailsPopup;
      }
    })
  },
  methods: {
    viewDetails (id) {
      let content = document.querySelector('html');
      content.classList.add('overflow-y-hidden');
      this.$store.commit('productModule/selectedProductId', id);
      this.$store.commit('productModule/showViewDetailsPopup', true);
      this.details = true;
    }
  }
};
</script>
