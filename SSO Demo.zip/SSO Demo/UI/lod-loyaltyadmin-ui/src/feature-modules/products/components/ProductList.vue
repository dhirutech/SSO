<template>
  <v-col>
    <v-row class="flex-column" no-gutters>
      <v-col class="loyalty-users-common">
        <v-row class="flex-column bpt4" no-gutters>
          <v-col>
            <brierley-page-headings
              :pageSubHeading="$t('Products')"
              :pageSecondaryHeading="`(${productsCount} ${$t('Products')})`"
            ></brierley-page-headings>
          </v-col>
        </v-row>
      </v-col>
      <v-col>
        <v-row class="gen2-search-filter bpt2" no-gutters>
          <v-col class="text-left loyalty-users-common" cols="5">
            <v-row class="d-flex grid-search" no-gutters>
              <v-col class="bpr2">
                <v-text-field
                  autocomplete="off"
                  class="search-field"
                  id="product_loyaltyAdmin_searchProduct"
                  :label="$t('searchProductText')"
                  prepend-inner-icon="mdi-magnify"
                  v-model="searchText"
                  @input="isTyping = true"
                ></v-text-field>
              </v-col>
            </v-row>
          </v-col>
          <v-col cols="7" class="text-right align-self-center">
            <brierley-filter
              v-on:click.native="isHidden = !isHidden"
            ></brierley-filter>

            <div class="bmr1 d-inline-block">
              <brierley-view-option
                :viewList="cardlist"
                @viewChanged="viewType = $event"
              ></brierley-view-option>
            </div>
            <span
              v-if="businessEntities.length > 1"
              class="primary-text fbold text-uppercase bpr3"
              @click="businessEntityDialog = true"
              >{{ $t('switchEntity') }}</span
            >
            <v-btn
              text
              class="primaryctabtn no-ripple"
              @click="openProgramEntitySwitcher()"
              >{{ $t('createAProduct') }}</v-btn
            >
          </v-col>
          <v-col cols="12" class="filter-dropdown bmt1">
            <!-- <brierley-filter-result v-if="isHidden">
                <template v-slot:body-content>
                </template>
                <template v-slot:footer>
                  <v-btn
                    text
                    title="Clear & Close"
                    class="mr-5 cancel bmt3"
                    id="viewuser_btn_clear"
                    >{{ $t('clearBtnText') }}</v-btn
                  >
                  <v-btn
                    title="Apply Filters"
                    depressed
                    class="next bmt3 primaryctabtn"
                    >{{ $t('filterBtnText') }}</v-btn
                  >
                </template>
              </brierley-filter-result> -->
          </v-col>
        </v-row>
      </v-col>
      <v-col v-if="viewType == 'card_view'">
        <Product-card-view :productslistdata="ProductList" />
      </v-col>
      <v-col v-if="viewType == 'grid_view'">
        <Product-grid-view :productslistdata="ProductList" />
      </v-col>
      <v-col v-if="viewType == 'table_view'">
        <Product-table-view :productslistdata="ProductList" />
      </v-col>
      <brierley-dialogbox
        :dialog="businessEntityDialog"
        persistent
        @closeMe="closeEntityPopup()"
      >
        <template v-slot:dialog-header>
          <v-card-title
            class="gen2-dialog-title text-uppercase"
            data-qe-id="org_addEntity_cardTitle"
          >
            {{ $t('selectProgramEntityText') }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <p class="line-height-normal">
              {{ $t('programEntitySwitchOption') }}
            </p>
            <v-row
              no-gutters
              class="flex-column gen2-forms form-light-bg min-height-200 overflow-y-hidden"
            >
              <v-col class="bmt2" sm="4" xs="12" md="6">
                <p class="label-text line-height-normal">
                  {{ $t('selectProgramEntityText') }}
                </p>
                <v-select
                  :items="businessEntities"
                  item-text="name"
                  item-value="name"
                  v-model="businessEntity"
                  filled
                  attach
                  offset-y
                  class="gen2select gen2select__dark mini-list"
                  :label="$t('selectProgramEntityLabel')"
                  append-icon="expand_more"
                ></v-select>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            text
            class="cancel no-ripple cursor-p btn-hover-none"
            @click="closeEntityPopup()"
            >{{ $t('cancelBtnTextPopUp') }}</v-btn
          >
          <v-btn
            class="primaryctabtn text-uppercase cursor-p"
            :disabled="businessEntity === ''"
            @click="onsubmit()"
            >{{ $t('continueBtnText') }}</v-btn
          >
        </template>
      </brierley-dialogbox>
      <v-col v-if="productsCount === 0">
        <brierley-no-result
          :noResultMessage="noData"
          id="products_img_no_data"
        ></brierley-no-result>
      </v-col>
      <v-col align="center">
        <loadmore
          :loadingText="$t('loading')"
          v-if="loadmore & (productsCount !== 0)"
          id="viewuser_loadmore"
          class="margin-auto"
        />
      </v-col>
      <program-entity-dialog
        :dialog="chooseProgramEntity"
        :entities="programEntities"
        @entity-selected="uploadStore"
        @close="cancelEntitySelect"
      ></program-entity-dialog>
    </v-row>
  </v-col>
</template>
<script>
import { productListObj } from '../../../i18n/language.js';
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import {
  BrierleyFilter,
  BrierleyViewOption,
  Loadmore,
  BrierleyNoResult,
  BrierleyPageHeadings
} from '@brierley/SharedComponents';
import ProductCardView from '../components/child/ProductCardView';
import ProductGridView from '../components/child/ProductGridView';
import ProductTableView from '../components/child/ProductTableView';
import { mapState } from 'vuex';
import _ from 'lodash';
import ProgramEntityDialog from './ProgramEntityDialog.vue';

export default {
  components: {
    BrierleyFilter,
    BrierleyViewOption,
    ProductCardView,
    ProductGridView,
    ProductTableView,
    Loadmore,
    BrierleyDialogbox,
    BrierleyNoResult,
    BrierleyPageHeadings,
    ProgramEntityDialog
  },
  i18n: productListObj,
  data () {
    return {
      businessEntityDialog: false,
      loadmore: true,
      searchText: '',
      isTyping: false,
      businessEntities: '',
      businessEntity: '',
      viewType: 'grid_view',
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: this.$t('gridViewText')
        },
        {
          key: 'table_view',
          icon: 'table_chart',
          label: this.$t('tableViewText')
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: this.$t('cardViewText')
        }
      ],
      chooseProgramEntity: false
    };
  },
  mounted () {
    this.products();
    window.addEventListener('scroll', this.onScroll);
  },
  computed: {
    ...mapState('productModule', ['params']),
    ...mapState('productModule', {
      ProductList: (state) => {
        return state.getProductsListMutations;
      },
      productsCount: (state) => {
        return state.getProductsCount;
      },
      programEntities: (state) => {
        return state.businessEntities;
      }
    })
  },
  methods: {
    closeEntityPopup () {
      this.businessEntityDialog = false;
    },
    searchInit (searchText) {
      this.params.searchText =
        searchText === '' || searchText === undefined ? '' : searchText.trim();
      this.params.pageNumber = 1;
      this.params.pageSize = 10;
      this.$store.dispatch('productModule/getProductsListActions', this.params);
    },
    onsubmit () {
      this.ProductList.length = 0;
      sessionStorage.setItem('selectedBusinessEntity', this.businessEntity);
      this.businessEntities = JSON.parse(
        sessionStorage.getItem('businessEntities')
      );
      let businessEntityName = sessionStorage.getItem('selectedBusinessEntity');
      if (this.businessEntities.length > 1) {
        this.businessEntities.forEach((res) => {
          if (businessEntityName === res.name) {
            this.params.businessEntityId = res.businessEntityId;
          }
        });
      } else if (this.businessEntities.length === 1) {
        this.params.businessEntityId = this.businessEntities[0].businessEntityId;
      }
      this.params.pageNumber = 1;
      this.params.pageSize = 10;
      this.$store.dispatch('productModule/getProductsListActions', this.params);
      this.businessEntityDialog = false;
    },
    products () {
      this.loadmore = true;
      this.businessEntities = JSON.parse(
        sessionStorage.getItem('businessEntities')
      );
      let businessEntityName = sessionStorage.getItem('selectedBusinessEntity');
      if (this.businessEntities.length > 1) {
        this.businessEntities.forEach((res) => {
          if (businessEntityName === res.name) {
            this.params.businessEntityId = res.businessEntityId;
          }
        });
      } else if (this.businessEntities.length === 1) {
        this.params.businessEntityId = this.businessEntities[0].businessEntityId;
      }
      if (
        this.params.pageNumber * this.params.pageSize <
        this.productsCount + 12
      ) {
        this.$store.dispatch(
          'productModule/getProductsListActions',
          this.params
        );
      } else {
        this.loadmore = false;
      }
    },
    onScroll () {
      window.onscroll = () => {
        if (
          document.documentElement.scrollHeight ===
          document.documentElement.scrollTop + window.innerHeight
        ) {
          this.params.pageSize += 10;
          this.products();
        }
      };
    },
    cancelEntitySelect () {
      this.chooseProgramEntity = false;
    },
    uploadStore (entity) {
      this.chooseProgramEntity = false;
      const businessEntity = {
        businessEntityId: entity.entityId,
        businessEntityName: entity.entityName
      };
      this.$store.commit(
        'productModule/setSelectedBusinessEntity',
        businessEntity
      );
      this.$router.push('/loyaltyadmin/products/upload');
    },
    openProgramEntitySwitcher () {
      let programId = this.$root.GlobalStoreEventStore.state.program.programId;
      if (programId !== null) {
        this.$store
          .dispatch('productModule/getBusinessEntities', programId)
          .then(() => {
            this.chooseProgramEntity = true;
          });
      }
    }
  },
  watch: {
    ProductList () {
      this.loadmore = false;
    },
    searchText: function () {
      const self = this;
      _.debounce(function () {
        self.isTyping = false;
        self.params.pageNumber = 1;
      }, 3000)();
    },
    isTyping: function (value) {
      if (this.searchText === '') {
        this.params.searchText = '';
      }
      if (!value) {
        this.searchInit(this.searchText);
      }
    }
  },
  beforeDestroy () {
    window.removeEventListener('scroll', this.onScroll);
  }
};
</script>
