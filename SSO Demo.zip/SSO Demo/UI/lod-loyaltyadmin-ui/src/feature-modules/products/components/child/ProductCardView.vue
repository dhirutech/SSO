<template>
  <v-row>
    <v-col
      md="6"
      sm="12"
      xs="12"
      v-for="(list, index) in productslistdata"
      :key="index"
    >
      <brierley-card>
        <template v-slot:header>
          <h2 class="bmb2">{{ list.name }}</h2>
        </template>
        <template v-slot:footer>
          <v-col>
            <p>
              <strong>{{ $t('basePrice') }}: </strong>
              <span>{{ list.basePrice }}</span>
            </p>
          </v-col>
          <v-col>
            <p class="elipsis-fullwidth" :title="list.externalId">
              <strong> {{ $t('externalId') }}: </strong>
              <span>{{ list.externalId }}</span>
            </p>
          </v-col>
          <v-col sm="12" class="bmy3">
            <p class="bmb0 fbold">{{ $t('productDescription') }}:</p>
            <p class="elipsis-twoline">
              {{ list.description }}
            </p>
            <p class="bmt2">
              <strong> {{ $t('programEntityLabel') }}:</strong>
              {{ list.programEntityName }}
            </p>
          </v-col>
          <v-col sm="12">
            <brierleyCardIcons>
              <template v-slot:action-icons>
                <span class="active" @click="viewDetails(list.productId)">
                  <v-icon :title="$t('viewDetails')">visibility</v-icon>
                  <span class="viewdetails-icon"> {{ $t('viewDetails') }}</span>
                </span>
                <!-- <span>
                  <v-icon class="blackicon" title="Edit">fe fe-edit</v-icon>
                  <span class="edit-icon">Edit</span>
                </span>
                <span>
                  <v-icon title="Copy">mdi-content-copy</v-icon>
                  <span class="copy-icon">Copy</span>
                </span>
                <span>
                  <v-icon title="Pause">mdi-pause</v-icon>
                  <span class="pause-icon">Pause</span>
                </span>
                <span>
                  <v-icon class="blackicon" title="Delete">fe-trash-2</v-icon>
                  <span class="delete-icon">Delete</span>
                </span> -->
              </template>
            </brierleyCardIcons>
          </v-col>
        </template>
      </brierley-card>
    </v-col>
    <v-col>
      <product-view-details-pop-up v-if="details === true" />
    </v-col>
  </v-row>
</template>

<script>
import { BrierleyCard, BrierleyCardIcons } from '@brierley/SharedComponents';
import ProductViewDetailsPopUp from '../ProductViewDetailsPopUp';
import { productListObj } from './../../../../i18n/language.js';
import { mapState } from 'vuex';

export default {
  components: {
    BrierleyCard,
    BrierleyCardIcons,
    ProductViewDetailsPopUp
  },
  i18n: productListObj,
  data () {
    return {};
  },
  props: {
    productslistdata: {
      type: Array,
      defualt: []
    }
  },
  computed: {
    ...mapState('productModule', {
      details: (state) => {
        return state.showViewDetailsPopup;
      }
    })
  },
  methods: {
    viewDetails (id) {
      let content = document.querySelector('html');
      content.classList.add('overflow-y-hidden');
      this.$store.commit('productModule/selectedProductId', id);
      this.$store.commit('productModule/showViewDetailsPopup', true);
      this.details = true;
    }
  }
};
</script>
