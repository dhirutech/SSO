import {
  communicationNameExistsOrNot,
  getChannelsByProgram,
  getCommunicationsMessageTemplates,
  saveDeliveryChannelData,
  getCommunicationsProviderMessageFields,
  getMessageAttributeData,
  getEmailSubjectData,
  getCommunicationsIdResponse,
  commMsgBookmark,
  getCommMsgSearch,
  getAllProgramStatusForCommunicationManagement,
  getUserApi,
  deleteCommMessage,
  testTemplateData
} from '../api/communicationManagementApi';

const checkCommunicationNameExistingOrNotAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    communicationNameExistsOrNot(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getChannelsByProgramAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getChannelsByProgram(payload)
      .then(res => {
        resolve(res);
        let deliveryChannelData = [];
        deliveryChannelData = [
          {
            channelList: [
              {
                name: res.data.data[0].channelName.toUpperCase(),
                Id: res.data.data[0].channelId,
                isSelected: true,
                icon: 'mail'
              }
            ],
            providersList: [
              {
                name: res.data.data[0].providerName
              }
            ]
          }
        ];
        context.commit('deliveryChannelDataMutation', deliveryChannelData);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getCommunicationsMsgTemplates = (context, payload) => {
  return new Promise((resolve, reject) => {
    getCommunicationsMessageTemplates(payload.providerName)
      .then(result => {
        if (payload.templateId !== '') {
          if (result.data.data.length > 0) {
            result.data.data.forEach(item => {
              if (parseInt(payload.templateId) === item.id) {
                item.isSelected = true;
                context.commit('selectedMsgTemplateMutation', item);
              } else {
                item.isSelected = false;
              }
            });
          }
        } else {
          if (result.data.data.length > 0) {
            result.data.data.forEach(item => {
              item.isSelected = false;
            });
          }
        }
        context.commit(
          'updateCommunicationMsgTemplatesMutation',
          result.data.data
        );
      })
      .catch(err => {
        reject(err);
      });
  });
};

const saveDeliveryChannelDraftAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    saveDeliveryChannelData(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getCommunicationsProviderMsgFields = (context, payload) => {
  return new Promise((resolve, reject) => {
    getCommunicationsProviderMessageFields(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getMessageAttributesAction = (context, payload) => {
  getMessageAttributeData(payload)
    .then(result => {
      context.commit('getMessageAttributeMutation', result.data.data);
    })
    .catch();
};

const getEmailSubjectAction = (context, payload) => {
  getEmailSubjectData(payload)
    .then(result => {
      context.commit('setEmailSubjectMutation', result.data.data);
    })
    .catch();
};

const getEmailSubjectDetailsAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getEmailSubjectData(payload[0].groupId)
      .then(res => {
        resolve(res);
        res.data.data.subjectLine = payload[0].subjectLine;
        context.commit('setEmailSubjectMutation', res.data.data);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const editCommunicationManagementAction = (context, payload) => {
  getCommunicationsIdResponse(payload)
    .then(result => {
      context.commit('editCommunicationManagementMutation', result.data.data);
    })
    .catch();
};

const goToCommMsgBtnAction = (context, payload) => {
  context.commit('goToCommMsgMutation', payload);
};

const commMsgBookmarkAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    commMsgBookmark(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getCommMsgListAction = (context, value) => {
  return new Promise((resolve, reject) => {
    getCommMsgSearch(value)
      .then(result => {
        resolve(result);
        context.commit(
          'userSearchListMutation',
          result.data.data.commMessageProps
        );
        context.commit('userCountMutation', result.data.data);
      })
      .catch(err => {
        reject(err);
        if (err.response.status === 400 || err.response.status === 404) {
          context.commit(
            'userSearchListMutation',
            err.response.data.data.commMessageProps
          );
          context.commit('userCountMutation', err.response.data.data);
          context.commit('loadMore', false);
        }
      });
  });
};

const getAllProgramStatusForCommunication = context => {
  return new Promise((resolve, reject) => {
    getAllProgramStatusForCommunicationManagement()
      .then(res => {
        resolve(res);
        context.commit('getAllProgramsCommunicationMutation', res.data);
      })
      .catch(err => {
        reject(err);
        if (err.response.status === 400 || err.response.status === 404) {
          context.commit(
            'getAllProgramsCommunicationMutation',
            err.response.data.data
          );
        }
      });
  });
};

const getUserData = (context, payload) => {
  getUserApi(payload)
    .then(res => {
      context.commit('userData', res.data.userAccountPreference);
    })
    .catch();
};

const deleteCommMsgAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    deleteCommMessage(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getCommListDataAction = (context, payload) => {
  let obj = {
    ProgramId: payload,
    pageSize: 10,
    pageNumber: 1,
    searchText: '',
    filterEndRange: '',
    filterStartRange: '',
    status: '',
    draftStatus: ''
  };
  return new Promise((resolve, reject) => {
    getCommMsgSearch(obj)
      .then(result => {
        resolve(result);
        context.commit(
          'userSearchListMutation',
          result.data.data.commMessageProps
        );
        context.commit('userCountMutation', result.data.data);
      })
      .catch(err => {
        reject(err);
        if (err.response.status === 400 || err.response.status === 404) {
          context.commit(
            'userSearchListMutation',
            err.response.data.data.commMessageProps
          );
          context.commit('userCountMutation', err.response.data.data);
          context.commit('loadMore', false);
        }
      });
  });
};

const programIdAction = (context, payload) => {
  context.commit('programIdMutation', payload);
};

const getPreviewDetailsAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    getCommunicationsIdResponse(payload)
      .then(res => {
        resolve(res);
        context.commit('templateIdEditMutation', res.data.data.templateId);
        context.commit(
          'updatemessagePersonalizationsMutation',
          res.data.data.messagePersonalizations
        );
      })
      .catch(err => {
        reject(err);
      });
  });
};

const testTemplateAction = (context, payload) => {
  return new Promise((resolve, reject) => {
    testTemplateData(payload)
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export default {
  checkCommunicationNameExistingOrNotAction,
  getChannelsByProgramAction,
  deleteCommMsgAction,
  commMsgBookmarkAction,
  getUserData,
  programIdAction,
  getAllProgramStatusForCommunication,
  getCommMsgListAction,
  getCommListDataAction,
  getCommunicationsMsgTemplates,
  saveDeliveryChannelDraftAction,
  getCommunicationsProviderMsgFields,
  getMessageAttributesAction,
  getEmailSubjectAction,
  editCommunicationManagementAction,
  goToCommMsgBtnAction,
  getPreviewDetailsAction,
  getEmailSubjectDetailsAction,
  testTemplateAction
};
