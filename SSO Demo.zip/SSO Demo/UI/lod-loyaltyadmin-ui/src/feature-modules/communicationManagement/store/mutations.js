const communicationMsgExistsMutation = (state, payload) => {
  state.communicationMessageDetails.communicationMsgExists = payload;
};

const deliveryChannelDataMutation = (state, payload) => {
  state.communicationMessageDetails.deliveryChannelData = payload;
};

const updateCommunicationStepperMutation = (state, payload) => {
  state.communicationMessageDetails.communicationStepper = payload;
};

const updateGlobalProgramIdMutation = (state, payload) => {
  state.communicationMessageDetails.programId = payload;
};

const goToCommMsgMutation = (state, payload) => {
  state.goToCommMsgBtn = payload;
};

const updateCommunicationMessageDetailsObjectMutation = (state, payload) => {
  state.communicationMessageDetails.commMessageId = payload.commMessageId;
  state.communicationMessageDetails.commChannelId = payload.commChannelId;
  state.communicationMessageDetails.templateId = payload.templateId;
  state.communicationMessageDetails.messagePersonalizations = payload.messagePersonalizations;
};

const clearCommMsgTemplatesMutation = (state, payload)=>{
  state.communicationMessageDetails.commMsgTemplates = payload;
};

const updateReviewCommunicationMessageDetailsObjectMutation = (
  state,
  payload
) => {
  state.communicationMessageDetails.commMessageId = payload.commMessageId;
  state.communicationMessageDetails.commChannelId = payload.commChannelId;
  state.communicationMessageDetails.templateId = payload.templateId;
  state.communicationMessageDetails.messagePersonalizations =
    payload.messagePersonalizations;
};

const updateCommunicationMsgTemplatesMutation = (state, payload) => {
  state.communicationMessageDetails.commMsgTemplates = payload;
};

const getMessageAttributeMutation = (state, payload) => {
  state.communicationMessageDetails.messageAttributes = payload;
};

const updateCommunicationsProviderMessageFieldsMutation = (state, payload) => {
  state.communicationMessageDetails.communicationsProviderMessageFields = payload;
};

const selectedMsgTemplateMutation = (state, payload) => {
  state.communicationMessageDetails.selectedMsgTemplate = payload;
  state.communicationMessageDetails.templateId = payload.id;
};

const setEmailSubjectMutation = (state, payload) => {
  state.communicationMessageDetails.messageDetails = payload;
};

const updateStatusMutation = (state, payload) => {
  state.communicationMessageDetails.status = payload;
};

const openCancelPopupMutation = (state, payload) => {
  state.communicationMessageDetails.showCancelPopup = payload;
};

const clearCommunicationMessageDetailsMutation = (state, payload) => {
  state.communicationMessageDetails = payload;
};

const updatemessagePersonalizationsMutation = (state, payload) => {
  state.communicationMessageDetails.messagePersonalizations = payload;
};

const editCommunicationManagementMutation = (state, payload) => {
  state.communicationMessageDetails.commMessageId = payload.commMessageId;
  state.communicationMessageDetails.commChannelId = payload.commChannelId;
  state.communicationMessageDetails.createdDate = payload.createdDate;
  state.communicationMessageDetails.description = payload.description;
  state.communicationMessageDetails.messagePersonalizations =
    payload.messagePersonalizations;
  state.communicationMessageDetails.name = payload.name;
  state.communicationMessageDetails.programId = payload.programId;
  state.communicationMessageDetails.status = payload.status;
  state.communicationMessageDetails.templateId = payload.templateId;
  state.communicationMessageDetails.updatedDate = payload.updatedDate;
};

const testMessageStepMutation = (state, payload) => {
  state.testMessageStep = payload;
};

const templateErrorMutation = (state, payload) => {
  state.templateError = payload;
};

const viewTypeMutation = (state, payload) => {
  state.viewType = payload;
};

const personalizationBtnStatusMutation = (state, payload) => {
  state.personalizationBtnStatus = payload;
};
const showDeletePopUpDialogueMutation = (state, payload) => {
  state.showDeletePopUp = payload;
};
const programIdMutation = (state, payload) => {
  state.programId = parseInt(payload);
};
const cardViewEnableMutation = (state, payload) => {
  state.cardViewEnb = payload;
};

const deleteCommMessageIdMutation = (state, payload) => {
  state.deleteCommMsgId = payload;
};
const userSearchListMutation = (state, payload) => {
  state.getCommMsgListRes = payload;
};
const userCountMutation = (state, payload) => {
  state.commMsgCompleteRes = payload;
  state.filterCount = payload.filterListCount;
  state.userCountRes = payload.publishedStatusCount + payload.draftStatusCount;
};

const showAlertPopUpDialogueMutation = (state, payload) => {
  state.showAlertPopUpDialogue = payload;
};

const alertPopUpDialogueMsgMutation = (state, payload) => {
  state.alertMsg = payload;
};

const getAllProgramsCommunicationMutation = (state, payload) => {
  state.allProgramStatusListForCommunication = payload;
};

const userData = (state, payload) => {
  state.userDataRes = payload;
};

const templateIdEditMutation = (state, payload) => {
  state.communicationMessageDetails.templateId = parseInt(payload);
};

const commObjectArrayMutation = (state, payload) => {
  state.commObjectArray = payload;
};

const reviewBtnStatusMutation = (state, payload) => {
  state.communicationReviewBtnExists = payload;
};

export default {
  clearCommMsgTemplatesMutation,
  reviewBtnStatusMutation,
  userData,
  communicationMsgExistsMutation,
  getAllProgramsCommunicationMutation,
  deliveryChannelDataMutation,
  alertPopUpDialogueMsgMutation,
  userCountMutation,
  showAlertPopUpDialogueMutation,
  deleteCommMessageIdMutation,
  userSearchListMutation,
  updateCommunicationStepperMutation,
  updateGlobalProgramIdMutation,
  updateCommunicationMessageDetailsObjectMutation,
  updateCommunicationMsgTemplatesMutation,
  getMessageAttributeMutation,
  updateCommunicationsProviderMessageFieldsMutation,
  selectedMsgTemplateMutation,
  setEmailSubjectMutation,
  programIdMutation,
  updateStatusMutation,
  cardViewEnableMutation,
  openCancelPopupMutation,
  showDeletePopUpDialogueMutation,
  clearCommunicationMessageDetailsMutation,
  updatemessagePersonalizationsMutation,
  editCommunicationManagementMutation,
  updateReviewCommunicationMessageDetailsObjectMutation,
  testMessageStepMutation,
  templateErrorMutation,
  goToCommMsgMutation,
  viewTypeMutation,
  personalizationBtnStatusMutation,
  templateIdEditMutation,
  commObjectArrayMutation
};
