<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <brierley-form-title
        formTitle="PROVIDER : MAPP"
        :currentStep="3"
        :totalStep="5"
        :infoText="$t('providerInfo')"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <v-col
      data-qe-id="communicationManagement_providerselectmsg"
      class="bpt5 label-text"
      v-if="goToCommMsgBtn && viewType !== 'card_view'"
    >
      {{ $t("providerSelectMsg") }}
    </v-col>
    <v-col class="bpt5 label-text" v-if="!goToCommMsgBtn">
      {{ noData }}
    </v-col>
    <v-col class="bpt5 label-text" v-if="cardViewEnb">
      {{ noData }}
    </v-col>

    <v-col class="gray-bg bmb2 bpx3 bpy2 ">
      <v-row class="flex-column " no-gutters>
        <v-col>
          <v-row class="" no-gutters>
            <v-col cols="6">
              <!-- <v-row class="d-flex gen2-search-filter" no-gutters>
                <v-col class="text-left" cols="11">
                  <brierley-grid-search
                    :labelText="$t('searchForTemplateText')"
                    icon="mdi-magnify"
                    @SearchInit="onSearchText"
                  ></brierley-grid-search>
                </v-col>
              </v-row> -->
            </v-col>
            <v-col cols="6" class="text-right bpt1" v-if="goToCommMsgBtn">
              <brierley-view-option
                :viewList="cardlist"
                data-qe-id="communicationManagement_typeview"
                @viewChanged="typeview($event)"
              ></brierley-view-option>
              <!-- <brierley-icon-with-head
                iconName="add_circle"
                iconTitle="create a new Template"
              ></brierley-icon-with-head> -->
            </v-col>
          </v-row>
        </v-col>
        <v-col v-if="viewType == 'grid_view' && goToCommMsgBtn">
          <v-row class="notification-templates bpb1">
            <v-col
              cols="12"
              sm="6"
              v-for="(item, i) in communicationMessageDetails.commMsgTemplates"
              :key="i"
            >
              <v-card class="gen2-search-card">
                <v-row
                  id="wrapper"
                  no-gutters
                  data-qe-id="communicationManagement_selectcommmsgtemplate"
                  @click="selectcommMsgTemplate(i)"
                >
                  <v-col
                    id="left"
                    data-qe-id="communicationManagement_msgname"
                    class="gen2-search-card__head text-uppercase elipsis-fullwidth"
                    >{{ item.messageName }}</v-col
                  >
                  <v-col id="right" class="action-icons text-right">
                    <v-icon
                      class="dark-selected "
                      v-if="item.isSelected === true"
                    >
                      check_circle
                    </v-icon>
                    <v-icon class="" v-if="item.isSelected === false">
                      panorama_fish_eye
                    </v-icon>
                  </v-col>
                  <v-col cols="12">
                    <p>
                      {{ $t("providerCreatedOn") }} :
                      {{ format_date(item.creationDate) }}
                    </p>
                    <p>{{ format_time(item.creationDate) }}</p>
                  </v-col>
                </v-row>
              </v-card>
            </v-col>
          </v-row>
        </v-col>
        <v-col v-if="viewType == 'card_view' && goToCommMsgBtn">
          <brierley-no-result
            :noResultMessage="noData"
            noRecordFoundHeader=""
            id="viewuser_img_no_data"
          >
            <template v-slot:custom-heading>
              <h3 class="custom-head-noresult transform-none">
                {{ $t("providerSupportText") }}
              </h3>
            </template>
          </brierley-no-result>
        </v-col>
        <v-col v-if="!goToCommMsgBtn">
          <brierley-no-result
            :noResultMessage="noData"
            noRecordFoundHeader=""
            id="viewuser_img_no_data"
          >
            <template v-slot:custom-heading>
              <h3 class="custom-head-noresult transform-none">
                {{ $t("providerSupportText") }} <br />
                {{ $t("previewEmailText") }}
              </h3>
            </template>
          </brierley-no-result>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import {
  BrierleyViewOption,
  BrierleyFormTitle,
  BrierleyNoResult
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import moment from 'moment';
import { communicationProviderLayoutObj } from '../../../../i18n/language.js';
export default {
  data () {
    return {
      providerObj: [],
      localSelectMsg: false,
      formTitle: '',
      noData: '',
      gridView: 'grid_view',
      cardlist: [
        {
          key: 'grid_view',
          icon: 'calendar_view_day',
          label: 'grid_view'
        },
        {
          key: 'card_view',
          icon: 'view_module',
          label: 'card_view'
        }
      ]
    };
  },
  i18n: communicationProviderLayoutObj,
  components: {
    BrierleyViewOption,
    BrierleyFormTitle,
    BrierleyNoResult
  },
  computed: {
    ...mapState('CommunicationManagementModule', {
      communicationMessageDetails: state => {
        return state.communicationMessageDetails;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      goToCommMsgBtn: state => {
        return state.goToCommMsgBtn;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      cardViewEnb: state => {
        return state.cardViewEnb;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      viewType: state => {
        return state.viewType;
      }
    })
  },
  mounted () {
    this.$store.commit(
      'CommunicationManagementModule/viewTypeMutation',
      this.gridView
    );
    this.$store.commit(
      'CommunicationManagementModule/clearCommMsgTemplatesMutation',
      []
    );
    if (this.communicationMessageDetails.commMsgTemplates.length === 0) {
      let obj = {};
      obj.providerName = this.communicationMessageDetails.deliveryChannelData[0].providersList[0].name;
      obj.templateId = this.communicationMessageDetails.templateId;
      this.$store
        .dispatch(
          'CommunicationManagementModule/getCommunicationsMsgTemplates',
          obj
        )
        .catch(err => {
          if (err.response.status === 400 || err.response.status === 404) {
            this.$store.dispatch(
              'CommunicationManagementModule/goToCommMsgBtnAction',
              false
            );
          }
        });
    }
  },
  methods: {
    typeview (val) {
      this.$store.commit('CommunicationManagementModule/viewTypeMutation', val);
      if (this.viewType === 'card_view') {
        this.$store.commit(
          'CommunicationManagementModule/personalizationBtnStatusMutation',
          true
        );
        this.$store.commit(
          'CommunicationManagementModule/cardViewEnableMutation',
          true
        );
      } else {
        this.$store.commit(
          'CommunicationManagementModule/personalizationBtnStatusMutation',
          false
        );
        this.$store.commit(
          'CommunicationManagementModule/cardViewEnableMutation',
          false
        );
      }
    },
    format_date (value) {
      if (value) {
        return moment(String(value)).format('DD/MMM/YYYY');
      }
    },
    format_time (value) {
      if (value) {
        return moment(String(value)).format('hh:mm A');
      }
    },
    selectcommMsgTemplate (idx) {
      this.$store.commit(
        'CommunicationManagementModule/updateCommunicationsProviderMessageFieldsMutation',
        []
      );
      this.$store.commit(
        'CommunicationManagementModule/updatemessagePersonalizationsMutation',
        []
      );
      for (
        let i = 0;
        i < this.communicationMessageDetails.commMsgTemplates.length;
        i++
      ) {
        if (i === idx) {
          this.communicationMessageDetails.commMsgTemplates[
            i
          ].isSelected = true;
          this.$store.commit(
            'CommunicationManagementModule/selectedMsgTemplateMutation',
            this.communicationMessageDetails.commMsgTemplates[i]
          );
        } else {
          this.communicationMessageDetails.commMsgTemplates[
            i
          ].isSelected = false;
        }
      }
      this.$store.commit(
        'CommunicationManagementModule/updateCommunicationMsgTemplatesMutation',
        this.communicationMessageDetails.commMsgTemplates
      );
    }
  }
};
</script>
