<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closePopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ $t("cardTitle") }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <v-alert
                  class="b-alert-error"
                  type="error"
                  :dismissible="false"
                >
                  <v-row class="alert-block align-center havebtn" no-gutters>
                    <v-col class="alert-block__body">
                      {{ $t("alertMsg") }}
                    </v-col>
                  </v-row>
                </v-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="org_btn_cancelDeleteDialog"
            data-qe-id="communicationManagement_no_btn"
            text
            class="cancel no-ripple"
            @click="closeDeleteEntityPopupWhenClickNo()"
            >{{ $t("noBtnTextPopUp") }}</v-btn
          >
          <v-btn
            id="org_btn_deleteDeleteDialog"
            data-qe-id="communicationManagement_yes_btn"
            class="primaryctabtn text-uppercase"
            title
            @click="navigateToList()"
            >{{ $t("yesBtnTextPopUp") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox } from '@brierley/SharedComponents';
import { communicationManagementDeletePopup } from '../../../../i18n/language.js';
import { mapState } from 'vuex';
export default {
  data () {
    return {
      dialog: false
    };
  },
  components: {
    BrierleyDialogbox
  },
  i18n: communicationManagementDeletePopup,
  methods: {
    closePopup () {
      this.$store.commit(
        'CommunicationManagementModule/showDeletePopUpDialogueMutation',
        false
      );
    },
    navigateToList () {
      this.$store
        .dispatch(
          'CommunicationManagementModule/deleteCommMsgAction',
          this.deleteCommMsgId
        )
        .then(res => {
          if (res.status === 201 || res.status === 200) {
            this.$store.commit(
              'CommunicationManagementModule/showDeletePopUpDialogueMutation',
              false
            );
            this.$store.dispatch(
              'CommunicationManagementModule/getCommMsgListAction',
              this.params
            );
          }
        });
    },
    closeDeleteEntityPopupWhenClickNo () {
      this.closePopup();
    }
  },
  computed: {
    ...mapState('CommunicationManagementModule', ['deleteCommMsgId', 'params'])
  }
};
</script>
