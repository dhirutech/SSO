<template>
  <brierley-inner-view>
    <template
      v-slot:header
      v-if="$route.path.includes('/loyaltyadmin/CommunicationsManagementEdit')"
    >
      <span class="inner-head">{{ $t("communicationEditMessage") }}</span>
    </template>
    <template v-slot:header v-else>
      <span class="inner-head">{{ $t("communicationMessage") }}</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        data-qe-id="commmsgdetails_routerpush"
        text
        @click.native="$router.push('/gettingstarted')"
      >
        <v-icon>mdi-close</v-icon>CLOSE
      </v-btn>
    </template>
    <template v-slot:body-container>
      <cancel-popup v-if="communicationMessageDetails.showCancelPopup" />
      <brierley-primary-stepper
        :currentStep="communicationMessageDetails.communicationStepper"
        :stepperSize="6"
        class="mt-1"
      >
        <template v-slot:stepper-steps>
          <v-stepper-step step="1">{{ $t("basicInfoStepper") }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="2">{{
            $t("deliveryChannelStepper")
          }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="3">{{ $t("selectMsgStepper") }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="4">{{
            $t("personalizationStepper")
          }}</v-stepper-step>
          <v-divider></v-divider>
          <v-stepper-step step="5">{{ $t("reviewStepper") }}</v-stepper-step>
        </template>
        <template slot="stepper-content">
          <v-stepper-items>
            <v-stepper-content step="1">
              <Validation-Observer v-slot="{ handleSubmit }">
                <form id="basic_form" @submit.prevent="handleSubmit(onsubmit)">
                  <basic-info-layout
                    v-if="
                      communicationMessageDetails.communicationStepper === 1
                    "
                  />
                </form>
              </Validation-Observer>
            </v-stepper-content>
            <v-stepper-content step="2">
              <delivery-channel-layout
                v-if="communicationMessageDetails.communicationStepper === 2"
              />
            </v-stepper-content>
            <v-stepper-content step="3">
              <provider-layout
                v-if="communicationMessageDetails.communicationStepper === 3"
              />
            </v-stepper-content>
            <v-stepper-content step="4">
              <personalization-layout
                v-if="communicationMessageDetails.communicationStepper === 4"
              />
            </v-stepper-content>
            <v-stepper-content step="5">
              <review-layout
                v-if="communicationMessageDetails.communicationStepper === 5"
              />
            </v-stepper-content>
            <v-stepper-content step="6">
              <template
                v-if="communicationMessageDetails.communicationStepper === 6"
              >
                <v-row class="flex-column bmt2" no-gutters>
                  <v-col>
                    <brierley-form-title
                      :formTitle="$t('successFormTitle')"
                      :infoText="$t('successInfoText')"
                    ></brierley-form-title>
                  </v-col>
                  <v-col class="bpt5">
                    <brierley-alert
                      :isSiteLevel="true"
                      alertType="success"
                      :alertBody="alertMessage"
                      :alertHeader="$t('successAlertHeader')"
                      icon="done"
                    ></brierley-alert>
                  </v-col>
                </v-row>
              </template>
            </v-stepper-content>
          </v-stepper-items>
        </template>
      </brierley-primary-stepper>
    </template>
    <template v-slot:footer-previous>
      <v-btn
        id="user_btn_previous"
        text
        class="mr-5 cancel no-ripple"
        data-qe-id="commmsgdetails_gotoprevious"
        @click="goToPrevious()"
        v-if="
          communicationMessageDetails.communicationStepper > 1 &&
            communicationMessageDetails.communicationStepper < 6
        "
      >
        <v-icon class="bpr1">arrow_back</v-icon>{{ $t("previousBtn") }}
      </v-btn>
    </template>
    <template v-slot:footer>
      <v-btn
        id="user_btn_cancel"
        text
        class="cancel no-ripple bmt2 bmr5"
        v-if="communicationMessageDetails.communicationStepper < 6"
        @click="cancelMessageCreation()"
        data-qe-id="commmsgdetails_cancelmsg"
        >{{ $t("cancelBtnText") }}</v-btn
      >
      <v-btn
        form="basic_form"
        type="submit"
        class="primaryctabtn bmt2 bml2"
        v-if="communicationMessageDetails.communicationStepper === 1"
        data-qe-id="commmsgdetails_nextdeliverybtn"
        :disabled="communicationMessageDetails.communicationMsgExists"
        >{{ $t("nextDeliveryChannelBtnText") }}</v-btn
      >
      <v-btn
        class="primaryctabtn bmt2 bml2"
        v-if="communicationMessageDetails.communicationStepper === 2"
        @click="goToSelectProvider()"
        data-qe-id="commmsgdetails_gotoselectprovider"
        >{{ $t("nextSelectTemplateBtnText") }}</v-btn
      >
      <v-btn
        class="primaryctabtn bmt2 bml2"
        v-if="
          communicationMessageDetails.communicationStepper === 3 &&
            goToCommMsgBtn
        "
        :disabled="!communicationMessageDetails.selectedMsgTemplate.isSelected"
        @click="goToSelectPersonalization()"
        data-qe-id="commmsgdetails_gotoselectpersonalization"
        >{{ $t("personalizationBtn") }}</v-btn
      >
      <v-btn
        class="primaryctabtn bmt2 bml2"
        v-if="communicationMessageDetails.communicationStepper === 4"
        :disabled="communicationReviewBtnExists"
        @click="goToReviewPage()"
        data-qe-id="commmsgdetails_reviewpage"
        >{{ $t("reviewAndSaveBtn") }}</v-btn
      >
      <v-btn
        id="user_btn_saveUser"
        v-if="!goToCommMsgBtn"
        class="primaryctabtn bmt2"
        @click="goToListPage()"
        data-qe-id="commmsgdetails_listpgae"
        >{{ $t("goToCommTxt") }}</v-btn
      >
      <v-btn
        class="primaryctabtn bmt2 bml2"
        v-if="communicationMessageDetails.communicationStepper === 5"
        @click="publishMessage()"
        data-qe-id="commmsgdetails_pusblishbtn"
        >{{ $t("publishBtn") }}</v-btn
      >
    </template>
    <template
      v-slot:footer-redirect
      v-if="communicationMessageDetails.communicationStepper === 6"
    >
      <v-btn
        id="user_btn_goToUsers"
        class="primaryctabtn bmt2"
        data-qe-id="commmsgdetails_gotoinitialpage"
        @click="gotoInitialPage()"
        >{{ $t("goToCommBtn") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import BasicInfoLayout from './child/basicInfoLayout.vue';
import DeliveryChannelLayout from './child/deliveryChannelLayout.vue';
import ProviderLayout from './child/providerLayout.vue';
import personalizationLayout from './child/personalizationLayout.vue';
import reviewLayout from './child/reviewLayout.vue';
import CancelPopup from './child/cancelPopup.vue';
import { mapState } from 'vuex';
import { communicationManagementStepper } from '../../../i18n/language.js';
import {
  BrierleyInnerView,
  BrierleyPrimaryStepper,
  BrierleyFormTitle,
  brierleyAlert
} from '@brierley/SharedComponents';
export default {
  components: {
    BasicInfoLayout,
    BrierleyInnerView,
    BrierleyPrimaryStepper,
    DeliveryChannelLayout,
    ProviderLayout,
    personalizationLayout,
    reviewLayout,
    BrierleyFormTitle,
    brierleyAlert,
    CancelPopup
  },
  i18n: communicationManagementStepper,
  computed: {
    ...mapState('CommunicationManagementModule', {
      communicationMessageDetails: state => {
        return state.communicationMessageDetails;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      communicationReviewBtnExists: state => {
        return state.communicationReviewBtnExists;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      goToCommMsgBtn: state => {
        return state.goToCommMsgBtn;
      }
    }),
    alertMessage () {
      if (this.$route.name !== 'CommunicationsManagementEdit') {
        return this.$t('alertBodyText');
      } else {
        return this.$t('alertBodyEditText');
      }
    }
  },
  created () {
    this.$store.dispatch(
      'CommunicationManagementModule/goToCommMsgBtnAction',
      true
    );
    this.$store.commit(
      'CommunicationManagementModule/openCancelPopupMutation',
      false
    );
    this.$store.commit(
      'CommunicationManagementModule/clearCommunicationMessageDetailsMutation',
      {
        commMessageId: 0,
        programId: null,
        commChannelId: null,
        name: '',
        description: '',
        templateId: '',
        status: 0,
        createdDate: '',
        updatedDate: '',
        messagePersonalizations: [],
        communicationMsgExists: false,
        deliveryChannelData: [],
        communicationStepper: 1,
        commMsgTemplates: [],
        communicationsProviderMessageFields: [],
        messageAttributes: [],
        selectedMsgTemplate: {},
        messageDetails: {},
        showCancelPopup: false
      }
    );
    let id = localStorage.getItem('programId');
    this.$store.commit(
      'CommunicationManagementModule/updateGlobalProgramIdMutation',
      id
    );
  },
  mounted () {
    this.$store.dispatch(
      'CommunicationManagementModule/getMessageAttributesAction'
    );
  },
  methods: {
    cancelMessageCreation () {
      this.$store.commit(
        'CommunicationManagementModule/openCancelPopupMutation',
        true
      );
    },
    goToListPage () {
      this.$store.dispatch(
        'CommunicationManagementModule/goToCommMsgBtnAction',
        true
      );
      this.$router.push('Communications');
    },
    onsubmit () {
      if (this.$route.name === 'CommunicationPage') {
        let obj = {
          name: this.communicationMessageDetails.name,
          programId: this.$root.GlobalStoreEventStore.getters.getProgram.programId
        };

        this.$store
          .dispatch(
            'CommunicationManagementModule/checkCommunicationNameExistingOrNotAction',
            obj
          )
          .then(res => {
            if (res.data.data === true) {
              this.$store.commit(
                'CommunicationManagementModule/communicationMsgExistsMutation',
                true
              );
            } else if (res.data.data === false) {
              this.$store.commit(
                'CommunicationManagementModule/updateCommunicationStepperMutation',
                this.communicationMessageDetails.communicationStepper += 1
              );
            }
          })
          .catch();
      } else if (this.$route.name === 'CommunicationsManagementEdit') {
        this.$store.commit(
          'CommunicationManagementModule/updateCommunicationStepperMutation',
          this.communicationMessageDetails.communicationStepper += 1
        );
      }
    },
    goToSelectProvider () {
      let saveDeliveryChannel = {
        name: this.communicationMessageDetails.name,
        description: this.communicationMessageDetails.description,
        commMessageId: this.communicationMessageDetails.commMessageId,
        programId: this.communicationMessageDetails.programId,
        status: this.communicationMessageDetails.status,
        commChannelId: this.communicationMessageDetails.deliveryChannelData[0]
          .channelList[0].Id,
        templateId: this.communicationMessageDetails.templateId,
        messagePersonalizations: this.communicationMessageDetails
          .messagePersonalizations
      };
      this.$store
        .dispatch(
          'CommunicationManagementModule/saveDeliveryChannelDraftAction',
          saveDeliveryChannel
        )
        .then(res => {
          if (res.status === 201 || res.status === 200) {
            this.$store.commit(
              'CommunicationManagementModule/updateCommunicationMessageDetailsObjectMutation',
              res.data.data
            );
            this.$store.commit(
              'CommunicationManagementModule/updateCommunicationStepperMutation',
              this.communicationMessageDetails.communicationStepper += 1
            );
          }
        });
    },
    goToSelectPersonalization () {
      let saveProviderChannel = {
        name: this.communicationMessageDetails.name,
        description: this.communicationMessageDetails.description,
        commMessageId: this.communicationMessageDetails.commMessageId,
        programId: this.communicationMessageDetails.programId,
        status: this.communicationMessageDetails.status,
        commChannelId: this.communicationMessageDetails.deliveryChannelData[0]
          .channelList[0].Id,
        templateId: this.communicationMessageDetails.templateId,
        messagePersonalizations: this.communicationMessageDetails
          .messagePersonalizations
      };
      this.$store
        .dispatch(
          'CommunicationManagementModule/saveDeliveryChannelDraftAction',
          saveProviderChannel
        )
        .then(res => {
          if (res.status === 201 || res.status === 200) {
            this.$store.commit(
              'CommunicationManagementModule/updateCommunicationMessageDetailsObjectMutation',
              res.data.data
            );
            // this.$store.commit(
            //   'CommunicationManagementModule/updatemessagePersonalizationsMutation',
            //   res.data.data.messagePersonalizations
            // );
            this.$store.commit(
              'CommunicationManagementModule/updateCommunicationStepperMutation',
              this.communicationMessageDetails.communicationStepper += 1
            );
          }
        });
    },
    goToReviewPage () {
      // this.$store.commit(
      //   'CommunicationManagementModule/updatemessagePersonalizationsMutation',
      //   []
      // );
      let personalizationArr = [];
      for (
        let i = 0;
        i <
        this.communicationMessageDetails.communicationsProviderMessageFields
          .length;
        i++
      ) {
        let obj = {};
        obj.personalizationElement = this.communicationMessageDetails.communicationsProviderMessageFields[
          i
        ].personalizationElement;
        obj.personalizationAttributeId = this.communicationMessageDetails.communicationsProviderMessageFields[
          i
        ].selectedAttribute;
        obj.selectedAttribute = this.communicationMessageDetails.communicationsProviderMessageFields[
          i
        ].selectedAttribute;
        obj.messagePersonalizationId = this.communicationMessageDetails.communicationsProviderMessageFields[
          i
        ].messagePersonalizationId;
        personalizationArr.push(obj);
      }
      let savePersonalizationChannel = {
        name: this.communicationMessageDetails.name,
        description: this.communicationMessageDetails.description,
        commMessageId: this.communicationMessageDetails.commMessageId,
        programId: this.communicationMessageDetails.programId,
        status: this.communicationMessageDetails.status,
        commChannelId: this.communicationMessageDetails.deliveryChannelData[0]
          .channelList[0].Id,
        templateId: this.communicationMessageDetails.templateId,
        messagePersonalizations: personalizationArr
      };
      this.$store
        .dispatch(
          'CommunicationManagementModule/saveDeliveryChannelDraftAction',
          savePersonalizationChannel
        )
        .then(res => {
          if (res.status === 201 || res.status === 200) {
            this.$store.commit(
              'CommunicationManagementModule/updateReviewCommunicationMessageDetailsObjectMutation',
              res.data.data
            );
            // this.$store.commit(
            //   'CommunicationManagementModule/updateCommunicationsProviderMessageFieldsMutation',
            //   res.data.data.messagePersonalizations
            // );
            this.$store.commit(
              'CommunicationManagementModule/updateCommunicationStepperMutation',
              this.communicationMessageDetails.communicationStepper += 1
            );
          }
        });
    },
    publishMessage () {
      this.$store.commit(
        'CommunicationManagementModule/updateStatusMutation',
        1
      );
      let savePersonalizationChannel = {
        name: this.communicationMessageDetails.name,
        description: this.communicationMessageDetails.description,
        commMessageId: this.communicationMessageDetails.commMessageId,
        programId: this.communicationMessageDetails.programId,
        status: this.communicationMessageDetails.status,
        commChannelId: this.communicationMessageDetails.deliveryChannelData[0]
          .channelList[0].Id,
        templateId: this.communicationMessageDetails.templateId,
        messagePersonalizations: this.communicationMessageDetails
          .messagePersonalizations
      };
      this.$store
        .dispatch(
          'CommunicationManagementModule/saveDeliveryChannelDraftAction',
          savePersonalizationChannel
        )
        .then(res => {
          if (res.status === 201 || res.status === 200) {
            this.$store.commit(
              'CommunicationManagementModule/updateCommunicationMessageDetailsObjectMutation',
              res.data.data
            );
            this.$store.commit(
              'CommunicationManagementModule/updateCommunicationStepperMutation',
              this.communicationMessageDetails.communicationStepper += 1
            );
          }
        });
    },
    goToPrevious () {
      this.$store.commit(
        'CommunicationManagementModule/updateCommunicationStepperMutation',
        this.communicationMessageDetails.communicationStepper -= 1
      );
      this.$store.dispatch(
        'CommunicationManagementModule/goToCommMsgBtnAction',
        true
      );
    },
    gotoInitialPage () {
      this.$router.push('/loyaltyadmin/communications');
    }
  }
};
</script>
