<template>
  <communication-layout />
</template>
<script>
import CommunicationLayout from './communicationLayout.vue';
export default {
  components: {
    CommunicationLayout
  },
  created () {
    if (this.$route.name === 'CommunicationsManagementEdit') {
      this.$store.dispatch(
        'CommunicationManagementModule/editCommunicationManagementAction',
        this.$route.query.res
      );
    }
  }
};
</script>
