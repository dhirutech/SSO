<template>
  <v-row no-gutters class="d-flex">
    <v-col>
      <brierley-form-title
        :formTitle="$t('reviewFormTitle')"
        :currentStep="5"
        :totalStep="5"
        :infoText="$t('reviewInfoText')"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <v-col class="gen2-forms form-light-bg" xs="12" sm="12" md="12">
      <v-row justify="space-between">
        <v-col class="bmt3" xs="11" sm="11" md="11">
          <h3 class="fbold bml1">{{ $t("reviewBasicTitle") }}</h3>
        </v-col>
        <v-col class="hoverEdit bmt3">
          <span
            class="primary-text fbold text-right text-uppercase"
            data-qe-id="communicationManagement_editinfo"
            @click="editBasicInfo()"
          >
            <v-icon class="bpr1" color="#000">create</v-icon
            >{{ $t("editIconBtn") }}
          </span>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-col class="bml1 mt-2 pl-0">
        <p>
          <strong>{{ $t("reviewCommName") }}:</strong>
          <span class="pl-1" data-qe-id="commmsgdetails_name">{{
            communicationMessageDetails.name
          }}</span>
        </p>
        <p class="textWrap">
          <strong>{{ $t("reviewCommDes") }}:</strong>
          <span data-qe-id="commmsgdetails_des">{{
            communicationMessageDetails.description
          }}</span>
        </p>
      </v-col>
      <v-row>
        <v-col class="bmt2" xs="11" sm="11" md="11">
          <h3 class="fbold bml1">{{ $t("reviewDeliveryTitle") }}</h3>
        </v-col>
        <v-col class="hoverEdit bmt2">
          <span
            class="primary-text fbold text-right text-uppercase"
            data-qe-id="commmsgdetails_editdelivery"
            @click="editDeliveryChannel()"
          >
            <v-icon class="bpr1" color="#000">create</v-icon
            >{{ $t("editIconBtn") }}
          </span>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-col class="bml1 mt-2 pl-0">
        <p>
          <strong>{{ $t("reviewDeliveryName") }}:</strong>
          <span class="pl-1" data-qe-id="commmsgdetails_deliveryname">{{
            communicationMessageDetails.deliveryChannelData[0].channelList[0]
              .name
          }}</span>
        </p>
      </v-col>
      <v-row>
        <v-col class="bmt2" xs="11" sm="11" md="11">
          <h3 class="fbold bml1">{{ $t("reviewEmailTitle") }}</h3>
        </v-col>
        <v-col class="hoverEdit bmt2">
          <span
            class="primary-text fbold text-right text-uppercase"
            data-qe-id="commmsgdetails_editemailtemplate"
            @click="editEmailTemplate()"
          >
            <v-icon class="bpr1" color="#000">create</v-icon
            >{{ $t("editIconBtn") }}
          </span>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-col class="bml1 mt-2 pl-0">
        <p>
          <strong>{{ $t("reviewSelectedEmail") }}:</strong>
          <span class="pl-1" data-qe-id="commmsgdetails_selectedmsg">{{
            communicationMessageDetails.selectedMsgTemplate.messageName
          }}</span>
        </p>
      </v-col>
      <v-row>
        <v-col class="bmt2" xs="11" sm="11" md="11">
          <h3 class="fbold bml1">{{ $t("reviewMsgTitle") }}</h3>
        </v-col>
        <v-col class="hoverEdit bmt2">
          <span
            class="primary-text fbold text-right text-uppercase"
            data-qe-id="commmsgdetails_editpersonalization"
            @click="editMsgPersonalization()"
          >
            <v-icon class="bpr1" color="#000">create</v-icon
            >{{ $t("editIconBtn") }}
          </span>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-col class="bml1 mt-2 pl-0">
        <p>
          <strong>{{ $t("reviewFromEmail") }}:</strong>
          <span class="pl-1" data-qe-id="commmsgdetails_email">{{
            communicationMessageDetails.messageDetails.email
          }}</span>
        </p>
        <p>
          <strong>{{ $t("reviewSub") }}:</strong>
          <span class="pl-1" data-qe-id="commmsgdetails_subject">{{
            communicationMessageDetails.selectedMsgTemplate.subjectLine
          }}</span>
        </p>
      </v-col>
    </v-col>
    <v-col>
      <v-row>
        <v-col class="bmt2" xs="11" sm="11" md="11">
          <h3 class="fbold bml1">{{ $t("personalizationMappingTitle") }}</h3>
        </v-col>
        <v-col class="hoverEdit bmt2">
          <span
            class="primary-text fbold text-right text-uppercase"
            data-qe-id="commmsgdetails_msgpersonalization"
            @click="editMsgPersonalization()"
          >
            <v-icon class="bpr1" color="#000">create</v-icon
            >{{ $t("editIconBtn") }}
          </span>
        </v-col>
      </v-row>
      <v-row>
        <v-col xs="12" sm="12" md="12">
          <v-divider class="divider" xs="12" sm="12" md="12"></v-divider>
        </v-col>
      </v-row>
      <v-col class="bml1 mt-2 pl-0">
        <p
          v-for="(item,
          i) in communicationMessageDetails.messagePersonalizations"
          :key="i"
        >
          <strong data-qe-id="commmsgdetails_personalization"
            >user.{{ item.personalizationElement }} =</strong
          >
          <span class="pl-1">{{ getAttributeName(item) }}</span>
        </p>
      </v-col>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyFormTitle } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { communicationManagementReviewLayout } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyFormTitle
  },
  computed: {
    ...mapState('CommunicationManagementModule', {
      communicationMessageDetails: state => {
        return state.communicationMessageDetails;
      }
    })
  },
  i18n: communicationManagementReviewLayout,
  methods: {
    getAttributeName (item) {
      let obj = this.communicationMessageDetails.messageAttributes.filter(
        x => x.personalizationAttributeId === item.personalizationAttributeId
      );
      return obj[0].displayName;
    },
    editBasicInfo () {
      this.$store.commit(
        'CommunicationManagementModule/updateCommunicationStepperMutation',
        1
      );
    },
    editDeliveryChannel () {
      this.$store.commit(
        'CommunicationManagementModule/updateCommunicationStepperMutation',
        2
      );
    },
    editEmailTemplate () {
      this.$store.commit(
        'CommunicationManagementModule/updateCommunicationStepperMutation',
        3
      );
    },
    editMsgPersonalization () {
      this.$store.commit(
        'CommunicationManagementModule/updateCommunicationStepperMutation',
        4
      );
    }
  }
};
</script>
<style scoped>
.hoverEdit {
  cursor: pointer !important;
}
</style>
