<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <brierley-form-title
        :formTitle="$t('basicFormTitle')"
        :currentStep="1"
        :totalStep="5"
        :infoText="$t('basicInfoText')"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <v-col>
      <v-row no-gutters class="bmt5">
        <v-col sm="7" class="gen2-forms form-light-bg">
          <v-row class="flex-column " no-gutters>
            <v-col class="label-text">{{ $t("basicHeaderText") }}</v-col>
            <v-col sm="7">
              <validation-provider
                id="user_v_email"
                rules="required"
                v-slot="{ errors }"
              >
                <v-text-field
                  autocomplete="off"
                  data-qe-id="communicationManagement_name"
                  class="isrequired"
                  :label="$t('communicationName')"
                  v-model="communicationMessageDetails.name"
                  @focusout="checkName()"
                  @input="nameField()"
                   @blur="
                    communicationMessageDetails.name = removeSpaces(
                      communicationMessageDetails.name
                    )"
                  filled
                  :disabled="disableNameDesc()"
                ></v-text-field>
                <v-layout
                  class="custom-error-msg"
                  v-if="communicationMessageDetails.communicationMsgExists"
                  >{{ $t("nameError") }}
                </v-layout>
                <p
                  class="custom-error-msg"
                  v-if="
                    errors[0] != undefined &&
                      errors[0].length > 0 &&
                      errors[0] == 'This field is required'
                  "
                >
                  {{ $t("commNameRequired") }}
                </p>
              </validation-provider>
            </v-col>
            <v-col sm="9">
              <v-textarea
                :label="$t('communicationDes')"
                data-qe-id="communicationManagement_description"
                v-model="communicationMessageDetails.description"
                auto-grow
                filled
              ></v-textarea>
            </v-col>
          </v-row>
        </v-col>
        <v-col sm="5">
          <brierley-info-side>
            <template v-slot:info-side-header>
              <div class="info_title">
                <v-icon>info</v-icon>{{ $t("info") }}
              </div>
            </template>
            <template v-slot:info-side-body>
              <div>
                {{ $t("basicInfoBodyText") }}
              </div>
            </template>
          </brierley-info-side>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import {
  BrierleyInfoSide,
  BrierleyFormTitle
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { communicationManagementBasicInfo } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyInfoSide,
    BrierleyFormTitle
  },
  computed: {
    ...mapState('CommunicationManagementModule', {
      communicationMessageDetails: state => {
        return state.communicationMessageDetails;
      }
    })
  },
  methods: {
    removeSpaces (string) {
      return string.trim();
    },
    checkName () {
      let obj = {
        name: this.communicationMessageDetails.name,
        programId: this.$root.GlobalStoreEventStore.getters.getProgram.programId
      };

      this.$store
        .dispatch(
          'CommunicationManagementModule/checkCommunicationNameExistingOrNotAction',
          obj
        )
        .then(res => {
          if (res.data.data === true) {
            this.$store.commit(
              'CommunicationManagementModule/communicationMsgExistsMutation',
              true
            );
          }
        })
        .catch();
    },
    disableNameDesc () {
      if (
        this.$route.path.includes('/loyaltyadmin/CommunicationsManagementEdit')
      ) {
        return true;
      } else {
        return false;
      }
    },
    nameField () {
      this.$store.commit(
        'CommunicationManagementModule/communicationMsgExistsMutation',
        false
      );
    }
  },
  i18n: communicationManagementBasicInfo
};
</script>
