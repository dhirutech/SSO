<template>
  <v-row no-gutters>
    <v-col>
      <brierley-dialogbox
        :dialog="true"
        @closeMe="closePopup()"
        id="org_btn_dialog_deleteClose"
      >
        <template v-slot:dialog-header>
          <v-card-title class="gen2-dialog-title text-uppercase">
            {{ $t("cardTitle") }}</v-card-title
          >
        </template>
        <template v-slot:dialog-body-description>
          <v-col>
            <v-row no-gutters>
              <v-col md="12">
                <brierley-alert
                  alertType="error"
                  :alertBody="$t('basicInfoAlertMsg')"
                ></brierley-alert>
              </v-col>
            </v-row>
          </v-col>
        </template>
        <template v-slot:dialog-footer>
          <v-btn
            id="org_btn_cancelDeleteDialog"
            data-qe-id="communicationManagement_no_btn"
            text
            class="cancel no-ripple"
            @click="closeDeleteEntityPopupWhenClickNo()"
            >{{ $t("noBtnTextPopUp") }}</v-btn
          >
          <v-btn
            id="org_btn_deleteDeleteDialog"
            class="primaryctabtn text-uppercase"
            data-qe-id="communicationManagement_yes_btn"
            title
            @click="navigateToList()"
            >{{ $t("yesBtnTextPopUp") }}</v-btn
          >
        </template>
      </brierley-dialogbox>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyDialogbox, brierleyAlert } from '@brierley/SharedComponents';
import { communicationManagementCancelPopup } from '../../../../i18n/language.js';
export default {
  data () {
    return {
      dialog: false
    };
  },
  components: {
    BrierleyDialogbox,
    brierleyAlert
  },
  i18n: communicationManagementCancelPopup,
  methods: {
    closePopup () {
      this.$store.commit(
        'CommunicationManagementModule/openCancelPopupMutation',
        false
      );
    },
    navigateToList () {
      this.$router.push('/loyaltyadmin/communications');
    },
    closeDeleteEntityPopupWhenClickNo () {
      this.closePopup();
    }
  }
};
</script>
