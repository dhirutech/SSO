<template>
  <brierley-inner-view>
    <template v-slot:header>
      <span class="inner-head">COMMUNICATION MESSAGE PREVIEW</span>
    </template>
    <template v-slot:headerclose>
      <v-btn
        class="no-ripple"
        href
        target="_blank"
        text
        data-qe-id="commmsgdetails_routerpushbtn"
        @click.native="$router.push('/loyaltyadmin/communications')"
      >
        <v-icon>mdi-close</v-icon>CLOSE
      </v-btn>
    </template>
    <template v-slot:body-container>
      <v-row class="flex-column bmt5" no-gutters>
        <v-col>
          <brierley-form-title
            :formTitle="$t('personalizationFormTitle')"
            infoText="info texts"
          ></brierley-form-title>
        </v-col>
        <Validation-Observer v-slot="{ handleSubmit }">
          <form
            id="connect_popup"
            @submit.prevent="handleSubmit(onSubmitPopup)"
          >
            <brierley-dialogbox
              :dialog="messageDialog"
              @closeMe="closePopUp()"
              :persistent="false"
              max-width="1065"
              class="customfullheightdialog"
            >
              <template v-slot:dialog-header v-if="templateError">
                <v-card-title class="gen2-dialog-title text-uppercase">{{
                  $t("templateHeader")
                }}</v-card-title>
              </template>
              <template v-slot:dialog-header v-else>
                <v-card-title class="gen2-dialog-title text-uppercase">
                  {{ $t("testMessageText") }}</v-card-title
                >
              </template>
              <template v-slot:dialog-body-description>
                <v-row
                  no-gutters
                  class="bmt2"
                  v-if="testMessageStep === 1 && templateError"
                >
                  <v-col sm="10" class="gen2-forms form-light-bg">
                    <v-row class="flex-column" no-gutters>
                      <v-col class="label-text">{{ $t("subjectText") }}</v-col>
                      <v-col sm="10">
                        <v-text-field
                          autocomplete="off"
                          :label="$t('Subject')"
                          :disabled="true"
                          data-qe-id="commmsgdetails_subject"
                          v-model="
                            communicationMessageDetails.messageDetails
                              .subjectLine
                          "
                          auto-grow
                          filled
                        ></v-text-field>
                      </v-col>
                    </v-row>
                    <v-row class="flex-column" no-gutters>
                      <v-col class="label-text">{{
                        $t("testEmailText")
                      }}</v-col>
                      <v-col sm="11">
                        <v-row
                          class="flex-column block-with-chips editable-chips"
                          no-gutters
                        >
                          <v-col class="block-with-chips__label">
                            <template>
                              <span class="req-label">{{
                                $t("emailIdText")
                              }}</span>
                            </template>
                          </v-col>
                          <v-col class="block-with-chips__body">
                            <v-combobox
                              v-model="emailChips"
                              chips
                              clearable
                              :label="$t('emailIdText')"
                              data-qe-id="commmsgdetails_emailidtext"
                              multiple
                              solo
                              append-icon="false"
                              clear-icon="false"
                              class="editable-chips__field"
                            >
                              <template
                                v-slot:selection="{
                                  attrs,
                                  item,
                                  select,
                                  selected
                                }"
                              >
                                <v-chip
                                  v-bind="attrs"
                                  :input-value="selected"
                                  close
                                  :title="item"
                                  @click="select"
                                  @click:close="remove(item)"
                                >
                                  <strong>{{ item }}</strong>
                                </v-chip>
                              </template>
                            </v-combobox>
                          </v-col>
                        </v-row>
                      </v-col>
                    </v-row>
                    <v-row class="flex-column pt-4" no-gutters>
                      <v-col class="label-text">{{
                        $t("customAttributeText")
                      }}</v-col>
                      <v-col sm="11">
                        <v-row class="flex-column" no-gutters>
                          <v-col class="bmb5 bpb4 pl-2 pr-2">
                            <v-row
                              class="flex-column member-attr-table"
                              no-gutters
                            >
                              <v-col
                                class="member-attr-table__rows attributeRow pl-2 pr-2 mt-2"
                              >
                                <v-row
                                  no-gutters
                                  v-for="(item, i) in commObjectArray"
                                  :key="i"
                                >
                                  <v-col class="name" cols="4"
                                    >{{ item.personalizationElement }}
                                  </v-col>
                                  <v-col class="icon" cols="2"
                                    ><v-icon>forward</v-icon></v-col
                                  >
                                  <v-col class="field" cols="6">
                                    <v-text-field
                                      autocomplete="off"
                                      filled
                                      :label="$t('memberAttributeText')"
                                      data-qe-id="commmsgdetails_memberattributetext"
                                      :value="item.displayName"
                                      @input="changeName($event, i)"
                                    ></v-text-field>
                                  </v-col>
                                </v-row>
                              </v-col>
                            </v-row>
                          </v-col>
                        </v-row>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
                <v-row no-gutters class="bmt2" v-if="!templateError">
                  <v-col>
                    <brierley-no-result
                      :noResultMessage="noData"
                      noRecordFoundHeader=""
                      id="viewuser_img_no_data"
                    >
                      <template v-slot:custom-heading>
                        <h3 class="custom-head-noresult transform-none">
                          {{ $t("providerNotres") }} <br />
                        </h3>
                      </template>
                    </brierley-no-result>
                  </v-col>
                </v-row>
              </template>
              <template
                v-slot:dialog-body-alert
                v-if="testMessageStep === 2 && templateError"
              >
                <v-alert
                  icon="done"
                  class="success b-alert-success max-width-full"
                >
                  <h3>
                    {{ $t("successTxt") }}
                  </h3>
                  <p>{{ $t("templateSuccessTxt") }}</p>
                </v-alert>
              </template>
              <template v-slot:dialog-footer v-if="templateError">
                <v-btn
                  text
                  class="cancel no-ripple cursor-p btn-hover-none"
                  @click="closePopUp()"
                  data-qe-id="commmsgdetails_closepopup"
                  v-if="testMessageStep === 1"
                  >{{ $t("cancelBtnText") }}</v-btn
                >
                <v-btn
                  class="primaryctabtn text-uppercase cursor-p"
                  title="Default"
                  type="submit"
                  @click="sendTestTemplate()"
                  data-qe-id="commmsgdetails_sendtesttemplate"
                  :disabled="emailChips.length === 0 || disableSaveBtn"
                  v-if="testMessageStep === 1"
                  >{{ $t("sendBtnText") }}</v-btn
                >
                <v-btn
                  data-qe-id="com_BasicInfo_Audience_button_Done"
                  class="primaryctabtn"
                  v-if="testMessageStep === 2"
                  @click="closePopUp()"
                  >{{ $t("close") }}</v-btn
                >
              </template>
              <template v-slot:dialog-footer v-else>
                <v-btn
                  class="primaryctabtn text-uppercase cursor-p"
                  title="Default"
                  data-qe-id="commmsgdetails_closepopup"
                  @click="closePopUp()"
                  >{{ $t("close") }}</v-btn
                >
              </template>
            </brierley-dialogbox>
          </form>
        </Validation-Observer>
        <v-col>
          <v-row no-gutters class="bmt5">
            <v-col sm="7" class="gen2-forms form-light-bg">
              <v-row class="flex-column " no-gutters>
                <v-col class="label-text">{{
                  $t("personalizationMsgDetails")
                }}</v-col>
                <v-col sm="8">
                  <v-text-field
                    autocomplete="off"
                    :label="$t('emailLabel')"
                    data-qe-id="commmsgdetails_emailable"
                    :disabled="true"
                    v-model="communicationMessageDetails.messageDetails.email"
                    filled
                  ></v-text-field>
                </v-col>
                <v-col sm="8">
                  <v-text-field
                    autocomplete="off"
                    :label="$t('Subject')"
                    data-qe-id="commmsgdetails_subject"
                    :disabled="true"
                    v-model="
                      communicationMessageDetails.messageDetails.subjectLine
                    "
                    filled
                  ></v-text-field>
                </v-col>
              </v-row>
            </v-col>
            <v-col sm="5">
              <brierley-info-side>
                <template v-slot:info-side-header>
                  <div class="info_title">
                    <v-icon>info</v-icon>{{ $t("personalizationInfo") }}
                  </div>
                </template>
                <template v-slot:info-side-body>
                  <div>
                    {{ $t("personalizationInfoText") }}
                  </div>
                </template>
              </brierley-info-side>
            </v-col>
          </v-row>
        </v-col>
        <v-col class="bpt4">
          <v-row no-gutters class="notification-templates">
            <v-col class="label-text text-left">
              {{ $t("personalization") }}
            </v-col>
            <v-col
              class="gen2-search-card__head text-uppercase elipsis-fullwidth min-height-20 alignText"
              data-qe-id="commmsgdetails_testmesage"
              @click="testMessage()"
            >
              <v-icon color="#0628b1">fact_check</v-icon
              >{{ $t("testMessageText") }}</v-col
            >
          </v-row>
        </v-col>
        <v-col class="gray-bg bmb2 bpa5">
          <v-row class="flex-column" no-gutters>
            <v-col class="bpb5 bmb4">
              <v-row class="notification-templates bpb1">
                <v-col
                  cols="12"
                  sm="6"
                  v-for="(item,
                  i) in communicationMessageDetails.selectedMsgTemplate"
                  :key="i"
                >
                  <v-card class="gen2-search-card">
                    <v-row id="wrapper" no-gutters class="flex-column">
                      <v-col
                        id="left"
                        class="gen2-search-card__head text-uppercase elipsis-fullwidth min-height-20"
                        >{{ item.messageName }}</v-col
                      >
                      <!-- <v-col id="right" class="action-icons text-right">
                    <v-icon class="dark-selected">mdi-bookmark</v-icon
                    >
                  </v-col> -->
                      <v-col>
                        <p>
                          {{ $t("personalizationCreatedOn") }} :
                          {{ format_date(item.creationDate) }}
                        </p>
                        <p>{{ format_time(item.creationDate) }}</p>
                      </v-col>
                    </v-row>
                  </v-card>
                </v-col>
              </v-row>
            </v-col>
            <v-col class="bmb5 bpb4">
              <brierleyTabs class="gray-bg">
                <template v-slot:tabs-header>
                  <v-tab>{{ $t("personalizationMemberAttributes") }}</v-tab>
                </template>
                <template v-slot:tabs-body>
                  <v-tab-item>
                    <v-row class="flex-column member-attr-table" no-gutters>
                      <v-col class="member-attr-table__head">
                        <v-row no-gutters>
                          <v-col class="head"
                            >{{ $t("personProviderMsgFields") }}
                            <v-icon
                              class="info-icon"
                              :title="$t('providerMsgTitle')"
                              >info_outline</v-icon
                            ></v-col
                          >
                          <v-col class="head"
                            >{{ $t("personApplicationFields") }}
                            <v-icon
                              class="info-icon"
                              :title="$t('applicationTitle')"
                              >info_outline</v-icon
                            ></v-col
                          >
                        </v-row>
                      </v-col>
                      <v-col
                        class="member-attr-table__rows"
                        v-for="(item, i) in commObjectArray"
                        :key="i"
                      >
                        <v-row no-gutters>
                          <v-col class="name" cols="4"
                            >{{ item.personalizationElement }}
                          </v-col>
                          <v-col class="icon" cols="2"
                            ><v-icon>forward</v-icon></v-col
                          >
                          <v-select
                            :items="item.msgAttributes"
                            item-text="displayName"
                            item-value="personalizationAttributeId"
                            filled
                            attach
                            data-qe-id="commmsgdetails_msgattributes"
                            :disabled="true"
                            v-model="item.selectedAttribute"
                            offset-y
                            class="gen2select gen2select__dark mini-list"
                            label="Member Attribute"
                            append-icon="expand_more"
                          ></v-select>
                        </v-row>
                      </v-col>
                    </v-row>
                  </v-tab-item>
                </template>
              </brierleyTabs>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </template>
    <template v-slot:footer>
      <v-btn
        id="user_btn_goToUsers"
        class="primaryctabtn bmt2"
        data-qe-id="commmsgdetails_gotoinitialpage"
        @click="gotoInitialPage()"
        >{{ $t("closeBtn") }}</v-btn
      >
    </template>
  </brierley-inner-view>
</template>
<script>
import {
  BrierleyInfoSide,
  BrierleyFormTitle,
  BrierleyInnerView,
  BrierleyTabs,
  BrierleyDialogbox,
  BrierleyNoResult
} from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import moment from 'moment';
import { communicationPersonalizationLayoutObj } from '../../../i18n/language.js';
export default {
  components: {
    BrierleyInfoSide,
    BrierleyFormTitle,
    BrierleyTabs,
    BrierleyInnerView,
    BrierleyDialogbox,
    BrierleyNoResult
  },
  data () {
    return {
      selectedProvider: null,
      emailChips: [],
      messageDialog: false,
      attributeRes: null,
      memberAttr: [],
      response: [],
      noData: '',
      testMessageArr: [],
      disableSaveBtn: false
    };
  },
  i18n: communicationPersonalizationLayoutObj,
  methods: {
    gotoInitialPage () {
      this.$router.push('/loyaltyadmin/communications');
    },
    changeName (event, idx) {
      if (event === '') {
        this.disableSaveBtn = true;
      } else {
        this.disableSaveBtn = false;
        this.testMessageArr[idx].displayName = event;
      }
    },
    sendTestTemplate () {
      let emailParameters = {};
      for (let i = 0; i < this.testMessageArr.length; i++) {
        emailParameters[this.testMessageArr[i].name] = this.testMessageArr[
          i
        ].displayName;
      }
      let obj = {
        providerName: this.communicationMessageDetails.deliveryChannelData[0]
          .providersList[0].name,
        emailTemplateId: this.communicationMessageDetails.selectedMsgTemplate[0]
          .id,
        emailIds: [...this.emailChips],
        emailParameters: emailParameters
      };
      this.$store
        .dispatch('CommunicationManagementModule/testTemplateAction', obj)
        .then(res => {
          if (res.status === 201 || res.status === 200) {
            if (this.testMessageStep === 1) {
              this.$store.commit(
                'CommunicationManagementModule/testMessageStepMutation',
                this.testMessageStep + 1
              );
            }
          }
        })
        .catch(err => {
          if (err.response.status === 400 || err.response.status === 404) {
            this.$store.commit(
              'CommunicationManagementModule/templateErrorMutation',
              false
            );
          }
        });
    },
    closePopUp () {
      this.$store.commit(
        'CommunicationManagementModule/templateErrorMutation',
        true
      );
      this.messageDialog = false;
      this.emailChips = [];
      if (this.testMessageStep === 2) {
        this.$store.commit(
          'CommunicationManagementModule/testMessageStepMutation',
          this.testMessageStep - 1
        );
      }
    },
    testMessage () {
      this.testMessageArr = [];
      let display;
      for (let i = 0; i < this.commObjectArray.length; i++) {
        if (this.commObjectArray[i].selectedAttribute) {
          let id = this.communicationMessageDetails.messageAttributes.filter(
            x =>
              x.personalizationAttributeId ===
              this.commObjectArray[i].selectedAttribute
          );
          display = id[0].displayName;
        } else {
          display = '';
        }
        this.testMessageArr[i] = {
          name: this.commObjectArray[i].personalizationElement,
          displayName: display
        };
      }
      this.messageDialog = true;
    },
    format_date (value) {
      if (value) {
        return moment(String(value)).format('DD/MMM/YYYY');
      }
    },
    format_time (value) {
      if (value) {
        return moment(String(value)).format('hh:mm A');
      }
    }
  },
  computed: {
    ...mapState('CommunicationManagementModule', {
      communicationMessageDetails: state => {
        return state.communicationMessageDetails;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      testMessageStep: state => {
        return state.testMessageStep;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      templateError: state => {
        return state.templateError;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      templateIdEdit: state => {
        return state.templateIdEdit;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      providerName: state => {
        return state.providerName;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      selectedTemplatesArr: state => {
        return state.selectedTemplatesArr;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      commObjectArray: state => {
        return state.commObjectArray;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      messageData: state => {
        return state.messageData;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      getMessageAttributeRes: state => {
        return state.getMessageAttributeRes;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      templateIdEdit: state => {
        return state.templateIdEdit;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      getMessageAttributeRes: state => {
        return state.getMessageAttributeRes;
      }
    }),
    ...mapState('CommunicationManagementModule', {
      personalisation: state => {
        return state.personalisation;
      }
    })
  }
};
</script>
<style lang="scss" scoped>
.min-height-20 {
  min-height: 20px;
}
.alignText {
  text-align: end !important;
  cursor: pointer !important;
}
.attributeRow {
  background: whitesmoke;
}
.v-input.v-text-field .v-input__slot {
  background: white !important;
}
.gen2select__dark.mini-list {
  width: 304px;
  max-width: 304px !important;
}
</style>
<style lang="scss">
.block-with-chips.editable-chips {
  min-height: 150px !important;
  max-height: 150px !important;
  .block-with-chips__label {
    max-height: 25px;
  }
  .block-with-chips__body {
    overflow-x: hidden;
    .editable-chips__field {
      .v-input__control {
        min-height: 97px;
        .v-input__slot {
          margin-bottom: 0 !important;
          box-shadow: none !important;
          background: none !important;
          min-height: 100px;
          padding: 0 !important;
          .v-select__slot {
            top: -17px !important;
            position: relative;
            .v-label {
              display: none;
            }
            .v-select__selections {
              position: absolute;
              top: 0;
              margin-left: 0px;
              width: 100%;
              input {
                padding: 0 !important;
                //min-height: 114px !important;
              }
              .v-chip {
                min-width: 230px !important;
                max-width: 230px !important;
                margin-left: 0px;
                margin-right: 8px;
                &__content {
                  font-weight: 300 !important;
                  padding-top: 0 !important;
                }
              }
            }
          }
        }
        .v-text-field__details {
          display: none;
        }
      }
    }
  }
}
</style>
