<template>
  <v-row class="flex-column" no-gutters>
    <v-col>
      <brierley-form-title
        :formTitle="$t('deliveryFormTitle')"
        :currentStep="2"
        :totalStep="5"
        :infoText="$t('deliveryInfoText')"
        :showSteps="true"
      ></brierley-form-title>
    </v-col>
    <v-col class="bpt5 label-text">
      {{ $t("deliveryHeaderText") }}
    </v-col>
    <v-col class="gray-bg bpa3 bmb2">
      <v-row class="bmb5 bpb5 channel-block">
        <v-col
          sm="3"
          v-for="(item, i) in communicationMessageDetails.deliveryChannelData[0]
            .channelList"
          :key="i"
        >
          <v-row
            class="bpy4 bpx3 white-bg flex-column channel-block__eachblock"
            data-qe-id="communicationManagement_checkicon"
            no-gutters
            @click="selectDeliveryChannel(item, i)"
          >
            <v-col class="name" data-qe-id="communicationManagement_name">
              {{ item.name }}
              <v-icon
                class="float-right font24"
                v-if="item.isSelected === true"
              >
                check_circle
              </v-icon>
            </v-col>
            <v-col class="icon" data-qe-id="communicationManagement_icon">
              <v-icon>{{ item.icon }}</v-icon>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import { BrierleyFormTitle } from '@brierley/SharedComponents';
import { mapState } from 'vuex';
import { communicationManagementDeliveryChannel } from '../../../../i18n/language.js';
export default {
  components: {
    BrierleyFormTitle
  },
  i18n: communicationManagementDeliveryChannel,
  computed: {
    ...mapState('CommunicationManagementModule', {
      communicationMessageDetails: state => {
        return state.communicationMessageDetails;
      }
    })
  },
  methods: {
    selectDeliveryChannel (val) {
      if (val.name === 'EMAIL') {
        val.isSelected = true;
      } else {
        val.isSelected = false;
      }
    }
  },
  mounted () {
    if (this.$route.name !== 'CommunicationsManagementEdit') {
      let id = localStorage.getItem('programId');
      this.$store.dispatch(
        'CommunicationManagementModule/getChannelsByProgramAction',
        id
      );
    } else {
      this.$store.dispatch(
        'CommunicationManagementModule/getChannelsByProgramAction',
        this.communicationMessageDetails.programId
      );
    }
  }
};
</script>
