import Vue from 'vue';

const communicationNameExistsOrNot = payload => {
  return Vue.prototype.$http.get(
    'communication/api/v1/communicationmanagement/ismessageexist/' +
      payload.programId +
      '/' +
      payload.name
  );
};

const getChannelsByProgram = payload => {
  return Vue.prototype.$http.get(
    'communication/api/v1/providerconfiguration/channelsbyprogram/' + payload
  );
};

const getCommunicationsMessageTemplates = payload => {
  return Vue.prototype.$http.get(
    '/communication/api/v1/communicationmanagement/getmessagetemplates/' +
      payload
  );
};

const saveDeliveryChannelData = payload => {
  return Vue.prototype.$http.post(
    'communication/api/v1/communicationmanagement/savemessage',
    payload
  );
};

const getCommunicationsProviderMessageFields = payload => {
  return Vue.prototype.$http.get(
    'communication/api/v1/providerconfiguration/getattributes/' +
      payload.provider +
      '/' +
      payload.id
  );
};

const testTemplateData = payload => {
  return Vue.prototype.$http.post(
    'communication/api/v1/communicationmanagement/sendsingleemail',
    payload
  );
};

const getMessageAttributeData = () => {
  return Vue.prototype.$http.get(
    'communication/api/v1/communicationmanagement/getmessageattribute'
  );
};

const getEmailSubjectData = payload => {
  return Vue.prototype.$http.get(
    'communication/api/v1/communicationmanagement/getmessageheader/' + payload
  );
};

const getCommunicationsIdResponse = payload => {
  return Vue.prototype.$http.get(
    '/communication/api/v1/communicationmanagement/getmessage/' + payload
  );
};

const commMsgBookmark = payload => {
  return Vue.prototype.$http.post('communication/api/v1/bookmark', payload);
};

const getCommMsgSearch = payload => {
  return Vue.prototype.$http.get(
    'communication/api/v1/communicationmanagement/getall?ProgramId=' +
      payload.ProgramId +
      '&PageSize=' +
      payload.pageSize +
      '&PageNumber=' +
      payload.pageNumber +
      '&SearchText=' +
      payload.searchText +
      payload.filterStartRange +
      payload.filterEndRange +
      payload.status +
      payload.draftStatus +
      payload.IsBookmarks
  );
};

const getAllProgramStatusForCommunicationManagement = () => {
  return Vue.prototype.$http.get('loyaltyconfiguration/api/v1/programs');
};

const getUserApi = userId => {
  return Vue.prototype.$http.get('identity/api/v1/users/' + userId);
};
const deleteCommMessage = payload => {
  return Vue.prototype.$http.delete(
    'communication/api/v1/communicationmanagement/deletemessage/' + payload
  );
};
export {
  deleteCommMessage,
  communicationNameExistsOrNot,
  getCommMsgSearch,
  getAllProgramStatusForCommunicationManagement,
  getUserApi,
  getChannelsByProgram,
  getCommunicationsMessageTemplates,
  saveDeliveryChannelData,
  commMsgBookmark,
  getCommunicationsProviderMessageFields,
  getMessageAttributeData,
  getEmailSubjectData,
  getCommunicationsIdResponse,
  testTemplateData
};
