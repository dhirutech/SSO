import CommunicationPage from './components/communicationPage.vue';
import communicationDashboard from './components/communicationDashboard';
import CommunicationsManagementPreview from './components/CommunicationPersonalizationPreview.vue';

const CommunicationManagementRoutesNew = [
  {
    path: '/loyaltyadmin/CommunicationsManagement',
    name: 'CommunicationPage',
    component: CommunicationPage,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/CommunicationsManagementEdit',
    name: 'CommunicationsManagementEdit',
    component: CommunicationPage,
    meta: {
      showNavigation: false
    }
  },
  {
    path: '/loyaltyadmin/communications',
    name: 'communicationDashboard',
    component: communicationDashboard,
    meta: {
      showNavigation: true
    }
  },
  {
    path: '/loyaltyadmin/CommunicationsManagementPreview',
    name: 'CommunicationsManagementPreview',
    component: CommunicationsManagementPreview,
    meta: {
      showNavigation: false
    }
  }
];

export default CommunicationManagementRoutesNew;
