const setDashboard = (state, payload) => {
  state.dashboard = payload;
};

const setModuleVar = (state, payload) => {
  state.moduleVar = payload;
};

export default {
  setDashboard,
  setModuleVar,
};
