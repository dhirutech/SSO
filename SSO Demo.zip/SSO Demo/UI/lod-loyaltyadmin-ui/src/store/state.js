export default {
  moduleVar: 'I am Module',
  dashboard: {}
};
