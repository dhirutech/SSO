import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

import state from './state.js';
import getters from './getters.js';
import mutations from './mutations.js';
import actions from './actions.js';

// import Module Store here
import userModule from '../feature-modules/user/store/index';
import orgModule from '../feature-modules/loyalty-admin/organization/store/index.js';
import userviewModule from '../feature-modules/Viewusers/store/index';
import companyModule from '../feature-modules/company-information/store/index';
import signUpModule from '../feature-modules/signup-completion/store/index';
import roleModule from '../feature-modules/role/store/index.js';
import productdefinitionModule from '../feature-modules/product-definition/store/index';
import storeDefinitionModule from '../feature-modules/store-definition/store/index';
import memberDefinitionModule from '../feature-modules/member-definition/store/index';
import communicationModule from '../feature-modules/communication/store/index';
// import communicationManagementModule from '../feature-modules/communication-management/store/index';
import CommunicationManagementModule from '../feature-modules/communicationManagement/store/index';
import productModule from '../feature-modules/products/store/index';
import storeModule from '../feature-modules/stores/store/index';
import batchImportModule from '../feature-modules/batchImports/store/index';
import transactionDefinitionModule from '../feature-modules/transaction-definition/store/index';
import storeGroupModule from '../feature-modules/store-groups/store/index';
import productGroupModule from '../feature-modules/product-groups/store/index';

export default new Vuex.Store({
  namespaced: true,
  state,
  getters,
  mutations,
  actions,
  modules: {
    userModule,
    userviewModule,
    companyModule,
    orgModule,
    signUpModule,
    roleModule,
    productdefinitionModule,
    storeDefinitionModule,
    memberDefinitionModule,
    communicationModule,
    // communicationManagementModule,
    CommunicationManagementModule,
    productModule,
    storeModule,
    batchImportModule,
    transactionDefinitionModule,
    storeGroupModule,
    productGroupModule
  }
});
