const getData = async () => [{}];

export default {
  getData
};
