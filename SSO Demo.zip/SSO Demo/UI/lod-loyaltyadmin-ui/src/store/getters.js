const getModuleVar = (state) => state.moduleVar;

export default {
  getModuleVar,
};
