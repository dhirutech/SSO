import Vue from 'vue';
import VueRouter from 'vue-router';

// import module level route
import viewuserRoutes from '../feature-modules/Viewusers/user-route';
import userRoutes from '../feature-modules/user/user-route';
import productsRoutes from '../feature-modules/products/products-route';
import storesRoutes from '../feature-modules/stores/stores-route';
import productdefinitionRoutes from '../feature-modules/product-definition/productdefinition-route';
import organizationRoutes from '../feature-modules/loyalty-admin/organization/organization-route.js';
import companyInfoRoutes from '../feature-modules/company-information/company-information';
import roleRoutes from '../feature-modules/role/role-route';
import signupuserroutes from '../feature-modules/signup-completion/signup-route';
import storeDefinitionRoutes from '../feature-modules/store-definition/store-definition-route';
import memberDefinitionRoutes from '../feature-modules/member-definition/member-definition-route';
import communicationRoutes from '../feature-modules/communication/communication-route';
// import communicationManagementRoutes from '../feature-modules/communication-management/communication-management-route';
import transactionDefinitionRoutes from '../feature-modules/transaction-definition/transaction-definition-route';
import configurableExtensionRoutes from '../feature-modules/configurableExtensionDefinition/configurable-extension-route';
import CommunicationManagementRoutesNew from '../feature-modules/communicationManagement/communicationManagementRoute';
import batchImportRoutes from '../feature-modules/batchImports/batchImport-route';
import storeGroupRoutes from '../feature-modules/store-groups/storeGroupRoute';
import productGroupRoutes from '../feature-modules/product-groups/productGroupRoute';

Vue.use(VueRouter);

const routes = [
  ...storeGroupRoutes,
  ...organizationRoutes,
  ...viewuserRoutes,
  ...userRoutes,
  ...companyInfoRoutes,
  ...roleRoutes,
  ...signupuserroutes,
  ...productdefinitionRoutes,
  ...storeDefinitionRoutes,
  ...memberDefinitionRoutes,
  ...communicationRoutes,
  // ...communicationManagementRoutes,
  ...transactionDefinitionRoutes,
  ...configurableExtensionRoutes,
  ...productsRoutes,
  ...storesRoutes,
  ...CommunicationManagementRoutesNew,
  ...batchImportRoutes,
  ...productGroupRoutes
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
});

export default router;
