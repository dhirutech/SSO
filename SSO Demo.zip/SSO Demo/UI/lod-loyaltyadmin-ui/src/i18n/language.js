// COMMUNICATION MANAGEMENT MODULE STARTS

// COMMUNICATION DASHBOARD INFO COMPONENTS STARTS

export const communicationDashboardObj = {
  messages: {
    en: {
      headerTxt: 'Communications',
      createFirstTxt: 'Create your first',
      communicationMsgTxt: 'Communication MSG',
      noMsgTxt: 'You have no communication messages, why not create one.',
      clickHereTxt: 'Click here'
    },
    ja: {
      headerTxt: 'コミュニケーション',
      createFirstTxt: 'コミュニケーションの登録を',
      communicationMsgTxt: 'はじめましょう',
      noMsgTxt:
        'コミュニケーションメッセージが登録されていません。\n早速登録しましょう。',
      clickHereTxt: 'ここをクリック'
    }
  }
};

// COMMUNICATION DASHBOARD INFO COMPONENTS ENDS

// COMMUNICATION PROVIDER LAYOUT INFO COMPONENTS STARTS

export const communicationProviderLayoutObj = {
  messages: {
    en: {
      providerInfo:
        'You can preview these templates by selecting Card View in VIEW OPTIONS if your provider supports this feature',
      providerSelectMsg: 'SELECT MESSAGES FROM BELOW',
      providerCreatedOn: 'Created on',
      provider: 'Provider :',
      gridViewText: 'grid view',
      cardViewText: 'card view',
      providerSupportText: 'Provider does not support message preview',
      previewEmailText: 'preview email templates.'
    },
    ja: {
      providerInfo:
        'プロバイダーがプレビュー機能をサポートしている場合のみ、「ビューオプション」の「カードビュー」選択時に、プレビューが表示されます。',
      providerSelectMsg: 'メッセージテンプレートを選択してください',
      providerCreatedOn: '作成日時',
      provider: 'プロバイダー',
      gridViewText: 'グリッドビュー',
      cardViewText: 'カードビュー',
      providerSupportText: 'プレビュー機能がサポートされていません',
      previewEmailText: 'メールテンプレートのプレビューを表示します'
    }
  }
};

// COMMUNICATION PROVIDER LAYOUT INFO COMPONENTS ENDS

// COMMUNICATION PERSONALIZATION  INFO COMPONENTS STARTS

export const communicationPersonalizationLayoutObj = {
  messages: {
    en: {
      personalizationFormTitle: 'msg/personalization',
      personalizationMsgDetails: 'Message Details',
      personalizationInfo: 'Info',
      personalizationInfoText:
        'You can map all the dynamic elements of your message, such as the member’s name, to corresponding fields in the application. The values for these fields will get populated in the message when it’s triggered.',
      personalization: 'Personalization',
      personalizationCreatedOn: 'Created on',
      personalizationMemberAttributes: 'Member attributes',
      personProviderMsgFields: 'Provider Message Fields',
      personApplicationFields: 'Application Fields',
      emailLabel: 'From Email',
      Subject: 'Subject',
      providerMsgTitle:
        'This column represents Personalization variables configured in the provider message.',
      applicationTitle:
        'This column represents fields from this Application’s data model.',
      memberAtt: 'Member Attribute',
      templateHeader: 'TEST TEMPLATE',
      subjectText: 'SUBJECT',
      testEmailText: 'ENTER TEST EMAIL IDs',
      emailIdText: 'Email Ids',
      customAttributeText: 'CUSTOM VALUE ATTRIBUTES',
      memberAttributeText: 'Member Attribute',
      cancelBtnText: 'Cancel',
      sendBtnText: 'SEND',
      testMessageText: 'TEST MESSAGE',
      providerNotres:
        'There was a problem sending your message. Please check if your email address is valid or if the provider’s server is available..',
      providerPreviewNotres: 'There was a problem sending your message.',
      plsTryPreviewLaterText:
        'Please check if your email address is valid or if the provider’s server is available.',
      plsTryLaterText: 'please try again later.',
      successTxt: 'SUCCESS',
      templateSuccessTxt: 'The selected template has been successfully sent.',
      close: 'CLOSE',
      closeBtn: 'CLOSE'
    },
    ja: {
      providerPreviewNotres: 'メッセージの送信に失敗しました。',
      plsTryPreviewLaterText:
        '入力されたメールアドレスが有効か、またはプロバイダーが利用可能状態か確認してください。',
      personalizationFormTitle: 'パーソナライズ設定',
      personalizationMsgDetails: 'メッセージ詳細',
      personalizationInfo: 'インフォメーション',
      personalizationInfoText:
        'メッセージ内の動的フィールドに、LODで保持する情報をマッピングすることができます（会員の氏名など）。これらのフィールドの値は、メッセージ送信イベントがトリガーされる際に設定されます。',
      personalization: 'パーソナライズ',
      personalizationCreatedOn: '作成日時',
      personalizationMemberAttributes: '会員属性',
      personProviderMsgFields: 'プロバイダーメッセージフィールド',
      personApplicationFields: 'LODデータ',
      emailLabel: '送信元メールアドレス',
      Subject: '件名',
      providerMsgTitle:
        'プロバイダー側でメッセージ内に設定された動的フィールドを表示しています。',
      applicationTitle: 'LODデータモデルの属性と項目名を表示しています。',
      memberAtt: '会員属性',
      templateHeader: 'テストメール送信',
      subjectText: '件名',
      testEmailText: 'テストメールIDを入力してください',
      emailIdText: 'メールID',
      customAttributeText: 'フィールド値設定',
      memberAttributeText: 'テスト用設定値',
      cancelBtnText: 'キャンセル',
      sendBtnText: '送信する',
      testMessageText: 'テストメッセージ送信',
      providerNotres: 'プロバイダーサーバーが応答していません。',
      plsTryLaterText: 'しばらくしてからもう一度お試しください。',
      successTxt: '送信完了',
      templateSuccessTxt: 'テストメールが正常に送信されました。',
      close: '閉じる',
      closeBtn: '閉じる'
    }
  }
};

// COMMUNICATION PERSONALIZATION  INFO COMPONENTS ENDS

// COMMUNICATION BASIC INFO COMPONENTS STARTS
export const communicationManagementBasicInfo = {
  messages: {
    en: {
      basicFormTitle: 'Basic INFORMATION',
      basicInfoText:
        'Please choose a name for your message that clearly identifies the purpose of the communication.',
      basicHeaderText: 'Communication Details',
      basicInfoBodyText:
        'A Communication message needs to be created for every communication that will be sent to the member.',
      info: 'Info',
      commNameRequired: 'Communication Name is Required.',
      communicationName: 'Communication Name',
      communicationDes: 'Communication Description',
      nameError: 'This name already exists. Please use a different name'
    },
    ja: {
      basicFormTitle: '基本情報',
      basicInfoText:
        'コミュニケーションの目的が明確になるよう、メッセージ名を設定してください。',
      basicHeaderText: 'コミュニケーション詳細',
      basicInfoBodyText:
        '会員通知機能を利用するには、通知する内容をコミュニケーションメッセージとして登録する必要があります。',
      info: 'インフォメーション',
      commNameRequired: '「メッセージ名」は必須項目です。',
      communicationName: 'メッセージ名',
      communicationDes: 'メッセージ概要',
      nameError: '設定された名称はすでに存在します。別の名前を設定してください。'
    }
  }
};

// COMMUNICATION BASIC INFO COMPONENTS ENDS

// COMMUNICATION REVIEW INFO COMPONENTS STARTS

export const communicationManagementReviewLayout = {
  messages: {
    en: {
      reviewFormTitle: 'REVIEW',
      reviewInfoText:
        'You can review all your inputs and make changes if necessary by clicking on the relevant Edit link',
      reviewBasicTitle: 'BASIC INFORMATION',
      editIconBtn: 'EDIT',
      reviewCommName: 'Communication Name',
      reviewCommDes: 'Communication Description',
      reviewDeliveryTitle: 'DELIVERY CHANNEL',
      reviewDeliveryName: 'Selected Delivery Channel',
      reviewEmailTitle: 'EMAIL TEMPLATE',
      reviewSelectedEmail: 'Selected Email Template',
      reviewMsgTitle: 'MSG/PERSONALIZATION',
      reviewFromEmail: 'From Email',
      reviewSub: 'Subject',
      personalizationMappingTitle: 'PERSONALIZATION MAPPING'
    },
    ja: {
      reviewFormTitle: '登録内容確認',
      reviewInfoText:
        '「編集」をクリックすると、各ステップの情報を再度編集することができます。',
      reviewBasicTitle: '基本情報',
      editIconBtn: '編集',
      reviewCommName: 'メッセージ名',
      reviewCommDes: 'メッセージ概要',
      reviewDeliveryTitle: 'チャネル',
      reviewDeliveryName: 'チャネル',
      reviewEmailTitle: 'メールテンプレート',
      reviewSelectedEmail: 'メールテンプレート',
      reviewMsgTitle: 'パーソナライズ',
      reviewFromEmail: '送信元メールアドレス',
      reviewSub: '件名',
      personalizationMappingTitle: 'パーソナライズ フィールドマッピング'
    }
  }
};

// COMMUNICATION REVIEW INFO COMPONENTS ENDS

// COMMUNICATION STEPPER INFO COMPONENTS STARTS
export const communicationManagementStepper = {
  messages: {
    en: {
      communicationMessage: 'NEW COMMUNICATION MESSAGE',
      communicationEditMessage: 'EDIT COMMUNICATION MESSAGE',
      close: 'CLOSE',
      basicInfoStepper: 'BASIC INFORMATION',
      deliveryChannelStepper: 'DELIVERY CHANNEL',
      msgPersonalizationStepper: 'MSG/PERSONALIZATION',
      selectMsgStepper: 'SELECT MSG',
      reviewStepper: 'REVIEW',
      personalizationStepper: 'PERSONALIZATION',
      previousBtnText: 'Previous',
      cancelBtnText: 'Cancel',
      nextDeliveryChannelBtnText: 'NEXT: DELIVERY CHANNEL',
      nextSelectTemplateBtnText: 'NEXT: SELECT PROVIDER MESSAGE',
      publishBtn: 'PUBLISH',
      goToCommBtn: 'GO TO COMMUNICATION MESSAGES',
      successFormTitle: 'SUCCESS',
      successInfoText:
        'Once a communication message is published, it becomes visible in other parts of the application.',
      alertBodyText: 'Your communication message has been published.',
      alertBodyEditText: 'Your Communication message has been saved.',
      successAlertHeader: 'Success',
      previousBtn: 'Previous',
      personalizationBtn: 'NEXT: PERSONALIZATION',
      reviewAndSaveBtn: 'NEXT: REVIEW & SAVE',
      goToCommTxt: 'GOTO COMMMSG'
    },
    ja: {
      communicationMessage: 'コミュニケーションメッセージ 登録',
      communicationEditMessage: 'コミュニケーションメッセージ 編集',
      close: '閉じる',
      basicInfoStepper: '基本情報',
      alertBodyEditText: 'コミュニケーションメッセージが正常に保存されました。',
      deliveryChannelStepper: 'チャネル',
      msgPersonalizationStepper: 'パーソナライズ',
      selectMsgStepper: 'メッセージテンプレート',
      personalizationStepper: 'パーソナライズ',
      reviewStepper: '登録内容確認',
      previousBtnText: '戻る',
      cancelBtnText: 'キャンセル',
      nextDeliveryChannelBtnText: '次へ : チャネル設定',
      nextSelectTemplateBtnText: '次へ : テンプレート選択',
      publishBtn: '公開する',
      goToCommBtn: 'コミュニケーションメッセージ一覧へ',
      successFormTitle: '更新完了',
      successInfoText:
        'コミュニケーションメッセージが公開されると、会員通知設定画面で選択可能になります。',
      alertBodyText: 'コミュニケーションメッセージが公開されました。',
      successAlertHeader: '更新成功',
      previousBtn: '戻る',
      personalizationBtn: '次へ : パーソナライズ',
      reviewAndSaveBtn: '次へ : 登録内容確認',
      goToCommTxt: 'コミュニケーションメッセージ一覧へ'
    }
  }
};

// COMMUNICATION STEPPER INFO COMPONENTS ENDS

// COMMUNICATION DELIVERY INFO COMPONENTS STARTS

export const communicationManagementDeliveryChannel = {
  messages: {
    en: {
      deliveryFormTitle: 'Delivery channel',
      deliveryInfoText:
        'Only channels that are configured for your program will be displayed on this page.',
      deliveryHeaderText: 'Select delivery type from below'
    },
    ja: {
      deliveryFormTitle: 'チャネル設定',
      deliveryInfoText:
        'プログラム設定で選択されたチャネルが選択肢として表示されます。',
      deliveryHeaderText: '配信タイプを選択してください'
    }
  }
};

// COMMUNICATION DELIVERY INFO COMPONENTS ENDS

// COMMUNICATION DELETE POPUP INFO COMPONENTS STARTS

export const communicationManagementDeletePopup = {
  messages: {
    en: {
      cardTitle: 'DELETE MESSAGE',
      alertMsg: 'Do you want to permanently delete this message?',
      noBtnTextPopUp: 'no',
      yesBtnTextPopUp: 'yes'
    },
    ja: {
      cardTitle: 'メッセージ削除',
      alertMsg: 'メッセージを削除します。よろしいですか？',
      noBtnTextPopUp: 'いいえ',
      yesBtnTextPopUp: 'はい'
    }
  }
};

// COMMUNICATION DELETE POPUP INFO COMPONENTS ENDS

// COMMUNICATION CANCELPOPUP INFO COMPONENTS STARTS

export const communicationManagementCancelPopup = {
  messages: {
    en: {
      cardTitle: 'UNSAVED CHANGES',
      basicInfoAlertMsg:
        'Are you sure you want to cancel message creation? If you cancel, any information you entered on this page will not be saved.',
      alertMsg: 'Do you want to save your changes ?',
      noBtnTextPopUp: 'NO',
      yesBtnTextPopUp: 'YES'
    },
    ja: {
      cardTitle: '変更内容が保存されていません',
      basicInfoAlertMsg:
        '現在の作業を中断します。よろしいですか？このページで入力した情報は保存されません。',
      alertMsg: '変更内容を保存しますか？',
      noBtnTextPopUp: 'いいえ',
      yesBtnTextPopUp: 'はい'
    }
  }
};

// COMMUNICATION CANCELPOPUP INFO COMPONENTS ENDS

// COMMUNICATION ALERT POPUP INFO COMPONENTS STARTS
export const communicationManagementAlertPopup = {
  messages: {
    en: {
      cardTitle: 'ALERT',
      closeBtnTextPopUp: 'CLOSE'
    },
    ja: {
      cardTitle: 'アラート',
      closeBtnTextPopUp: '閉じる'
    }
  }
};
// COMMUNICATION ALERT POPUP INFO COMPONENTS ENDS

// COMMUNICATION MANAGEMENT MODULE ENDS

// COMMUNICATION MODULE STARTS

// COMMUNICATION PREVIEW AND SAVE COMPONENT STARTS
export const communicationPreviewObj = {
  messages: {
    en: {
      headerText: 'CHANNEL SETUP',
      programNameText: 'Program Name:',
      providerText: 'Provider:'
    },
    ja: {
      headerText: 'チャネル設定',
      programNameText: 'プログラム名 : ',
      providerText: 'プロバイダー : '
    }
  }
};
// COMMUNICATION PREVIEW AND SAVE COMPONENT ENDS

// COMMUNICATION SETUP COMPONENT STARTS
export const communicationSetUpObj = {
  messages: {
    en: {
      providerErrorTxt: 'Select Provider to be used for managing Communication',
      programErrorTxt: 'Select Program to be configured',
      channelErrorTxt: 'Select Communication Channel to be configured',
      fndText: 'Found',
      rndText: 'email templates in the system.',
      alertMsg: 'Any unsaved changes will be lost. Do you want to proceed?',
      noBtnTextPopUp: 'NO',
      yesBtnTextPopUp: 'YES',
      cardTitle: 'UNSAVED CHANGES',
      headerChannelText: 'CHOOSE PROGRAM, CHANNEL & PROVIDER',
      headerText: 'COMMUNICATIONS',
      closeText: 'CLOSE',
      communicationFormTitle: 'COMMUNICATIONS SETUP',
      communicationInfoText:
        'If all your programs use the same provider, select “All Programs” in the list.',
      channelSetUpText: 'Channel Setup',
      setUpProgramText: 'SETUP ANOTHER PROGRAM',
      updateCommunication: 'Communication Setup has been successfully updated',
      reviewFormTitle: 'REVIEW',
      reviewInfoText:
        'On this page, you can check if all channels and providers are configured correctly for each program',
      nextReviewText: 'NEXT : REVIEW',
      saveSetUpText: 'SAVE SETUP',
      previousText: 'Previous',
      setUpCommunicationText: 'SETUP COMMUNICATION FOR ANOTHER PROGRAM',
      communicationForProgramText:
        'Would you like to set the communication channel for another program?',
      clickHereText: 'Click Here',
      goToList: 'GO TO LIST',
      cancelList: 'Cancel',
      successFormTitle: 'SUCCESS',
      saveCommunicationText:
        'Your communication setup has been successfully saved',
      selectProgramLabel: 'Select Program',
      selectChannelLabel: 'Select Channel',
      selectProviderLabel: 'Select Provider',
      configureProviderLabel: 'CONFIGURE PROVIDER',
      yesBtnText: 'yes',
      noBtnText: 'no',
      providerName: 'MAPP SETUP',
      confirmationHeader: 'CONFIRMATION',
      providerConfigParams: 'Mapp CONFIGURATION PARAMETERS',
      cancelBtnTextPopUp: 'CANCEL',
      connectBtnTextPopUp: 'CONNECT',
      closeBtnTextPopUp: 'CLOSE',
      alertText: 'ALERT',
      setUpText: 'SETUP',
      userNameLabel: 'User Name',
      passwordLabel: 'Password',
      apiUrlLabel: 'API URL',
      successTitle: 'Success',
      mapConfigText:
        'Mapp configuration parameters has been successfully completed.',
      programErrorText: 'Program has already been selected in previous section',
      errorText: 'Error',
      userNameError: 'UserName is required.',
      passwordError: 'Password is required.',
      apiUrlError: 'API URL is required.',
      filedRequiredError: 'this field is required',
      invalidCredentials:
        'There was an error connecting to the server. Please check your credentials',
      urlNotValidText: 'URL is Not Valid'
    },
    ja: {
      providerErrorTxt: '利用するプロバイダーを選択してください',
      programErrorTxt: '対象のプログラムを選択してください',
      channelErrorTxt: '設定するチャネルを選択してください',
      fndText: '現在',
      updateCommunication: 'コミュニケーション設定が正常に更新されました',
      rndText: '件のメールテンプレートが登録されています。',
      alertMsg:
        '現在の作業を中断します。よろしいですか？このページで入力された情報は保存されません。',
      noBtnTextPopUp: 'いいえ',
      yesBtnTextPopUp: 'はい',
      cardTitle: '変更内容が保存されていません',
      headerChannelText: 'プログラム、チャネル、プロバイダーを選択',
      headerText: 'コミュニケーション',
      closeText: '閉じる',
      communicationFormTitle: 'コミュニケーション設定',
      communicationInfoText:
        'すべてのプログラムで同じプロバイダーを利用する場合は、プログラムリストから「すべてのプログラム」を選択してください。',
      channelSetUpText: 'チャネル設定',
      setUpProgramText: '他のプログラムのコミュニケーション設定を追加する',
      reviewFormTitle: '登録内容確認',
      reviewInfoText:
        'チャネルとプロバイダーが各プログラムに対して正しく設定されているか確認してください',
      nextReviewText: '次へ : 登録内容確認',
      saveSetUpText: '設定を保存する',
      previousText: '戻る',
      setUpCommunicationText:
        '他のプログラムのコミュニケーション設定を追加する',
      communicationForProgramText:
        '他のプログラムのコミュニケーション設定を追加するには、',
      clickHereText: 'ここをクリックしてください',
      goToList: 'コミュニケーション設定一覧へ',
      cancelList: 'キャンセル',
      successFormTitle: '更新完了',
      saveCommunicationText: 'コミュニケーション設定が正常に保存されました',
      selectProgramLabel: 'プログラム選択',
      selectChannelLabel: 'チャネル選択',
      selectProviderLabel: 'プロバイダー選択',
      configureProviderLabel: 'プロバイダー設定',
      yesBtnText: 'はい',
      noBtnText: 'いいえ',
      providerName: 'Mapp接続設定',
      confirmationHeader: '設定確認',
      providerConfigParams: 'Mapp接続パラメーター',
      cancelBtnTextPopUp: 'キャンセル',
      connectBtnTextPopUp: '接続する',
      closeBtnTextPopUp: '閉じる',
      alertText: 'アラート',
      setUpText: 'セットアップ',
      userNameLabel: 'ユーザ名',
      passwordLabel: 'パスワード',
      apiUrlLabel: 'API URL',
      successTitle: '設定完了',
      mapConfigText: 'Mapp接続パラメーター設定が正常に完了しました。',
      programErrorText: 'プログラムは前のセクションですでに選択されています',
      errorText: 'エラー',
      userNameError: '「ユーザ名」は必須項目です。',
      passwordError: '「パスワード」は必須項目です。',
      apiUrlError: '「API URL」は必須項目です。',
      filedRequiredError: 'この項目は必須です。',
      invalidCredentials:
        'サーバーへの接続中にエラーが発生しました。説極情報を確認してください。',
      urlNotValidText: 'URLが無効です。'
    }
  }
};
// COMMUNICATION SETUP COMPONENT ENDS

// COMMUNICATION MODULE ENDS

// VIEW USERS MODULE STARTS

// USER LIST COMPONENT STARTS
export const viewUsersObj = {
  messages: {
    en: {
      headerText: 'VIEW USERS',
      closeBtnText: 'CLOSE',
      usersLabel: 'users',
      activityDate: 'ACTIVITY DATE',
      fromLabel: 'From',
      cancelBtnText: 'Cancel',
      okBtnText: 'OK',
      toLabel: 'To',
      programLabel: 'PROGRAM',
      selectProgramLabel: 'Select Program',
      roleLabel: 'ROLE',
      selectRoleLabel: 'Select Role',
      statusLabel: 'Status',
      activeLabel: 'Active',
      inActiveLabel: 'Inactive',
      expiredLinkLabel: 'Expired Link',
      pendingLabel: 'Pending Signup',
      draftLabel: 'Draft',
      clearBtnText: 'Clear & Close',
      filterBtnText: 'APPLY FILTERS',
      searchUsersText: 'Search Users',
      usersText: 'Users',
      userInfoText:
        'The list of users can be viewed in different layouts such as Grid, Card and Table by using the View Options menu',
      createNewUser: 'Create a new User',
      gridViewText: 'grid view',
      tableViewText: 'Table view',
      cardViewText: 'card view',
      noResultsFoundText: 'No results containing your search terms were found.',
      fromDateText: '&FromDate=',
      toDateText: '&ToDate=',
      programIdText: '&ProgramId=',
      roleIdText: '&RoleId=',
      statusText: '&Status='
    },
    ja: {
      headerText: 'ユーザ一覧',
      closeBtnText: '閉じる',
      usersLabel: '件',
      activityDate: '日付範囲指定(最終アクセス日時)',
      fromLabel: '開始日',
      cancelBtnText: 'キャンセル',
      okBtnText: 'OK',
      toLabel: '終了日',
      programLabel: 'プログラム',
      selectProgramLabel: 'プログラム選択',
      roleLabel: 'ロール',
      selectRoleLabel: 'ロール選択',
      statusLabel: 'ステータス',
      activeLabel: 'アクティブ',
      inActiveLabel: '非アクティブ',
      expiredLinkLabel: 'リンク有効期限切れ',
      pendingLabel: '保留',
      draftLabel: '下書き',
      clearBtnText: 'キャンセルして閉じる',
      filterBtnText: 'フィルターを適用する',
      searchUsersText: 'ユーザ検索',
      usersText: 'ユーザ',
      userInfoText:
        '「ビューオプション」を利用すると、ユーザ一覧の表示レイアウトを変更することができます（グリッド、カード、テーブル）',
      createNewUser: 'ユーザ登録',
      gridViewText: 'グリッドビュー',
      tableViewText: 'テーブルビュー',
      cardViewText: 'カードビュー',
      noResultsFoundText:
        '検索結果がみつかりませんでした。検索条件を修正して、もう一度お試しください。',
      fromDateText: '&FromDate=',
      toDateText: '&ToDate=',
      programIdText: '&ProgramId=',
      roleIdText: '&RoleId=',
      statusText: '&Status='
    }
  }
};
// USER LIST COMPONENT ENDS

// USER TABLE VIEW COMPONENT STARTS
export const userTableViewObj = {
  messages: {
    en: {
      resendLinkText: 'Resend Link',
      editLabel: 'Edit',
      copyLabel: 'Copy',
      activateLabel: 'Activate',
      labelDeactivate: 'De Activate',
      deActivateLabel: 'De-activate',
      nameText: 'Name',
      programsText: 'Programs',
      externalIdText: 'External ID',
      createdOnText: 'Created On',
      lastActivityText: 'Last Activity',
      statusText: 'Status',
      inActiveText: 'Inactive',
      activeText: 'Active',
      deActivateText: 'Deactive',
      activateUserText: 'Activate User',
      activateText: 'activate',
      deActivateUserText: 'De-activate User',
      deActivateLabelText: 'deactivate'
    },
    ja: {
      resendLinkText: 'リンクを再送信',
      editLabel: '編集',
      copyLabel: 'コピー',
      activateLabel: '有効化',
      labelDeactivate: '非アクティブ化',
      deActivateLabel: '無効化',
      nameText: 'ユーザ名',
      programsText: 'プログラム',
      externalIdText: '外部ID',
      createdOnText: '作成日',
      lastActivityText: '最終アクセス日時',
      statusText: 'ステータス',
      inActiveText: 'なし',
      activeText: 'アクティブ',
      deActivateText: '非アクティブ',
      activateUserText: 'ユーザを有効化する',
      activateText: ' ',
      deActivateUserText: 'ユーザを無効化する',
      deActivateLabelText: ' '
    }
  }
};
// USER TABLE VIEW COMPONENT ENDS

// USER GRID VIEW COMPONENT STARTS
export const userGridViewObj = {
  messages: {
    en: {
      emailText: 'Email:',
      phoneText: 'Phone:',
      externalIdText: 'External ID:',
      labelDeactivate: 'De Activate',
      editLabel: 'Edit',
      copyLabel: 'Copy',
      activateLabel: 'Activate',
      deActivateLabel: 'De-activate',
      programsLabel: 'Programs:',
      createdLabel: 'Created On:',
      lastActivityLabel: 'Last Activity:',
      statusLabel: 'Status',
      resendLinkText: 'Resend Link',
      inActiveText: 'Inactive',
      activeText: 'Active',
      deActivateText: 'Deactive',
      activateUserText: 'Activate User',
      activateText: 'activate',
      deActivateUserText: 'De-activate User',
      deActivateLabelText: 'deactivate'
    },
    ja: {
      emailText: 'メール : ',
      phoneText: '電話番号 : ',
      externalIdText: '外部ID : ',
      labelDeactivate: '非アクティブ化',
      editLabel: '編集',
      copyLabel: 'コピー',
      activateLabel: '有効化',
      deActivateLabel: '無効化',
      programsLabel: 'プログラム : ',
      createdLabel: '作成日 : ',
      lastActivityLabel: '最終アクセス日時 : ',
      statusLabel: 'ステータス',
      resendLinkText: 'リンク再送信',
      inActiveText: 'なし',
      activeText: 'アクティブ',
      deActivateText: '非アクティブ',
      activateUserText: 'ユーザを有効化する',
      activateText: ' ',
      deActivateUserText: 'ユーザを無効化する',
      deActivateLabelText: ' '
    }
  }
};
// USER GRID VIEW COMPONENT ENDS

// USER CARD VIEW COMPONENT STARTS
export const userCardViewObj = {
  messages: {
    en: {
      emailText: 'Email:',
      phoneText: 'Phone:',
      externalIdText: 'External ID:',
      editLabel: 'Edit',
      copyLabel: 'Copy',
      labelDeactivate: 'De Activate',
      programsLabel: 'Programs:',
      rewardsLabel: 'M Rewards (USA):',
      mRewardsLabel: 'M Rewards (UK):',
      createdLabel: 'Created On:',
      lastActivityLabel: 'Last Activity:',
      activateLabel: 'Activate',
      deActivateLabel: 'De-activate',
      statusLabel: 'Status',
      resendLinkText: 'Resend Link',
      activateUserText: 'Activate User',
      activateText: 'activate',
      deActivateUserText: 'De-activate User',
      deActivateText: 'deactivate',
      activeText: 'Active',
      inActiveText: 'Inactive',
      deActiveText: 'Deactive'
    },
    ja: {
      emailText: 'メール : ',
      phoneText: '電話番号 : ',
      externalIdText: '外部ID : ',
      editLabel: '編集',
      copyLabel: 'コピー',
      programsLabel: 'プログラム : ',
      labelDeactivate: '非アクティブ化',
      rewardsLabel: 'Mリワード（米国） : ',
      mRewardsLabel: 'Mリワード（英国） : ',
      createdLabel: '作成日 : ',
      lastActivityLabel: '最後アクセス日時 : ',
      activateLabel: '有効化',
      deActivateLabel: '無効化',
      statusLabel: 'ステータス',
      resendLinkText: 'リンク再送信',
      activateUserText: 'ユーザを有効化する',
      activateText: ' ',
      deActivateUserText: 'ユーザを無効化する',
      deActivateText: ' ',
      activeText: 'アクティブ',
      inActiveText: 'なし',
      deActiveText: '非アクティブ'
    }
  }
};
// USER CARD VIEW COMPONENT ENDS

// CLOSE POPUP COMPONENT STARTS
export const closePopUpObj = {
  messages: {
    en: {
      noBtnText: 'No, keep',
      areYouSureText: 'Are you sure you want to',
      thisUserText: 'this user?',
      yesBtnText: 'Yes,'
    },
    ja: {
      noBtnText: 'いいえ',
      areYouSureText: '操作を実行します。',
      thisUserText: 'よろしいですか？',
      yesBtnText: 'はい'
    }
  }
};
// CLOSE POPUP COMPONENT ENDS

// SUCCESS POPUP COMPONENT STARTS
export const successPopUpObj = {
  messages: {
    en: {
      sentEmailText: 'Email Sent',
      okBtnText: 'OK',
      alertMessageText:
        'An email has been sent to this user with a new signup link. The old link will no longer be valid.'
    },
    ja: {
      sentEmailText: '送信完了',
      okBtnText: 'OK',
      alertMessageText:
        '新たなユーザ登録用リンクが記載されたメールが、対象のユーザに送信されました。古いリンクは無効になります。'
    }
  }
};
// SUCCESS POPUP COMPONENT ENDS

// VIEW USERS MODULE ENDS

// PRODUCT DEFINITION MODULE STARTS

// PROGRAM HIERARCHY PAGE STARTS
export const programHierarchyLanguageObj = {
  messages: {
    en: {
      programHierarchy: 'PROGRAM HIERARCHY',
      noBtnText: 'NO',
      doneBtnText: 'DONE'
    },
    ja: {
      programHierarchy: 'プログラム構成',
      noBtnText: 'キャンセル',
      doneBtnText: '確定する'
    }
  }
};
// PROGRAM HIERARCHY PAGE ENDS

// ORGANIZATION PRODUCT CHART NODE PAGE STARTS
export const orgProductChartNodeLanguageObj = {
  messages: {
    en: {
      tooltipLabel: 'INFO',
      tooltipText:
        'This Program Entity has already been assigned to another product definition and cannot be selected anymore.'
    },
    ja: {
      tooltipLabel: 'インフォメーション',
      tooltipText:
        'このプログラムエンティティはすでに別の商品情報定義にマッピングされているため、選択できません。'
    }
  }
};
// ORGANIZATION PRODUCT CHART NODE PAGE ENDS

// PRODUCT LAYOUT COMPONENT STARTS
export const productLayoutObj = {
  messages: {
    en: {
      closePopUp: 'close',
      closeBtnText: 'CLOSE',
      productDefInfoText:
        'A product definition defines the set of attributes associated with your products.',
      successFormTitle: 'SUCCESS',
      successInfoText:
        'A product definition defines the set of attributes associated with your products.',
      basicDetailsText: 'BASIC DETAILS',
      productSetNameLabel: 'Product Set Name',
      productSetNameError: 'Enter Product Set Name',
      productSetNameAlphabeticError:
        'Product Set Name may only contain alphabetic characters',
      productSetDescriptionLabel: 'Product Set Description',
      infoText: 'Info',
      infoPassage:
        'A product definition is required for every program entity that will be sending product data.',
      productAttributesLabel: 'Product Attributes',
      programEntityMappingLabel: 'Program Entity Mapping',
      programEntityPassage:
        'Please select Org entity or entities that this Definitions should be mapped to:',
      programEntityText: 'Program Entities',
      noProgramEntitySelectedText: 'No Program Entities Selected',
      programEntityError: 'Program Entity is Required',
      selectedProgramEntitiesLabel: 'Selected Program Entities',
      selectHereLabel: 'CLICK HERE TO SELECT',
      unsavedChangesLabel: 'UNSAVED CHANGES',
      noBtnText: 'NO',
      yesBtnText: 'YES',
      cancelBtnText: 'Cancel',
      saveContinueBtnText: 'SAVE & CONTINUE',
      goToProductDefText: 'Go To Product Definitions',
      headerText: 'CREATE PRODUCT DEFINITION',
      editFormTitle: 'Edit Product Definition',
      newFormTitle: 'NEW PRODUCT DEFINITION',
      productDefText: 'The Product Definition  ',
      saveSuccesfulText: '  has been successfully saved.',
      successAlert: 'success',
      errorMsgText: 'Do you want to save your changes ?',
      editProductDefinition: 'EDIT PRODUCT DEFINITION',
      alertPopUpMessage:
        'Attribute is not saved. Please save the attribute before you continue',
      alertText: 'ALERT',
      productNameErrorText: 'Product Name already exists.'
    },
    ja: {
      closePopUp: '閉じる',
      closeBtnText: '閉じる',
      productDefInfoText: '商品情報として管理する項目を定義します。',
      successFormTitle: '更新完了',
      successInfoText: '商品情報定義の登録が完了しました。',
      basicDetailsText: '基本情報',
      productSetNameLabel: '商品情報定義名',
      productSetNameError: '「商品情報定義名」を入力してください',
      productSetNameAlphabeticError:
        '「商品情報定義名」にはアルファベットのみ入力可能です',
      productSetDescriptionLabel: '商品情報定義概要',
      infoText: 'インフォメーション',
      infoPassage:
        '商品情報を扱うプログラムエンティティに対して、商品情報を定義する必要があります。',
      productAttributesLabel: '商品項目',
      programEntityMappingLabel: 'プログラムエンティティマッピング',
      programEntityPassage:
        'この商品情報定義をマッピングするエンティティを選択してください',
      programEntityText: 'プログラムエンティティ',
      noProgramEntitySelectedText: 'プログラムエンティティが選択されていません',
      programEntityError: 'プログラムエンティティを選択してください',
      selectedProgramEntitiesLabel: '選択されたプログラムエンティティ',
      selectHereLabel: 'ここをクリックして選択してください',
      unsavedChangesLabel: '変更内容が保存されていません',
      noBtnText: 'いいえ',
      yesBtnText: 'はい',
      cancelBtnText: 'キャンセル',
      saveContinueBtnText: '保存して続ける',
      goToProductDefText: '商品情報定義一覧へ',
      headerText: '商品情報定義 登録',
      editFormTitle: '商品情報定義 編集',
      newFormTitle: '商品情報定義 登録',
      productDefText: '商品情報定義 ',
      saveSuccesfulText: ' が正常に登録されました。',
      successAlert: '更新成功',
      errorMsgText: '変更内容を保存しますか？',
      editProductDefinition: '商品情報定義 編集',
      alertPopUpMessage:
        '追加した項目が保存されていません。次へ進む前に新規追加した項目を保存してください。',
      alertText: 'アラート',
      productNameErrorText:
        '設定された名称はすでに存在します。別の名前を設定してください。'
    }
  }
};
// PRODUCT LAYOUT COMPONENT ENDS

// PRODUCT DEFINITION CARD VIEW COMPONENT STARTS
export const productDefinitionCardViewObj = {
  messages: {
    en: {
      descriptionLabel: 'Description:',
      programEntityLabel: 'Program Entity:',
      editLabel: 'Edit',
      copyLabel: 'Copy',
      viewLabel: 'View',
      viewDetails: 'View Details'
    },
    ja: {
      descriptionLabel: '商品情報定義概要:',
      programEntityLabel: 'プログラムエンティティ:',
      editLabel: '編集',
      copyLabel: 'コピー',
      viewLabel: '詳細を見る',
      viewDetails: '詳細を見る'
    }
  }
};
// PRODUCT DEFINITION CARD VIEW COMPONENT ENDS

// PRODUCT DEFINITION GRID VIEW COMPONENT STARTS
export const productDefinitionGridViewObj = {
  messages: {
    en: {
      editLabel: 'Edit',
      copyLabel: 'Copy',
      viewLabel: 'View',
      viewDetails: 'View Details',
      descriptionLabel: 'Description:',
      programEntityLabel: 'Program Entity:'
    },
    ja: {
      editLabel: '編集',
      copyLabel: 'コピー',
      viewLabel: '詳細を見る',
      viewDetails: '詳細を見る',
      descriptionLabel: '商品情報定義概要:',
      programEntityLabel: 'プログラムエンティティ:'
    }
  }
};
// PRODUCT DEFINITION GRID VIEW COMPONENT ENDS

// PRODUCT DEFINITION TABLE VIEW COMPONENT STARTS
export const productDefinitionTableViewObj = {
  messages: {
    en: {
      editLabel: 'Edit',
      copyLabel: 'Copy',
      viewLabel: 'View',
      viewDetails: 'View Details',
      defNameText: 'Definition Name',
      descriptionText: 'Description',
      programEntityText: 'Program Entity'
    },
    ja: {
      editLabel: '編集',
      copyLabel: 'コピー',
      viewLabel: '詳細を見る',
      viewDetails: '詳細を見る',
      defNameText: '商品情報定義名',
      descriptionText: '商品情報定義概要',
      programEntityText: 'プログラムエンティティ'
    }
  }
};
// PRODUCT DEFINITION TABLE VIEW COMPONENT ENDS

// PRODUCT DEFINITION VIEW DETAILS COMPONENT STARTS
export const productDefinitionViewDetailsObj = {
  messages: {
    en: {
      closeBtnText: 'CLOSE',
      attributeTitle:
        'Any change to the default value will only apply to new data',
      maxLengthTitle:
        'Once it is set, max length can be increased but not reduced.',
      productDefinitionLabel: 'PRODUCT DEFINITION',
      productDefInfoText:
        'A product definition defines the set of attributes associated with your products.',
      basicDetailsText: 'BASIC DETAILS',
      productSetNameLabel: 'Product Set Name',
      productSetDescriptionLabel: 'Product Set Description',
      infoText: 'Info',
      infoPassage:
        'A product definition is required for every program entity that will be sending product data.',
      productAttributesLabel: 'Product Attributes',
      attributeNameLabel: 'Attribute Name',
      dataTypeLabel: 'Data Type',
      maxLengthLabel: 'Max Length',
      requireLabel: 'Require',
      uniqueLabel: 'Unique',
      descriptionLabel: 'Description',
      defaultValueLabel: 'Default Value',
      displayNameLabel: 'Display Text',
      actionsLabel: 'Actions',
      programEntityLabel: 'Program Entity Mapping',
      programEntitiesText: 'Program Entities',
      noProgramEntitySelectedText: 'No Program Entities Selected',
      selectedProgramEntitiesLabel: 'Selected Program Entities'
    },
    ja: {
      closeBtnText: '閉じる',
      productDefinitionLabel: '商品情報定義',
      productDefInfoText: '商品情報として管理する項目を定義します。',
      basicDetailsText: '基本情報',
      productSetNameLabel: '商品情報定義名',
      productSetDescriptionLabel: '商品情報定義概要',
      infoText: 'インフォメーション',
      infoPassage:
        '商品情報を扱うプログラムエンティティに対して、商品情報を定義する必要があります。',
      productAttributesLabel: '商品項目',
      attributeNameLabel: '項目名',
      dataTypeLabel: 'データ型',
      maxLengthLabel: '最大長',
      requireLabel: '必須',
      uniqueLabel: 'ユニーク',
      descriptionLabel: '概要',
      defaultValueLabel: 'デフォルト値',
      displayNameLabel: '表示名',
      actionsLabel: '操作',
      programEntityLabel: 'プログラムエンティティマッピング',
      programEntitiesText: 'プログラムエンティティ',
      noProgramEntitySelectedText: 'プログラムエンティティを選択してください',
      selectedProgramEntitiesLabel: '選択されたプログラムエンティティ',
      attributeTitle:
        'デフォルト値を変更した場合、すでに存在するデータには影響せず、新たに入力されるデータから、変更後のデフォルト値が適用されます。',
      maxLengthTitle: '設定後は、最大長の値を短くすることはできません。'
    }
  }
};
// PRODUCT DEFINITION VIEW DETAILS COMPONENT ENDS

// PRODUCT ATTRIBUTES COMPONENT STARTS
export const productAttributesObj = {
  messages: {
    en: {
      attrNameRequired: 'Attribute Name is Required',
      displayRequired: 'Display Text is Required',
      defaultRequired: 'Default Value is Required',
      dataTypeRequired: 'DataType is Required',
      maxLengthRequired: 'Max Length Required',
      attrNameAlreadyExits: 'Attribute Name already exists.',
      fieldReq: 'This field is required',
      maxLengthGreaterError:
        'Max length should be greater than current length.',
      alertPopUpMessage:
        'Attribute is not saved. Please save the attribute before you continue',
      attributeNameLabel: 'Attribute Name',
      dataTypeLabel: 'Data Type',
      dataTypeText: 'DATA TYPE',
      maxLengthLabel: 'Max Length',
      maxLengthText: 'MAX LENGTH',
      requireLabel: 'Require',
      uniqueLabel: 'Unique',
      descriptionLabel: 'Description',
      defaultValueLabel: 'Default Value',
      defaultValueText: 'DEFAULT VALUE',
      displayNameLabel: 'Display Text',
      displayNameText: 'DISPLAY NAME',
      attributeNameText: 'ATTRIBUTE NAME',
      actionsLabel: 'Actions',
      attributeNameErrorLabel: 'Attribute Name is Required',
      typeLabel: 'Type',
      dataTypeErrorLabel: 'DataType is Required',
      maxLengthError: 'Max Length is Required.',
      defaultValueError: 'Default Value is Required',
      displayNameError: 'Display Name is Required',
      editText: 'edit',
      deleteText: 'delete',
      cancelText: 'cancel',
      addNewAttributeLabel: 'ADD NEW ATTRIBUTE',
      maxLengthErrorText: 'Max length should be greater than current length.',
      maxLengthTranslateError:
        'Max length value enter will translate to max characters if you set the data type to string.',
      attributeNameExistenceError: 'Attribute Name already exists.',
      attributeTitle:
        'Any change to the default value will only apply to new data',
      maxLengthTitle:
        'Once it is set, max length can be increased but not reduced.'
    },
    ja: {
      attrNameRequired: '属性名は必須です',
      displayRequired: '表示テキストが必要です',
      defaultRequired: 'デフォルト値が必要です',
      dataTypeRequired: 'データ型は必須です',
      maxLengthRequired: '必要な最大長',
      attrNameAlreadyExits: '属性名はすでに存在します。',
      fieldReq: 'この項目は必須です',
      maxLengthGreaterError: '最大長は現在の長さより大きくする必要があります',
      alertPopUpMessage: '追加した項目が保存されていません。保存してください。',
      displayNameText: '表示名',
      attributeNameText: '項目名',
      attributeNameLabel: '項目名',
      dataTypeLabel: 'データ型',
      dataTypeText: 'データ型',
      maxLengthLabel: '最大長',
      maxLengthText: '最大長',
      requireLabel: '必須',
      uniqueLabel: 'ユニーク',
      descriptionLabel: '概要',
      defaultValueLabel: 'デフォルト値',
      defaultValueText: 'デフォルト値',
      displayNameLabel: '表示名',
      actionsLabel: '操作',
      attributeNameErrorLabel: '「項目名」は必須項目です',
      typeLabel: 'データ型',
      dataTypeErrorLabel: '「データ型」は必須項目です',
      maxLengthError: '「最大長」は必須項目です',
      defaultValueError: '「デフォルト値」は必須項目です',
      displayNameError: '「表示名」は必須項目です',
      editText: '編集',
      deleteText: '削除',
      cancelText: 'キャンセル',
      addNewAttributeLabel: '項目を追加する',
      maxLengthErrorText:
        '「最大長」には現在の設定値より大きい値を入力してください。',
      maxLengthTranslateError:
        'データ型がString（文字列）の場合、「最大長」は最大文字数として扱われます。',
      attributeNameExistenceError:
        '設定された項目名はすでに存在します。別の名前を設定してください。',
      attributeTitle:
        'デフォルト値を変更した場合、すでに存在するデータには影響せず、新たに入力されるデータから、変更後のデフォルト値が適用されます。',
      maxLengthTitle: '設定後は、最大長の値を短くすることはできません。'
    }
  }
};
// PRODUCT ATTRIBUTES COMPONENT ENDS

// PRODUCT INFORMATION COMPONENT STARTS
export const productInfoObj = {
  messages: {
    en: {
      basicDetailsText: 'BASIC DETAILS',
      productSetNameLabel: 'Product Set Name',
      productSetNameError: 'Enter Product Set Name',
      productSetNameAlphabeticError:
        'Product Set Name may only contain alphabetic characters',
      infoText: 'Info',
      infoPassage:
        'A product definition is required for every program entity that will be sending product data.',
      productSetDescriptionLabel: 'Product Set Description'
    },
    ja: {
      basicDetailsText: '基本情報',
      productSetNameLabel: '商品情報定義名',
      productSetNameError: '「商品情報定義名」を入力してください',
      productSetNameAlphabeticError:
        '「商品情報定義名」にはアルファベットのみ入力可能です',
      infoText: 'インフォメーション',
      infoPassage:
        '商品情報を扱うプログラムエンティティに対して、商品情報を定義する必要があります。',
      productSetDescriptionLabel: '商品情報定義概要'
    }
  }
};
// PRODUCT INFORMATION COMPONENT ENDS

// PRODUCT DEFINITION COMPONENT STARTS
export const productDefinitionObj = {
  messages: {
    en: {
      productDefInfoText: 'PRODUCT DEFINITION',
      closeBtnText: 'CLOSE',
      productDefinitionFormTitle: 'PRODUCT DEFINITIONS',
      productDefinitionInfoText:
        'A product definition defines the set of attributes associated with your products.',
      closeBtnLabel: 'Close',
      viewNoOfProductsText: 'Product Definitions',
      searchProdDefText: 'Search Product Definitions',
      createNewDefTitle: 'Create a new Definition',
      gridViewText: 'grid view',
      tableViewText: 'Table view',
      cardViewText: 'card view'
    },
    ja: {
      productDefInfoText: '商品情報定義',
      closeBtnText: '閉じる',
      productDefinitionFormTitle: '商品情報定義一覧',
      productDefinitionInfoText:
        '商品情報を扱うプログラムエンティティに対して、商品情報を定義する必要があります。',
      closeBtnLabel: '閉じる',
      viewNoOfProductsText: '件',
      searchProdDefText: '商品情報定義検索',
      createNewDefTitle: '商品情報定義登録',
      gridViewText: 'グリッドビュー',
      tableViewText: 'テーブルビュー',
      cardViewText: 'カードビュー'
    }
  }
};
// PRODUCT DEFINITION COMPONENT STARTS

// PRODUCT DEFINITION MODULE ENDS

// ORGANIZATION MODULE STARTS

// ADD ENTITY COMPONENT STARTS
export const addEntityOrganizationObject = {
  messages: {
    en: {
      cardTitle: 'ADD NEW ENTITY',
      cancelBtnText: 'Cancel',
      saveBtnText: 'Save & Continue',
      fieldErrorText: 'Please Enter the Fields?',
      nameErrorText: 'Type Name is Required.',
      typeOfOrgText: 'What type of Organization is this?',
      enterOrgText: 'Enter Type of Organization',
      howManyText: 'How many ?'
    },
    ja: {
      cardTitle: '新規エンティティ追加',
      cancelBtnText: 'キャンセル',
      saveBtnText: '保存して続ける',
      fieldErrorText: '必須項目です。',
      nameErrorText: '「エンティティタイプ名」は必須項目です。',
      typeOfOrgText: 'エンティティタイプ',
      enterOrgText: 'エンティティタイプ名',
      howManyText: '追加数'
    }
  }
};
// ADD ENTITY COMPONENT ENDS

// ADD ENTITY TYPE COMPONENT STARTS
export const addTypeEntityOrganizationObject = {
  messages: {
    en: {
      cardTitle: 'ADD NEW ENTITY',
      orgTypeDetails: 'Details',
      cancelBtnText: 'Cancel',
      saveBtnText: 'Save',
      nameErrorText: 'Name is Required.',
      descriptionErrorText: 'Description must be less than 500 characters.',
      orgTypeDescription: '{orgType} Description',
      orgTypeName: '{orgType} Name',
      nameError: 'Name Already Exists'
    },
    ja: {
      cardTitle: '新規エンティティ追加',
      orgTypeDetails: '詳細',
      cancelBtnText: 'キャンセル',
      saveBtnText: '保存する',
      nameErrorText: '名は必須項目です。',
      descriptionErrorText: '概要は500文字未満で入力してください。',
      orgTypeDescription: '{orgType}概要',
      orgTypeName: '{orgType}名',
      nameError: '名はすでに存在します。別の名前を設定してください。'
    }
  }
};
// ADD ENTITY TYPE COMPONENT ENDS

// DELETE POPUP COMPONENT STARTS
export const deletePopUpOrganizationObject = {
  messages: {
    en: {
      cardTitle: 'DELETE ENTITY',
      cancelBtnText: 'NO',
      deleteEntityText:
        'Are you sure you want to delete this entity? This action cannot be undone.',
      yesBtnText: 'YES',
      activeProgramDeleteEntityText:
        'This entity cannot be deleted because its referenced by an active program.',
      okBtnText: 'OK',
      dataDefinitionDeleteEntityText:
        'This entity cannot be deleted because it has the following data definition associated with it:',
      activeProgramAndDataDefinitionDeleteEntityText:
        'This entity cannot be deleted because its referenced by an active program and it has the following data definition associated with it:'
    },
    ja: {
      cardTitle: 'エンティティ削除',
      cancelBtnText: 'いいえ',
      deleteEntityText:
        'エンティティを削除します。よろしいですか？この操作は取り消しできません。',
      yesBtnText: 'はい',
      activeProgramDeleteEntityText:
        '選択されたエンティティは「アクティブ」ステータスのプログラムに紐づいているため、削除できません。',
      okBtnText: 'OK',
      dataDefinitionDeleteEntityText:
        '選択されたエンティティは以下のデータ定義に紐づいているため、削除できません。',
      activeProgramAndDataDefinitionDeleteEntityText:
        '選択されたエンティティは「アクティブ」ステータスのプログラムと、以下のデータ定義に紐づいているため、削除できません。'
    }
  }
};
// DELETE POPUP COMPONENT ENDS

// ORGANIZATION CHART NODE COMPONENT STARTS
export const organizationChartNodeElementObject = {
  messages: {
    en: {
      addText: 'ADD',
      editText: 'EDIT',
      deleteText: 'DELETE',
      orgName: '{orgName}'
    },
    ja: {
      addText: '追加',
      editText: '編集',
      deleteText: '削除',
      orgName: '{orgName}'
    }
  }
};
// ORGANIZATION CHART NODE COMPONENT ENDS

// UPDATE POPUP COMPONENT STARTS
export const updatePopUpOrganizationObject = {
  messages: {
    en: {
      editText: 'EDIT',
      detailsText: 'DETAILS',
      nameErrorText: 'Name is Required.',
      descriptionErrorText: 'Description must be less than 500 characters.',
      customIconText: 'Select Custom Icon',
      cancelBtnText: 'Cancel',
      orgTypeName: '{orgType} Name',
      orgTypeDescription: '{orgType} Description',
      saveBtnText: 'SAVE',
      saveCloseBtnText: 'SAVE & CLOSE'
    },
    ja: {
      editText: '編集 :',
      detailsText: '詳細',
      nameErrorText: '名は必須項目です。',
      descriptionErrorText: '概要は500文字未満で入力してください。',
      customIconText: 'アイコン選択',
      cancelBtnText: 'キャンセル',
      orgTypeName: '{orgType}名',
      orgTypeDescription: '{orgType}概要',
      saveBtnText: '保存する',
      saveCloseBtnText: '保存して閉じる'
    }
  }
};
// UPDATE POPUP COMPONENT ENDS

// ORGANIZATION CHART COMPONENT STARTS
export const organizationChartObject = {
  messages: {
    en: {
      formTitleSuccess: 'SUCCESS',
      headerText: 'COMPANY ORG',
      closeBtnText: 'CLOSE',
      programHierarchyText:
        'Your Program Hierarchy represents the hierarchy of brands, regions and other entities from your organization for which programs can be defined.',
      continueBtnText: 'CONTINUE',
      programHierarchyFormTitle: 'PROGRAM HIERARCHY',
      hierarchyInfoText:
        'A company org structure represents the hierarchy of brands, regions or other business units for which programs can be defined.',
      successFormTitle: 'SUCCESS',
      successInfoText:
        'A company org structure represents the hierarchy of brands, regions or other business units for which programs can be defined.',
      successAlertHeader: 'success',
      programHierarchyCompany: 'Program Hierarchy for Company',
      updatedSuccesfulText: 'has been successfully updated.'
    },
    ja: {
      formTitleSuccess: '更新完了',
      headerText: '企業組織情報',
      closeBtnText: '閉じる',
      programHierarchyText:
        '貴社のブランドや拠点、その他のビジネスエンティティがどのように構成されているかを定義します。',
      continueBtnText: '続ける',
      programHierarchyFormTitle: 'プログラム構成',
      hierarchyInfoText:
        'このページで追加したブランド、拠点、またはその他のビジネスユニットに紐づける形でプログラムが定義されます',
      successFormTitle: '更新完了',
      successInfoText:
        'このページで追加したブランド、拠点、またはその他のビジネスユニットに紐づける形でプログラムが定義されます',
      successAlertHeader: '更新成功',
      programHierarchyCompany: 'プログラム構成 :',
      updatedSuccesfulText: 'が正常に登録されました。'
    }
  }
};
// ORGANIZATION CHART COMPONENT ENDS

// ORGANIZATION CHART CONTAINER COMPONENT STARTS
export const organizationChartContainerObject = {
  messages: {
    en: {
      companyText: 'Company',
      regionText: 'Region',
      customEntityText: 'Custom Entity',
      brandText: 'Brand',
      legendText: 'Legend'
    },
    ja: {
      companyText: '会社',
      regionText: '拠点',
      customEntityText: 'カスタム',
      brandText: 'ブランド',
      legendText: '凡例'
    }
  }
};
// ORGANIZATION CHART CONTAINER COMPONENT ENDS

// ORGANIZATION MODULE ENDS

// COMPANY INFORMATION MODULE STARTS

// COMPANY INFORMATION LAYOUT COMPONENT STARTS
export const companyInfoLayoutObj = {
  messages: {
    en: {
      headerText: 'COMPANY INFORMATION',
      closeBtnText: 'CLOSE',
      previousBtnText: 'Previous',
      continueBtnText: 'CONTINUE',
      cancelBtnText: 'Cancel',
      saveContinueBtnText: 'SAVE & CONTINUE',
      formTitle: 'COMPANY INFORMATION',
      formTitleInfoText:
        'Company represents the corporate entity under which your loyalty programs will be created.',
      formTitleSuccess: 'SUCCESS',
      formTitleInfoSuccessText:
        'Company represents the corporate entity under which your loyalty programs will be created.',
      companyInfoText: 'Information for Company ',
      successfulUpdateText: ' has been successfully updated.'
    },
    ja: {
      headerText: '企業情報',
      closeBtnText: '閉じる',
      previousBtnText: '戻る',
      continueBtnText: '続ける',
      cancelBtnText: 'キャンセル',
      saveContinueBtnText: '保存して続ける',
      formTitle: '企業情報',
      formTitleInfoText:
        'ロイヤリティープログラムを作成する企業の情報を登録します。',
      formTitleSuccess: '更新成功',
      formTitleInfoSuccessText:
        'ロイヤリティープログラムを作成する企業の情報を登録します。',
      companyInfoText: '企業情報 : ',
      successfulUpdateText: 'が正常に更新されました。'
    }
  }
};
// COMPANY INFORMATION LAYOUT COMPONENT ENDS

// BASIC INFO COMPONENT STARTS
export const basicInfoObject = {
  messages: {
    en: {
      companyNameLabel: 'Company Name',
      companyProfileLabel: 'Company Profile',
      companyProfileError: 'Company Profile must be less than 500 characters.',
      companyCorporateLabel: 'Company Corporate Office',
      addressLabel: 'Address1',
      addressLabelError: 'Address1 must be less than 50 characters.',
      addressSecondaryLabel: 'Address2',
      addressSecondaryLabelError: 'Address2 must be less than 50 characters.',
      cityLabel: 'City',
      cityLabelError: 'City Name must be less than or equal 50 characters.',
      stateLabel: 'State',
      countryLabel: 'Country',
      infoText: 'Info',
      infoPassage:
        'Please verify your company information and update if necessary.'
    },
    ja: {
      companyNameLabel: '企業名',
      companyProfileLabel: '企業プロフィール',
      companyProfileError: '企業プロフィールは500文字未満で入力してください',
      companyCorporateLabel: '所在地',
      addressLabel: '住所（番地まで）',
      addressLabelError: '「住所（番地まで）」は50文字未満で入力してください。',
      addressSecondaryLabel: '住所（ビル名等）',
      addressSecondaryLabelError:
        '「住所（ビル名等）」は50文字未満で入力してください。',
      cityLabel: '市区町村',
      cityLabelError: '「市区町村」は50文字以下で入力してください。',
      stateLabel: '都道府県',
      countryLabel: '国',
      infoText: 'インフォメーション',
      infoPassage: '企業情報を確認し、必要に応じて更新してください。'
    }
  }
};
// BASIC INFO COMPONENT ENDS

// MORE INFO COMPONENT STARTS
export const moreInfoObject = {
  messages: {
    en: {
      companyTypeLabel: 'COMPANY TYPE',
      categoryLabel: 'Category',
      userInfo: 'AUTHORIZED USER INFORMATION',
      nameLabel: 'Name',
      positionLabel: 'Position',
      cityLabel: 'City',
      cityLabelError: 'City Name must be less than or equal 50 characters.',
      stateLabel: 'State',
      countryLabel: 'Country',
      infoText: 'Info',
      infoPassage:
        'Please verify your company information and update if necessary.'
    },
    ja: {
      companyTypeLabel: '業種',
      categoryLabel: 'カテゴリー',
      userInfo: '管理者情報',
      nameLabel: '管理者名',
      positionLabel: 'ポジション',
      cityLabel: '住所（市区町村）',
      cityLabelError: '「住所（市区町村）」は50文字以下で入力してください。',
      stateLabel: '住所（都道府県）',
      countryLabel: '国',
      infoText: 'インフォメーション',
      infoPassage: '企業情報を確認し、必要に応じて更新してください。'
    }
  }
};
// MORE INFO COMPONENT ENDS

// COMPANY INFORMATION MODULE ENDS

// USER MODULE STARTS

// PERSONAL INFORMATION COMPONENT STARTS
export const personalInformationObject = {
  messages: {
    en: {
      emailHeader: 'Email Address',
      emailValidationError: 'User already exists with the same Email Id.',
      emailText: 'Enter Email',
      userHeader: 'User Details',
      firstNameText: 'Enter First Name',
      firstNameValidationError:
        'First Name may only contain alphabetic characters',
      lastNameText: 'Enter Last Name',
      lastNameValidationError:
        'Last Name may only contain alphabetic characters',
      phoneNumberValidationError: 'Phone Number must be 10 characters long',
      externalIdText: 'External Id',
      emailLabel: 'Email',
      firstNameLabel: 'First Name',
      lastNameLabel: 'Last Name',
      phoneNumberLabel: 'Phone Number',
      externalIdLabel: 'External Id',
      incorrectEmailText: 'Incorrect Email format'
    },
    ja: {
      emailHeader: 'メールアドレス',
      emailValidationError: 'このメールアドレスはすでに登録されています。',
      emailText: '「メールアドレス」は必須項目です。',
      userHeader: 'ユーザ詳細',
      firstNameText: '「名前（名）」は必須項目です。',
      firstNameValidationError:
        '「名前（名）」にはアルファベットのみ入力可能です。',
      lastNameText: '「名前（姓）」は必須項目です。',
      lastNameValidationError:
        '「名前（姓）」にはアルファベットのみ入力可能です。',
      phoneNumberValidationError:
        '「電話番号」には10桁の値を設定してください。',
      externalIdText: '外部ID',
      emailLabel: 'メールアドレス',
      firstNameLabel: '名前（名）',
      lastNameLabel: '名前（姓）',
      phoneNumberLabel: '電話番号',
      externalIdLabel: '外部ID',
      incorrectEmailText: '「メールアドレス」のフォーマットを確認してください。'
    }
  }
};
// PERSONAL INFORMATION COMPONENT ENDS

// CANCEL POPUP COMPONENT STARTS
export const cancelPopUpObject = {
  messages: {
    en: {
      cardTitle: 'UNSAVED CHANGES',
      noBtnText: 'NO',
      yesBtnText: 'YES',
      alertMsg: 'Do you want to save your changes ?'
    },
    ja: {
      cardTitle: '変更内容が保存されていません',
      noBtnText: 'いいえ',
      yesBtnText: 'はい',
      alertMsg: '変更内容を保存しますか？'
    }
  }
};
// CANCEL POPUP COMPONENT ENDS
// LOYALTY ID COMPONENT STARTS
export const loyaltyIdObject = {
  messages: {
    en: {
      chooseGenerationSource: 'Choose your generation source',
      example: 'Example',
      codePattern: 'CODE PATTERN',
      loyaltyIdentifierPattern:
        'pattern for loyalty identifier (LID) generation',
      prefixValues: 'Prefix values',
      allowedValues:
        'Allowed number of values are alphanumeric 0 – 9 and/or A - Z( Max 4 Characters )',
      allowedValuesErrorMsg:
        'Allowed number of values are alphanumeric 0 – 9 and/or A - Z',
      toggleAlertBodyText:
        'LID will be generated by client system and sent to BP at the time of member enrollment. The length of LIDcannot exceed 20 characters.',
      alertBodyText:
        'LID will be generated by LoyaltyOnDemand platform at the time of member enrollment. The length of LID is fixed to 16 digits exclusive of a prefix if defined. A check digit algorithm will be applied to digits after the prefix.',
      alertType: 'info',
      codePrefix: 'Code Prefix',
      generationSource: 'Generation Source'
    },
    ja: {
      chooseGenerationSource: 'ロイヤリティーID(LID)の生成方法を選択してください',
      example: '例',
      codePattern: 'コードパターンサンプル',
      loyaltyIdentifierPattern:
        'ロイヤリティーIDのコード接頭辞を設定してください',
      prefixValues: 'コード接頭辞',
      allowedValues:
        'コード接頭辞には最大4桁のアルファベットまたは数字を設定できます。',
      allowedValuesErrorMsg:
        'コード接頭辞には最大4桁のアルファベットまたは数字を入力してください',
      toggleAlertBodyText:
        '現在の設定では、ロイヤリティーIDはクライアントシステムにて生成され、会員登録時にLODシステムに連携される必要があります。また、ロイヤリティーIDは20文字以内の文字列である必要があります。',
      alertBodyText:
        '現在の設定では、ロイヤリティーIDは、会員登録時にLODシステムにて生成されます。この場合、生成されるロイヤリティーIDは、コード接頭辞＋16桁の数字で構成され、数字部分にチェックディジットアルゴリズムが適用されます。',
      alertType: 'インフォメーション',
      codePrefix: 'コード接頭辞',
      generationSource: '生成方法'
    }
  }
};
// LOYALTY ID COMPONENT STARTS
// PREVIEW & SAVE COMPONENT STARTS
export const previewAndSaveObject = {
  messages: {
    en: {
      headerText: 'Personal Information',
      editText: 'Edit',
      emailLabel: 'Email Address :',
      firstNameLabel: 'First Name :',
      lastNameLabel: 'Last Name :',
      phoneNumberLabel: 'Phone Number :',
      externalIdLabel: 'External ID :',
      roleInfoHeader: 'Role Information',
      roleAssignmentText: 'Role Assignment :',
      selectedProgram: 'Selected Program',
      adminText: 'Administrator :',
      loyaltyAdminText: 'Loyalty Administrator'
    },
    ja: {
      headerText: '基本情報',
      editText: '編集',
      emailLabel: 'メールアドレス : ',
      firstNameLabel: '名前（名） : ',
      lastNameLabel: '名前（姓） : ',
      phoneNumberLabel: '電話番号  : ',
      externalIdLabel: '外部ID : ',
      roleInfoHeader: 'ロール設定',
      roleAssignmentText: 'ロール : ',
      selectedProgram: '対象プログラム',
      adminText: '管理者権限 : ',
      loyaltyAdminText: 'Loyalty Administrator（ロイヤリティー管理者）'
    }
  }
};
// PREVIEW & SAVE COMPONENT ENDS

// ROLE ADMINISTRATOR COMPONENT STARTS
export const roleAdminstratorObject = {
  messages: {
    en: {
      headerText: 'ROLE ASSIGNMENT',
      viewText: 'View',
      createText: 'Create',
      editText: 'Edit',
      deleteText: 'Delete'
    },
    ja: {
      headerText: 'ロール設定',
      viewText: '参照',
      createText: '作成',
      editText: '編集',
      deleteText: '削除'
    }
  }
};
// ROLE ADMINISTRATOR COMPONENT ENDS

// ROLE ASSIGNMENT COMPONENT STARTS
export const roleAssignmentObject = {
  messages: {
    en: {
      headerText: 'IS THIS USER AN ADMINISTRATOR?',
      yesLabelText: 'YES',
      noLabelText: 'NO',
      alertHeader: 'You are assigning an Admin Role',
      alertBody:
        'When this role is assigned, the user will get access to permissions to all functions across every program in your system'
    },
    ja: {
      headerText: '管理者に設定する',
      yesLabelText: 'はい',
      noLabelText: 'いいえ',
      alertHeader: '管理者ロールを付与します',
      alertBody:
        '管理者ロールが付与されると、すべてのプログラムのすべての機能を利用する権限が与えられます。'
    }
  }
};
// ROLE ASSIGNMENT COMPONENT ENDS

// ROLE ASSIGNMENT CHILD COMPONENT STARTS
export const roleAssignmentChildObject = {
  messages: {
    en: {
      programText: 'SELECT PROGRAM',
      fieldRequired: 'This field is required',
      programNameError: 'Already Program Name Exists',
      removeText: 'REMOVE',
      roleAssignmentText: 'ROLE ASSIGNMENT',
      roleSelectionText: 'Select any role',
      assignProgramText: 'Assign another program',
      programName: 'Program Name',
      viewText: 'View',
      createText: 'Create',
      editText: 'Edit',
      deleteText: 'Delete'
    },
    ja: {
      programText: 'プログラムを選択してください',
      fieldRequired: '必須項目です',
      programNameError:
        'このプログラムのロール設定はすでに存在します。別のプログラムを選択してください。',
      removeText: '削除',
      roleAssignmentText: 'ロール設定',
      roleSelectionText: 'ロールを選択してください',
      assignProgramText: '他のプログラムとも紐づける',
      programName: 'プログラム名',
      viewText: '参照',
      createText: '作成',
      editText: '編集',
      deleteText: '削除'
    }
  }
};
// ROLE ASSIGNMENT CHILD COMPONENT ENDS

// USER LAYOUT COMPONENT STARTS
export const userLayoutObject = {
  messages: {
    en: {
      personalInfoLabel: 'PERSONAL INFORMATION',
      roleAssignmentLabel: 'ROLE ASSIGNMENT',
      reviewSaveLabel: 'REVIEW & SAVE',
      closeBtnText: 'CLOSE',
      personalInfoFormTitle: 'PERSONAL INFORMATION',
      personalInfoText:
        'Personal information will be used to identify the user and will be displayed on the user’s Profile',
      roleInfoFormTitle: 'ROLE INFORMATION',
      roleInfoText:
        'Roles determine the functions a user can access within this application.',
      reviewInfoFormTitle: 'REVIEW',
      reviewInfoText:
        'Click on the Edit icon to make changes to this user before saving',
      successFormTitle: 'SUCCESS',
      previousBtnText: 'Previous',
      gotoUsersBtnText: 'Go To Users',
      cancelBtnText: 'Cancel',
      roleAssignmentNextBtnText: 'NEXT : ROLE ASSIGNMENT',
      previewNextBtnText: 'NEXT : REVIEW',
      saveUserBtnText: 'SAVE USER',
      newUserOnboardText: 'NEW USER ONBOARDING',
      editUserText: 'EDIT USER',
      emailSuccessText: 'An email has been sent to',
      successText:
        'asking this user to create a password. If the user doesn\'t take any action, the link will expire after 24 hours and you will be notified accordingly.',
      successAlertHeader: 'success',
      userSuccessMessage: 'User details have been successfully updated'
    },
    ja: {
      personalInfoLabel: '基本情報',
      roleAssignmentLabel: 'ロール設定',
      reviewSaveLabel: '登録内容確認・登録',
      closeBtnText: '閉じる',
      personalInfoFormTitle: '基本情報',
      personalInfoText:
        'このページで入力された情報は、ユーザの識別とプロフィール表示時に利用されます。',
      roleInfoFormTitle: 'ロール設定',
      roleInfoText:
        'ロールの設定によって、ユーザがこのアプリケーション内でアクセスできる機能を制限できます。',
      reviewInfoFormTitle: '登録内容確認',
      reviewInfoText: '「編集」をクリックすると、対象の情報を変更できます。',
      successFormTitle: '更新完了',
      previousBtnText: '戻る',
      gotoUsersBtnText: 'ユーザ一覧へ',
      cancelBtnText: 'キャンセル',
      roleAssignmentNextBtnText: '次へ : ロール設定',
      previewNextBtnText: '次へ : 登録内容確認',
      saveUserBtnText: '登録する',
      newUserOnboardText: 'ユーザ 登録',
      editUserText: 'ユーザ 編集',
      emailSuccessText: '初期パスワード設定メールが',
      successText:
        'に送信されました。メールを確認し、初期パスワードを設定してください。\nパスワード設定用リンクの有効期限は24時間です。期限が切れますとその旨が通知されます。',
      successAlertHeader: '更新成功',
      userSuccessMessage: 'ユーザ情報が正常に更新されました。'
    }
  }
};
// USER LAYOUT COMPONENT ENDS

// USER MODULE ENDS

// COMMUNIATION LAYOUT COMPONENT STARTS
export const communicationObj = {
  messages: {
    en: {
      comminicationLabel: 'COMMUNICATIONS',
      closePopUp: 'close',
      closeBtnText: 'CLOSE',
      commSetup: 'COMMUNICATION SETUP',
      commSetupInfoText:
        'A provider needs to be configured for every program that will be sending communication to members',
      pgmList: 'PROGRAM LIST',
      gridViewText: 'grid view',
      tableViewText: 'Table view',
      cardViewText: 'card view'
    },
    ja: {
      comminicationLabel: 'コミュニケーション設定',
      closePopUp: '閉じる',
      closeBtnText: '閉じる',
      commSetup: 'コミュニケーション設定',
      commSetupInfoText:
        '会員とのコミュニケーション（メール、プッシュ通知など）が発生するプログラムには、プロバイダー設定を行う必要があります。',
      pgmList: 'プログラム一覧',
      gridViewText: 'グリッドビュー',
      tableViewText: 'テーブルビュー',
      cardViewText: 'カードビュー'
    }
  }
};

// COMMUNIATION LAYOUT COMPONENT ENDS

// COMMUNIATION CARD VIEW COMPONENT STARTS
export const communicationCardViewObj = {
  messages: {
    en: {
      comminicationLabel: 'COMMUNICATIONS',
      pgmDescription: 'Program Description',
      Provider: 'Provider',
      providerSetup: 'Provider Setup:',
      campaign: 'campaign',
      GOTOCOMMMSG: 'GO TO COMM... MSG',
      editText: 'Edit',
      pgmName: 'Program Name:',
      pgmLogo: 'Program Logo',
      pgmNameTable: 'Program Name',
      des: 'Description',
      Channel: 'Channel',
      pgmSetup: 'Program Setup'
    },
    ja: {
      comminicationLabel: 'コミュニケーション',
      pgmDescription: 'プログラム概要',
      Provider: 'プロバイダー',
      providerSetup: 'プロバイダーセットアップ : ',
      campaign: 'キャンペーン',
      GOTOCOMMMSG: 'メッセージ一覧へ',
      editText: '編集',
      pgmName: 'プログラム名 : ',
      pgmLogo: 'プログラムロゴ',
      pgmNameTable: 'プログラム名',
      des: 'プログラム概要',
      Channel: 'チャネル',
      pgmSetup: 'プログラムセットアップ'
    }
  }
};

// Member Definition
export const memberDefinitionLanguageObj = {
  messages: {
    en: {
      memberDefinitionTitle: 'member definition',
      memberDefinitionFormTitle: 'MEMBER definition(S)',
      close: 'CLOSE',
      memberDefinitionList: 'MEMBER DEFINITION LIST'
    },
    ja: {
      memberDefinitionTitle: '会員情報定義',
      memberDefinitionFormTitle: '会員情報定義',
      close: '閉じる',
      memberDefinitionList: '会員情報定義一覧'
    }
  }
};

export const memberDefinitionTableViewObj = {
  messages: {
    en: {
      definitionName: 'Definition Name',
      mappedProgram: 'Mapped Program',
      description: 'Description',
      reviewStatus: 'Reviewed Status',
      edit: 'Edit',
      viewDetails: 'View Details'
    },
    ja: {
      definitionName: '会員情報定義名',
      mappedProgram: 'プログラム',
      description: '会員情報定義概要',
      reviewStatus: '確認ステータス',
      edit: '編集',
      viewDetails: '詳細を見る'
    }
  }
};

export const memberDefinitionGridViewObj = {
  messages: {
    en: {
      mappedProgram: 'Mapped Program',
      description: 'Description',
      reviewStatus: 'Reviewed Status',
      edit: 'Edit',
      viewDetails: 'View Details'
    },
    ja: {
      mappedProgram: 'プログラム',
      description: '会員情報定義概要',
      reviewStatus: '確認ステータス',
      edit: '編集',
      viewDetails: '詳細を見る'
    }
  }
};

export const memberAttributesObj = {
  messages: {
    en: {
      dataName: 'Data Name',
      dataType: 'Data Type',
      maxLength: 'Max Length',
      maxLengthContent:
        'Max length value is only required for String data type',
      required: 'Required',
      unique: 'Unique',
      encryption: 'Encryption',
      encryptionContent:
        'If personal customer information is defined as part of your member definition, it should be encrypted.',
      defaultField: 'Default Field',
      defaultFieldContent:
        'Changes to default value is effective for new data only; existing data is not impacted. Examples of some defaults by data type: “-1”for numbers, “Unknown” for strings, “False “for boolean, “1900-01-01T00:00:00Z” for dates',
      isDSARFlag: 'IsDSAR Flag',
      isDSARFlagContent:
        'Flag to determine if this field should be exported as part of a Data Subject Access Request',
      isRTBFFlag: 'IsRTBF Flag',
      isRTBFFlagContent:
        'Flag to determine if this field should be nulled out or some “N/A” type value set as part of a Request To Be Forgotten request',
      description: 'Description',
      actions: 'Actions',
      cancel: 'cancel',
      ok: 'OK',
      save: 'save',
      edit: 'edit',
      delete: 'delete',
      error: 'Error',
      addNewAttribute: 'add New Attribute'
    },
    ja: {
      dataName: '項目名',
      dataType: 'データ型',
      maxLength: '最大長',
      maxLengthContent: 'データ型がStringの場合のみ最大長が設定できます。',
      required: '必須',
      unique: 'ユニーク',
      encryption: '暗号化',
      encryptionContent: '個人情報を含む項目の場合、暗号化対象としてください。',
      defaultField: 'デフォルト値',
      defaultFieldContent:
        'デフォルト値を変更した場合、すでに存在するデータには影響せず、新たに入力されるデータから、変更後のデフォルト値が適用されます。\nデータ型別デフォルト値設定例は次の通りです。 number: “-1”, string: “Unknown”, boolean: “False “for boolean, date: “1900-01-01T00:00:00Z”',
      isDSARFlag: 'DSARフラグ',
      isDSARFlagContent:
        'Data Subject Access Request（データ主体によるアクセスリクエスト）によって出力されるべき項目にフラグを設定してください。',
      isRTBFFlag: 'RTBFフラグ',
      isRTBFFlagContent:
        'Right To Be Forgotten（忘れられる権利）のリクエストによって削除または匿名化処理されるべき項目にフラグを設定してください。',
      description: '概要',
      actions: '操作',
      cancel: 'cancel',
      ok: 'OK',
      save: 'save',
      edit: 'edit',
      delete: 'delete',
      error: 'エラー',
      addNewAttribute: '項目を追加する'
    }
  }
};

export const editMemberDefinitionLanguageObj = {
  messages: {
    en: {
      close: 'close',
      basicDetails: 'Basic details',
      definitionName: 'Definition Name',
      definitionDescription: 'Definition Description',
      info: 'info',
      infoAlertMessage:
        'Below are the standard Member definition attributes. To better integrate the Member data attributes within your requirements, you should consider customizing the attributes.',
      memberAttributes: 'Member Attributes',
      loyaltyCardAttributes: 'Loyalty Card attributes',
      memberIdentifiers: 'Member Identifiers',
      memberIdentifiersInfoText:
        'In LOD, there are different possibilities to uniquely identify a member. Once unique member identifiers are configured for your program, these identifiers will be used to look up information for all members',
      memberIdentifiersInfoHeader: 'Configure your unique member identifiers',
      memberIdentifierSubInfo1:
        'Select from the following data elements to be used as unique member identifiers.',
      memberIdentifierSubInfo2:
        'When a data element is selected as unique member identifiers then they will be set as unique and require.',
      loyaltyIdNumber: 'Loyalty ID Number',
      alternateID: 'Alternate ID',
      primaryEmailAddress: 'Primary Email Address',
      primaryPhoneNumber: 'Primary Phone Number',
      addNewIdentifier: 'add a new identifier',
      encryptionReview: 'Encryption Review',
      alert: 'Alert',
      alertMessage:
        'By saving, you have confirmed the encryption for member attributes have been reviewed.',
      cancel: 'cancel',
      confirm: 'Confirm',
      saveClose: 'Save & Close',
      loyaltyID: 'Loyalty ID',
      memberDefRevertChanges:
        'Updates to member definition will not be saved, do you wish to continue?',
      continue: 'Continue',
      cancelclose: 'Cancel & Close',
      memberStatus: 'Member Status'
    },
    ja: {
      close: '閉じる',
      basicDetails: '基本情報',
      definitionName: '会員情報定義名',
      definitionDescription: '会員情報定義概要',
      info: 'インフォーメーション',
      infoAlertMessage:
        '以下はデフォルトで用意される基本的な会員項目です。より要件に合致する会員情報定義を実現するためには、会員項目のカスタマイズをご検討ください。',
      memberAttributes: '会員項目',
      loyaltyCardAttributes: 'ロイヤリティーカード項目',
      memberIdentifiers: '会員識別項目',
      memberIdentifiersInfoText:
        'LODでは会員を一意に識別する方法がいくつか存在します。以下で設定した会員識別項目が、APIなどで一意の会員情報を参照・更新する際に利用できるようになります。',
      memberIdentifiersInfoHeader: '会員識別項目を設定してください',
      memberIdentifierSubInfo1:
        '以下の項目から会員識別項目として設定する項目を選択してください。',
      memberIdentifierSubInfo2:
        '会員識別項目として設定された項目には、必須およびユニークの制約が設定されます。',
      loyaltyIdNumber: 'Loyalty ID Number（ロイヤリティーID）',
      alternateID: 'Alternate ID（外部ID）',
      primaryEmailAddress: 'Primary Email Address（メインメールアドレス）',
      primaryPhoneNumber: 'Primary Phone Number（メイン電話番号）',
      addNewIdentifier: '会員識別項目を追加する',
      encryptionReview: '暗号化内容確認',
      alert: 'アラート',
      alertMessage:
        '「同意する」をクリックすることで、暗号化対象の会員項目をご確認いただいたこととし、変更内容を保存します。',
      cancel: 'キャンセル',
      confirm: '同意する',
      saveClose: '保存して閉じる',
      loyaltyID: 'ロイヤリティーID',
      memberDefRevertChanges:
        '編集中の会員情報定義は保存されません。よろしいですか？',
      continue: 'はい',
      cancelclose: 'キャンセルして閉じる',
      memberStatus: '会員ステータス'
    }
  }
};

// COMMUNICATION TABLE VIEW COMPONENT STARTS
export const communicationLanguageObj = {
  messages: {
    en: {
      headerTxt: 'Communications',
      createFirstTxt: 'Create your first',
      communicationMsgTxt: 'Communication MSG',
      noMsgTxt: 'You have no communication messages, why not create one.',
      clickHereTxt: 'Click here',
      CommunicationName: 'Communication Name',
      CommunicationMessages: 'Communication Messages',
      SearchCommunicationMessages: 'Search Communication Messages',
      createCommMessage: 'Create A COMM.. MESSAGE',
      MessageName: 'Message Name',
      Description: 'Description',
      Author: 'Author',
      resendLinkText: 'Resend Link',
      editLabel: 'Edit',
      Delete: 'Delete',
      copyLabel: 'Copy',
      previewLabel: 'Preview',
      activateLabel: 'Activate',
      deActivateLabel: 'De-activate',
      nameText: 'Name',
      programsText: 'Programs',
      externalIdText: 'External ID',
      createdOnText: 'Created Date',
      lastActivityText: 'Last Activity',
      statusText: 'Status',
      inActiveText: 'Inactive',
      activeText: 'Active',
      deActivateText: 'Deactive',
      activateUserText: 'Activate User',
      activateText: 'activate',
      deActivateUserText: 'De-activate User',
      deActivateLabelText: 'deactivate',
      Modifieddate: 'Modified date',
      Createddate: 'Created date',
      statusLabel: 'Status',
      GridView: 'Grid View',
      TableView: 'Table View',
      activityDate: 'MODIFIED DATE RANGE',
      fromLabel: 'From',
      toLabel: 'To',
      channel: 'CHANNEL',
      bookmark: 'BOOKMARK',
      clearBtnText: 'Cancel & Close',
      filterBtnText: 'APPLY FILTERS',
      draftLable: 'Draft',
      publishedLable: 'Published',
      showAllBookmarks: 'Show All Bookmarks',
      cancelBtnText: 'Cancel',
      okBtnText: 'Ok',
      loading: 'loading',
      Email: 'Email',
      Sms: 'SMS',
      PushNotification: 'Push Notification',
      LoyaltyMessages: 'Loyalty Messages',
      resetAll: 'Reset All',
      pgmErrorTxt: 'Provider set up has not been completed for the program ',
      adminContactTxt: '. Please contact your Administrator.',
      viewDetails: 'View Details'
    },
    ja: {
      viewDetails: '詳細を見る',
      previewLabel: 'プレビュー',
      headerTxt: 'コミュニケーションメッセージ',
      createFirstTxt: ' ',
      communicationMsgTxt: 'メッセージを登録しましょう',
      noMsgTxt:
        'コミュニケーションメッセージが登録されていません。登録を始めましょう。',
      clickHereTxt: 'ここをクリック',
      CommunicationName: 'メッセージ名',
      CommunicationMessages: '件',
      SearchCommunicationMessages: 'メッセージ検索',
      createCommMessage: 'メッセージ登録',
      MessageName: 'メッセージ名',
      Description: 'メッセージ概要',
      Author: '作成者',
      resendLinkText: 'リンク再送信',
      editLabel: '編集',
      copyLabel: 'コピー',
      Delete: '削除',
      activateLabel: '有効化',
      deActivateLabel: '無効化',
      nameText: 'メッセージ名',
      programsText: 'プログラム',
      externalIdText: '外部ID',
      createdOnText: '作成日',
      lastActivityText: '最終アクセス日時',
      statusText: 'ステータス',
      inActiveText: 'なし',
      activeText: 'アクティブ',
      deActivateText: '非アクティブ',
      activateUserText: 'ユーザを有効化する',
      activateText: ' ',
      deActivateUserText: 'ユーザを無効化する',
      deActivateLabelText: ' ',
      Modifieddate: '変更日',
      Createddate: '作成日',
      statusLabel: 'ステータス',
      GridView: 'グリッドビュー',
      TableView: 'テーブルビュー',
      activityDate: '日付範囲指定',
      fromLabel: '開始日',
      toLabel: '終了日',
      channel: 'チャネル',
      bookmark: 'ブックマーク',
      clearBtnText: 'キャンセルして閉じる',
      filterBtnText: 'フィルターを適用する',
      draftLable: '下書き',
      publishedLable: '公開済',
      showAllBookmarks: 'すべてのブックマークを表示',
      cancelBtnText: 'キャンセル',
      okBtnText: 'OK',
      loading: 'ロード中',
      Email: 'メール',
      Sms: 'SMS',
      PushNotification: 'プッシュ通知',
      LoyaltyMessages: 'ロイヤリティーメッセージ',
      resetAll: 'リセット',
      pgmErrorTxt:
        'コミュニケーションプロバイダー設定が完了していません（プログラム名 : ',
      adminContactTxt: '）。管理者に連絡してください。'
    }
  }
};

// Transaction Definiton COMPONENT STARTS
export const transactionDefinitonObj = {
  messages: {
    en: {
      noRecordsMessage: 'Click Create Transaction Definition to get started',
      trasactionIdentifierHeading:
        'Being able to uniquely identify a transaction is one of the key components to reward your members for their purchases and is critical to ensuring that duplicate points are not awarded. The LoyaltyOnDemand platform offers a couple of different configurations to accomplish this.',
      transactionIdentifierTitle:
        'The following data elements will be used as unique transaction identifiers.',
      transactionIdentifierPoint1: 'For transaction header: TxnHeaderId',
      transactionIdentifierPoint2: 'For transaction detail: TxnDetailId',
      transactionIdentifierPoint3: 'For transaction tender: TenderId',
      transactionIdentifierPoint4:
        'For transaction reward redemption: TxnRewardId',
      transactionInfocontent:
        'Create a transaction definition for your program entity.',
      infoText: 'info',
      txndeflable: 'Transaction definition name',
      txndefdesclable: 'Transaction definition description',
      txndefnameunique: 'Transaction Definition Name should be Unique',
      defdesc: 'Definition description:',
      pgmentities: 'Program Entities',
      edittxndefname: 'Edit transaction definition',
      creatxndefname: 'create transaction definition',
      clonetxndefname: 'Clone transaction definition',
      saveAndClose: 'SAVE & CLOSE',
      close: 'Close',
      Txndef: 'Transaction Definition',
      Txndefs: 'transaction definition(S)',
      TxndefList: 'TRANSACTION DEFINITION LIST',
      createTxndef: 'Create New DEFINITION',
      viewdetails: 'View Details',
      copy: 'copy',
      edit: 'edit',
      delete: 'Delete',
      defname: 'Definition Name',
      pgmentity: 'Program Entities',
      desc: 'Description',
      programEntityMapping: 'Program Entity Mapping',
      selectProgramEntity:
        'Please select a Program Entity that this Transaction definition should be mapped to:',
      programEntity: 'PROGRAM ENTITY',
      clickHereSelectText: 'Click Here to Select',
      selectedProgramEntity: 'Selected Program Entity',
      noProgramEntity: 'No Program Entity Selected',
      progHierarchyText: 'Program Hierarchy',
      alreadyAssignedProgramEntityMessage:
        'This Program Entity has already been assigned to another Transaction definition and cannot be selected anymore.',
      cancel: 'Cancel',
      done: 'Done',
      deleteAlertName: 'Delete',
      deleteAlertBody:
        'Are you sure you want to delete the selected transaction definition?',
      yes: 'Yes',
      no: 'No',
      newTransactionDef: 'new transaction definition',
      basicDetails: 'Basic details',
      attibutename: ' Attribute Name',
      datatype: 'Data Type',
      maxlength: 'Max Length',
      maxlengthcontent:
        'Max length value is only required for String data type',
      required: 'Required',
      unique: 'Unique',
      defaultfield: ' Default Field',
      defaultfieldcontent:
        'Changes to default value is effective for new data only; existing data is not impacted.  Examples of some defaults by data type: “-1”for numbers, “Unknown” for strings, “False “for boolean, “1900-01-01T00:00:00Z” for dates',
      isdsarflag: ' IsDSAR Flag',
      isdsarflagcontent:
        'Flag to determine if this field should be exported as part of a Data Subject Access Request',
      isrtbfflag: ' IsRTBF Flag',
      isrtbfflagcontent:
        'Flag to determine if this field should be nulled out or some “N/A” type value set as part of a Request To Be Forgotten request',
      description: 'Description',
      action: 'Actions',
      addnewattribute: ' add New Attribute',
      headerAttributes: 'Header Attributes',
      detailsAttributes: 'Detail Attributes',
      tenderAttributes: 'Tender Attributes',
      transactionIdentifiers: 'Transaction Identifiers',
      rewardRedemption: 'Reward Redemption',
      addNewAttribute: 'add New Attribute',
      continue: 'continue',
      alert: 'ALERT',
      noSavingAlert:
        'Transaction definition will not be saved, do you wish to continue?',
      mapProgramAlert: 'Please map a program to create transaction definition',
      txndefnamerequired: 'Transaction definition name required'
    },
    ja: {
      mapProgramAlert:
        'トランザクション情報定義がプログラムエンティティにマッピングされていません。マッピングを行ってください。',
      noSavingAlert:
        '編集中のトランザクション情報定義は保存されません。よろしいですか？',
      alert: 'アラート',
      continue: '続ける',
      saveAndClose: '保存して閉じる',
      noRecordsMessage:
        '「トランザクション情報定義登録」をクリックしてトランザクション情報定義を追加しましょう',
      trasactionIdentifierHeading:
        'ロイヤリティープログラムの重要な要素の1つである、購買によるポイントを正しく、重複なく付与するためには、購買トランザクションを一意に識別できる必要があります。LoyaltyOnDemandプラットフォームでは、トランザクションを一意に識別するためのデータ項目が複数存在します。',
      transactionIdentifierTitle:
        '以下のデータ項目は、購買トランザクションの識別子として使用されます。',
      transactionIdentifierPoint1:
        'トランザクションヘッダーの場合：TxnHeaderId',
      transactionIdentifierPoint2: 'トランザクション詳細の場合：TxnDetailId',
      transactionIdentifierPoint3: '支払方法情報の場合：TenderId',
      transactionIdentifierPoint4: '特典引換情報の場合：TxnRewardId',
      transactionInfocontent:
        'トランザクション情報を扱うプログラムエンティティに対して、トランザクション情報を定義する必要があります。',
      infoText: 'インフォメーション',
      txndeflable: 'トランザクション情報定義名',
      txndefdesclable: 'トランザクション情報定義概要',
      txndefnameunique:
        '設定された名称はすでに存在します。別の名前を設定してください。',
      defdesc: 'トランザクション情報定義概要 :',
      pgmentities: 'プログラムエンティティ :',
      edittxndefname: 'トランザクション情報定義 編集',
      creatxndefname: 'トランザクション情報定義 登録',
      clonetxndefname: 'トランザクション情報定義 コピー',
      close: '閉じる',
      Txndef: 'トランザクション情報定義',
      Txndefs: 'トランザクション情報定義',
      TxndefList: 'トランザクション情報定義一覧',
      createTxndef: 'トランザクション情報定義登録',
      viewdetails: '詳細を見る',
      copy: 'コピー',
      edit: '編集',
      delete: '削除',
      defname: 'トランザクション情報定義名',
      pgmentity: 'プログラムエンティティ',
      desc: 'トランザクション情報定義概要',
      programEntityMapping: 'プログラムエンティティマッピング',
      selectProgramEntity:
        'このトランザクション情報定義をマッピングするエンティティを選択してください ',
      programEntity: 'プログラムエンティティ',
      clickHereSelectText: 'ここをクリックして選択してください',
      selectedProgramEntity: '選択されたプログラムエンティティ',
      noProgramEntity: 'プログラムエンティティが選択されていません',
      progHierarchyText: 'プログラム構成',
      alreadyAssignedProgramEntityMessage:
        'このプログラムエンティティはすでに別のトランザクション情報定義にマッピングされているため、選択できません。',
      cancel: 'キャンセル',
      done: '確定する',
      deleteAlertName: '削除',
      deleteAlertBody: 'トランザクション情報定義を削除します。よろしいですか？',
      yes: 'はい',
      no: 'いいえ',
      newTransactionDef: 'トランザクション情報定義 登録',
      basicDetails: '基本情報',
      attibutename: '項目名',
      datatype: 'データ型',
      maxlength: '最大長',
      maxlengthcontent: 'データ型がStringの場合のみ最大長が設定できます。',
      required: '必須',
      unique: 'ユニーク',
      defaultfield: 'デフォルト値',
      defaultfieldcontent:
        'デフォルト値を変更した場合、すでに存在するデータには影響せず、新たに入力されるデータから、変更後のデフォルト値が適用されます。\nデータ型別デフォルト値設定例は次の通りです。 number: “-1”, string: “Unknown”, boolean: “False” for boolean, date: “1900-01-01T00:00:00Z”',
      isdsarflag: 'DSARフラグ',
      isdsarflagcontent:
        'Data Subject Access Request（データ主体によるアクセスリクエスト）によって出力されるべき項目にフラグを設定してください。',
      isrtbfflag: 'RTBFフラグ',
      isrtbfflagcontent:
        'Right To Be Forgotten（忘れられる権利）のリクエストによって削除または匿名化処理されるべき項目にフラグを設定してください。',
      description: '概要',
      action: '操作',
      addnewattribute: '項目を追加する',
      headerAttributes: 'トランザクションヘッダー',
      detailsAttributes: 'トランザクション詳細',
      tenderAttributes: '支払方法情報',
      transactionIdentifiers: 'トランザクション識別子',
      rewardRedemption: '特典引換情報',
      addNewAttribute: '項目を追加する',
      txndefnamerequired: '「トランザクション情報定義名」を入力してください'
    }
  }
};

export const storeListsObj = {
  messages: {
    en: {
      message: {
        mainHeader: 'Stores',
        searchLabel: 'Search Stores by Name, Store Code and Brand Store Number',
        switchEntity: 'Switch Entity',
        createLabel: 'Create a store',
        loadingText: 'LOAD MORE',
        gridView: 'Grid view',
        tableView: 'Table view',
        cardView: 'Card view',
        storeName: 'Name',
        storeCode: 'Store Code',
        programEntity: 'Program Entity',
        address: 'Store Address',
        openDate: 'Open Date',
        closeDate: 'Close Date',
        status: 'Status',
        viewText: 'View Detail',
        editText: 'Edit',
        cloneText: 'Clone',
        deleteText: 'Delete',
        noRecordFoundHeader: 'NO STORES FOUND',
        noResultMessage:
          'The search could not find any store based on the search text you entered in the search field. Please revise the search text to try again.',
        copyText: 'Copy',
        openDateRange: 'OPEN DATE',
        closeDateRange: 'CLOSE DATE',
        resetBtn: 'Reset',
        applyFilterBtn: 'Apply Filter',
        active: 'Active',
        inactive: 'Inactive',
        fromTxt: 'From',
        toTxt: 'To',
        errorMsg: '"From" date cannot be later than "To" date.'
      }
    },
    ja: {
      message: {
        mainHeader: '店舗',
        searchLabel: '店舗名、店舗コード、ブランド番号で検索',
        switchEntity: 'エンティティ切替',
        createLabel: '店舗登録',
        loadingText: 'ロード中',
        gridView: 'グリッドビュー',
        tableView: 'テーブルビュー',
        cardView: 'カードビュー',
        storeName: '店舗名',
        storeCode: '店舗コード',
        programEntity: 'プログラムエンティティ',
        address: '店舗住所',
        openDate: '開始年月日',
        closeDate: '終了年月日',
        status: 'ステータス',
        viewText: '詳細を見る',
        editText: '編集',
        cloneText: 'コピー',
        deleteText: '削除',
        noRecordFoundHeader: '検索結果がみつかりませんでした',
        noResultMessage:
          '検索結果がみつかりませんでした。検索条件を修正して、もう一度お試しください。',
        copyText: 'コピー',
        openDateRange: '日付範囲指定（開始年月日）',
        closeDateRange: '日付範囲指定（終了年月日）',
        resetBtn: 'リセット',
        applyFilterBtn: 'フィルターを適用する',
        active: 'アクティブ',
        inactive: '非アクティブ',
        fromTxt: '開始日',
        toTxt: '終了日',
        errorMsg: '「開始日」には「終了日」以前の日付を設定してください'
      }
    }
  }
};

export const productListObj = {
  messages: {
    en: {
      gridViewText: 'grid view',
      products: 'products',
      cardViewText: 'card view',
      tableViewText: 'Table view',
      createAProduct: 'Create A Product',
      Products: 'Products',
      loading: 'loading',
      searchProductText: 'Search Products by Name, External ID',
      tooltip:
        'By default all products for the selected program entity are displayed. You can switch to a different program entity by clicking on the Switch Entity option.',
      basePrice: 'Base Price',
      externalId: 'External ID',
      productDescription: 'Product Description',
      programEntityLabel: 'Program Entity',
      visibility: 'Visibility',
      viewDetails: 'View Details',
      nameText: 'Name',
      descriptionLabel: 'Description',
      selectProgramEntityText: 'SELECT PROGRAM ENTITY',
      programEntitySwitchOption:
        'To which Program Entity you would like to switch?',
      selectProgramEntityLabel: 'Select Program Entity',
      cancelBtnTextPopUp: 'CANCEL',
      continueBtnText: 'CONTINUE',
      productDetails: 'Product Details',
      productNameText: 'Product Name',
      switchEntity: 'Switch Entity'
    },
    ja: {
      gridViewText: 'グリッドビュー',
      cardViewText: 'カードビュー',
      tableViewText: 'テーブルビュー',
      createAProduct: '商品登録',
      Products: '商品',
      loading: 'ロード中',
      searchProductText: '商品名、外部IDで検索',
      tooltip:
        '選択中のプログラムエンティティに紐づく商品一覧が表示されます。 「エンティティ切替」をクリックすると、別のプログラムエンティティに切り替えることができます。',
      basePrice: '単価',
      externalId: '外部ID',
      productDescription: '商品概要',
      programEntityLabel: 'プログラムエンティティ',
      visibility: '詳細を見る',
      viewDetails: '詳細を見る',
      nameText: '商品名',
      descriptionLabel: '商品概要',
      selectProgramEntityText: 'プログラムエンティティ選択',
      programEntitySwitchOption: 'どのプログラムエンティティに切り替えますか？',
      selectProgramEntityLabel: 'プログラムエンティティを選択してください',
      cancelBtnTextPopUp: 'キャンセル',
      continueBtnText: '続ける',
      productDetails: '商品詳細',
      productNameText: '商品名',
      switchEntity: 'エンティティ切替'
    }
  }
};

export const storeDetailObj = {
  messages: {
    en: {
      storeDetails: 'STORE DETAILS',
      storeCode: 'Store Code',
      storeEmail: 'Email',
      brandStoreName: 'Brand Store Number',
      phoneNumber: 'Phone Number',
      storeAddress: 'Store Address',
      storeTiming: 'ADDITIONAL STORE INFORMATION',
      opensAt: 'Open Date',
      storeStatus: 'Store Status',
      closesAt: 'Close Date',
      devision: 'Devision',
      category: 'Category',
      class: 'Class',
      department: 'Department',
      subCategory: 'Sub Category',
      subClass: 'Sub Class',
      storeLocation: 'STORE LOCATION',
      editLabel: 'Edit',
      copyLabel: 'Copy',
      deleteLabel: 'Delete',
      viewDetails: 'View Details',
      region: 'Region',
      district: 'District',
      zone: 'Zone'
    },
    ja: {
      storeDetails: '店舗詳細',
      storeCode: '店舗コード',
      storeEmail: 'メール',
      brandStoreName: 'ブランド番号',
      phoneNumber: '電話番号',
      storeAddress: '店舗住所',
      storeTiming: '店舗追加情報',
      opensAt: '開始年月日',
      storeStatus: 'ステータス',
      closesAt: '終了年月日',
      devision: '事業',
      category: 'カテゴリー',
      class: 'クラス',
      department: '部門',
      subCategory: 'サブカテゴリー',
      subClass: 'サブクラス',
      storeLocation: '店舗位置',
      editLabel: '編集',
      copyLabel: 'コピー',
      deleteLabel: '削除',
      viewDetails: '詳細を見る',
      region: '管轄',
      district: '地区',
      zone: 'ゾーン'
    }
  }
};

export const storeGroupBasicInfoObj = {
  messages: {
    en: {
      nameAlreadyExists: 'Store group name already exists. Please enter a unique store group name.',
      formTitle: 'BASIC INFORMATION',
      infoText:
        'Store group name and store group description are defined here.',
      storeDetails: 'STORE GROUP DETAILS',
      storeGroupName: 'Store Group Name',
      storeGroupDes: 'Store Group Description',
      storeCreatedBy: 'Created By',
      storeInfo: 'Info',
      storeInfoText:
        ' A store group is a dynamic grouping of stores in the system. The store group can be used in inclusion and exclusion criteria in business rules.',
      commNameRequired: 'Store group name is required'
    },
    ja: {
      nameAlreadyExists: '店舗グループ名はすでに存在します。別の店舗グループ名を入力してください。',
      formTitle: '基本情報',
      infoText: '店舗グループ名と店舗グループ概要を設定してください。',
      storeDetails: '店舗グループ詳細',
      storeGroupName: '店舗グループ名',
      storeGroupDes: '店舗グループ概要',
      storeCreatedBy: '作成者',
      storeInfo: 'インフォメーション',
      storeInfoText:
        '店舗グループを利用することで、登録済みの店舗が動的にグループ化されます。定義した店舗グループは、ビジネスルールの設定時に、適用条件と除外条件で使用できます。',
      commNameRequired: '「店舗グループ名」を入力してください'
    }
  }
};
export const batchImportObj = {
  messages: {
    en: {
      batchImportHeaderText: 'Batch import',
      closeBtn: 'CLOSE',
      batchImportsText: 'batch import setup',
      batchImportInfoText:
        'Create, manage, and view all batch process configurations and file statuses',
      locationsTabText: 'File Locations',
      encryptionTabText: 'ENCRYPTION KEYS',
      allFilesText: 'All Files'
    },
    ja: {
      batchImportHeaderText: 'バッチインポート',
      closeBtn: '閉じる',
      batchImportsText: 'バッチインポート',
      batchImportInfoText:
        'バッチプロセスの作成と管理、および設定内容の参照とファイルステータスの確認ができます。',
      locationsTabText: 'ファイルロケーション',
      encryptionTabText: '暗号化キー',
      allFilesText: 'ファイル一覧'
    }
  }
};

export const encryptionKeyObj = {
  messages: {
    en: {
      encryptionListText: 'ENCRYPTION list',
      addEncryptionKeyText: 'ADD new encryption key',
      gridViewText: 'grid view',
      tableViewText: 'Table view',
      cardViewText: 'card view'
    },
    ja: {
      encryptionListText: '暗号化キー一覧',
      addEncryptionKeyText: '暗号化キー登録',
      gridViewText: 'グリッドビュー',
      cardViewText: 'カードビュー',
      tableViewText: 'テーブルビュー'
    }
  }
};

export const encryptionGridViewObj = {
  messages: {
    en: {
      algorithm: 'Algorithm',
      keySize: 'Key Size',
      description: 'Description',
      createdDate: 'Created Date',
      expiration: 'Expiration',
      encryptionKey: 'Encryption Key',
      downloadkey: 'Download key',
      edit: 'Edit',
      delete: 'Delete',
      encryptionName: 'Encryption Name'
    },
    ja: {
      algorithm: 'アルゴリズム',
      keySize: 'サイズ',
      description: '暗号化キー概要',
      createdDate: '作成日時',
      expiration: '有効期限',
      encryptionKey: '暗号化キー',
      downloadkey: 'ダウンロード',
      edit: '編集',
      delete: '削除',
      encryptionName: '暗号化キー名'
    }
  }
};

export const editEncryptionObj = {
  messages: {
    en: {
      batchImportText: 'batch import',
      encryptionText: 'encryption',
      newText: 'new',
      editText: 'edit',
      close: 'Close',
      basicInformation: 'basic information',
      infoText:
        'An encryption setup is required for batch import process so that the user can create an encryption which can be used for batch import process. The same encryption will be displayed under Batch import encryption selection.',
      encryptionDetails: 'encryption details',
      encryptionKeyName: 'Encryption Key Name',
      encryptionKeyNameMessage: 'Please fill the encryption key name',
      encryptionKeyDescription: 'Encryption Key Description',
      encryptionKeyDescriptionMessage:
        'Please fill the encryption key description',
      algorithm: 'Algorithm',
      keySize: 'Key Size',
      expiration: 'Expiration',
      passphrase: 'Passphrase',
      passphraseMessage: 'Please fill the passphrase',
      cancel: 'Cancel',
      nextbtn: 'NEXT: REVIEW',
      editEncrYption: 'EDIT encrYption',
      back: 'back',
      reviewText: 'Review',
      reviewInfo: 'Review and Edit the file encryption details',
      regeneratekey: 'regenerate key',
      alertBodyMessage:
        'Please ensure that all files that were encrypted using the old key have been processed completely. Once the key is regenerated, the new key will be effective immediately.',
      alertHeader: 'Alert',
      confirmMessage: 'Do you wish to continue regenerate the key?',
      no: 'No',
      yes: 'Yes',
      infoTitle: 'Info'
    },
    ja: {
      batchImportText: 'バッチインポート',
      encryptionText: '暗号化キー',
      newText: '登録 - ',
      editText: '編集 - ',
      close: '閉じる',
      basicInformation: '基本情報',
      infoText:
        'バッチインポートの実行には暗号化キーの設定が必要です。ここで設定した暗号化キーがバッチインポート登録時に利用できます。',
      encryptionDetails: '暗号化キー詳細',
      encryptionKeyName: '暗号化キー名',
      encryptionKeyNameMessage: '「暗号化キー名」を入力してください',
      encryptionKeyDescription: '暗号化キー概要',
      encryptionKeyDescriptionMessage: '「暗号化キー概要」を入力してください',
      algorithm: 'アルゴリズム',
      keySize: 'サイズ',
      expiration: '有効期限',
      passphrase: 'パスフレーズ',
      passphraseMessage: '「パスフレーズ」を入力してください',
      cancel: 'キャンセル',
      nextbtn: '次へ : 登録内容確認',
      editEncrYption: '編集 - 暗号化キー',
      back: '戻る',
      reviewText: '登録内容確認',
      reviewInfo:
        '暗号化キー詳細の設定内容を確認し、必要に応じて修正してください。',
      regeneratekey: 'キーの再生成',
      alertBodyMessage:
        '再生成前の暗号化キーを利用したファイルの処理がすべて完了していることを確認してください。キーを再生成すると、新たなキーが即時適用となります。',
      alertHeader: 'アラート',
      confirmMessage: 'キーを再生成します。よろしいですか？',
      no: 'いいえ',
      yes: 'はい',
      infoTitle: 'インフォメーション'
    }
  }
};

export const SuccessEncryptionObj = {
  messages: {
    en: {
      editEncrYption: 'EDIT encryption',
      batchImportText: 'batch import',
      back: 'back',
      close: 'Close',
      newKayGen: 'Create another Encryption key',
      newKeyGenMessage: 'Would you like to create another Encryption key?',
      clickText: 'Click here',
      successText: 'Success',
      errorText: 'Error',
      successMessage: 'File Encryption created successfully',
      errorMessage:
        'File Encryption could not be created. Kindly re-create a new Encryption Edited',
      duplicateKeyMessage: 'Encryption with the same Key Name already exists'
    },
    ja: {
      editEncrYption: '編集 - 暗号化キー',
      batchImportText: 'バッチインポート',
      back: '戻る',
      close: '閉じる',
      newKayGen: '新たに暗号化キーを追加する',
      newKeyGenMessage: '続けて暗号化キーを追加するには、',
      clickText: 'ここをクリックしてください',
      successText: '更新成功',
      errorText: 'エラー',
      successMessage: '暗号化キーの生成が正常に終了しました',
      errorMessage: '暗号化キーの生成に失敗しました。登録しなおしてください。',
      duplicateKeyMessage:
        'すでに同一の暗号化キー名が存在します。別の名前を設定してください。'
    }
  }
};

export const locationsObj = {
  messages: {
    en: {
      locationListText: ' File Locations list',
      addNewLocationText: 'ADD new location',
      gridViewText: 'grid view',
      tableViewText: 'Table view',
      cardViewText: 'card view'
    },
    ja: {
      locationListText: 'ファイルロケーション一覧',
      addNewLocationText: 'ファイルロケーション登録',
      gridViewText: 'グリッドビュー',
      cardViewText: 'カードビュー',
      tableViewText: 'テーブルビュー'
    }
  }
};

export const addBatchImportObj = {
  messages: {
    en: {
      batchImportText: 'batch import',
      back: 'back',
      changesText: 'ALL CHANGES SAVED',
      cancel: 'Cancel',
      close: 'Close',
      addNewImportText: 'Add another Batch Import',
      askNewText: ' Would you like to add another batch import?',
      clickHereText: 'Click here',
      edit: 'edit',
      new: 'new',
      nextText: 'Next: Review',
      createText: 'Create'
    },
    ja: {
      batchImportText: 'バッチインポート',
      back: '戻る',
      changesText: '変更内容が保存されました',
      cancel: 'キャンセル',
      close: '閉じる',
      addNewImportText: '新たにバッチインポートを追加する',
      askNewText: '続けてバッチインポートを追加するには、',
      clickHereText: 'ここをクリックしてください',
      edit: '編集 - ',
      new: '登録 - ',
      nextText: '次へ : 登録内容確認',
      createText: '登録する'
    }
  }
};

export const basicInforimationObj = {
  messages: {
    en: {
      basicInfoText: 'basic information',
      basicInfoMessage:
        'Fill in the basic information for the batch import process and submit the files for processing',
      batchImportDetails: 'batch import details',
      batchName: 'Batch Name',
      batchNameMessage: 'Please enter batch name',
      batchDescription: 'Batch Description',
      batchDescriptionMessage: 'Please enter batch description',
      batchTemplate: 'Batch Template *',
      batchTemplateMessage: 'Please select batch template',
      selectProgram: 'Select Program *',
      selectProgramMessage: 'Please select program',
      fileLocation: 'File Location *',
      fileLocationMessage: 'Please select file location',
      namingConventionPrefix: 'Naming Convention Prefix *',
      namingConventionPrefixMessage: 'Please enter naming convention prefix',
      namingConventionPrefixMessageAlph:
        'Please enter only alphabetic characters, numbers, dashes or underscores.',
      example: 'Example',
      emailNotificationText: 'email notification',
      emailNotificationMessage: 'Email notification when file is received',
      optIn: 'OPt-IN',
      emailNotificationFails: 'Email notification when processing fails *',
      emailNotificationProcessFails: 'Email notification when processing fails',
      emailNotificationComplete: 'Email notification when processing completes',
      encryptionKey: 'encryption key',
      fileEncryptionKey: 'File Encryption Key *',
      fileEncryptionKeyMessage: 'Please select file encryption key',
      setDeliveryTime: 'set expected Delivery time',
      yes: 'Yes',
      no: 'No',
      timeZone: 'Time and time zone',
      timeZoneMessage:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.',
      startTime: 'Start Time',
      cancel: 'Cancel',
      ok: 'ok',
      gracePeriod: 'Grace Period',
      timeZoneText: 'Time zone',
      emailAlert: 'Email alert',
      emailAlertInfo:
        'An alert will be sent to this email address if the expected file is not received by the expected date and time or before the grace period has elapsed.',
      emailAddress: 'Email Address for Alert',
      processDuplicateFiles: 'process duplicate files',
      emailAddressReq: 'Email Address for Alert*',
      emailAddressReqMessage: 'Please select email address',
      rejectFile: 'REJECT FILE',
      fileExport: 'File Export',
      topicText: 'Topics (Kafka)',
      helpTopics: 'Help Topics',
      downloadTemplate: 'Download Template',
      batchProcessText:
        'Files submitted for batch processing are required to follow the prescribed template.',
      fileSetupText:
        'A location setup is required to specify the source location of the files to be processed.',
      locationsText: 'Locations',
      manageLocations: 'Manage Locations',
      namingConvention: 'Naming Convention',
      namingConventionText:
        'The batch process will use the Naming Convention to identify the correct files to retrieve for this batch configuration.',
      encryptionsText: 'Encryptions',
      encryptionsTextMessage:
        'An encryption setup is required to allow the batch process to properly decrypt the files retrieved for processing. Encryptions configured here will be displayed as File Encryption Key options when configuring a batch import process.',
      manageEncryptions: 'Manage Encryptions',
      reviewText: 'Review',
      reviewInfoText: 'Review and Edit the batch import details',
      edit: 'Edit',
      batchTemplateText: 'Batch Template',
      selectProgramText: 'Select Program',
      fileLocationText: 'File Location',
      fileEncryptionKeyText: 'File Encryption Key',
      expectedDeliveryby: 'Expected Delivery by',
      SelectedDaysoftheMonth: 'Selected Days of the Month',
      selectedTime: 'Selected Time',
      duplicateFiles: 'Duplicate Files',
      rejectedFiles: 'Rejected files',
      csvNamingConvention: '_YYYYMMDDhhmissms.csv',
      exampleNamingConvention: 'Products_GAP_2020100817403950.csv',
      fileReceiptNotificationEmail:
        'Please enter the email address when file is received',
      validEmailAddress: 'Please enter a valid email address ',
      fileProcessFailureNotificationEmail:
        'Please enter the email address when processing fails',
      fileProcessCompletionNotificationEmail:
        'Please enter the email when processing completes'
    },
    ja: {
      basicInfoText: '基本情報',
      basicInfoMessage:
        'バッチインポートの基本情報を入力してください。登録後、インポート処理が可能になります。',
      batchImportDetails: 'バッチインポート詳細',
      batchName: 'バッチインポート名',
      batchNameMessage: '「バッチインポート名」を入力してください',
      batchDescription: 'バッチインポート概要',
      batchDescriptionMessage: '「バッチインポート概要」を入力してください',
      batchTemplate: 'バッチテンプレート *',
      batchTemplateMessage: '「バッチテンプレート」を選択してください',
      selectProgram: 'プログラム *',
      selectProgramMessage: '「プログラム」を選択してください',
      fileLocation: 'ファイルロケーション *',
      fileLocationMessage: '「ファイルロケーションを選択してください」',
      namingConventionPrefix: 'ファイル名接頭辞 *',
      namingConventionPrefixMessage: '「ファイル名接頭辞」を入力してください',
      namingConventionPrefixMessageAlph:
        '「ファイル名接頭辞」には、アルファベット、数字、ハイフン、アンダースコアのみ利用できます。',
      example: '例',
      emailNotificationText: 'メール通知',
      emailNotificationMessage: 'メールアドレス（ファイル受信通知用）',
      optIn: 'オプトイン',
      emailNotificationFails: 'メールアドレス（プロセス異常終了通知用）*',
      emailNotificationProcessFails: 'メールアドレス（プロセス異常終了通知用）',
      emailNotificationComplete: 'メールアドレス（プロセス正常終了通知用）',
      encryptionKey: '暗号化キー',
      fileEncryptionKey: 'ファイル暗号化キー *',
      fileEncryptionKeyMessage: '「ファイル暗号化キー」を選択してください',
      setDeliveryTime: '実行日を設定する',
      yes: 'はい',
      no: 'いいえ',
      timeZone: '時間・タイムゾーン',
      timeZoneMessage:
        'インポート処理を実行する時間およびタイムゾーンを設定してください。',
      startTime: '実行時間',
      cancel: 'キャンセル',
      ok: 'OK',
      gracePeriod: '猶予時間',
      timeZoneText: 'タイムゾーン',
      emailAlert: 'アラートメール通知',
      emailAlertInfo:
        '設定した実行時間（猶予時間を含む）にファイルが受信されない場合、指定されたメールアドレスにアラートメールが送信されます。',
      emailAddress: 'メールアドレス（アラートメール通知用）',
      processDuplicateFiles: 'ファイルを複製する',
      emailAddressReq: 'メールアドレス（アラートメール通知用）*',
      emailAddressReqMessage:
        '「メールアドレス（アラートメール通知用）」を選択してください',
      rejectFile: 'リジェクトファイル',
      fileExport: 'ファイル出力',
      topicText: 'トピックス (Kafka)',
      helpTopics: 'ヘルプ',
      downloadTemplate: 'テンプレートのダウンロード',
      batchProcessText:
        'バッチ処理でインポートするファイルは、当システムからダウンロードされたファイルテンプレートを利用して作成してください。',
      fileSetupText:
        'バッチ処理対象のファイルがどこで連携されるのかを指定するために、ファイルロケーションを定義する必要があります。',
      locationsText: 'ファイルロケーション',
      manageLocations: 'ファイルロケーションを管理する',
      namingConvention: '命名規則',
      namingConventionText:
        'ファイル名接頭辞の命名規則に沿ったファイルのみがバッチインポートにて処理されます。',
      encryptionsText: '暗号化',
      encryptionsTextMessage:
        '連携された暗号化済みのファイルを復号処理するために、暗号化キーの設定が必要です。暗号化キー登録で設定した暗号化キーがバッチインポートの設定時に選択できます。',
      manageEncryptions: '暗号化キーを管理する',
      reviewText: '登録内容確認',
      reviewInfoText:
        'バッチインポートの設定内容を確認し、必要に応じて修正してください。',
      edit: '編集',
      batchTemplateText: 'バッチテンプレート',
      selectProgramText: 'プログラム',
      fileLocationText: 'ファイルロケーション',
      fileEncryptionKeyText: 'ファイル暗号化キー',
      expectedDeliveryby: '実行スケジュール',
      SelectedDaysoftheMonth: '日付',
      selectedTime: '時間',
      duplicateFiles: 'ファイルを複製する',
      rejectedFiles: 'リジェクトファイル',
      csvNamingConvention: '_YYYYMMDDhhmissms.csv',
      exampleNamingConvention: 'Products_GAP_2020100817403950.csv',
      fileReceiptNotificationEmail:
        '「メールアドレス（ファイル受信通知用）」を入力してください',
      validEmailAddress: '正しいメールアドレスを入力してください',
      fileProcessFailureNotificationEmail:
        '「メールアドレス（プロセス異常終了通知用）」を入力してください',
      fileProcessCompletionNotificationEmail:
        '「メールアドレス（プロセス正常終了通知用）」を入力してください'
    }
  }
};

export const batchImportStatusObj = {
  messages: {
    en: {
      successText: 'Success',
      successImpText: 'SUCCESS',
      errorImpText: 'ERROR',
      errorText: 'Error',
      successMessage: 'Batch import created successfully',
      errorMessage:
        'Batch import could not be created. Kindly re-upload the data.',
      successUpdateMessage: 'Batch import updated successfully',
      errorUpdateMessage:
        'Batch import could not be updated. Kindly re-upload the data.'
    },
    ja: {
      successText: '更新完了',
      successImpText: '更新成功',
      errorImpText: 'エラー',
      errorText: 'エラー',
      successMessage: 'バッチインポートが正常に登録されました。',
      errorMessage:
        'バッチインポートの登録に失敗しました。再度登録しなおしてください。',
      successUpdateMessage: 'Batch import updated successfully',
      errorUpdateMessage:
        'Batch import could not be updated. Kindly re-upload the data.'
    }
  }
};

export const expectedDeliveryTimeObj = {
  messages: {
    en: {
      weekly: 'Weekly',
      monthly: 'Monthly',
      everyDay: 'Every day',
      daysoftheMonth: 'Select Days of the Month',
      select: 'Select',
      selectDay: 'Select Day',
      monthText: 'month(s)'
    },
    ja: {
      weekly: '週次',
      monthly: '月次',
      everyDay: '毎日',
      daysoftheMonth: '日付選択',
      select: '選択',
      selectDay: '日付選択',
      monthText: 'か月おきに実行'
    }
  }
};

export const addLocationStatusObj = {
  messages: {
    en: {
      successText: 'Success',
      successImpText: 'SUCCESS',
      errorImpText: 'ERROR',
      errorText: 'Error',
      successMessage: 'File location created successfully',
      errorMessage:
        'File location could not be created. Kindly re-upload the file.'
    },
    ja: {
      successText: '更新完了',
      successImpText: '更新成功',
      errorImpText: 'エラー',
      errorText: 'エラー',
      successMessage: 'ファイルロケーションが正常に登録されました。',
      errorMessage:
        'ファイルロケーションの登録に失敗しました。再度登録しなおしてください。'
    }
  }
};

export const locationBasicInfoObj = {
  messages: {
    en: {
      basicInfo: 'basic information',
      basicInfoMessage:
        'A location setup is required to specify the source location of the files to be processed. Locations configured here will be displayed as File Location options when configuring a batch import process.',
      fileLocationDetails: 'File location details',
      fileLocationName: 'File Location Name',
      fileLocationType: 'File Location Type',
      infoText: 'Info',
      objectStoreDetails: 'OBJECT STORE DETAILS',
      headerInfoText: 'Information',
      headerInfoBodyText:
        'There will be a read-only info that will show the bucket path (TBD) for the tenant.',
      fileLocationDescription: 'File Location Description',
      fileLocation: 'file location',
      back: 'Back',
      changesSavedText: 'ALL CHANGES SAVED',
      batchImport: 'batch import',
      cancel: 'Cancel',
      close: 'Close',
      newText: 'new',
      editText: 'Edit',
      reviewBtnText: 'Next: Review',
      createText: 'Create',
      reviewText: 'review',
      reviewInfoText: 'Review and Edit the file location details'
    },
    ja: {
      basicInfo: '基本情報',
      basicInfoMessage:
        'バッチ処理対象のファイルがどこで連携されるのかを指定するために、ファイルロケーションを定義する必要があります。ここで設定したファイルロケーションが、バッチインポート登録時に選択できます。',
      fileLocationDetails: 'ファイルロケーション詳細',
      fileLocationName: 'ファイルロケーション名',
      fileLocationType: 'ファイルロケーションタイプ',
      infoText: 'インフォメーション',
      objectStoreDetails: 'OBJECT STORE 詳細',
      headerInfoText: 'インフォメーション',
      headerInfoBodyText:
        'ここに対象店舗専用のバケットに関する情報が表示されます。',
      fileLocationDescription: 'ファイルロケーション概要',
      fileLocation: 'ファイルロケーション',
      back: '戻る',
      changesSavedText: '変更内容が保存されました',
      batchImport: 'バッチインポート',
      cancel: 'キャンセル',
      close: '閉じる',
      newText: '登録 - ',
      editText: '編集 - ',
      reviewBtnText: '次へ : 登録内容確認',
      createText: '登録する',
      reviewText: '登録内容確認',
      reviewInfoText:
        'ファイルロケーションの設定内容を確認し、必要に応じて修正してください。'
    }
  }
};

export const batchImportViewObj = {
  messages: {
    en: {
      batchImportListText: 'Batch Import List',
      switchFilesText: 'Switch to all files',
      addBatchImport: 'Add new batch import',
      dateRangeText: 'Date Range',
      fromText: 'From',
      toText: 'To',
      batchTemplate: 'Batch Template',
      batchTemplateType: 'Batch Template Type',
      programEntity: 'Program Entity',
      selectProgramEntity: 'Select Program Entity',
      processed: 'Processed',
      failed: 'Failed',
      resetBtn: 'Reset',
      saveBtn: 'Save',
      selectEntityType: 'Select Entity Type',
      addImportInfo: 'To which Entity you would like to create batch import?',
      selectEntity: 'Select Entity',
      cancel: 'Cancel',
      continue: 'Continue',
      noEntities: 'No Program Entities available',
      switchImportText: 'Switch to imports',
      statusText: 'Status',
      gridViewText: 'grid view',
      tableViewText: 'Table view',
      cardViewText: 'card view'
    },
    ja: {
      batchImportListText: 'バッチインポート一覧',
      switchFilesText: 'ファイル一覧へ',
      addBatchImport: 'バッチインポート登録',
      dateRangeText: '日付範囲指定',
      fromText: '開始日',
      toText: '終了日',
      batchTemplate: 'バッチテンプレート',
      batchTemplateType: 'バッチテンプレートタイプ',
      programEntity: 'プログラムエンティティ',
      selectProgramEntity: 'プログラムエンティティ選択',
      processed: '処理済',
      failed: 'エラー',
      resetBtn: 'リセット',
      saveBtn: 'フィルターを適用する',
      selectEntityType: 'プログラムエンティティ選択',
      addImportInfo:
        'バッチインポートを作成する対象のプログラムエンティティを選択してください',
      selectEntity: 'プログラムエンティティ選択',
      cancel: 'キャンセル',
      continue: '続ける',
      noEntities: '選択可能なプログラムエンティティが存在しません',
      switchImportText: 'バッチインポート一覧へ',
      statusText: 'ステータス',
      gridViewText: 'グリッドビュー',
      cardViewText: 'カードビュー',
      tableViewText: 'テーブルビュー'
    }
  }
};

export const storeNamePopUpObject = {
  messages: {
    en: {
      saveChanges: 'SAVE CHANGES?',
      storeNameAlreadyExists: 'Group Name Already Exists',
      storeDes: 'Store group name already exists. Please enter a unique store group name.',
      okTxt: 'OK'
    },
    ja: {
      saveChanges: '変更内容を保存しますか？',
      storeNameAlreadyExists: '店舗グループ名が重複しています',
      storeDes: '店舗グループ名はすでに存在します。別の店舗グループ名を入力してください。',
      okTxt: 'OK'
    }
  }
};

export const storeCancelPopUpObject = {
  messages: {
    en: {
      storeGroupAttribute: 'Store Group Attribute',
      entity: 'Entity',
      storesList: 'STORES LIST',
      storeCriteriaDetails: 'STORES CRITERIA DETAILS',
      criteriaType: 'Criteria Type',
      criteriaValue: 'Criteria Value',
      storeDetails: 'STORES DETAILS',
      stores: 'Stores',
      storeName: 'Store Name',
      storeCode: 'Store Code',
      storeAddress: 'Store Address',
      countryCityName: 'Country/City Name',
      status: 'Status',
      loadMore: 'LOAD MORE',
      saveChanges: 'SAVE CHANGES?',
      saveYourChanges: 'Would you like to save the changes you’ve made?',
      cardTitle: ' Cancel Creating Store Group',
      noBtnText: 'NO',
      yesBtnText: 'YES',
      alertMsg: 'Are you sure you wish to cancel creating a new store group?',
      noRecordFoundHeader: 'NO STORES DETAILS FOUND',
      noResultMessage:
        'The search could not find any store group based on the search text you entered in the search field. Please revise the search text to try again.'
    },
    ja: {
      storeGroupAttribute: '店舗グループ条件属性・設定値',
      entity: 'プログラムエンティティ',
      storesList: '店舗グループ詳細',
      storeCriteriaDetails: '店舗グループ条件',
      criteriaType: '条件',
      criteriaValue: '設定値',
      storeDetails: '店舗詳細',
      stores: '件',
      storeName: '店舗名',
      storeCode: '店舗コード',
      storeAddress: '店舗住所',
      countryCityName: '国/都市名',
      status: 'ステータス',
      loadMore: 'ロード中',
      saveChanges: '変更内容を保存しますか？',
      saveYourChanges: '変更内容を保存します。よろしいですか？',
      cardTitle: '店舗グループ登録キャンセル',
      noBtnText: 'いいえ',
      yesBtnText: 'はい',
      alertMsg: '店舗グループ登録をキャンセルします。よろしいですか？',
      noRecordFoundHeader: '条件に一致するデータがみつかりませんでした',
      noResultMessage:
        'グルーピングの条件に合致するデータがみつかりませんでした。想定と異なる場合は、グルーピング条件を修正してもう一度お試しください。'
    }
  }
};
export const batchImportCardViewObj = {
  messages: {
    en: {
      batchTemplate: 'Batch Template',
      fileEncryptionKey: 'File Encryption Key',
      fileLocation: 'File Location',
      description: 'Description',
      createdDate: 'Created Date',
      lastEditedDate: 'Last Edited Date',
      viewDetails: 'View Details',
      edit: 'Edit',
      copy: 'Copy',
      delete: 'Delete',
      batchImportName: 'Batch Import Name'
    },
    ja: {
      batchTemplate: 'バッチテンプレート',
      fileEncryptionKey: 'ファイル暗号化キー',
      fileLocation: 'ファイルロケーション',
      description: 'バッチインポート概要',
      createdDate: '作成日時',
      lastEditedDate: '最終更新日時',
      viewDetails: '詳細を見る',
      edit: '編集',
      copy: 'コピー',
      delete: '削除',
      batchImportName: 'バッチインポート名'
    }
  }
};

export const storeGroupLayoutObj = {
  messages: {
    en: {
      newProductStoreGroup: 'NEW PRODUCT GROUP FOR',
      editStoreGroup: 'EDIT STORE GROUP FOR',
      cloneStoreGroup: 'CLONE STORE GROUP FOR',
      newStoreGroup: 'NEW STORE GROUP FOR',
      closeTxt: 'CLOSE',
      basicInfo: 'BASIC INFORMATION',
      criteriaTxt: 'CRITERIA',
      reviewTxt: 'REVIEW',
      cancelTxt: 'Cancel',
      nextCriteriaBtn: 'NEXT: CREATE CRITERIA',
      footerChangesSavedText: 'ALL CHANGES SAVED',
      nxtReviewBtn: 'Next: Review',
      saveGroupBtn: 'CREATE GROUP',
      createGroupBtn: 'CREATE GROUP',
      createAnotherStoreGroup: 'CREATE ANOTHER STORE GROUP',
      createStoreGroupText: 'Would you like to create store group?',
      clickHereText: 'Click Here',
      textMessgae: 'The new store group',
      createdText: 'has been created.',
      storeGroupEditMessgae: 'Changes to the Store Group',
      editTextMessage: 'have been saved.',
      udpateGroupBtn: 'SAVE GROUP',
      successTxt: 'SUCCESS',
      successAlert: 'success',
    },
    ja: {
      newProductStoreGroup: '商品グループ登録 : ',
      editStoreGroup: '店舗グループ編集 : ',
      cloneStoreGroup: '店舗グループコピー : ',
      newStoreGroup: '店舗グループ登録 : ',
      closeTxt: '閉じる',
      basicInfo: '基本情報',
      criteriaTxt: '条件',
      reviewTxt: '登録内容確認・登録',
      cancelTxt: 'キャンセル',
      nextCriteriaBtn: '次へ ： 条件を設定する',
      footerChangesSavedText: '変更内容が保存されました',
      nxtReviewBtn: '次へ： 登録内容確認',
      saveGroupBtn: '登録する',
      createGroupBtn: '保存する',
      createAnotherStoreGroup: '新たに店舗グループを作成する',
      createStoreGroupText: '続けて新たな店舗グループを作成する場合は、',
      clickHereText: 'ここをクリックしてください',
      textMessgae: '店舗グループ: ',
      createdText: 'が正常に登録されました。',
      storeGroupEditMessgae: '店舗グループ: ',
      editTextMessage: 'の変更が正常に保存されました。',
      udpateGroupBtn: '更新する',
      successTxt: '更新完了',
      successAlert: '更新成功',
    }
  }
};

export const productGroupLayoutObj = {
  messages: {
    en: {
      newProductStoreGroup: 'NEW PRODUCT GROUP FOR',
      editProductGroup: 'EDIT PRODUCT GROUP FOR',
      cloneProductGroup: 'CLONE PRODUCT GROUP FOR',
      closeTxt: 'CLOSE',
      basicInfo: 'BASIC INFORMATION',
      criteriaTxt: 'CRITERIA',
      reviewTxt: 'REVIEW',
      cancelTxt: 'Cancel',
      nextCriteriaBtn: 'NEXT: CREATE CRITERIA',
      footerChangesSavedText: 'ALL CHANGES SAVED',
      nxtReviewBtn: 'Next: Review',
      saveGroupBtn: 'CREATE GROUP',
      udpateGroupBtn: 'SAVE GROUP',
      createGroupBtn: 'CREATE GROUP'
    },
    ja: {
      newProductStoreGroup: '商品グループ登録 : ',
      editProductGroup: '商品グループ編集 : ',
      cloneProductGroup: '商品グループコピー : ',
      closeTxt: '閉じる',
      basicInfo: '基本情報',
      criteriaTxt: '条件',
      reviewTxt: '登録内容確認・登録',
      cancelTxt: 'キャンセル',
      nextCriteriaBtn: '次へ ： 条件を設定する',
      footerChangesSavedText: '変更内容が保存されました',
      nxtReviewBtn: '次へ： 登録内容確認',
      saveGroupBtn: '保存する',
      udpateGroupBtn: '更新する',
      createGroupBtn: '登録する'
    }
  }
};

export const storeGroupReviewObj = {
  messages: {
    en: {
      formTitle: 'REVIEW',
      infoText:
        'Review the following information before you save the store group.',
      basicInfo: 'BASIC INFORMATION',
      edit: 'edit',
      storeGroupName: 'Store Group Name',
      storeGroupDes: 'Store Group Description',
      criteria: 'CRITERIA',
      entity: 'Entity',
      storeGroupAttribute: 'Store Group Attribute'
    },
    ja: {
      formTitle: '登録内容確認',
      infoText: '店舗グループを保存する前に、次の設定内容を確認してください。',
      basicInfo: '基本情報',
      edit: '編集',
      storeGroupName: '店舗グループ名',
      storeGroupDes: '店舗グループ概要',
      criteria: '条件',
      entity: 'プログラムエンティティ',
      storeGroupAttribute: '店舗グループ条件属性・設定値'
    }
  }
};
export const locationsCardViewObj = {
  messages: {
    en: {
      locationType: 'File Location Type',
      hostName: 'Host Name',
      description: 'File Location Description',
      createdDate: 'Created Date',
      lastEditedDate: 'Last Edited Date',
      status: 'Status',
      edit: 'EDit',
      delete: 'Delete',
      locationName: 'File Location Name'
    },
    ja: {
      locationType: 'ロケーションタイプ',
      hostName: 'ホスト名',
      description: 'ファイルロケーション概要',
      createdDate: '作成日時',
      lastEditedDate: '最終更新日時',
      status: 'ステータス',
      edit: '編集',
      delete: '削除',
      locationName: 'ファイルロケーション名'
    }
  }
};

export const batchImportViewDetailsObj = {
  messages: {
    en: {
      dateRangeText: 'Date Range',
      fromText: 'From',
      toText: 'To',
      processed: 'Processed',
      failed: 'Failed',
      resetBtn: 'Reset',
      saveBtn: 'Save',
      batchImportDetailedText: 'batch import name Details',
      batchTemplateText: 'Batch Template',
      fileLocation: 'File Location',
      description: 'Description',
      fileEncryptionText: 'File Encryption Key',
      createdDate: 'Created Date',
      search: 'Search',
      fileName: 'File Name',
      uploadedDate: 'Uploaded Date',
      processedDate: 'Processed Date',
      status: 'Status',
      failedRecords: 'Failed Records',
      download: 'Download'
    },
    ja: {
      dateRangeText: '日付範囲指定',
      fromText: '開始日',
      toText: '終了日',
      processed: '処理済',
      failed: 'エラー',
      resetBtn: 'リセット',
      saveBtn: 'フィルターを適用する',
      batchImportDetailedText: 'バッチインポート詳細',
      batchTemplateText: 'バッチテンプレート',
      fileLocation: 'ファイルロケーション',
      description: 'バッチインポート概要',
      fileEncryptionText: 'ファイル暗号化キー',
      createdDate: '作成日時',
      search: '検索',
      fileName: 'ファイル名',
      uploadedDate: 'アップロード日時',
      processedDate: '処理日時',
      status: 'ステータス',
      failedRecords: 'エラーレコード',
      download: 'ダウンロード'
    }
  }
};

export const batchImportSwitchFilesObj = {
  messages: {
    en: {
      fileName: 'File Name',
      templateName: 'Template Name',
      uploadDate: 'Uploaded Date',
      processedRecordsText: 'No.of Records Loaded',
      failedRecordsText: 'No.of Records Failed',
      processedDate: 'Processed Date',
      status: 'Status',
      failedRecords: 'Failed Records',
      download: 'Download'
    },
    ja: {
      fileName: 'ファイル名',
      templateName: 'テンプレート名',
      uploadDate: 'アップロード日時',
      processedRecordsText: '正常レコード数',
      failedRecordsText: 'エラーレコード数',
      processedDate: '処理日時',
      status: 'ステータス',
      failedRecords: 'エラーレコード',
      download: 'ダウンロード'
    }
  }
};

export const storeGroupListObj = {
  messages: {
    en: {
      createStoreGroup: 'CREATE A STORE GROUP',
      storeGroupCode: 'Store Group Code',
      storesCount: 'No.of Stores ',
      storeGroupDescription: 'Store Group Description',
      storeGroupCreatedBy: 'Created By',
      createdOnText: 'Created Date',
      programEntityLabel: 'Program Entity',
      statusLabel: 'Status',
      viewDetails: 'View Details',
      cloneLabel: 'Clone',
      editLabel: 'Edit',
      deleteText: 'Delete',
      storeGroupName: 'STORE GROUP NAME',
      searchStoreGroup: 'Search Store Group',
      gridViewText: 'grid view',
      cardViewText: 'card view',
      tableViewText: 'Table view',
      storeGroups: 'Store Groups',
      storeGroupNameLabel: 'Name',
      searchlabelTxt:
        'Store Group Name,Program Entity,Store Group Description,Created By',
      datRange: 'DATE RANGE',
      fromlabelTxt: 'From',
      tolabelTxt: 'To',
      cancelText: 'Cancel',
      okText: 'Ok',
      byProgramEntitty: 'BY PROGRAM ENTITY',
      selectProgramlabelTxt: 'Select Program Entity',
      resetBtn: 'Reset',
      applyFilterBtn: 'Apply Filters',
      dateValidationErrMsg: '“From” date cannot be later than “To” date.',
      noRecordFoundHeader: 'NO STORES GROUPS FOUND',
      noResultMessage:
        'The search could not find any store group based on the search text you entered in the search field. Please revise the search text to try again.',
      cardTitle: 'Delete Store Group?',
      alertMsg: 'Do you wish to delete the store group',
      noBtnTextPopUp: 'no',
      yesBtnTextPopUp: 'yes'
    },
    ja: {
      createStoreGroup: '店舗グループ登録',
      storeGroupCode: '店舗グループコード',
      storesCount: '店舗数',
      storeGroupDescription: '店舗グループ概要',
      storeGroupCreatedBy: '作成者',
      createdOnText: '作成日時',
      programEntityLabel: 'プログラムエンティティ',
      statusLabel: 'ステータス',
      viewDetails: '詳細を見る',
      cloneLabel: 'コピー',
      editLabel: '編集',
      deleteText: '削除',
      storeGroupName: '店舗グループ名',
      searchStoreGroup: '店舗グループ検索',
      gridViewText: 'グリッドビュー',
      tableViewText: 'テーブルビュー',
      cardViewText: 'カードビュー',
      searchlabelTxt:
        '店舗グループ名、プログラムエンティティ、店舗グループ概要、作成者で検索',
      datRange: '日付範囲指定',
      fromlabelTxt: '開始日',
      tolabelTxt: '終了日',
      cancelText: 'キャンセル',
      okText: 'OK',
      byProgramEntity: 'プログラムエンティティで絞り込む',
      selectProgramlabelTxt: 'プログラムエンティティ選択',
      resetBtn: 'リセット',
      applyFilterBtn: 'フィルターを適用する',
      dateValidationErrMsg:
        '「開始日」には「終了日」以前の日付を設定してください',
      noRecordFoundHeader: '検索結果がみつかりませんでした',
      noResultMessage:
        '検索結果がみつかりませんでした。検索条件を修正して、もう一度お試しください。',
      storeGroups: '店舗グループ',
      storeGroupNameLabel: '店舗グループ名',
      cardTitle: 'ストアグループを削除する',
      alertMsg: 'ストアグループを削除しますか',
      noBtnTextPopUp: 'いいえ',
      yesBtnTextPopUp: 'はい'
    }
  }
};
export const createStoreEntityObj = {
  messages: {
    en: {
      pgmEntity: 'SELECT PROGRAM ENTITY',
      bodyDes: 'Select the program entity to create new store group',
      selectEntity: 'Select Program Entity',
      cancelTxt: 'CANCEL',
      continueTxt: 'CONTINUE',
      noPgmEntity: 'No Program Entities Available'
    },
    ja: {
      pgmEntity: 'プログラムエンティティ選択',
      bodyDes: 'どのプログラムエンティティに紐づく店舗グループを作成しますか？',
      selectEntity: 'プログラムエンティティを選択してください',
      cancelTxt: 'キャンセル',
      continueTxt: '続ける',
      noPgmEntity: '選択可能なプログラムエンティティが存在しません'
    }
  }
};

// Store Upload Program Entity
export const programEntityDialogObj = {
  messages: {
    en: {
      header: 'Select program entity',
      title: 'To which Program Entity you would like to create store?',
      selectEntity: 'Select Program Entity',
      noEntities: 'No Program Entities available',
      cancel: 'Cancel',
      continue: 'Continue'
    },
    ja: {
      header: 'プログラムエンティティ選択',
      title: 'どのプログラムエンティティに紐づく店舗を登録しますか？',
      selectEntity: 'プログラムエンティティを選択してください',
      noEntities: '選択可能なプログラムエンティティが存在しません',
      cancel: 'キャンセル',
      continue: '続ける'
    }
  }
};

// Store Upload view
export const storeUploadObj = {
  messages: {
    en: {
      uploadStore: 'UPLOAD STORES',
      close: 'Close',
      chooseFile: 'CHOOSE FILE',
      chooseUploadFileInfo:
        'Choose and upload the CSV file that contains the stores data for batch processing.',
      uploadStoreInfo:
        'To upload your Stores data into Loyalty Services, you need to populate a CSV file with your source data. Please use the provided CSV template. The columns in the template are the expected attributes.',
      importStoreTasks: 'To import Stores data, perform following tasks',
      importStoreTasks_1:
        '1. Download the template from the right to create a CSV file.',
      importStoreTasks_2:
        '2. Populate the CSV file with the import data. Do not change the column headers.',
      importStoreTasks_3:
        '3. Upload the CSV file in the upload box provided below.',
      importStoreTasks_4: '4. Import the CSV file by clicking on “Import”.',
      uploadCSV: 'upload CSV file',
      dropCSVFile: 'Drop your .CSV file here, or',
      browse: 'browse',
      info: 'Info',
      csvTemplate: 'CSV Template',
      one: '1.',
      store_Template: 'Stores Data Import Template',
      importInProgress: 'Import in progress',
      cancel: 'Cancel',
      import: 'Import',
      store_csv: 'Store.csv',
      latestTemplateMsg: 'Please download the latest template.',
      fileNameExceedsMsg:
        'The file name should not be greater than 252 characters including the file extension.',
      fileFormatType: 'Incorrect File Format',
      fileExceedsType: 'File Size Exceeds Maximum Allowed',
      fileFormatMsg: 'Please ensure that you are uploading a CSV file.',
      fileExceedsMsg: 'The file you are trying to upload exceeds 1 gigabyte.',
      previous: 'Previous'
    },
    ja: {
      uploadStore: '店舗アップロード',
      close: '閉じる',
      chooseFile: 'ファイル選択',
      chooseUploadFileInfo:
        'バッチ処理にてインポートする店舗データファイルを選択し、アップロードしてください。',
      uploadStoreInfo:
        '店舗データをアップロードするには、ソースとなるデータをCSVファイルに用意し、アップロード先のデータ定義にマッピングする必要があります。インポート用のCSVテンプレートをダウンロードし、ご利用ください。テンプレート内の各項目がデータ登録が必要な項目です。',
      importStoreTasks: '以下の手順で店舗データをアップロードしてください',
      importStoreTasks_1:
        '1. 右記のリンクからCSVのテンプレートをダウンロードする',
      importStoreTasks_2:
        '2. インポート用のCSVファイルを作成する（このとき、ヘッダーは変更しないこと）',
      importStoreTasks_3:
        '3. 以下の枠線内にファイルをドロップし、CSVファイルをアップロードする',
      importStoreTasks_4:
        '4. 「インポートする」をクリックし、データのインポートを開始する',
      uploadCSV: 'CSVファイルアップロード',
      dropCSVFile: 'ここに.csvファイルをドロップするか、',
      browse: 'ファイルを指定してください',
      info: 'インフォメーション',
      csvTemplate: 'CSVテンプレートがダウンロードできます',
      one: '1.',
      store_Template: '店舗データテンプレート',
      importInProgress: 'インポート中',
      cancel: 'キャンセル',
      import: 'インポートする',
      store_csv: 'Store.csv',
      latestTemplateMsg: '最新のテンプレートをダウンロードしてください。',
      fileNameExceedsMsg:
        'アップロードするファイルのファイル名は、拡張子を含め252文字以内である必要があります。',
      fileFormatType: '無効なファイルフォーマット',
      fileExceedsType: 'ファイルサイズ超過',
      fileFormatMsg:
        '不正なファイルフォーマットです。CSVファイルが選択されているか確認してください。',
      fileExceedsMsg:
        'アップロードするファイルのサイズは1GB以内である必要があります。',
      previous: '戻る'
    }
  }
};

// Store Upload Status
export const storeUploadStatusObj = {
  messages: {
    en: {
      uploadStore: 'UPLOAD STORES',
      close: 'Close',
      success: 'SUCCESS',
      error: 'ERROR',
      successInfoText: 'File has been sent for batch processing.',
      errorInfoText: 'Import failed due to an error.',
      successMessage:
        'The file you have imported will be processed. You may view the status of the processing by clicking the dashboard button.',
      errorMessage:
        'An error occurred while trying to import the file. File import was not completed. Please try again.',
      importing: 'Importing',
      completed: '% Completed',
      go_to_dashboard: 'go to dashboard',
      uploadAnotherFile: 'upload another Store file?',
      addNewFile_Entity:
        'Would you like to upload a new store file to this Program Entity?',
      clickHere: 'Click here'
    },
    ja: {
      uploadStore: '店舗アップロード',
      close: '閉じる',
      success: '更新成功',
      error: 'エラー',
      successInfoText: 'ファイルインポート処理が正常に開始されました。',
      errorInfoText: 'ファイルインポート処理が失敗しました。',
      successMessage:
        'ファイルインポート処理が正常に開始されました。「ダッシュボードへ」をクリックすると、インポート処理のステータスが確認できます。',
      errorMessage:
        'エラーによりファイルインポート処理を開始できませんでした。再度お試しください。',
      importing: 'インポート中',
      completed: '% 完了',
      go_to_dashboard: 'ダッシュボードへ',
      uploadAnotherFile: '新たに店舗ファイルをアップロードする',
      addNewFile_Entity:
        'このプログラムエンティティにさらに店舗ファイルをアップロードする場合は、',
      clickHere: 'ここをクリックしてください'
    }
  }
};

export const memberStatusDefObj = {
  messages: {
    en: {
      configNonEnrollHeader: 'Configurable conditions for NonEnroll status',
      optionallyConditionsForNonEnroll:
        'A customer can optionally be set to NonMember at the time of new account creation.',
      memberStatusThroughApi: 'Through status sent in POST Member.',
      memberStatusThroughPortal:
        'Through member enrollment on Customer Care portal (future enhancements).',
      statusConditionsNonEnroll1:
        'A NonMember member can be converted to an Active member when the Activate API is called.',
      statusConditionsNonEnroll2:
        'A NonMember member can be set to merged and forgotten (2021 Enhancements).',
      statusConditionsNonEnroll3:
        'A NonMember member cannot be set to locked, deactivated, or terminated.',
      configPreEnrollHeader: 'Configurable conditions for PreEnrolled status',
      optionallyConditionsForPreEnroll:
        'A new member account can be optionally set to PreEnrolled at the time of member creation.',
      memberStatusThroughApiPreEnroll: 'Through status sent in POST Member.',
      memberStatusThroughPortalPreEnroll:
        'Through member enrollment on Customer Care portal.',
      statusConditionsPreEnroll1:
        'A PreEnrolled member can be set to merged, terminated, or forgotten status.',
      statusConditionsPreEnroll2:
        'A PreEnrolled member cannot be set to locked or deactivated.',
      configActiveHeader: 'Configurable conditions for Active status',
      optionallyConditionsForActive:
        'A member is initially to PreEnrolled or NonMember or Active. Active status is default set when the status is not specified when a member enrollment is received with POST member. Or when Active status is selected as part of member enrollment on CSportal.',
      activeStatusCondition1:
        'An Active member can be set to locked, deactivated, merged, forgotten or terminated.',
      activeStatusCondition2:
        'Deactivated member is reinstated when Activate API is called.',
      activeStatusCondition3:
        'When a Deactivated member is reinstated, they will resume accruing, can redeem, and earn program tiers.',
      activeStatusCondition4:
        'A PreEnrolled or NonMember can be converted to an Active member',
      activeStatusCondition5:
        'An update to member status is received when the Activate API is called.',
      activeStatusCondition6:
        'When the following member attributes are received to complete their member profile',
      activeStatusCondition7:
        'When a PreEnrolled or NonMember is converted, reward issuance and tier evaluation will be triggered.',
      firstName: 'First Name',
      lastName: 'Last Name',
      pryEmail: 'Primary Email',
      pryPhone: 'Primary Phone',
      configLockedHeader: 'Configurable conditions for Locked status',
      optionallyConditionsForLocked:
        'An Active member will be updated to Locked member when fail login authentication limits are reached. Or if the Locked api is called.',
      lockedStatusCondition1:
        'A Locked member can be activated, deactivated, or terminated.',
      lockedStatusCondition2:
        'A Locked member cannot be merged with another member.',
      lockedStatusCondition3:
        'A Locked member must be re-activated before they can be forgotten.',
      lockedStatusCondition4:
        'A Lock member can be-activated when a request to reinstate a member is received when reinstate api is called.',
      lockedStatusCondition5: 'A reset password attempt is successful.',
      lockedStatusCondition6:
        'When a Locked member is reinstated, reward issuance and tier evaluation will be triggered.',
      configDeactiveHeader: 'Configurable conditions for deactivated status',
      optionallyConditionsForDeactive:
        'A Lock or Active member can be converted to a Deactivated member when a request to deactivate a member is received from the Customer Care portal or when Deactivate api is called.',
      deactiveStatusCondition1:
        'A Deactivated member can be set to a lock, re-activated, or terminated.',
      deactiveStatusCondition2:
        'A Deactivated member must be re-activated before they can be forgotten.',
      deactiveStatusCondition3:
        'A Deactivate member can be re-activated when a request to reinstate a member is received from the Customer Care portal or when reinstate api is called.',
      deactiveStatusCondition4:
        'A Deactivated member cannot be set to merge with another member.',
      configForgottenHeader: 'Configurable conditions for Forgotten status',
      optionallyConditionsForForgotten:
        'A NonMember, PreEnrolled, Active, Lock, Deactivated or Merge member can be converted to a Forgotten member when a request to be forgotten is received from the Customer Care portal or when Forget api is called.',
      forgottenStatusCondition1:
        'Automatically expires points, tiers, rewards, promotions, coupons, and cards.',
      configTerminatedHeader: 'Configurable conditions for Terminated status',
      optionallyConditionsForTerminated:
        'An Active, Lock or Deactivate member can be converted to a Terminated member when a request to terminate member is received from the Customer Care portal or when Terminate api is called.',
      terminatedStatusCondition1:
        'Automatically expires points, tiers, rewards, promotions, coupons, and cards.',
      configMergedHeader: 'Configurable conditions for Merged status',
      optionallyConditionsForMerged:
        'PreEnrolled and Active members will be updated to a Merged member when their member account gets merge into another member account from the Customer Care portal or when Merge api is called.',
      mergedStatusCondition1:
        'Once a member has been merged with another member, they cannot be activated, deactivated, converted, terminated, or locked.',
      nonMemberTooltip:
        'Customers that have not enrolled in a loyalty program.',
      preEnrollTooltip:
        'This status allows a member to be put in a holding status before becoming active.',
      activeTooltip:
        'When a member is first added, the member is assigned the "Active" status',
      lockedTooltip:
        'Member that has exceeded defined failed authentication limits.',
      deactiveTooltip: 'A Active or Lock member that has been disabled.',
      forgottenTooltip:
        'Resulting status of a Request to be Forgotten. This process deletes or anonymizes configured member attributes metadata (configurable as part of the member definition management flow). Once a member has been forgotten, this action is irreversible.',
      terminatedTooltip:
        'A member that has been terminated. Once a member has been terminated, they can not become active again.',
      mergedTooltip:
        'Resulting status of the "victim" member from a member merge event.',
      nonMemberTooltipHeader: 'NonMember',
      preEnrollTooltipHeader: 'PreEnrolled',
      activeTooltipHeader: 'Active',
      lockedTooltipHeader: 'Locked',
      deactiveTooltipHeader: 'Deactivated',
      forgottenTooltipHeader: 'Forgotten',
      terminatedTooltipHeader: 'Terminated',
      mergedTooltipHeader: 'Merged'
    },
    ja: {
      configNonEnrollHeader: '「未入会」ステータスについて',
      optionallyConditionsForNonEnroll:
        '以下の方法で、会員登録時に「未入会」ステータスでの登録を選択することができます。',
      memberStatusThroughApi:
        'POST Member APIのリクエストで、「未入会」ステータスを設定する。',
      memberStatusThroughPortal:
        'カスタマーサービスポータルでの会員登録時に、「未入会」ステータスを選択する。（今後開発予定）',
      statusConditionsNonEnroll1:
        '「未入会」ステータスの会員は、Activate APIを呼び出すことで、「アクティブ」ステータスに遷移できます。',
      statusConditionsNonEnroll2:
        '「未入会」ステータスの会員は、「マージ済」または「個人情報削除」ステータスに遷移できます。（2021年開発予定）',
      statusConditionsNonEnroll3:
        '「未入会」ステータスの会員は、「ロック」、「非アクティブ」、「退会」ステータスに遷移できません。',
      configPreEnrollHeader: '「先行入会」ステータスについて',
      optionallyConditionsForPreEnroll:
        '以下の方法で、会員登録時に「先行入会」ステータスでの登録を選択することができます。',
      memberStatusThroughApiPreEnroll:
        'POST Member APIのリクエストで、「先行入会」ステータスを設定する。',
      memberStatusThroughPortalPreEnroll:
        'カスタマーサービスポータルでの会員登録時に、「先行入会」ステータスを選択する。',
      statusConditionsPreEnroll1:
        '「先行入会」ステータスの会員は、「マージ済」、「退会」、「個人情報削除」ステータスに遷移できます。',
      statusConditionsPreEnroll2:
        '「先行入会」ステータスの会員は、「ロック」および「非アクティブ」ステータスに遷移できません。',
      configActiveHeader: '「アクティブ」ステータスについて',
      optionallyConditionsForActive:
        '会員登録時の会員ステータスは、「未入会」、「先行入会」または「アクティブ」のいずれかです。POST Member APIにて会員登録する場合のデフォルトステータスは「アクティブ」であり、カスタマーサービスポータルでの会員登録時に「アクティブ」ステータスを選択できます。',
      activeStatusCondition1:
        '「アクティブ」ステータスの会員は、「ロック」、「非アクティブ」、「マージ済」、「個人情報削除」、「退会」ステータスに遷移できます。',
      activeStatusCondition2:
        '「非アクティブ」ステータスの会員は、Activate APIを呼び出すことで「アクティブ」ステータスに戻ります。',
      activeStatusCondition3:
        '「非アクティブ」ステータスの会員が、「アクティブ」ステータスに戻った場合、ポイントの取得・利用およびランク判定が再開されます。',
      activeStatusCondition4:
        '「先行入会」および「未入会」ステータスの会員は、以下の方法で「アクティブ」ステータスへ遷移できます。',
      activeStatusCondition5:
        'Activate APIを呼び出すことで、会員ステータスを「アクティブ」に更新する。',
      activeStatusCondition6:
        '以下の会員項目に値を設定し、会員プロフィールの登録を完了する。',
      activeStatusCondition7:
        'また、「先行入会」および「未入会」ステータスの会員が「アクティブ」ステータスに遷移するタイミングで、特典付与やランク判定の処理が実行されます。',
      firstName: '名',
      lastName: '姓',
      pryEmail: 'メールアドレス（メイン）',
      pryPhone: '電話番号（メイン）',
      configLockedHeader: '「ロック」ステータスについて',
      optionallyConditionsForLocked:
        '「アクティブ」ステータスの会員は、ログイン試行回数上限を超えてログインに失敗した場合、およびLock APIが呼び出された場合に「ロック」ステータスに遷移します。',
      lockedStatusCondition1:
        '「ロック」ステータスの会員は、「アクティブ」、「非アクティブ」、「退会」ステータスに遷移できます。',
      lockedStatusCondition2:
        '「ロック」ステータスの会員は、他の会員にマージできません。',
      lockedStatusCondition3:
        '「ロック」ステータスの会員は、「個人情報削除」ステータスに遷移する前に、以下の方法で「アクティブ」ステータスに戻る必要があります。',
      lockedStatusCondition4: 'Reinstate APIを呼び出す',
      lockedStatusCondition5: 'パスワードリセット実施後、再ログインに成功する',
      lockedStatusCondition6:
        '「ロック」ステータスの会員が「アクティブ」ステータスに遷移するタイミングで、特典付与やランク判定の処理が実行されます。',
      configDeactiveHeader: '「非アクティブ」ステータスについて',
      optionallyConditionsForDeactive:
        '「ロック」および「アクティブ」ステータスの会員は、カスタマーサービスポータルで「非アクティブ」ステータスに更新された場合、およびDeactivate APIが呼び出された場合に「非アクティブ」ステータスに遷移します。',
      deactiveStatusCondition1:
        '「非アクティブ」ステータスの会員は、「ロック」、「アクティブ」、「退会」ステータスに遷移できます。',
      deactiveStatusCondition2:
        '「非アクティブ」ステータスの会員は、「個人情報削除」ステータスに遷移する前に、以下の方法で「アクティブ」ステータスに戻る必要があります。',
      deactiveStatusCondition3:
        'カスタマーサービスポータルで「アクティブ」ステータスに更新する、またはReinstate APIを呼び出す。',
      deactiveStatusCondition4:
        '「非アクティブ」ステータスの会員は、他の会員にマージできません。',
      configForgottenHeader: '「個人情報削除」ステータスについて',
      optionallyConditionsForForgotten:
        '「未入会」、「先行入会」、「アクティブ」、「ロック」、「非アクティブ」および「マージ済」ステータスの会員は、カスタマーサービスポータルで「個人情報削除」ステータスに更新する、またはForget APIを呼び出すことで、「個人情報削除」ステータスに遷移します。',
      forgottenStatusCondition1:
        '紐づくポイント、ランク、特典、プロモーション、クーポンおよびロイヤリティーカードの有効期限が自動的に有効期限切れになります。',
      configTerminatedHeader: '「退会」ステータスについて',
      optionallyConditionsForTerminated:
        '「アクティブ」、「ロック」および「非アクティブ」ステータスの会員は、カスタマーサービスポータルで「退会」ステータスに更新する、またはTerminate APIを呼び出すことで、「退会」ステータスに遷移します。',
      terminatedStatusCondition1:
        '紐づくポイント、ランク、特典、プロモーション、クーポンおよびロイヤリティーカードの有効期限が自動的に有効期限切れになります。',
      configMergedHeader: '「マージ済」ステータスについて',
      optionallyConditionsForMerged:
        '「先行入会」および「アクティブ」ステータスの会員は、カスタマーサービスポータルでマージ処理を行う、またはMerge APIを呼び出すことで、「マージ済」ステータスに遷移します。',
      mergedStatusCondition1:
        '一度マージされた会員は、「アクティブ」、「非アクティブ」、「退会」、「ロック」ステータスに遷移できず、他の会員にマージすることもできません。',
      nonMemberTooltip:
        'システム上にアカウントは存在するが、ロイヤリティープログラムには未入会である会員',
      preEnrollTooltip:
        '必要な会員情報の更新が未済であるなどの理由で、ロイヤリティープログラムに入会はしているが、「アクティブ」ステータスではない会員',
      activeTooltip:
        'ロイヤリティープログラムに入会している会員。会員登録時にデフォルトで設定されるステータス。',
      lockedTooltip: 'ログイン試行回数上限を超えてログインに失敗した会員',
      deactiveTooltip: 'アカウントが停止された状態の会員',
      forgottenTooltip:
        'Right To Be Forgotten（忘れられる権利）のリクエストによって削除または匿名化処理された状態の会員。この処理により、Right To Be Forgottenの対象項目として設定されている会員情報は、削除または匿名化処理される。一度このステータスに遷移すると他のステータスに戻せない。',
      terminatedTooltip:
        'ロイヤリティープログラムを退会した会員。一度退会すると、「アクティブ」ステータスに戻れない。',
      mergedTooltip: '会員マージ処理によって「マージされた側」の会員。',
      nonMemberTooltipHeader: '未入会',
      preEnrollTooltipHeader: '先行入会',
      activeTooltipHeader: 'アクティブ',
      lockedTooltipHeader: 'ロック',
      deactiveTooltipHeader: '非アクティブ',
      forgottenTooltipHeader: '個人情報削除',
      terminatedTooltipHeader: '退会',
      mergedTooltipHeader: 'マージ済'
    }
  }
};

// Product Upload Program Entity
export const productEntityDialogObj = {
  messages: {
    en: {
      header: 'Select program entity',
      title: 'To which Program Entity you would like to create product?',
      selectEntity: 'Select Program Entity',
      noEntities: 'No Program Entities available',
      cancel: 'Cancel',
      continue: 'Continue'
    },
    ja: {
      header: 'プログラムエンティティ選択',
      title: 'どのプログラムエンティティに紐づく商品を作成しますか？',
      selectEntity: 'プログラムエンティティを選択してください',
      noEntities: '選択可能なプログラムエンティティが存在しません',
      cancel: 'キャンセル',
      continue: '続ける'
    }
  }
};

// Product Upload view
export const productUploadObj = {
  messages: {
    en: {
      uploadProduct: 'UPLOAD PRODUCTS',
      close: 'Close',
      chooseFile: 'CHOOSE FILE',
      chooseUploadFileInfo:
        'Choose and upload the CSV file that contains the products data for batch processing.',
      uploadProductInfo:
        'To upload your Products data into Loyalty Services, you need to populate a CSV file with your source data. Please use the provided CSV template. The columns in the template are the expected attributes.',
      importProductTasks: 'To import Products data, perform following tasks',
      importProductTasks_1:
        '1. Download the template from the right to create a CSV file.',
      importProductTasks_2:
        '2. Populate the CSV file with the import data. Do not change the column headers.',
      importProductTasks_3:
        '3. Upload the CSV file in the upload box provided below.',
      importProductTasks_4: '4. Import the CSV file by clicking on “Import”.',
      uploadCSV: 'upload CSV file',
      dropCSVFile: 'Drop your .CSV file here, or',
      browse: 'browse',
      info: 'Info',
      csvTemplate: 'CSV Template',
      one: '1.',
      product_Template: 'Products Data Import Template',
      importInProgress: 'Import in progress',
      cancel: 'Cancel',
      import: 'Import',
      product_csv: 'Products.csv',
      latestTemplateMsg: 'Please download the latest template.',
      fileNameExceedsMsg:
        'The file name should not be greater than 252 characters including the file extension.',
      fileFormatType: 'Incorrect File Format',
      fileExceedsType: 'File Size Exceeds Maximum Allowed',
      fileFormatMsg: 'Please ensure that you are uploading a CSV file.',
      fileExceedsMsg: 'The file you are trying to upload exceeds 1 gigabyte.',
      previous: 'Previous'
    },
    ja: {
      uploadProduct: '商品アップロード',
      close: '閉じる',
      chooseFile: 'ファイル選択',
      chooseUploadFileInfo:
        'バッチ処理にてインポートする商品データファイルを選択し、アップロードしてください。',
      uploadProductInfo:
        '商品データをアップロードするには、ソースとなるデータをCSVファイルに用意し、アップロード先のデータ定義にマッピングする必要があります。インポート用のCSVテンプレートをダウンロードし、ご利用ください。テンプレート内の各項目がデータ登録が必要な項目です。',
      importProductTasks: '以下の手順で商品データをアップロードしてください',
      importProductTasks_1:
        '1. 右記のリンクからCSVのテンプレートをダウンロードする',
      importProductTasks_2:
        '2. インポート用のCSVファイルを作成する（このとき、ヘッダーは変更しないこと）',
      importProductTasks_3:
        '3. 以下の枠線内にファイルをドロップし、CSVファイルをアップロードする',
      importProductTasks_4:
        '4. 「インポートする」をクリックし、データのインポートを開始する',
      uploadCSV: 'CSVファイルアップロード',
      dropCSVFile: 'ここに.csvファイルをドロップするか、',
      browse: 'ファイルを指定してください',
      info: 'インフォメーション',
      csvTemplate: 'CSVテンプレートがダウンロードできます',
      one: '1.',
      product_Template: '商品データテンプレート',
      importInProgress: 'インポート中',
      cancel: 'キャンセル',
      import: 'インポートする',
      product_csv: 'Products.csv',
      latestTemplateMsg: '最新のテンプレートをダウンロードしてください。',
      fileNameExceedsMsg:
        'アップロードするファイルのファイル名は、拡張子を含め252文字以内である必要があります。',
      fileFormatType: '無効なファイルフォーマット',
      fileExceedsType: 'ファイルサイズ超過',
      fileFormatMsg:
        '不正なファイルフォーマットです。CSVファイルが選択されているか確認してください。',
      fileExceedsMsg:
        'アップロードするファイルのサイズは1GB以内である必要があります。',
      previous: '戻る'
    }
  }
};

// Product Upload Status
export const productUploadStatusObj = {
  messages: {
    en: {
      uploadProduct: 'UPLOAD PRODUCTS',
      close: 'Close',
      success: 'SUCCESS',
      error: 'ERROR',
      successInfoText: 'File has been sent for batch processing.',
      errorInfoText: 'Import failed due to an error.',
      successMessage:
        'The file you have imported will be processed. You may view the status of the processing by clicking the dashboard button.',
      errorMessage:
        'An error occurred while trying to import the file. File import was not completed. Please try again.',
      importing: 'Importing',
      completed: '% Completed',
      go_to_dashboard: 'go to dashboard',
      uploadAnotherFile: 'upload another products file?',
      addNewFile_Entity:
        'Would you like to upload a new product file to this Program Entity?',
      clickHere: 'Click here'
    },
    ja: {
      uploadProduct: '商品アップロード',
      close: '閉じる',
      success: '更新完了',
      error: 'エラー',
      successInfoText: 'ファイルインポート処理が正常に開始されました。',
      errorInfoText: 'ファイルインポート処理が失敗しました。',
      successMessage:
        'ファイルインポート処理が正常に開始されました。「ダッシュボードへ」をクリックすると、インポート処理のステータスが確認できます。',
      errorMessage:
        'エラーによりファイルインポート処理を開始できませんでした。再度お試しください。',
      importing: 'インポート中',
      completed: '% 完了',
      go_to_dashboard: 'ダッシュボードへ',
      uploadAnotherFile: '新たに商品ファイルをアップロードする',
      addNewFile_Entity:
        'このプログラムエンティティにさらに商品ファイルをアップロードする場合は、',
      clickHere: 'ここをクリックしてください'
    }
  }
};

export const storeGroupCriteriaObj = {
  messages: {
    en: {
      formTitle: 'Criteria',
      infoText:
        'The criteria that will drive the dynamic list of stores for this store group are set here.',
      chooseStore: 'CHOOSE store group Entity',
      selectEntity: 'Select Entity',
      errorText: 'This field is required.',
      selectStoreAttr: 'Select Store Group Attribute',
      selectOper: 'Select Operator',
      previewText: 'PREVIEW',
      addQualifying: 'Add more qualifying criteria',
      select: 'Select'
    },
    ja: {
      formTitle: '条件設定',
      infoText: '店舗を動的にグルーピングするための条件を設定します。',
      chooseStore: '対象のプログラムエンティティを選択してください',
      selectEntity: '対象選択',
      errorText: 'この項目は必須です',
      selectStoreAttr: '選択: 店舗項目',
      selectOper: 'オペレーター選択',
      previewText: 'プレビュー',
      addQualifying: '条件を追加する',
      select: '選択'
    }
  }
};
export const storeGrpSuccessObj = {
  messages: {
    en: {
      successFormTitle: 'SUCCESS',
      successAlertHeader: 'Success',
      newStoreText: 'The new store group {store group name} has been created',
      anotherStore: 'CREATE ANOTHER STORE GROUP?',
      storeGroup: 'Would you like to create store group?',
      clickHere: 'Click here',
      closeText: 'Close',
      editStore:
        'Changes to the store group {store group name} have been saved.'
    },
    ja: {
      successFormTitle: '更新完了',
      successAlertHeader: '更新成功',
      newStoreText: '店舗グループ: {store group name} が正常に登録されました。',
      anotherStore: '店舗グループを追加する',
      storeGroup: '新たに店舗グループを登録するには、',
      clickHere: 'ここをクリックしてください',
      closeText: '閉じる',
      editStore: '店舗グループ: {store group name} が正常に更新されました。'
    }
  }
};
export const productGroupListObj = {
  messages: {
    en: {
      createProductGroup: 'CREATE A PRODUCT GROUP',
      deletepGroupText: 'DELETE PRODUCT GROUP?',
      areYouSureText: 'Are you sure you want to delete product group',
      yesBtnText: 'Yes',
      noBtnText: 'No',
      productGroupCode: 'Product Group Code',
      productsCount: 'No.of Products ',
      productGroupDescription: 'Product Group Description',
      productGroupCreatedBy: 'Created By',
      createdOnText: 'Created Date',
      programEntityLabel: 'Program Entity',
      statusLabel: 'Status',
      viewDetails: 'View Details',
      cloneLabel: 'Clone',
      editLabel: 'Edit',
      deleteText: 'Delete',
      productGroupName: 'PRODUCT GROUP NAME',
      searchProductGroup: 'Search Product Group',
      gridViewText: 'grid view',
      cardViewText: 'card view',
      tableViewText: 'Table view',
      productGroups: 'Product Groups',
      productGroupNameLabel: 'Name',
      searchlabelTxt:
        'Product Group Name,Program Entity,Product Group Description,Created By',
      datRange: 'DATE RANGE',
      fromlabelTxt: 'From',
      tolabelTxt: 'To',
      cancelText: 'Cancel',
      okText: 'Ok',
      byProgramEntitty: 'BY PROGRAM ENTITY',
      selectProgramlabelTxt: 'Select Program Entity',
      resetBtn: 'Reset',
      applyFilterBtn: 'Apply Filters',
      dateValidationErrMsg: '“From” date cannot be later than “To” date.',
      noRecordFoundHeader: 'NO PRODUCTS GROUPS FOUND',
      noResultMessage:
        'The search could not find any product group based on the search text you entered in the search field. Please revise the search text to try again.'
    },
    ja: {
      createProductGroup: '商品グループ登録',
      deletepGroupText: '製品グループを削除しますか？',
      areYouSureText: '製品グループを削除してもよろしいですか？',
      yesBtnText: 'はい',
      noBtnText: '番号',
      productGroupCode: '商品グループコード',
      productsCount: '商品数',
      productGroupDescription: '商品グループ概要',
      productGroupCreatedBy: '作成者',
      createdOnText: '作成日時',
      programEntityLabel: 'プログラムエンティティ',
      statusLabel: 'ステータス',
      viewDetails: '詳細を見る',
      cloneLabel: 'コピー',
      editLabel: '編集',
      deleteText: '削除',
      productGroupName: '商品グループ名',
      searchProductGroup: '商品グループ検索',
      gridViewText: 'グリッドビュー',
      tableViewText: 'テーブルビュー',
      cardViewText: 'カードビュー',
      searchlabelTxt:
        '商品グループ名、プログラムエンティティ、商品グループ概要、作成者で検索',
      datRange: '日付範囲',
      fromlabelTxt: '開始日',
      tolabelTxt: '終了日',
      cancelText: 'キャンセル',
      okText: 'OK',
      byProgramEntity: 'プログラムエンティティで絞り込む',
      selectProgramlabelTxt: 'プログラムエンティティを選択',
      resetBtn: 'リセット',
      applyFilterBtn: 'フィルターを適用する',
      dateValidationErrMsg:
        '「開始日」には「終了日」以前の日付を設定してください',
      noRecordFoundHeader: '検索結果がみつかりませんでした',
      noResultMessage:
        '検索結果がみつかりませんでした。検索条件を修正して、もう一度お試しください。',
      productGroups: '商品グループ',
      productGroupNameLabel: '商品グループ名'
    }
  }
};
export const createProductEntityObj = {
  messages: {
    en: {
      pgmEntity: 'SELECT PROGRAM ENTITY',
      bodyDes: 'Select the program entity for the new product group',
      selectEntity: 'Select Program Entity',
      cancelTxt: 'CANCEL',
      continueTxt: 'CONTINUE',
      noPgmEntity: 'No Program Entities Available'
    },
    ja: {
      pgmEntity: 'プログラムエンティティ選択',
      bodyDes: 'どのプログラムエンティティに紐づく商品グループを作成しますか？',
      selectEntity: 'プログラムエンティティを選択してください',
      cancelTxt: 'キャンセル',
      continueTxt: '続ける',
      noPgmEntity: '選択可能なプログラムエンティティが存在しません'
    }
  }
};
export const productGroupBasicInfoObj = {
  messages: {
    en: {
      formTitle: 'BASIC INFORMATION',
      infoText:
        'Product group name and product group description are defined here.',
      productGroupDetails: 'PRODUCT GROUP DETAILS',
      productGroupName: 'Product Group Name',
      productGroupDes: 'Product Group Description',
      productGroupCreatedBy: 'Created By',
      productGroupInfo: 'Info',
      productGroupInfoText:
        'A product group is a dynamic grouping of products in the system. The product group can be used in inclusion and exclusion criteria in business rules.',
      commNameRequired: 'Product group name is required',
      nameError:
        'Product group name already exists. Please enter a unique product group name'
    },
    ja: {
      formTitle: '基本情報',
      infoText: '商品グループ名と商品グループ概要を設定してください。',
      productGroupDetails: '商品グループ詳細',
      productGroupName: '商品グループ名',
      productGroupDes: '商品グループ概要',
      productGroupCreatedBy: '作成者',
      productGroupInfo: 'インフォメーション',
      productGroupInfoText:
        '商品グループを利用することで、登録済みの商品が動的にグループ化されます。定義した商品グループは、ビジネスルールの設定時に、適用条件と除外条件で使用できます。',
      commNameRequired: '「商品グループ名」を入力してください',
      nameError:
        '商品グループ名はすでに存在します。別の商品グループ名を入力してください'
    }
  }
};
export const productGroupCriteriaObj = {
  messages: {
    en: {
      formTitle: 'Criteria',
      infoText:
        'The criteria that will drive the dynamic list of product groups for this product group are set here.',
      chooseProductGrp: 'CHOOSE PRODUCT GROUP ENTITY',
      selectEntity: 'Select Entity',
      errorText: 'This is a required field.',
      selectProductGrpAttr: 'Select Product Group Attribute',
      selectOper: 'Select Operator',
      previewText: 'PREVIEW',
      addQualifying: 'Add more qualifying criteria',
      select: 'Select'
    },
    ja: {
      formTitle: '条件設定',
      infoText: '商品を動的にグルーピングするための条件を設定します。',
      chooseProductGrp: '対象のプログラムエンティティを選択してください',
      selectEntity: '対象選択',
      errorText: 'この項目は必須です',
      selectProductGrpAttr: '選択: 商品項目',
      selectOper: 'オペレーター選択',
      previewText: 'プレビュー',
      addQualifying: '条件を追加する',
      select: '選択'
    }
  }
};
export const productReviewSuccessObj = {
  messages: {
    en: {
      basicInfo: 'BASIC INFORMATION',
      productGrpName: 'Product Group Name:',
      productGrpDesc: 'Product Group Description:',
      productGrpCode: 'Product Group Code:',
      createdBy: 'Created By:',
      rules: 'CRITERIA',
      entity: 'Entity:',
      attributeType: 'Attribute Type:',
      criteria: 'Criteria:',
      productGrpAttribute: 'Product Group Attribute:',
      // productGrpName: 'Group Name:',
      successFormTitle: 'SUCCESS',
      successAlertHeader: 'Success',
      newProductGroupText:
        'The new product group {productGroupName} has been created',
      anotherProductGroup: 'CREATE ANOTHER PRODUCT GROUP?',
      productGroup: 'Would you like to create product group?',
      clickHere: 'Click here',
      closeText: 'Close',
      editStore:
        'Changes to the product group {productGroupName} have been saved.',
      infoText: 'Review the following information before you save the product group.'
    },
    ja: {
      basicInfo: '基本情報',
      productGrpName: '商品グループ名:',
      productGrpDesc: '商品グループ概要:',
      productGrpCode: '商品グループコード:',
      createdBy: '作成者:',
      rules: '条件',
      entity: 'プログラムエンティティ:',
      attributeType: '属性タイプ:',
      criteria: '商品グループ条件属性・設定値:',
      productGrpAttribute: '商品グループ条件属性・設定値:',
      // productGrpName: '商品グループ属性：',
      successFormTitle: '更新完了',
      successAlertHeader: '更新成功',
      newProductGroupText: '商品グループ: {productGroupName} が正常に登録されました。',
      anotherProductGroup: '商品グループを追加する',
      productGroup: '新たに商品グループを登録するには、',
      clickHere: 'ここをクリックしてください',
      closeText: '閉じる',
      editStore: '商品グループ: {productGroupName} が正常に更新されました。',
      infoText: '商品グループを保存する前に、次の設定内容を確認してください。'
    }
  }
};

// CANCEL POPUP FOR PRODUCTS
export const productCancelPopUpObject = {
  messages: {
    en: {
      cardTitle: ' Cancel Creating Product Group',
      editCardTitle: ' SAVE CHANGES?',
      noBtnText: 'NO',
      yesBtnText: 'YES',
      alertMsg: 'Are you sure you wish to cancel creating a new product group?',
      editAlertMsg: 'Would you like to save the changes you’ve made?',
      noRecordFoundHeader: 'NO PRODUCTS DETAILS FOUND',
      noResultMessage:
        'The search could not find any product group based on the search text you entered in the search field. Please revise the search text to try again.'

    },
    ja: {
      cardTitle: '商品グループ登録キャンセル',
      editCardTitle: '変更内容を保存しますか？',
      noBtnText: 'いいえ',
      yesBtnText: 'はい',
      alertMsg: '商品グループ登録をキャンセルします。よろしいですか？',
      editAlertMsg: '変更内容を保存します。よろしいですか？',
      noRecordFoundHeader: '条件に一致するデータがみつかりませんでした',
      noResultMessage:
        'グルーピングの条件に合致するデータがみつかりませんでした。想定と異なる場合は、グルーピング条件を修正してもう一度お試しください。'

    }
  }
};

// CANCEL POPUP FOR PRODUCTS
export const productDuplicatePopUpObject = {
  messages: {
    en: {
      cardTitle: ' Group Name Already Exists',
      noBtnText: 'OK',
      alertMsg: 'Product group name already exists. Please enter a unique product group name.'
    },
    ja: {
      cardTitle: 'グループ名はすでに存在します',
      noBtnText: 'はい',
      alertMsg: '製品グループ名はすでに存在します。一意の製品グループ名を入力してください。'
    }
  }
};

export const productPreviewPopUpObject = {
  messages: {
    en: {
      productDetailsText: 'products details',
      productnameText: 'Product Name',
      productcodeText: 'Product Code',
      productDescriptionText: 'Product Description',
      divisionOrDepartment: 'Division/Department',
      department: 'Department',
      division: 'Division',
      entity: 'Entity',
      criteria: 'Criteria',
      countrynameText: 'Country/City Name',
      statusText: 'Status',
      entityText: 'Entity',
      countryText: 'Country',
      productCriteriaText: 'products criteria Details',
      stateText: 'State',
      cityText: 'City',
      productlistText: 'products list',
      cardTitle: ' Cancel Creating Product Group',
      editCardTitle: ' SAVE CHANGES?',
      noBtnText: 'NO',
      yesBtnText: 'YES',
      alertMsg: 'Are you sure you wish to cancel creating a new product group?',
      editAlertMsg: 'Would you like to save the changes you’ve made?',
      noRecordFoundHeader: 'NO PRODUCTS DETAILS FOUND',
      noResultMessage:
        'The search could not find any product group based on the search text you entered in the search field. Please revise the search text to try again.'

    },
    ja: {
      productDetailsText: '商品詳細',
      productnameText: '商品名',
      productcodeText: '商品コード',
      productDescriptionText: '商品概要',
      divisionOrDepartment: '事業・部門',
      department: '部門',
      division: '事業',
      entity: 'プログラムエンティティ',
      countrynameText: '国/都市名',
      statusText: 'ステータス',
      entityText: 'プログラムエンティティ',
      countryText: '国',
      productCriteriaText: '商品グループ条件',
      stateText: '都道府県',
      cityText: '市区町村',
      productlistText: '商品グループ詳細',
      cardTitle: '商品グループ登録キャンセル',
      editCardTitle: ' 変更内容を保存しますか？',
      noBtnText: 'いいえ',
      yesBtnText: 'はい',
      alertMsg: '商品グループ登録をキャンセルします。よろしいですか？',
      editAlertMsg: '変更内容を保存します。よろしいですか？',
      noRecordFoundHeader: '条件に一致するデータがみつかりませんでした',
      noResultMessage:
        '検索フィールドに入力した検索テキストに基づいて、検索で製品グループが見つかりませんでした。検索テキストを修正して、再試行してください。',
      criteria: '基準'
    }
  }
};

export const configurableExtensionObj = {
  messages: {
    en: {
      configurableExtension: 'Configurable Extension',
      configurableExtensions: 'CONFIGURABLE EXTENSIONS(S)',
      configurableExtensionList: 'CONFIGURABLE EXTENSIONS LIST',
      createNewconfigExtension: 'CREATE A NEW CONFIGURABLE EXTENSION',
      extensionDescription: 'Extension Description',
      programEntity: 'Program Entity',
      extensionType: 'Extension Type',
      extensionName: 'Extension Name'
    },
    ja: {
      configurableExtension: 'Configurable Extension',
      configurableExtensions: 'CONFIGURABLE EXTENSIONS(S)',
      configurableExtensionList: 'CONFIGURABLE EXTENSIONS LIST',
      createNewconfigExtension: 'CREATE A NEW CONFIGURABLE EXTENSION',
      extensionDescription: 'Extension Description',
      programEntity: 'Program Entity',
      extensionType: 'Extension Type',
      extensionName: 'Extension Name'
    }
  }

};

export const acceptreportdatalangObj = {
  messages: {
    en: {
      selectProgramLabel: 'Select Program',
      toLabel: 'To',
      fromLabel: 'From',
      cancelBtnText: 'Cancel',
      okBtnText: 'Ok',
      selectRoleLabel: 'Select User Type',
      activeLabel: 'Active',
      inActiveLabel: 'Inactive',
      expiredLinkLabel: 'Expired Link',
      pendingLabel: 'Pending Signup',
      draftLabel: 'Draft',
      clearandcloseText: 'Clear & Close',
      applyfilterText: 'Apply Filters',
      closeText: 'CLOSE'
    },
    ja: {
      selectProgramLabel: 'Select Program',
      toLabel: 'To',
      fromLabel: 'From',
      cancelBtnText: 'Cancel',
      okBtnText: 'Ok',
      selectRoleLabel: 'Select User Type',
      activeLabel: 'Active',
      inActiveLabel: 'Inactive',
      expiredLinkLabel: 'Expired Link',
      pendingLabel: 'Pending Signup',
      draftLabel: 'Draft',
      clearandcloseText: 'Clear & Close',
      applyfilterText: 'Apply Filters',
      closeText: 'CLOSE'
    }
  }
};

export const deleteLocationObj = {
  messages: {
    en: {
      deleteLocation: 'Delete Location',
      infoText: 'Are you sure you want to delete this location?',
      no: 'No',
      yes: 'Yes'
    },
    ja: {
      deleteLocation: 'ファイルロケーション削除',
      infoText: 'ファイルロケーションを削除します。よろしいですか？',
      no: 'いいえ',
      yes: 'はい'
    }
  }
};
