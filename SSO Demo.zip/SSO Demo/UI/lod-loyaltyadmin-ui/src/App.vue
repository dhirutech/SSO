<template>
  <v-app class="tranparent-bg">
    <!-- View with Left and Top Navigation -- START -->
    <v-row
      v-if="$route.meta.showNavigation === true"
      class=" main-router__view"
      no-gutters
    >
      <v-col class="bpl3 white-bg bpr3 head-gap">
        <v-row class="main-router__viewContent flex-column" no-gutters>
          <router-view></router-view>
        </v-row>
      </v-col>
    </v-row>
    <!-- View with Left and Top Navigation -- END -->

    <!-- View with OUT Left and Top Navigation -- START -->
    <v-row
      v-if="$route.meta.showNavigation === false"
      class="inner_route"
      no-gutters
    >
      <router-view></router-view>
    </v-row>
    <!-- View with OUT Left and Top Navigation -- END -->
  </v-app>
</template>

<script>
// import { BrierleyFooter } from '@brierley/SharedComponents';
export default {
  name: 'App',
  components: {
    // BrierleyFooter
  },
  data: () => ({
    drawer: null
  }),
  mounted () {
    this.$root.GlobalStoreEventStore.dispatch(
      'showNavigationAction',
      this.$route.meta.showNavigation ? this.$route.meta.showNavigation : false
    );
  },
  watch: {
    '$route.meta.showNavigation': {
      handler: function (newValue) {
        this.$root.GlobalStoreEventStore.dispatch(
          'showNavigationAction',
          newValue
        );
      },
      deep: true
    }
  }
};
</script>
<style lang="scss">
@import url("https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap");
</style>
