
const fs = require('fs');
module.exports = {
  'transpileDependencies': [
    'vuetify'
  ],
  devServer: {
    hot: true,
    inline: false,
    https: {
      key: fs.readFileSync('./LoyaltyAdmin.pfx'),
      cert: fs.readFileSync('./LoyaltyAdmin.cer'),
      // key: fs.readFileSync('./server.key'),
      // cert: fs.readFileSync('./server.crt'),
    },
  },
  chainWebpack: config => {
    // config.devServer.set('inline', false)
    // config.devServer.set('hot', true)
    // Vue CLI 4 output filename is js/[chunkName].js, different from Vue CLI 3
    // More Detail: https://github.com/vuejs/vue-cli/blob/master/packages/%40vue/cli-service/lib/config/app.js#L29
    if (process.env.NODE_ENV !== 'production') {
      config.output.filename('[name].js');
    }
    config.externals(['vue', 'vue-router', 'vuetify', /^@brierley\/.+/]);
  },
  filenameHashing: false,
};
