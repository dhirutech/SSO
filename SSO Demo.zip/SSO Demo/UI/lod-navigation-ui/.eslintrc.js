module.exports = {
  root: true,
  env: {
    node: true
  },
  extends: ['plugin:vue/essential', 'eslint:recommended'],
  parserOptions: {
    parser: 'babel-eslint'
  },
  rules: {
    'no-debugger': 'error',
    indent: ['warn', 2],
    'no-console': ['error', { allow: ['debug', 'warn', 'error'] }],
    eqeqeq: 'error',
    'no-empty-function': 'error',
    'no-implicit-globals': 'error',
    'no-invalid-this': 'error',
    'no-undef': 'error',
    'no-unused-vars': 'warn',
    'no-use-before-define': 'warn',
    'no-sync': 'warn',
    'comma-dangle': 'off',
    'comma-spacing': 'warn',
    'comma-style': ['error', 'last'],
    'eol-last': 'warn',
    'no-extra-parens': 'warn',
    semi: ['warn', 'always'],
    'no-extra-semi': 'warn',
    'no-irregular-whitespace': 'error',
    'block-spacing': 'warn',
    'brace-style': 'error',
    'jsx-quotes': ['error', 'prefer-single'],
    quotes: ['error', 'single'],
    'no-inline-comments': 'warn',
    'keyword-spacing': 'warn',
    'key-spacing': 'warn',
    'no-mixed-spaces-and-tabs': 'warn',
    'no-multiple-empty-lines': 'error',
    'no-trailing-spaces': 'error',
    'no-whitespace-before-property': 'error',
    'object-curly-newline': 'warn',
    'object-curly-spacing': ['warn', 'always'],
    'spaced-comment': 'warn',
    'space-in-parens': 'warn',
    'space-before-function-paren': ['warn', 'always'],
    'space-before-blocks': 'warn',
    'no-var': 'error'
  },
  overrides: [
    {
      files: [
        '**/__tests__/*.{j,t}s?(x)',
        '**/tests/unit/**/*.spec.{j,t}s?(x)'
      ],
      env: {
        jest: true
      }
    }
  ]
};
