# Kona Identity

This project encapsulates the Kona-specific wrapper functionality ontop of [Microsoft IdentityServer4](https://identityserver4.readthedocs.io/en/latest/).  

## Getting Started

To get started, restore your nuget packages locally:
```
dotnet restore
```

* Ensure you have a local instance of Postgres running ([postgressapp.com](postgressapp.com) for mac, [postgresql.org](https://www.postgresql.org/download/windows/) for windows).
* Then kick off a build using your favorite debugger

## Creating Migrations

Because IdentityServer manages the majority of its schema, creating/managing migrations is slightly different in this project compared to the other Kona services.  For this reason, please use the following commands via the terminal *_while in the Repository folder_* for creating new migrations:

```
dotnet ef --startup-project ../API/ migrations add 050720_InitialMigration_PersistedKey --context PersistedKeyDbContext --output-dir Migrations/PersistedKey -v
```
```
dotnet ef --startup-project ../API/ migrations add 052120_UniqueCompositeIndexForUsernameAndTenant --context ApplicationDbContext --output-dir Migrations/Application -v
```
```
dotnet ef --startup-project ../API/ migrations add 050720_InitialMigration_Configuration --context ConfigurationDbContext --output-dir Migrations/Configuration -v
```
```
dotnet ef --startup-project ../API/ migrations add 050720_InitialMigration_PersistedGrant --context PersistedGrantDbContext --output-dir Migrations/PersistedGrant -v
```
