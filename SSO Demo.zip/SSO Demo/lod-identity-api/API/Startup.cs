using API.Filters;
using API.Swagger;
using API.Utilities;
using AutoMapper;
using IdentityModel;
using IdentityServer4.EntityFramework.DbContexts;
using IdentityServer4.EntityFramework.Mappers;
using IdentityServer4.EntityFramework.Options;
using IdentityServer4.Extensions;
using Logic.Interfaces;
using Logic.Mappers;
using Logic.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Repository;
using Repository.Interfaces;
using Repository.Models;
using Repository.Repositories;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;

namespace API
{
    public class Startup
    {
        private readonly IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        ///////////////////////////////
        //  CONFIGURE SERVICES (IoC Setup)
        //  This is where we add services to the IoC container (IServiceCollection).  For most 
        //  libraries an extension method is included which allows for customizing configurations
        //  through lambda expressions in their arguments.  For local classes, mappings to interfaces
        //  are provided allowing for three lifetimes including Singleton, Transient, and Scoped.
        //  https://docs.microsoft.com/en-us/aspnet/core/fundamentals/startup?view=aspnetcore-3.1
        ///////////////////////////////
        public void ConfigureServices(IServiceCollection services)
        {
            HttpClient httpClient = new HttpClient()
            {
                BaseAddress = new Uri(Environment.GetEnvironmentVariable("CommunicationAPI_BaseURL") ?? throw new InvalidOperationException())
            };

            services.AddSingleton<HttpClient>(httpClient);
            // ADD MVC CORE
            // Adds the minimum essential MVC services 
            // https://docs.microsoft.com/en-us/dotnet/api/microsoft.extensions.dependencyinjection.mvccoreservicecollectionextensions.addmvccore?view=aspnetcore-3.1
            services.AddMvcCore();


            // ADD LOCAL API AUTHENTICATION
            // 
            services.AddLocalApiAuthentication();

            // ADD CONTROLLERS
            // This method configures the MVC services for the commonly used features with controllers for an API.
            services.AddControllers(config => { config.Filters.Add(typeof(GlobalExceptionFilter)); })
                .AddNewtonsoftJson(setUpAction =>
                {
                    setUpAction.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;

                    // CONTRACT RESOLVER
                    // CamelCasePropertyNamesContractResolver - this is to allow for serializing/deserializing camelcase properties
                    setUpAction.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                });

            // ADD COOKIE POLICY
            // Configures a cookie policy to properly set the SameSite attribute.
            services.ConfigureNonBreakingSameSiteCookies();

            // ADD CORS
            // Determines Access-Control-Allow headers.  We may be able to tighten this down once the deployed versions are locked down
            // to only routing through the API Gateway.
            services.AddCors(options => options.AddPolicy("ApiCorsPolicy", builder =>
            {
                var ui_host = Environment.GetEnvironmentVariable("UI_Host");
                var ui_gap = Environment.GetEnvironmentVariable("UI_Gap");
                var ui_hertz = Environment.GetEnvironmentVariable("UI_Hertz");

                builder.WithOrigins(new string[]
                {
                    "https://" + ui_host,
                    "http://" + ui_host,
                    "https://" + ui_gap,
                    "http://" + ui_gap,
                    "https://" + ui_hertz,
                    "http://" + ui_hertz,
                    "http://localhost:8081",
                    "https://localhost:8081",
                    "https://localhost:44371",
                    "http://localhost:8080",
                    "https://localhost:8080",
                    "http://localhost:9000",
                    "https://localhost:9000",
                    "https://kona-dev.brierleycloud.net:8093",
                    "https://kona-qa.brierleycloud.net:8093",
                    "https://kona-uat.brierleycloud.net:8093",
                    "https://kona-dev-api.brierleycloud.net:8080",
                    "https://kona-demo.brierley.com",
                    "https://kona-perf.brierleycloud.net",
                    "http://gap-kona.brierley",
                    "https://kona.brierley:9000",
                    "https://gap-kona.brierley:9000",
                    "https://hertz-kona.brierley:9000",
                }
                ).AllowAnyMethod().AllowAnyHeader().AllowCredentials();
            }));


            // ADD DATABASE CONTEXTS
            // Adds the DB Contexts.  Given IdentityServers setup, multiple contexts are covered in this method.
            AddDatabaseContexts(services, _configuration);


            // MIGRATE DB's
            // Migrates the DB using the contexts defined in the AddDatabaseContexts method above.
            MigrateDatabase(services, _configuration);


            // ADD SWAGGER GEN
            // Register the Swagger generator, exposing the swagger models, enabling authentication, and defining 1 or more Swagger documents
            // https://docs.microsoft.com/en-us/aspnet/core/tutorials/getting-started-with-swashbuckle?view=aspnetcore-3.1&tabs=visual-studio
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "Identity Services",
                });
                c.SwaggerDoc("v2", new OpenApiInfo
                {
                    Version = "v2",
                    Title = "Identity Services",
                });
                // ADD SECURITY DEFINITION & ADD SECURITY REQUIREMENT
                // These 2 extensions enable the Swagger UI to include the Authorization header in its requests
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = "Added \"Bearer\" + [space].\r\n\r\nExample: \"Bearer 12345abcdef\"",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer"

                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            },
                            Scheme = "oauth2",
                            Name = "Bearer",
                            In = ParameterLocation.Header,

                        },
                        new List<string>()
                    }
                });
                c.OperationFilter<RemoveVersionFromParameter>();
                c.DocumentFilter<ReplaceVersionWithExactValueInPath>();

                c.DocInclusionPredicate((version, desc) =>
                {
                    var versions = desc.CustomAttributes()
                        .OfType<ApiVersionAttribute>()
                        .SelectMany(attr => attr.Versions);

                    var maps = desc.CustomAttributes()
                        .OfType<MapToApiVersionAttribute>()
                        .SelectMany(attr => attr.Versions)
                        .ToArray();

                    return versions.Any(v => $"v{v}" == version)
                                  && (!maps.Any() || maps.Any(v => $"v{v}" == version));
                });
                // For basic functionality, above is all that's required, however for summary, remarks, and other comment
                // based swagger and xml file must be generated (in the csproj, the GenerateDocumentationFile tag = true)
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
            });


            // ADD LOCAL SERVICES
            // Register local classes for dependency injection
            services.AddTransient<ILoginService, LoginService>();
            services.AddTransient<IUserService, UserService>();
            services.AddTransient<ITokenService, TokenService>();
            services.AddTransient<IEmailService, EmailService>();
            services.AddTransient<IUserRepository, UserRepository>();
            services.AddScoped<ITenantRequestProvider, TenantRequestProvider>();
            services.AddScoped<IHttpClientAccessor, HttpClientAccessor>();
            services.AddHttpContextAccessor();                                  // ADD HTTPS CONTEXT ACCESSOR - exposes access to the http context to be injected into the services
            services.AddTransient<IPrincipal>(provider =>
                provider.GetService<IHttpContextAccessor>()?.HttpContext?.User  // This exposes the user object specifically to be injected as needed
            );

            services.AddAutoMapper(typeof(LoginProfile));



            // ADD API VERSIONING
            // Adds versioning control for the API's
            services.AddApiVersioning();
            services.AddHostedService<UserStatusService>();
        }


        ////////////////
        //  CONFIGURE (Middleware)
        //  This is the middleware through which every request runs.  As each extension flows into
        //  the next, the order is incredibly important and every addition adds overhead to each
        //  request.  Use care in modifications and refer to the MS docs as a starting point for
        //  any questions: https://docs.microsoft.com/en-us/aspnet/core/fundamentals/middleware/?view=aspnetcore-3.1
        //////////////// 
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            // USE COOKIE POLICY
            // Custom middleware to handle same site cookie policy issues on Chrome.
            //app.UseCookiePolicy();

            // USE REQUEST RESPONSE LOGGING
            // Custom middleware for intercepting requests and responses and logging their values
            app.UseRequestResponseLogging();


            // USE REWRITER
            // Custom middleware for rewriting response headers, testing to make sure it's no longer needed -05/20/20



            // USE HTTPS REDIRECTION
            // This middleware shortcircuits the request from ever hitting an endpoint if the request
            // was not made over https.
            app.UseHttpsRedirection();


            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // USE HSTS
                // adds the Strict-Transport-Security header in the response, this adds the domain to the browsers
                // HSTS List so that all subsequent requests are made over HTTPS.  This is for client side optimization
                // to prevent further unneeded HTTP requests that would just be redirected to HTTPS anyways.  It's
                // dependent on browser support.
                app.UseHsts();
            }


            // USE CORS
            // This applies the CORS policies as defined during the Startup.ConfigureServices method. CORS is primarily
            // a browsers based security measure, therefore this is specifically for returning the correct headers for 
            // preflight (Options) requests to notify the browser what kind of cross-origin requests this server is ok with.
            app.UseCors("ApiCorsPolicy");


            // USE PATH BASE
            // This sets the first piece of the request path for anything that would hit this service 
            // (so that all calls to this service must start with what's defined here)
            app.UsePathBase(new PathString("/identity"));


            // SWAGGER
            // Enable middleware to serve generated Swagger as a JSON endpoint but customize the pathbase.
            app.Use((context, next) =>
            {
                context.Request.PathBase = new PathString("/identity");
                return next();
            }).UseSwagger();


            // SWAGGER UI
            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/identity/swagger/v1/swagger.json", "Version 1");

                c.SwaggerEndpoint("/identity/swagger/v2/swagger.json", "Version 2");
            });


            // USE IDENTITY SERVER
            // Adds the IdentityServer services to the middleware
            app.UseIdentityServer();


            // USE ROUTING
            // At this stage, the endpoint is chosen (but not yet invoked).  This is to allow the middleware that's dependent
            // on the route evaluation to act before the route's endpoint is executed (.UseEndpoints).  AuthN/AuthZ are the
            // primary middleware that fit between here and its counterpart .UseEndpoints().
            app.UseRouting();


            // USE AUTHENTICATION
            // This applies the JWT validation as set forth in the above ConfigureServices method.
            // This middleware answers the question "who are you" by inspecting the users token.
            app.UseAuthentication();


            // USE AUTHORIZATION
            // This connects the authentication applied in .UseAuthentication() against our controllers,
            // enforcing the authentication.
            // This middleware answers the question "are you allowed".
            app.UseAuthorization();


            // USE ENDPOINTS
            // This is the middleware that actually delivers the request to the method determined by the UseRouting
            // middleware above.
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });


            // MIGRATE DB AND SEED DATA
            // While this method is not actually used in the middleware, it will be called during startup after ConfigureServices
            // has already run allowing for grabbing services already registered through the IoC container.  This method then
            // populates the seed data primarily for configuration purposes (clients, claims, scopes) but also for seeding test
            // users
            AddSeedData(app);
        }



        private static void AddDatabaseContexts(IServiceCollection services, IConfiguration _configuration)
        {
            var connectionString = "Host=kona-dev-db.brierleycloud.net;Username=identityadmin;Password=Konaidentity@123;Database=Identity;Port=30502";// Environment.GetEnvironmentVariable("ConnectionStrings__IdentityAPIDBConnection");
            //connectionString = "Host=localhost;Username=postgres;Password=password;Database=Identity;Port=5432";
            // ADD APPLICATION's DB CONTEXT
            // Register our base context which is used by Identity
            services.AddDbContext<ApplicationDbContext>(builder =>
                builder.UseNpgsql(connectionString, sqlOptions =>
                    sqlOptions.MigrationsAssembly("Repository")));


            // ADD IDENTITY
            // Here we add Identity Services to the service collection and register our custom 
            // class "AppUser" which inherits from IdentityUser so that we can customize our
            // User objects.

            services.AddIdentity<AppUser, IdentityRole>(configure =>
                {
                    configure.Lockout.AllowedForNewUsers = true;
                    configure.Lockout.MaxFailedAccessAttempts = 5;
                    configure.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromDays(36500);

                    configure.Password.RequireDigit = true;
                    configure.Password.RequireUppercase = true;
                    configure.Password.RequiredLength = 8;
                    configure.Password.RequireLowercase = false;

                    configure.User.RequireUniqueEmail = true;
                })

                // ADD ENTITYFRAMEWORK STORES
                // This connects our EF context "ApplicationDbContext" (which inherits from IdentityDbContext)
                // to the Identity Services (Microsoft.AspNetCore.Identity).
                .AddEntityFrameworkStores<ApplicationDbContext>()


                // ADD USER MANAGER
                // Here we register our custom userManager with MS's Identity library so that we can override the standard 
                // methods for creating/updating/etc. of users to include tenantId.
                .AddUserManager<ApplicationUserManager<AppUser>>()


                // ADD USER STORE
                // Here we use our custom userStore, currently this is just for the create process.
                .AddUserStore<ApplicationUserStore<AppUser>>();



            var certPath = Path.Combine(Path.GetFullPath("./"), "certificate.pfx");
            var cert = new X509Certificate2(certPath, "Kona_2019");


            // ADD PERSISTENT KEYS
            // Registers our context which implements IDataProtectionKeyContext used for persisting the JWK's to the DB (table - DataProtectionKeys).  
            // This part is responsible for enabling scaling out of the Identity service because new containers will use the persisted keys for
            // validating JWT's.
            services.AddDbContext<PersistedKeyDbContext>(options =>
                options.UseNpgsql(connectionString, sqlOptions =>
                    sqlOptions.MigrationsAssembly("Repository")));


            // ADD DATA PROTECTION
            // This is required when persisting keys to the DB for en/decrypting them.
            services.AddDataProtection()
                .SetApplicationName("IdentityService")
                .PersistKeysToDbContext<PersistedKeyDbContext>()
                .SetDefaultKeyLifetime(TimeSpan.FromDays(14));


            // ADD IDENTITY SERVER
            // Registers the IdentityServer services.  Where .AddIdentity() includes the base implementations for
            // managing users, claims, scopes, etc., .AddIdentityServer() includes services for OAuth (ie authorization
            // code flow and above).  These services extend beyond basic implicit flow authentication.
            services.AddIdentityServer()

                // ADD OPERATIONAL STORE
                // Adds support for persisting AuthorizationGrants, Consents, and Tokens
                // http://docs.identityserver.io/en/stable/reference/ef.html#operational-store-support-for-authorization-grants-consents-and-tokens-refresh-and-reference
                .AddOperationalStore(options =>
                    options.ConfigureDbContext = builder =>
                        builder.UseNpgsql(connectionString, sqlOptions => sqlOptions.MigrationsAssembly("Repository")))


                // ADD CONFIGURATION STORE
                // Adds support for persisting Clients, Identity/API Resources, and CORS data to the DB.
                // http://docs.identityserver.io/en/stable/reference/ef.html
                .AddConfigurationStore(options =>
                    options.ConfigureDbContext = builder =>
                        builder.UseNpgsql(connectionString, sqlOptions => sqlOptions.MigrationsAssembly("Repository")))

                // ADD ASPNET IDENTITY
                // Here we register our custom user class which inherits from the IdentityUser class to be used by IdentityServer.
                // This user model needs to be the same as that passed to .AddIdentity() above.
                .AddAspNetIdentity<AppUser>()

                // ADD SIGNING CREDENTIALS
                // Here we register an X509 certificate used for signing tokens which is connected to
                // the last string in the token ("xxxxxx.xxxxxx.{signature}").
                .AddSigningCredential(cert);
        }


        private static void MigrateDatabase(IServiceCollection services, IConfiguration _configuration)
        {
            var connectionString = Environment.GetEnvironmentVariable("ConnectionStrings__IdentityAPIDBConnection");
            try
            {
                
                //connectionString = "Host=localhost;Username=postgres;Password=password;Database=Identity;Port=5432";
                // MIGRATE APPLICATION CONTEXT
                var applicationOptionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
                applicationOptionsBuilder.UseNpgsql(connectionString, sqlOptions => sqlOptions.MigrationsAssembly("Repository"));
                using (var context = new ApplicationDbContext(applicationOptionsBuilder.Options))
                {
                    context.Database.Migrate();
                }
            }
            catch(Exception ex)
                {
            }

            // MIGRATE PERSISTENT KEYS CONTEXT
            var persistentKeyOptionsBuilder = new DbContextOptionsBuilder<PersistedKeyDbContext>();
            persistentKeyOptionsBuilder.UseNpgsql(connectionString, sqlOptions => sqlOptions.MigrationsAssembly("Repository"));
            using (var context = new PersistedKeyDbContext(persistentKeyOptionsBuilder.Options))
            {
                context.Database.Migrate();
            }


            // MIGRATE PERSISTED GRANT CONTEXT
            var persistentGrantOptionsBuilder = new DbContextOptionsBuilder<PersistedGrantDbContext>();
            var operationalStoreOptions = new OperationalStoreOptions();
            persistentGrantOptionsBuilder.UseNpgsql(connectionString, sqlOptions => sqlOptions.MigrationsAssembly("Repository"));
            using (var context = new PersistedGrantDbContext(persistentGrantOptionsBuilder.Options, operationalStoreOptions))
            {
                context.Database.Migrate();
            }


            // MIGRATE CONFIGURATION CONTEXT
            var configurationOptionsBuilder = new DbContextOptionsBuilder<ConfigurationDbContext>();
            var configurationStoreOptions = new ConfigurationStoreOptions();
            configurationOptionsBuilder.UseNpgsql(connectionString, sqlOptions => sqlOptions.MigrationsAssembly("Repository"));
            using (var context = new ConfigurationDbContext(configurationOptionsBuilder.Options, configurationStoreOptions))
            {
                context.Database.Migrate();
            }
        }


        private static void AddSeedData(IApplicationBuilder app)
        {
            try
            {
                using var scope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope();

                var context = scope.ServiceProvider.GetRequiredService<ConfigurationDbContext>();

                if (!context.Clients.Any())
                {
                    foreach (var client in Clients.Get())
                    {
                        context.Clients.Add(client.ToEntity());
                    }
                    context.SaveChanges();
                }

                if (!context.IdentityResources.Any())
                {
                    foreach (var resource in Resources.GetIdentityResources())
                    {
                        context.IdentityResources.Add(resource.ToEntity());
                    }
                    context.SaveChanges();
                }

                if (!context.ApiResources.Any())
                {
                    foreach (var resource in Resources.GetApiResources())
                    {
                        context.ApiResources.Add(resource.ToEntity());
                    }
                    context.SaveChanges();
                }

                var userManager = scope.ServiceProvider.GetRequiredService<UserManager<AppUser>>();
                var noLockoutUsers = userManager.Users.Where(x => !x.LockoutEnabled).ToList();
                if (noLockoutUsers?.Count > 0)
                {
                    noLockoutUsers.ForEach(user =>
                    {
                        user.LockoutEnabled = true;
                        userManager.UpdateAsync(user).Wait();
                    });
                }
                if (!userManager.Users.Any())
                {
                    foreach (var testUser in Users.Get())
                    {
                        var defaultApp = "myDefaultApp";
                        var password = "Kona_2019";

                        testUser.AlternateEmail = "alternate-" + testUser.UserName;
                        testUser.DefaultApp = defaultApp;
                        testUser.Email = testUser.UserName;
                        testUser.ExternalId = testUser.FirstName + "ExternalId";
                        testUser.PhoneNumber = "1234567890";
                        testUser.PhoneNumberConfirmed = true;
                        testUser.Status = true;
                        testUser.PasswordQueue = "firstFakePasswordHistory";
                        testUser.LockoutEnabled = true;

                        var claims = new List<Claim>
                        {
                            new Claim(JwtClaimTypes.Email, testUser.Email),
                            new Claim(JwtClaimTypes.Role, "admin"),
                            new Claim("tenant", testUser.TenantId),
                            new Claim("defaultApp", defaultApp)
                        };

                        userManager.CreateAsync(testUser, password).Wait();
                        userManager.AddClaimsAsync(testUser, claims).Wait();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}
