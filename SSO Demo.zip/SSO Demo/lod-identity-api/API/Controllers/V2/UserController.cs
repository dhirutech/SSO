﻿using API.Utilities;
using AutoMapper;
using Brierley.Common.Web.Controllers.Response;
using Logic.Interfaces;
using Logic.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Repository.Models;
using Repository.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static IdentityServer4.IdentityServerConstants;

namespace API.Controllers.V2
{
    /// <summary>
    /// Version 2 User Controller for Gen2
    /// </summary>
    [ApiVersion("2")]
    [Route("api/v{version:apiVersion}/users")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly UserManager<AppUser> _userManager;
        private readonly IMapper _mapper;
        private readonly IEmailService _emailService;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="user"></param>
        /// <param name="userManager"></param>
        /// <param name="mapper"></param>
        /// <param name="emailService"></param>
        public UserController(IUserService user, UserManager<AppUser> userManager, IMapper mapper, IEmailService emailService)
        {
            _userService = user;
            _userManager = userManager;
            _mapper = mapper;
            _emailService = emailService;
        }

        /// <summary>
        /// Create User Method
        /// </summary>
        /// <param name="user"></param>
        /// <returns>Created User</returns>
        [ProducesResponseType(typeof(UserViewModel), StatusCodes.Status201Created)]
        [HttpPost]
        [Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> Create(CreateUser user)
        {
            if (string.IsNullOrEmpty(user.UserId))
            {
                user.UserId = Guid.NewGuid().ToString();
            }
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Select(x => x.Value.Errors)
                                       .Where(y => y.Count > 0)
                                       .ToList();
                return BadRequest(errors);
            }

            var createdUser = await _userService.CreateUser(user);
            return Created("user/create", createdUser);
        }

        /// <summary>
        /// Update User
        /// </summary>
        /// <param name="user"></param>
        /// <returns>Updated User</returns>
        [ProducesResponseType(typeof(UserViewModel), StatusCodes.Status200OK)]
        [HttpPatch]
        [Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> Update(EditUser user)
        {
            var updateUser = _userManager.Users.FirstOrDefault(x => x.Id == user.Id);
            if (updateUser == null)
            {
                throw new KeyNotFoundException("User not found");
            }
            try
            {
                if (user.IsProfileComplete == true && updateUser.UserStatusId == UserStatuses.Draft)
                {
                    updateUser.UserStatusId = UserStatuses.PendingSignup;
                    Task.Run(() => _emailService.UserSignUpEmail(updateUser));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            updateUser.Email = user.Email;
            updateUser.Roles = user.Roles;
            updateUser.FirstName = user.FirstName;
            updateUser.LastName = user.LastName;
            updateUser.AlternateEmail = user.AlternateEmail;
            updateUser.PhoneNumber = user.PhoneNumber;
            updateUser.ExternalId = user.ExternalId;
            updateUser.DefaultApp = user.DefaultApp;
            updateUser.TenantId = user.TenantId.ToUpper();
            //updateUser.Status = user.Status;//to be deprecated 
            IdentityResult result = await _userManager.UpdateAsync(updateUser);

            if (result.Succeeded)
            {
                var reqObj = _mapper.Map<UserRoleMapRequest>(user);
                await _userService.UserRoleMap(reqObj);
                return Ok(_mapper.Map<EditUser>(updateUser));
            }
            throw new InvalidOperationException(JsonConvert.SerializeObject(result.Errors.Select(x => x.Description)));
        }

        /// <summary>
        /// Check user already exist or not
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        [HttpGet("userexists/{userName}")]
        public async Task<IActionResult> UserExists(string userName)
        {
            var isExists = await _userManager.Users.AnyAsync(x => x.UserName.ToLower() == userName.ToLower()
            || x.Email.ToLower() == userName.ToLower());
            CommonResponse response = new CommonResponse()
            {
                Data = isExists,
                UserMessage = $"user with user name {userName} exists",
                HttpStatusCode = isExists ? StatusCodes.Status200OK : StatusCodes.Status204NoContent
            };
            return StatusCode(response.HttpStatusCode, response);
        }

        /// <summary>
        /// SignUpComplete
        /// </summary>
        /// <param name="passwordSignUpViewModel"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPatch("password/signup")]
        public async Task<IActionResult> SignUpComplete(PasswordSignUpViewModel passwordSignUpViewModel)
        {
            CommonResponse response = await _userService.SignUpComplete(passwordSignUpViewModel);
            return StatusCode(response.HttpStatusCode, response);
        }

        /// <summary>
        /// Updates the user expire to pending state and regenerates the new PasswordSignUpToken.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>True/False</returns>
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [HttpPatch("{userId}")]
        [Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> UpdateUserExpiredStatus(string userId)
        {
            var updatestatus = await _userService.updateUserStatus(userId);
            return Ok(updatestatus);
        }

        /// <summary>
        /// SignupExpiryUsers
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [HttpGet("signupexpired")]
        public async Task<IActionResult> SignupExpiryUsers()
        {
            CommonResponse response = await _userService.GetSignUpExpiredUsers();
            return StatusCode(response.HttpStatusCode, response);
        }

        /// <summary>
        /// Searches the users applying filtering, pagination, and sorting via path variables.
        /// </summary>
        /// <param name="searchFilterUser"></param>
        /// <returns></returns>
        [ProducesResponseType(typeof(SearchResultViewModel), StatusCodes.Status200OK)]
        [HttpGet("getall")]
        [Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> GetAll([FromQuery] SearchFilterViewModel searchFilterUser)
        {
            searchFilterUser.TenantId = User.TenantId().ToUpper();
            var userResults = await _userService.SearchUsers(searchFilterUser);
            if (userResults == null)
                return NoContent();

            return Ok(userResults);
        }

        /// <summary>
        /// Set User DefaultPreferences
        /// </summary>
        /// <param name="userPreferencesViewModel"></param>
        /// <returns></returns>
        [HttpPatch("setuserdefaultpreferences")]
        [Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> SetUserDefaultPreferences(UserPreferencesViewModel userPreferencesViewModel)
        {
            var response = await _userService.SetUserDefaultPreferences(userPreferencesViewModel);
            return StatusCode(response.HttpStatusCode, response);
        }

        /// <summary>
        /// To Get User Details By List Of UserIds
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        [HttpPost("getuserbyids")]
        [Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> GetUserDetailsByUserIds(List<string> userIds)
        {
            var response = await _userService.GetUserDetailsByUserIds(userIds);
            return StatusCode(response.HttpStatusCode, response);
        }        
    }
}
