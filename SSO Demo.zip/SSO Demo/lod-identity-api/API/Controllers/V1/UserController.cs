﻿using System;
using API.Utilities;
using Logic.Interfaces;
using Logic.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static IdentityServer4.IdentityServerConstants;

namespace API.Controllers.V1
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/users")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        public UserController(IUserService user)
        {
            _userService = user;
        }

        /// <summary>
        /// Searches the users applying filtering, pagination, and sorting via path variables.
        /// </summary>
        /// <param name="searchText"></param>
        /// <param name="pageSize"></param>
        /// <param name="pageNumber"></param>
        /// <param name="nameSortType"></param>
        /// <param name="emailSortType"></param>
        /// <param name="externalIdSortType"></param>
        /// <param name="statusSortType"></param>
        /// <returns>UserSearchResults</returns>
        [ProducesResponseType(typeof(SearchResultViewModel), StatusCodes.Status200OK)]
        [HttpGet("{searchText}/{pageSize}/{pageNumber}/{nameSortType}/{emailSortType}/{externalIdSortType}/{statusSortType}")]
        [Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> GetAll(string searchText, int pageSize, int pageNumber, string nameSortType, string emailSortType, string externalIdSortType, string statusSortType)
        {
            SearchFilterViewModel searchFilterViewModel = new SearchFilterViewModel
            {
                SearchText = searchText,
                PageSize = pageSize,
                PageNumber = pageNumber,
                NameSortType = nameSortType,
                EmailSortType = emailSortType,
                ExternalIdSortType = externalIdSortType,
                StatusSortType = statusSortType,
                TenantId = User.TenantId().ToUpper()
            };

            var userResults = await _userService.SearchUsers(searchFilterViewModel);
            if (userResults == null)
                return NoContent();

            return Ok(userResults);
        }

        /// <summary>
        /// Gets the user based on the users Id.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>User</returns>
		[ProducesResponseType(typeof(UserViewModel), StatusCodes.Status200OK)]
        [HttpGet("{userId}")]
        [Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> Get(string userId)
        {
            UserViewModel users = await _userService.GetUserById(userId);

            return Ok(users);
        }

        /// <summary>
        /// Creates a user for a given tenant.
        /// </summary>
        /// <param name="user"></param>
        /// <returns>Created User</returns>
		[ProducesResponseType(typeof(UserViewModel), StatusCodes.Status201Created)]
        [HttpPost]
        [Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> Create(CreateUserViewModel user)
        {
            if(string.IsNullOrEmpty(user.UserId))
            {
                user.UserId = Guid.NewGuid().ToString();
            }
        
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Select(x => x.Value.Errors)
                           .Where(y => y.Count > 0)
                           .ToList();
                return BadRequest(errors);
            }
            user.UserPrograms = new List<UserProgram>
            {
                new UserProgram
                {
                    ProgramId = null,
                    ProgramName = string.Empty,
                    UserRoleDetails = new List<UserRole>
                    {
                        new UserRole
                        {
                            RoleId = 201, RoleName = "Loyalty Administrator"
                        }
                    }
                }
            };
            var createdUser = await _userService.CreateUser(user);

            return Created("user/create", createdUser);
        }

        /// <summary>
        /// Update the user via the request body.  Fields left blank will be updated to null.
        /// </summary>
        /// <param name="user"></param>
        /// <returns>Updated User</returns>
		[ProducesResponseType(typeof(UserViewModel), StatusCodes.Status200OK)]
        [HttpPatch]
        [Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> Update(EditUserViewModel user)
        {
            var updatedUser = await _userService.UpdateUser(user);

            return Ok(updatedUser);
        }

        /// <summary>
        /// Activates and deactivates the given user to its current opposite state.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>True/False</returns>
		[ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [HttpDelete("{userId}")]
        //[Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> ActivateDeActivate(string userId)
        {
            var isDeleted = await _userService.ActivateDeActivateUser(userId);

            return Ok(isDeleted);
        }

        /// <summary>
        /// Sets the users default app when logging into the Kona platform.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="defaultApp"></param>
        /// <returns>True/False</returns>
		[ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [HttpPatch("{userId}/{defaultApp}")]
        [Authorize(LocalApi.PolicyName)]
        public async Task<IActionResult> SetUserDefaultApp(string userId, string defaultApp)
        {
            bool isSuccess = await _userService.SetUserDefaultApp(userId, defaultApp);
            return Ok(isSuccess);
        }
    }
}