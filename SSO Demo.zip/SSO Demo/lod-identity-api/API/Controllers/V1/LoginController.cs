﻿using Brierley.Common.Web.Controllers.Controller;
using Brierley.Common.Web.Controllers.Response;
using IdentityServer4;
using IdentityServer4.Configuration;
using IdentityServer4.Models;
using IdentityServer4.Validation;
using Logic.Interfaces;
using Logic.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting.Internal;
//using Microsoft.IdentityModel.Tokens;
//using Microsoft.IdentityModel.Tokens.Saml2;
//using Newtonsoft.Json;
using Repository.Interfaces;
using Repository.Models;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using System.Xml;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using System.Text;
using Microsoft.IdentityModel;
using Microsoft.IdentityModel.Tokens;
using Microsoft.IdentityModel.Tokens.Saml2;
using System.IdentityModel.Tokens;
using Microsoft.IdentityModel.Tokens.Saml;
using System.Xml.Serialization;

namespace API.Controllers.V1
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/auth")]
    [ApiController]
    public class LoginController : LoyaltyWareController
    {
        private readonly IConfiguration _configuration;
        private readonly ILoginService _loginService;
        private readonly ITokenService _tokenService;
        private readonly IEmailService _emailService;
        private readonly SignInManager<AppUser> _signInManager;
        private readonly UserManager<AppUser> _userManager;
        private readonly IdentityServerOptions _options;
        IdentityServer4.Services.ITokenService _defaultTokenService;
        IdentityServer4.Services.IRefreshTokenService _refreshTokenService;
        IUserClaimsPrincipalFactory<AppUser> _principalFactory;
        private readonly ITenantRequestProvider _tenantProvider;
        private IWebHostEnvironment _environment;

        public LoginController(IConfiguration configuration, ILoginService loginService, ITokenService tokenService, IEmailService emailService,
            UserManager<AppUser> userManager, SignInManager<AppUser> signInManager, [FromServices] IdentityServerOptions options,
            [FromServices] IUserClaimsPrincipalFactory<AppUser> principalFactory, ITenantRequestProvider tenantProvider, IWebHostEnvironment environment)
        {
            _configuration = configuration;
            _loginService = loginService;
            _tokenService = tokenService;
            _emailService = emailService;
            _userManager = userManager;
            _signInManager = signInManager;
            _options = options;
            _principalFactory = principalFactory;
            _tenantProvider = tenantProvider;
            _environment = environment; 
        }

        /// <summary>
		/// Initiate an Authorization Code with PKCE Flow
        /// </summary>
        /// <remarks>
        /// Initiate an Authorization Code with PKCE flow.  This method alone will not work within the Swagger UI as multiple
		/// redirections are required including generation of proof key code exchange from the javascript client to the identity
		/// provider for complete exchange for a token.
		/// </remarks>
        /// <param name="loginRequest"></param>
		[ProducesResponseType(StatusCodes.Status302Found)]
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromForm] LoginViewModel loginRequest)
        {
            // FIND THE USER INCLUDING TENANT
            // Here we specifically find the user first because there's currently no solid way to override the UserManager/UserStore
            // to fully streamline multi-tenancy.  If you look into the ApplicationUserManager.cs you'll find the override for 
            // FindByNameAsync which is used in a number of places throughout the framework under the hood but weren't designed to 
            // accommodate a composite uniqueness of username & tenantId.  If we try to log the user in directly using the
            // PasswordSignInAsync(username, password, ...) we have no (good) way to override SignInManager's internal call to
            // FindByNameAsync to include the tenantId without completely re-writing the Store and middleware extensions.
            //
            // Also this stuff probably needs to get moved to the logic/repository layers, it's a little awkward given Identity's
            // "Store" concepts.
            var loggedUser = await _userManager.Users
                .FirstOrDefaultAsync(x =>
                    (x.NormalizedUserName == loginRequest.Username.ToUpper() ||
                    x.Email.ToLower() == loginRequest.Username.ToLower()) &&
                    x.TenantId.ToLower() == loginRequest.Tenant.ToLower());
            if (loggedUser == null)
            {
                return NoContent();
            }
            else if (!loggedUser.Status)
            {
                await _signInManager.SignOutAsync();
                return new StatusCodeResult(StatusCodes.Status403Forbidden);
            }

            // PASSWORD SIGN IN
            // Since we have the user including their tenantId embedded in the object, we can now log the user in.
            var result = await _signInManager.PasswordSignInAsync(loggedUser, loginRequest.Password, false, true);
            if (result.Succeeded)
            {
                await _userManager.ResetAccessFailedCountAsync(loggedUser);
                loggedUser.LastLoginTime = DateTimeOffset.Now;
                await _userManager.UpdateAsync(loggedUser);
                return Redirect(loginRequest.ReturnUrl);
            }
            else if (result.IsLockedOut)
            {
                return new StatusCodeResult(StatusCodes.Status423Locked);
            }

            return new BadRequestObjectResult(
                new TokenResponse
                {
                    InvalidAttempts = loggedUser.AccessFailedCount,
                    ErrorDescription = "invalid_username_or_password"
                });
        }

        /// <summary>
        /// Update a User's Password
        /// </summary>
        /// <remarks></remarks>
        /// <param name="credentials"></param>
        /// <returns>OK 200 Result</returns>
		[ProducesResponseType(StatusCodes.Status200OK)]
        [HttpPatch("password")]
        public async Task<IActionResult> Update(UserViewModels credentials)
        {
            var result = await _loginService.UpdatePasswordAsync(credentials);

            return Ok(result);
        }

        /// <summary>
        /// Send a Reset Password Link
        /// </summary>
        /// <remarks></remarks>
        /// /// <param name="tenantId"></param>
        /// <param name="email"></param>
        //// <returns></returns>
        [ProducesResponseType(StatusCodes.Status201Created)]
        [HttpPost("resetPassword/{tenantId}/{email}")]
        public async Task<IActionResult> GenerateResetPasswordLink(string email, string tenantId)
        {
            //to-do: check sanity of email, case-sensitive convert to lowercase
            var user = await _userManager.Users.Where(x => x.UserName.ToLower() == email.ToLower())
                .FirstOrDefaultAsync();
            if (user == null)
            {
                throw new KeyNotFoundException("User Not found");
            }

            user.PasswordResetToken = Guid.NewGuid();
            user.PasswordResetTokenExpiration = DateTime.Now.AddMinutes(int.Parse(_configuration["PasswordResetTime"]));
            user.ResetPasswordLinkExpired = false;
            await _userManager.UpdateAsync(user);
            await _emailService.SendEmail(user, tenantId);


            return Created("password/generatelink", "Password reset link generated successfully");
        }

        /// <summary>
        /// Validate a Reset Token
        /// </summary>
        /// <remarks></remarks>
        /// <param name="resetToken"></param>
        //// <returns></returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [HttpPost("resetToken/{resetToken}")]
        public async Task<IActionResult> ValidateResetToken(Guid resetToken)
        {
            var userResetPassword = await _userManager.Users
                .Where(x => x.PasswordResetToken == resetToken).FirstOrDefaultAsync();
            if (userResetPassword == null)
            {
                throw new KeyNotFoundException("User Not Found");
            }
            if (DateTime.Now >= userResetPassword.PasswordResetTokenExpiration || userResetPassword.ResetPasswordLinkExpired)
            {
                userResetPassword.ResetPasswordLinkExpired = true;
                throw new Exception("Reset password link Expired.");
            }
            userResetPassword.ResetPasswordLinkExpired = true;
            await _userManager.UpdateAsync(userResetPassword);
            return Ok(new UserDetails
            { UserId = userResetPassword.Id, UserName = userResetPassword.UserName });
        }

        /// <summary>
        /// Implicit Flow Login
        /// </summary>
        /// <remarks>
        /// This is for testing purposes as acquiring a token via the PKCE flow must be done via the browser
        /// </remarks>
        /// <param name="tokenRequest"></param>
        //// <returns></returns>
        [ProducesResponseType(typeof(TokenResponse), StatusCodes.Status200OK)]
        [HttpPost("token")]
        public async Task<ActionResult<TokenResponse>> GenerateToken([FromForm] TokenRequest tokenRequest)
        {

            var user = await _userManager.Users
                .FirstOrDefaultAsync(x =>
                    (x.NormalizedUserName == tokenRequest.Username.ToUpper() ||
                    x.Email.ToLower() == tokenRequest.Username.ToLower())
                    && x.TenantId == tokenRequest.TenantId);

            if (user == null)
            {
                return new StatusCodeResult(StatusCodes.Status401Unauthorized);
            }

            var response = await _tokenService.GetToken(tokenRequest);

            if (!string.IsNullOrEmpty(response.Error))
            {
                return new BadRequestObjectResult(response);
            }

            return response;
        }

        /// <summary>
        /// Implicit Flow Login
        /// </summary>
        /// <remarks>
        /// This is for testing purposes as acquiring a token via the PKCE flow must be done via the browser
        /// </remarks>
        /// <param name="oktaToken"></param>
        //// <returns></returns>
        [ProducesResponseType(typeof(TokenResponse), StatusCodes.Status200OK)]
        [HttpPost("tokenEx")]
        public async Task<ActionResult<TokenResponse>> GenerateTokenEx(string oktaToken)
        {
            OktaTokenVerify oktaVerify = null;
            //okta configuration
            var oktaDOmain = "https://dev-3870708.okta.com/";
            var clientId = "0oa2wvbcsNvHcREUl5d6";
            var clientSecret = "jSx83IojAkZ4XVV0o2noOWPfSxY18I0HYTKsVCPN";
            var oktaClient = new RestClient(oktaDOmain + "oauth2/default/v1/introspect?token=" + oktaToken + "&token_type_hint=access_token");
            oktaClient.Timeout = -1;
            //validate okta token
            var base64Val = "Basic " + Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", clientId, clientSecret)));
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            request.AddHeader("Authorization", base64Val);
            IRestResponse oktaResponse = oktaClient.Execute(request);
            Console.WriteLine(oktaResponse.Content);
            oktaVerify = JsonSerializer.Deserialize<OktaTokenVerify>(oktaResponse.Content);

            //overriding user name for testing
            oktaVerify.username = "loyaltyadmin@kona.com";
            return await GenerateManualToken(oktaVerify.username);
        }

        /// <summary>
        /// Generate access token from Saml2p token
        /// </summary>
        /// <param name="token"></param>
        //// <returns></returns>
        [ProducesResponseType(typeof(TokenResponse), StatusCodes.Status200OK)]
        [HttpPost("tokensaml2p")]
        public async Task<ActionResult<TokenResponse>> GenerateTokenFromSaml2P([FromForm] string token)
        {
            string userName= string.Empty;
            var decodedSamlResponse = Convert.FromBase64String(token);
            using (var reader = XmlReader.Create(new MemoryStream(decodedSamlResponse)))
            {
                var serializer = new XmlSerializer(typeof(XmlElement));
                var samlResponseElement = (XmlElement)serializer.Deserialize(reader);
                var manager = new XmlNamespaceManager(samlResponseElement.OwnerDocument.NameTable);
                manager.AddNamespace("saml2", "urn:oasis:names:tc:SAML:2.0:assertion");
                var assertion = (XmlElement)samlResponseElement.SelectSingleNode("//saml2:Assertion", manager);
                Saml2SecurityTokenHandler secTokenHandler = new Saml2SecurityTokenHandler();
                using (var xmlReader = XmlReader.Create(new StringReader(assertion.OuterXml)))
                {

                    var path = _environment.ContentRootPath + "\\saml2.cert";
                    var certificate = new X509Certificate2(path);
                    Dictionary<String, X509Certificate2> certificates = new Dictionary<String, X509Certificate2>();
                    certificates.Add("test", certificate);

                    var tokenValidationParameters = new TokenValidationParameters()
                    {
                        IssuerSigningKeyResolver = (token, securityToken, kid, validationParameter) =>
                        {
                            return certificates
                                .Select(x => new X509SecurityKey(x.Value));
                        },
                        ValidateAudience = false,
                        ValidateIssuer = false
                    };

                    secTokenHandler.ValidateToken(xmlReader, tokenValidationParameters, out var secToken);
                    userName = ((Microsoft.IdentityModel.Tokens.Saml2.Saml2SecurityToken)secToken).Assertion.Subject.NameId.Value;
                }
            }

            //overriding user name for testing
            userName = "loyaltyadmin@kona.com";
            return await GenerateManualToken(userName);
        }

        private async Task<ActionResult<TokenResponse>> GenerateManualToken(string userName)
        {
            var user = await _userManager.Users
                .FirstOrDefaultAsync(x =>
                    (x.NormalizedUserName == userName.ToUpper() ||
                    x.Email.ToLower() == userName.ToLower()));

            if (user == null)
            {
                return new StatusCodeResult(StatusCodes.Status401Unauthorized);
            }

            _tenantProvider.SetTenant("BRIERLEY");

            //Create token request
            var IdentityPricipal = await _principalFactory.CreateAsync(user);
            var IdentityUser = new IdentityServerUser(user.Id.ToString());

            var client = Clients.Get().Where(x => x.ClientId == "kona_vue_app").FirstOrDefault();
            var claims = new List<Claim>();
            claims.AddRange(IdentityPricipal.Claims.ToList());
            IdentityUser.AdditionalClaims = claims;
            IdentityUser.DisplayName = user.UserName;
            IdentityUser.AuthenticationTime = System.DateTime.UtcNow;
            IdentityUser.IdentityProvider = IdentityServerConstants.LocalIdentityProvider;
            var tokenRequest = new TokenCreationRequest();
            tokenRequest.Subject = IdentityUser.CreatePrincipal();
            tokenRequest.ValidatedRequest = new ValidatedRequest();
            tokenRequest.ValidatedRequest.Subject = tokenRequest.Subject;
            tokenRequest.IncludeAllIdentityClaims = true;
            tokenRequest.ValidatedRequest.SetClient(client);
            tokenRequest.Resources = new IdentityServer4.Models.Resources(Resources.GetIdentityResources(), Resources.GetApiResources());
            tokenRequest.ValidatedRequest.ClientClaims = claims;
            tokenRequest.ValidatedRequest.Options = _options;

            //Get token
            var tokenResponse = await _tokenService.GetTokenEx(tokenRequest);
            return tokenResponse;
        }



        /// <summary>
        /// Invalidate a User's Session
        /// </summary>
        /// <remarks></remarks>
        /// <param name="logoutId"></param>
        //// <returns></returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [HttpGet("logout")]
        public async Task<IActionResult> Logout(string logoutId)
        {
            await _signInManager.SignOutAsync();

            return new OkResult();
        }

        /// <summary>
        /// ValidateSignUpToken
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="signUpToken"></param>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [HttpGet("password/{userName}/{signUpToken}")]
        public async Task<IActionResult> ValidateSignUpToken(string userName, Guid signUpToken)
        {
            CommonResponse response = await _loginService.ValidateSignUpToken(userName, signUpToken);

            return StatusCode(response.HttpStatusCode, response);
        }
    }

    public class OktaTokenVerify
    {
        public string username { get; set; }
        public string sub { get; set; }
        public string iss { get; set; }
    }
}
