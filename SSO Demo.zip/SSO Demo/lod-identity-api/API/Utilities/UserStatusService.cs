﻿using Brierley.Common.Web.Controllers.Response;
using Logic.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using Repository.Interfaces;
using Repository.Models;
using Repository.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace API.Utilities
{
    public class UserStatusService : IHostedService
    {
        private readonly int JobIntervalInSecs = int.Parse(Environment.GetEnvironmentVariable("UserSignUpExpiryTime"));
        private Timer _timer;
        private readonly IServiceProvider serviceProvider;
        private readonly HttpClient _httpClient;

        public UserStatusService(IServiceProvider serviceProvider, HttpClient _httpClient)
        {
            this.serviceProvider = serviceProvider;
            this._httpClient = _httpClient;
        }

        // The system invokes StartAsync method at application start up. 
        // This is a good place to initiate the timer to run your job at 
        // the specified interval.
        public Task StartAsync(CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {

                cancellationToken.ThrowIfCancellationRequested();
            }
            // Invoke the DoWork method every 5 seconds. 
            _timer = new Timer(callback: async o => await DoWork(o),
            state: null, dueTime: TimeSpan.FromSeconds(0),
            period: TimeSpan.FromSeconds(JobIntervalInSecs));
            return Task.CompletedTask;
        }
        private async Task DoWork(object o)
        {
            Console.WriteLine("Im in do work");
            try
            {
                using (var scope = serviceProvider.CreateScope())
                {
                    using (var userRepo = scope.ServiceProvider.GetRequiredService<IUserRepository>())
                    {
                        using (var userManager = scope.ServiceProvider.GetRequiredService<UserManager<AppUser>>())
                        {
                            var users = await userRepo.GetSignUpExpiredUsers();
                            var tenants = users.Select(x => x.TenantId.ToUpper()).Distinct().ToList();
                            if (tenants != null)
                            {
                                foreach (var tenant in tenants)
                                {
                                    var admins = await GetAdminUsers(201, tenant);
                                    var adminEmails = admins.Where(x => userManager.Users.Where(y => y.Email.ToUpper().Equals(x.EmailAddress.ToUpper()))
                                    .Any(y => y.UserStatusId == UserStatuses.Active))
                                        .Select(x => x.EmailAddress).ToList();
                                    var userEmails = users.Select(x => x.Email).ToList();
                                    adminEmails = adminEmails?.Except(userEmails)?.ToList();
                                    if (adminEmails != null
                                    && adminEmails.Count > 0
                                    && userEmails != null
                                    && userEmails.Count > 0)
                                    {
                                        SignUpExpiryRequest request = new SignUpExpiryRequest();
                                        request.Administrators = new List<string>();
                                        request.Administrators = adminEmails;
                                        request.ExpiredUsers = new List<string>();
                                        request.ExpiredUsers = userEmails;
                                        request.TenantId = tenant.ToUpper();
                                        Task.Run(() => NotifyAdmins(request));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private async Task<IList<UserResponse>> GetAdminUsers(int roleId, string tenantId)
        {

            try
            {
                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = await _httpClient.GetAsync(
                    Environment.GetEnvironmentVariable("PermissionsAPI_BaseUrl") + $"api/v1/users/usersbyrole/{tenantId}/{roleId}");
                if (response.StatusCode == HttpStatusCode.NoContent)
                {
                    return new List<UserResponse>();
                }
                else
                {
                    string result = await response.Content.ReadAsStringAsync();
                    var commonResponse = JsonConvert.DeserializeObject<CommonResponse>(result);
                    result = JsonConvert.SerializeObject(commonResponse.Data);
                    var users = JsonConvert.DeserializeObject<IList<UserResponse>>(result);
                    return users;
                }
                throw new Exception("Unable to get data role info");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.InnerException);
                if (e.InnerException != null)
                {
                    Console.WriteLine(e.InnerException.Message);
                }

                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.WriteLine(e.Source);
                return new List<UserResponse>();
            }
        }
        private async Task NotifyAdmins(SignUpExpiryRequest request)
        {
            try
            {
                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                string json = JsonConvert.SerializeObject(request);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync(
                    Environment.GetEnvironmentVariable("CommunicationAPI_BaseURL") + "communication/api/v1/email/signupexpirynotification",
                    data);
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new Exception("unable to send expire notification");
                }



            }
            catch (Exception e)
            {
                Console.WriteLine(e.InnerException);
                if (e.InnerException != null)
                {
                    Console.WriteLine(e.InnerException.Message);
                }

                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.WriteLine(e.Source);
            }
        }
        public Task StopAsync(CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                cancellationToken.ThrowIfCancellationRequested();
            } // Change the start time to infinite, thereby stop the timer. 
            _timer?.Change(Timeout.Infinite, 0); return Task.CompletedTask;
        }
    }
}
