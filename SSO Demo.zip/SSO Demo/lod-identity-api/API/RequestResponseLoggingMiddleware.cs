using System;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.IO;

namespace API
{	
	public class RequestResponseLoggingMiddleware
	{
		private readonly RequestDelegate _next;
		private readonly ILogger _logger;
		private readonly RecyclableMemoryStreamManager _recyclableMemoryStreamManager;

		public RequestResponseLoggingMiddleware(RequestDelegate next, ILoggerFactory loggerFactory)
		{
			_next = next;
			_logger = loggerFactory.CreateLogger<RequestResponseLoggingMiddleware>();
			_recyclableMemoryStreamManager = new RecyclableMemoryStreamManager();
		}

		public async Task Invoke(HttpContext context)
		{
			await LogRequest(context);
			await LogResponse(context);
		}

		private async Task LogRequest(HttpContext context)
		{
			context.Request.EnableBuffering();

			var headers = BuildHeadersString(context, true);

			var request = context.Request;

			var requestString = request.Scheme + "://" + request.Host;
			var requestPath = request.PathBase + request.Path;

			// REQUEST BODY
			await using var requestStream = _recyclableMemoryStreamManager.GetStream();
			await request.Body.CopyToAsync(requestStream);

			var requestBody = ReadStreamInChunks(requestStream);

			// QUERY STRING
			var queryString = BuildQueryString(request.Query);

			_logger.LogWarning("============TRANSACTION START==============");
			_logger.LogInformation($"\n\\\\\\\\ REQUEST \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" +
									$"\n\\\\ DateTime:      {DateTime.Now.ToString()}" +
									$"\n\\\\ Protocol:      {request.Protocol}" +
									$"\n\\\\ Method:        {request.Method}" +
									$"\n\\\\ IsHttps:       {request.IsHttps}" +
									$"\n\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" +
									$"\n\\\\ Request:       {requestString}" +
									$"\n\\\\   Path:              {requestPath}" +
									$"\n\\\\     Query:     {queryString}" +
									$"\n\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" +
									$"\n\\\\ Headers:       {headers}" +
									$"\n\\\\" +
									$"\n\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" +
									$"\n\\\\ ContentType:   {request.ContentType}" +
									$"\n\\\\ Request Body:  {requestBody}" +
									$"\n\\\\" +
									$"\n\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" +
									$"\n\\\\\\\\ REQUEST - END \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" +
									$"\n");
			context.Request.Body.Position = 0;
		}

		private async Task LogResponse(HttpContext context)
		{
			// SETUP - not sure how this works.
			var originalBodyStream = context.Response.Body;
			await using var responseBody = _recyclableMemoryStreamManager.GetStream();
			context.Response.Body = responseBody;

			await _next(context);

			context.Response.Body.Seek(0, SeekOrigin.Begin);
			var text = await new StreamReader(context.Response.Body).ReadToEndAsync();
			context.Response.Body.Seek(0, SeekOrigin.Begin);
			// END SETUP

			var headers = BuildHeadersString(context, false);

			var request = context.Response.HttpContext.Request;


			var requestString = request.Scheme + "://" + request.Host;
			var requestPath = request.PathBase + request.Path;
			var queryString = BuildQueryString(request.Query);

			_logger.LogInformation(	$"\n//// RESPONSE //////////////////////////" +
									$"\n// DateTime:     {DateTime.Now.ToString()}" +
									$"\n// StatusCode:   {context.Response.StatusCode}" +

									// $"\n/////////////////////////" +
									// $"\n// Request:       {requestString}" +
									// $"\n//   Path:              {requestPath}" +
									// $"\n//     Query:     {queryString}" +
									// $"\n//" +
									$"\n/////////////////////////" +
									$"\n// Headers:       {headers}" +
									$"\n//" +
									$"\n/////////////////////////" +
									$"\n// Response Body: {text}" +
									$"\n//" +
									$"\n/////////////////////////" +
									$"\n//// RESPONSE - END //////////////////////////" +
									$"\n");

			var setCookie = context.Response.GetTypedHeaders().SetCookie;

			// If the response is trying to set a cookie, log it
			if(setCookie.Count > 0)
			{
			_logger.LogError("============SENDING COOKIES==============");

				foreach (var cookie in setCookie)
				{
					_logger.LogCritical(
						$"DOMAIN: {cookie.Domain}\n" +
						$"EXPIRES		{cookie.Expires}\n" +
						$"HttpONLY		{cookie.HttpOnly}\n" +
						$"NAME:		{cookie.Name}\n" +
						$"PATH:		{cookie.Path}\n" +
						$"SAMESITE:		{cookie.SameSite}\n" +
						$"SECURE:		{cookie.Secure}\n" +
						$"VALUE:		{cookie.Value}\n"
					);
				}
			}

			_logger.LogWarning("============TRANSACTION END==============");

			// CLOSE OUT THE STREAM
			await responseBody.CopyToAsync(originalBodyStream);
		}

		private static string ReadStreamInChunks(Stream stream)
		{
			const int readChunkBufferLength = 4096;

			stream.Seek(0, SeekOrigin.Begin);

			using var textWriter = new StringWriter();
			using var reader = new StreamReader(stream);

			var readChunk = new char[readChunkBufferLength];
			int readChunkLength;

			do
			{
				readChunkLength = reader.ReadBlock(readChunk, 0, readChunkBufferLength);
				textWriter.Write(readChunk, 0, readChunkLength);
			} while (readChunkLength > 0);

			return textWriter.ToString();
		}

		private static string BuildQueryString(IQueryCollection queries)
		{
			var queryString = new StringBuilder();
			foreach (var query in queries)
			{
				queryString.Append($"\n==		{query.Key} : {query.Value.ToString().SafeSubstring(0, 45)}");
				if(query.Value.ToString().Length > 45)
					queryString.Append("...");
			}
			queryString.Append($"\n==");
			return queryString.ToString();
		}

		private static string BuildFormFromApplicationFormString(string form)
		{
			var formString = new StringBuilder();

			var formFields = form.Split("&");

			for (var i = 0; i < formFields.Length; i++)
			{
				var formValues = formFields[i].Split("=");
				formString.Append($"\n==		{formValues[0]} : {formValues[1].ToString().SafeSubstring(0, 45)}");
				if(formValues[1].ToString().Length > 45)
					formString.Append("...");
			}
			formString.Append($"\n==");
			return formString.ToString();
		}

		private static string BuildHeadersString(HttpContext context, bool isRequest)
		{
			int loop1;

			// Load Header collection into NameValueCollection object.
			NameValueCollection headerCollection;
			if (isRequest)
				headerCollection = context.Request.Headers.AsNameValueCollection();
			else
				headerCollection = context.Response.Headers.AsNameValueCollection();

			// Put the names of all keys into a string array.
			string[] arr1 = headerCollection.AllKeys;

			var headers = new StringBuilder();

			for (loop1 = 0; loop1 < arr1.Length; loop1++)
			{
				// HEADER KEY
				var headerKey = arr1[loop1];
				headers.Append($"\n++		{headerKey} = ");

				// Get all values under this key.
				String[] headerValues = headerCollection.GetValues(headerKey);

				// COOKIES
				if (headerKey.ToLower().StartsWith("cook"))
				{
					var cookies = headerValues[0].Split(";");

					foreach (var cookie in cookies)
					{
						headers.Append($"\n++++			{cookie.SafeSubstring(0, 40)}");
						if (cookie.Length > 40)
						{
							headers.Append("...");
						}
					}
				}
				// EVERYTHING ELSE
				else
				{
					headers.Append($"{headerValues[0].SafeSubstring(0, 90)}");
					if (headerValues[0].Length > 90)
					{
						headers.Append("...");
					}
				}
			}

			return headers.ToString();
		}
	}


	public static class RequestResponseLoggingMiddlewareExtensions
	{
		public static IApplicationBuilder UseRequestResponseLogging(this IApplicationBuilder builder)
		{
			return builder.UseMiddleware<RequestResponseLoggingMiddleware>();
		}
	}
}