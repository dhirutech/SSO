﻿using IdentityModel;
using IdentityServer4;
using IdentityServer4.Models;
using Repository.Models;
using System;
using System.Collections.Generic;
using System.Security.Claims;

namespace API
{
    internal static class Clients
    {
        public static IEnumerable<Client> Get()
        {
            var ui_host = Environment.GetEnvironmentVariable("UI_Host");
            return new List<Client> {
                new Client		// "Resource Owner Flow"
				{
                    ClientName = "Resource Owner Flow",
                    ClientId = "resource_owner_flow",
                    AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,
                    ClientSecrets =
                    {
                        new Secret("resource_owner_flow_secret".Sha256())
                    },
                    AllowedScopes = {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.OfflineAccess,
                        IdentityServerConstants.LocalApi.ScopeName,
                        "loyalty-config-api",
                        "members-api",
                        "transactions-api",
                        "redemptions-api",
                        "communications-api",
                        "permissions-api",
                        "stores-products-api",
                        "campaign-api",
                        "customer-care-api",
                        "kong-gateway-api",
                        "kona-core-apis"
                    },
                    AllowOfflineAccess = true,
                    RefreshTokenUsage = TokenUsage.ReUse,
                    AccessTokenLifetime = 3200,
                    RefreshTokenExpiration = TokenExpiration.Absolute,
                    AbsoluteRefreshTokenLifetime = 7200,
                    RedirectUris = new List<string> {
                        "http://development-ui-1289745214.us-east-2.elb.amazonaws.com/",
                        "https://localhost:44371/",
                        "http://localhost:8080/",
                        "https://localhost:8080/"
                    },
                    PostLogoutRedirectUris = new List<string> {
                        "http://development-ui-1289745214.us-east-2.elb.amazonaws.com/",
                        "https://localhost:44371",
                        "http://localhost:8080/",
                        "https://localhost:8080/"
                    }
                },
                new Client		// "Kona Vue App"
				{
                    ClientName = "Kona Vue App",
                    ClientId = "kona_vue_app",

					// ALWAYS INCLUDE USER CLAIMS IN ID TOKEN
					// Here we're ensuring that the users claims are included in the id_token so that we avoid doing a round trip to the userinfo
					// endpoint.
					AlwaysIncludeUserClaimsInIdToken = true,

					// USER SSO LIFETIME
					// Sets idsrv.session cookie lifetime before requiring re-login
					// UserSsoLifetime = 300,

					// ALLOWED GRANT TYPES
					// Grant types are equivalent to "flows", they determine how tokens can be acquired.  Because we're using the Authorization
					// Code Flow (with PKCE) for our UI, this client uses the "code" grant type. 
					AllowedGrantTypes = GrantTypes.Code,
                    RequirePkce = true,

					// CLIENT SECRETS
					// Because we using a single page app where it wouldn't be safe to store a client secret, this is omitted to prevent accidentally
					// opening up this client to insecure authorization methods.
					// ClientSecrets = { new Secret("kona_vue_app".Sha256()) },
					RequireClientSecret = false,

					// ALLOWED SCOPES
					// Here we define the scopes that are allowed to be requested by the client.  Given we use the PKCE flow, these would be defined
					// in the UI code as part of the initial request during the login process as a query string parameter
					AllowedScopes = {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.OfflineAccess,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.StandardScopes.Email,
                        IdentityServerConstants.LocalApi.ScopeName,					// This is to support authentication for the local API's in this application
						"user-info",
                        "kona-core-apis",

						// To-Be Deprecated
						"loyalty-config-api",
                        "members-api",
                        "transactions-api",
                        "redemptions-api",
                        "communications-api",
                        "permissions-api",
                        "stores-products-api",
                        "campaign-api",
                        "customer-care-api",
                        "kong-gateway-api",
                        "kona-api"
                    },

					// OFFLINE ACCESS
					// While the Allowed Scopes permits the client to request refresh tokens, this enables using those refresh tokens
					AllowOfflineAccess = true,
                    RefreshTokenUsage = TokenUsage.ReUse,
                    RefreshTokenExpiration = TokenExpiration.Absolute,
                    AbsoluteRefreshTokenLifetime = 7200, // seconds

					AccessTokenLifetime = 7200, // seconds

					// REQUIRE CONSENT
					// Per OIDC specifications, consent is part of a mechanism primarily used (if at all) during single-sign-on scenarios.
					RequireConsent = false,

                    RedirectUris = new List<string> {
						
						// DEV
						"http://development-ui-1289745214.us-east-2.elb.amazonaws.com/",
                        "http://development-ui-1289745214.us-east-2.elb.amazonaws.com/landingpage",
                        "https://development-ui-1289745214.us-east-2.elb.amazonaws.com/",
                        "https://development-ui-1289745214.us-east-2.elb.amazonaws.com/landingpage",

                        "http://kona-dev.brierleycloud.net/",
                        "http://kona-dev.brierleycloud.net/landingpage",
                        "https://kona-dev.brierleycloud.net/",
                        "https://kona-dev.brierleycloud.net/landingpage",
			"https://kona-dev-api.brierleycloud.net:8080",
			"https://kona-dev-api.brierleycloud.net:8080/landingpage",
			 "https://kona-demo.brierley.com",
		         "https://kona-demo.brierley.com/landingpage",

                        "http://gap-kona-dev.brierleycloud.net/",
                        "http://gap-kona-dev.brierleycloud.net/landingpage",
                        "https://gap-kona-dev.brierleycloud.net/",
                        "https://gap-kona-dev.brierleycloud.net/landingpage",
			"https://gap-kona-demo.brierley.com",
		         "https://gap-kona-demo.brierley.com/landingpage",

                        "http://hertz-kona-dev.brierleycloud.net/",
                        "http://hertz-kona-dev.brierleycloud.net/landingpage",
                        "https://hertz-kona-dev.brierleycloud.net/",
                        "https://hertz-kona-dev.brierleycloud.net/landingpage",
			"https://hertz-kona-demo.brierley.com",
		         "https://hertz-kona-demo.brierley.com/landingpage",
                        "https://kona-dev.brierleycloud.net:8093",//Gen2 Host
			"https://kona-preuat.brierleycloud.net",
                        "https://kona-dev.brierley.com/",

                        "https://kona-dev.brierleycloud.net:8093/gettingstarted",
                        "https://kona-dev.brierley.com/gettingstarted",
			"https://kona-preuat.brierleycloud.net/gettingstarted",
                        "https://kona-dev.brierley.com/loyaltyadmin/gettingstarted",

						// QA
                        "https://kona-qa.brierleycloud.net:8093",
                        "https://kona-qa.brierleycloud.net:8093/gettingstarted",
                        "http://qa-ui-1792093789.us-east-2.elb.amazonaws.com/",
                        "http://qa-ui-1792093789.us-east-2.elb.amazonaws.com/landingpage",
                        "https://qa-ui-1792093789.us-east-2.elb.amazonaws.com/",
                        "https://qa-ui-1792093789.us-east-2.elb.amazonaws.com/landingpage",

                        "http://kona-qa.brierleycloud.net/",
                        "http://kona-qa.brierleycloud.net/landingpage",
                        "https://kona-qa.brierleycloud.net/",
                        "https://kona-qa.brierleycloud.net/landingpage",

                        "http://gap-kona-qa.brierleycloud.net/",
                        "http://gap-kona-qa.brierleycloud.net/landingpage",
                        "https://gap-kona-qa.brierleycloud.net/",
                        "https://gap-kona-qa.brierleycloud.net/landingpage",

                        "http://hertz-kona-qa.brierleycloud.net/",
                        "http://hertz-kona-qa.brierleycloud.net/landingpage",
                        "https://hertz-kona-qa.brierleycloud.net/",
                        "https://hertz-kona-qa.brierleycloud.net/landingpage",

                        "http://gap-kona.brierley:9000/",
                        "http://gap-kona.brierley:9000/gettingstarted",
                        "https://gap-kona.brierley:9000/",
                        "https://gap-kona.brierley:9000/gettingstarted",

                        "http://hertz-kona.brierley:9000/",
                        "http://hertz-kona.brierley:9000/gettingstarted",
                        "https://hertz-kona.brierley:9000/",
                        "https://hertz-kona.brierley:9000/gettingstarted",
						// UAT
						"http://uat-ui-383456159.us-east-2.elb.amazonaws.com/",
                        "http://uat-ui-383456159.us-east-2.elb.amazonaws.com/landingpage",
                        "https://uat-ui-383456159.us-east-2.elb.amazonaws.com/",
                        "https://uat-ui-383456159.us-east-2.elb.amazonaws.com/landingpage",

                        "http://kona-uat.brierleycloud.net/",
                        "http://kona-uat.brierleycloud.net/landingpage",
                        "https://kona-uat.brierleycloud.net/",
                        "https://kona-uat.brierleycloud.net/landingpage",
                        "https://kona-uat.brierleycloud.net/gettingstarted",
                        "https://kona-uat.brierleycloud.net:8093/gettingstarted",

                        "http://gap-kona-uat.brierleycloud.net/",
                        "http://gap-kona-uat.brierleycloud.net/landingpage",
                        "https://gap-kona-uat.brierleycloud.net/",
                        "https://gap-kona-uat.brierleycloud.net/landingpage",

                        "http://hertz-kona-uat.brierleycloud.net/",
                        "http://hertz-kona-uat.brierleycloud.net/landingpage",
                        "https://hertz-kona-uat.brierleycloud.net/",
                        "https://hertz-kona-uat.brierleycloud.net/landingpage",


						// PERF
						"http://performance-ui-1298211985.us-east-2.elb.amazonaws.com/",
                        "http://performance-ui-1298211985.us-east-2.elb.amazonaws.com/landingpage",
                        "https://performance-ui-1298211985.us-east-2.elb.amazonaws.com/",
                        "https://performance-ui-1298211985.us-east-2.elb.amazonaws.com/landingpage",
			"https://kona-perf.brierleycloud.net",
			"https://kona-perf.brierleycloud.net/landingpage",
			"https://kona-perf.brierleycloud.net:8093",//Gen2 Host
			"https://kona-perf.brierleycloud.net:8093/gettingstarted",
            "https://localhost:44314/",

                        "http://18.221.2.57/",
                        "http://18.221.2.57/landingpage",
                        "https://18.221.2.57/",
                        "https://18.221.2.57/landingpage",


						// LOCAL
						"https://localhost:44371/",
                        "https://localhost:44371/Home/APIs",

                        "http://localhost:8080",
                        "https://localhost:8080",
                        "http://localhost:8081",
                        "https://localhost:8081",
                        "http://localhost:9000",
                        "https://localhost:9000",

                        "http://localhost:8080/",
                        "https://localhost:8080/",
                        "http://localhost:8081/",
                        "https://localhost:8081/",

                        "http://localhost:8080/login",
                        "https://localhost:8080/login",
                        "http://localhost:8081/login",
                        "https://localhost:8081/login",

                        "http://localhost:8080/landingpage",
                        "https://localhost:8080/landingpage",
                        "http://localhost:8081/landingpage",
                        "https://localhost:8081/landingpage",
                        "https://localhost:9000/gettingstarted",
						
						// Local Tenant Specific
							"https://gap-kona.com:8080",
                            "https://gap-kona.com:8080/landingpage",
                            "https://hertz-kona.com:8080",
                            "https://hertz-kona.com:8080/landingpage",
                            "https://kona.brierley",
                            "https://gap-kona.brierley",
                            "https://hertz-kona.brierley",
                            "http://kona.brierley",
                            "http://gap-kona.brierley",
                            "http://hertz-kona.brierley",
                            "https://kona.brierley/landingpage",
                            "https://gap-kona.brierley/landingpage",
                            "https://hertz-kona.brierley/landingpage",
                            "http://kona.brierley/landingpage",
                            "http://gap-kona.brierley/landingpage",
                            "http://hertz-kona.brierley/landingpage",


						// IDEALLY - we'll set these like this, but until we can standardize this for each of the environments, ^^^^ all that crap up there is in place to make sure it works
						"http://" + ui_host + "/landingpage",
                        "https://" + ui_host + "/landingpage",
                        "http://" + ui_host + "/oauth/login",
                        "https://" + ui_host + "/oauth/login",
                        "https://" + ui_host + "/gettingstarted"

                    },
                    PostLogoutRedirectUris = new List<string> {
						
						// DEV
						"http://development-ui-1289745214.us-east-2.elb.amazonaws.com/",
                        "http://development-ui-1289745214.us-east-2.elb.amazonaws.com/landingpage",
                        "https://development-ui-1289745214.us-east-2.elb.amazonaws.com/",
                        "https://development-ui-1289745214.us-east-2.elb.amazonaws.com/landingpage",

                        "http://kona-dev.brierleycloud.net/",
                        "http://kona-dev.brierleycloud.net/landingpage",
                        "https://kona-dev.brierleycloud.net/",
                        "https://kona-dev.brierleycloud.net/landingpage",
			"https://kona-demo.brierley.com",
		         "https://kona-demo.brierley.com/landingpage",

                        "http://gap-kona-dev.brierleycloud.net/",
                        "http://gap-kona-dev.brierleycloud.net/landingpage",
                        "https://gap-kona-dev.brierleycloud.net/",
                        "https://gap-kona-dev.brierleycloud.net/landingpage",
			"https://gap-kona-demo.brierley.com",
		         "https://gap-kona-demo.brierley.com/landingpage",

                        "http://hertz-kona-dev.brierleycloud.net/",
                        "http://hertz-kona-dev.brierleycloud.net/landingpage",
                        "https://hertz-kona-dev.brierleycloud.net/",
                        "https://hertz-kona-dev.brierleycloud.net/landingpage",
			"https://hertz-kona-demo.brierley.com",
		         "https://hertz-kona-demo.brierley.com/landingpage",

                        "https://kona-dev.brierleycloud.net:8093",//Gen2 Host
                        "https://kona-qa.brierleycloud.net:8093",
                "https://kona-dev-api.brierleycloud.net:8080",
			"https://kona-dev-api.brierleycloud.net:8080/landingpage",
						// QA
						"http://qa-ui-1792093789.us-east-2.elb.amazonaws.com/",
                        "http://qa-ui-1792093789.us-east-2.elb.amazonaws.com/landingpage",
                        "https://qa-ui-1792093789.us-east-2.elb.amazonaws.com/",
                        "https://qa-ui-1792093789.us-east-2.elb.amazonaws.com/landingpage",

                        "http://kona-qa.brierleycloud.net/",
                        "http://kona-qa.brierleycloud.net/landingpage",
                        "https://kona-qa.brierleycloud.net/",
                        "https://kona-qa.brierleycloud.net/landingpage",

                        "http://gap-kona-qa.brierleycloud.net/",
                        "http://gap-kona-qa.brierleycloud.net/landingpage",
                        "https://gap-kona-qa.brierleycloud.net/",
                        "https://gap-kona-qa.brierleycloud.net/landingpage",

                        "http://hertz-kona-qa.brierleycloud.net/",
                        "http://hertz-kona-qa.brierleycloud.net/landingpage",
                        "https://hertz-kona-qa.brierleycloud.net/",
                        "https://hertz-kona-qa.brierleycloud.net/landingpage",
						

						// UAT
						"http://uat-ui-383456159.us-east-2.elb.amazonaws.com/",
                        "http://uat-ui-383456159.us-east-2.elb.amazonaws.com/landingpage",
                        "https://uat-ui-383456159.us-east-2.elb.amazonaws.com/",
                        "https://uat-ui-383456159.us-east-2.elb.amazonaws.com/landingpage",

                        "http://kona-uat.brierleycloud.net/",
                        "http://kona-uat.brierleycloud.net/landingpage",
                        "https://kona-uat.brierleycloud.net/",
                        "https://kona-uat.brierleycloud.net/landingpage",

                        "http://gap-kona-uat.brierleycloud.net/",
                        "http://gap-kona-uat.brierleycloud.net/landingpage",
                        "https://gap-kona-uat.brierleycloud.net/",
                        "https://gap-kona-uat.brierleycloud.net/landingpage",

                        "http://hertz-kona-uat.brierleycloud.net/",
                        "http://hertz-kona-uat.brierleycloud.net/landingpage",
                        "https://hertz-kona-uat.brierleycloud.net/",
                        "https://hertz-kona-uat.brierleycloud.net/landingpage",
                        

						// PERF
						"http://performance-ui-1298211985.us-east-2.elb.amazonaws.com/",
                        "http://performance-ui-1298211985.us-east-2.elb.amazonaws.com/landingpage",
                        "https://performance-ui-1298211985.us-east-2.elb.amazonaws.com/",
                        "https://performance-ui-1298211985.us-east-2.elb.amazonaws.com/landingpage",
			"https://kona-perf.brierleycloud.net",
			"https://kona-perf.brierleycloud.net/landingpage",

                        "http://18.221.2.57/",
                        "http://18.221.2.57/landingpage",
                        "https://18.221.2.57/",
                        "https://18.221.2.57/landingpage",


						// LOCAL
						"https://localhost:44371/",

                        "http://localhost:8080",
                        "https://localhost:8080",
                        "http://localhost:8081",
                        "https://localhost:8081",

                        "http://localhost:8080/",
                        "https://localhost:8080/",
                        "http://localhost:8081/",
                        "https://localhost:8081/",

                        "http://localhost:8080/login",
                        "https://localhost:8080/login",
                        "http://localhost:8081/login",
                        "https://localhost:8081/login",

                        "http://localhost:8080/landingpage",
                        "https://localhost:8080/landingpage",
                        "http://localhost:8081/landingpage",
                        "https://localhost:8081/landingpage",	
						
						// Local Tenant Specific
							"https://gap-kona.com:8080",
                            "https://gap-kona.com:8080/landingpage",
                            "https://hertz-kona.com:8080",
                            "https://hertz-kona.com:8080/landingpage",
			                "https://kona.brierley",
                            "https://gap-kona.brierley",
                            "https://hertz-kona.brierley",
                            "http://kona.brierley",
                            "http://gap-kona.brierley",
                            "http://hertz-kona.brierley",
                            "https://kona.brierley/landingpage",
                            "https://gap-kona.brierley/landingpage",
                            "https://hertz-kona.brierley/landingpage",
                            "http://kona.brierley/landingpage",
                            "http://gap-kona.brierley/landingpage",
                            "http://hertz-kona.brierley/landingpage",

						// IDEALLY - we'll set these like this, but until we can standardize this for each of the environments, ^^^^ all that crap up there is in place to make sure it works
						"http://" + ui_host + "/landingpage",
                        "https://" + ui_host + "/landingpage",
                        "http://" + ui_host + "/oauth/login",
                        "https://" + ui_host + "/oauth/login"
                    },
                    AllowedCorsOrigins = new List<string>
                    {
                        "http://" + ui_host,
                        "https://" + ui_host,
                        "http://gap-kona.com",
                        "https://gap-kona.com",
                        "https://kona-dev.brierleycloud.net:8093",//Gen2 Host
                        "https://kona-qa.brierleycloud.net:8093",
		        "https://kona-dev-api.brierleycloud.net:8080",
			"https://kona.brierley",
            "http://kona.brierley",
            "http://gap-kona.brierley",
			"http://hertz-kona.brierley",
            "https://gap-kona.brierley",
			"https://hertz-kona.brierley",
		        "https://kona-demo.brierley.com",
		        "https://gap-kona-demo.brierley.com",
			"https://hertz-kona-demo.brierley.com",
			"https://kona-perf.brierleycloud.net"
                    }
                },
                new Client		// "QA Client"
				{
                    ClientName = "QA Client",
                    ClientId = "qa_client",
                    AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,
                    ClientSecrets =
                    {
                        new Secret("qa_client_secret".Sha256())
                    },
                    AllowedScopes = {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.OfflineAccess,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.StandardScopes.Email,
                        IdentityServerConstants.LocalApi.ScopeName,
                        "user-info",
                        "kona-core-apis",

						// To-Be Deprecated
						"loyalty-config-api",
                        "members-api",
                        "transactions-api",
                        "redemptions-api",
                        "communications-api",
                        "permissions-api",
                        "stores-products-api",
                        "campaign-api",
                        "customer-care-api",
                        "kong-gateway-api",
                        "kona-api"
                    },
                    AllowOfflineAccess = true,
                    RefreshTokenUsage = TokenUsage.ReUse,
                    AccessTokenLifetime = 3600,
                    RefreshTokenExpiration = TokenExpiration.Absolute,
                    AbsoluteRefreshTokenLifetime = 7200,
                    RedirectUris = new List<string> {
                        "http://" + ui_host + "/landingpage",
                        "https://" + ui_host + "/landingpage",
                        "http://" + ui_host + "/oauth/login",
                        "https://" + ui_host + "/oauth/login"
                    },
                    PostLogoutRedirectUris = new List<string> {
                        "http://" + ui_host + "/landingpage",
                        "https://" + ui_host + "/landingpage",
                        "http://" + ui_host + "/oauth/logout",
                        "https://" + ui_host + "/oauth/logout"
                    },
                },
                new Client		// "Developer Client"
				{
                    ClientName = "Developer Client",
                    ClientId = "developer_client",
                    AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,
                    ClientSecrets =
                    {
                        new Secret("developer_client_secret".Sha256())
                    },
                    AllowedScopes = {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.OfflineAccess,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.StandardScopes.Email,
                        IdentityServerConstants.LocalApi.ScopeName,
                        "user-info",
                        "kona-core-apis",
                    },
                    AllowOfflineAccess = true,
                    RefreshTokenUsage = TokenUsage.ReUse,
                    AccessTokenLifetime = 3600,
                    RefreshTokenExpiration = TokenExpiration.Absolute,
                    AbsoluteRefreshTokenLifetime = 7200,
                    RedirectUris = new List<string> {
                        "http://" + ui_host + "/landingpage",
                        "https://" + ui_host + "/landingpage",
                        "http://" + ui_host + "/oauth/login",
                        "https://" + ui_host + "/oauth/login"
                    },
                    PostLogoutRedirectUris = new List<string> {
                        "http://" + ui_host + "/landingpage",
                        "https://" + ui_host + "/landingpage",
                        "http://" + ui_host + "/oauth/logout",
                        "https://" + ui_host + "/oauth/logout"
                    },
                },
                new Client		// "GENERIC - Service Client"
				{
                    ClientName = "Service Client Brierley",
                    ClientId = "service_client_brierley",
                    AllowedGrantTypes = GrantTypes.ClientCredentials,
                    Claims = new List<Claim>
                    {
                        new Claim("tenant", "BRIERLEY")
                    },
                    ClientClaimsPrefix = "",
                    ClientSecrets =
                    {
                        new Secret("service_client_secret".Sha256())
                    },
                    AllowedScopes = {
                        IdentityServerConstants.LocalApi.ScopeName,
                        "kona-core-apis",
                    },
                    AllowOfflineAccess = false,
                    AccessTokenLifetime = 157784760, // 5 years
				},
                new Client		// "HERTZ - Service Client"
				{
                    ClientName = "Service Client Generic",
                    ClientId = "service_client_hertz",
                    AllowedGrantTypes = GrantTypes.ClientCredentials,
                    Claims = new List<Claim>
                    {
                        new Claim("tenant", "HERTZ")
                    },
                    ClientClaimsPrefix = "",
                    ClientSecrets =
                    {
                        new Secret("service_client_secret".Sha256())
                    },
                    AllowedScopes = {
                        IdentityServerConstants.LocalApi.ScopeName,
                        "kona-core-apis",
                    },
                    AllowOfflineAccess = false,
                    AccessTokenLifetime = 157784760, // 5 years
				},
                new Client		// "GAP - Service Client"
				{
                    ClientName = "Service Client Gap",
                    ClientId = "service_client_gap",
                    AllowedGrantTypes = GrantTypes.ClientCredentials,
                    Claims = new List<Claim>
                    {
                        new Claim("tenant", "GAP")
                    },
                    ClientClaimsPrefix = "",
                    ClientSecrets =
                    {
                        new Secret("service_client_secret".Sha256())
                    },
                    AllowedScopes = {
                        IdentityServerConstants.LocalApi.ScopeName,
                        "kona-core-apis",
                    },
                    AllowOfflineAccess = false,
                    AccessTokenLifetime = 157784760, // 5 years
				}
            };
        }
    }

    internal static class Resources
    {
        public static IEnumerable<IdentityResource> GetIdentityResources()
        {
            return new List<IdentityResource> {
                new IdentityResources.OpenId(),
                new IdentityResources.Profile(),
                new IdentityResources.Email(),
                new IdentityResource {
                    Name = "user-info",
                    UserClaims = new List<string>
                    {
                        "tenant",
                        "defaultApp"
                    },
                    ShowInDiscoveryDocument = true
                }
            };
        }

        public static IEnumerable<ApiResource> GetApiResources()
        {
            var apiResources = new List<ApiResource>()
            {
                new ApiResource(IdentityServerConstants.LocalApi.ScopeName),	// This is to register the scope for authentication for API's added locally to this service.  So when we call the .AddAuthentication in Startup.cs and decorate the API's we created in this project, they're being validated on this scope (IdentityServerApi)
				new ApiResource
                {
                    Name = "kona-core-apis",							// This equates to the Audience (aud) claim in tokens
					DisplayName = "Kona Core API's",
                    Description = "Access to Kona Core API's",
                    UserClaims = new List<string> 						// Claims that must be present in the access token when making requests against this resource api
					{
                        "role",
                        "tenant"
                    },
                    ApiSecrets = new List<Secret> 						// The secret using for authenticating the resource api when trying to introspect an access token
					{
                        new Secret("core_service_secret".Sha256())
                    },
                    Scopes = new List<Scope> {							// The scopes required in the access token for accessing this api's resources
						new Scope(){
                            Name = "kona-core-apis",

							// USER CLAIMS
							// this specifies the list of claims to be included in the access token
							UserClaims = {
                                JwtClaimTypes.Name,
                                JwtClaimTypes.Email,
                                JwtClaimTypes.Role,
                                "tenant",
                                "defaultApp",
                                "introspection"
                            }
                        }
                    }
                }
            };

            return apiResources;
        }
    }

    internal static class Users
    {
        public static List<AppUser> Get()
        {
            return new List<AppUser>
            {
				// BRIERLEY USERS
				new AppUser
                {
                    Id = "a36fde36-f4bf-4282-996a-a0d1594ee021",
                    UserName = "loyaltyAdmin@kona.com",
                    FirstName = "John",
                    LastName = "Doe",
                    TenantId = "BRIERLEY"
                },
                new AppUser
                {
                    Id = "b88e93ff-1b5e-4aef-be87-0d55cc455705",
                    UserName = "loyaltyManager@kona.com",
                    FirstName = "Jane",
                    LastName = "Smith",
                    TenantId = "BRIERLEY"
                },
                new AppUser
                {
                    Id = "cad26122-914c-499c-af80-0e4b70fd28ca",
                    UserName = "customerServiceAgent@kona.com",
                    FirstName = "Carl",
                    LastName = "Jr.",
                    TenantId = "BRIERLEY"
                },

				// GAP USERS
				new AppUser
                {
                    Id = "a36fde36-f4bf-4282-996a-a0d1594ee022",
                    UserName = "gapLoyaltyAdmin@kona.com",
                    FirstName = "Karl",
                    LastName = "Marx",
                    TenantId = "GAP"
                },
                new AppUser
                {
                    Id = "b88e93ff-1b5e-4aef-be87-0d55cc455706",
                    UserName = "gapLoyaltyManager@kona.com",
                    FirstName = "Leo",
                    LastName = "Tolstoy",
                    TenantId = "GAP"
                },
                new AppUser
                {
                    Id = "cad26122-914c-499c-af80-0e4b70fd28cb",
                    UserName = "gapCustomerServiceAgent@kona.com",
                    FirstName = "Carl",
                    LastName = "Jung",
                    TenantId = "GAP"
                },

				// HERTZ USERS
				new AppUser
                {
                    Id = "a36fde36-f4bf-4282-996a-a0d1594ee023",
                    UserName = "hertzLoyaltyAdmin@kona.com",
                    FirstName = "Immanuel",
                    LastName = "Kant",
                    TenantId = "HERTZ"
                },
                new AppUser
                {
                    Id = "b88e93ff-1b5e-4aef-be87-0d55cc455707",
                    UserName = "hertzLoyaltyManager@kona.com",
                    FirstName = "Rene",
                    LastName = "Descarte",
                    TenantId = "HERTZ"
                },
                new AppUser
                {
                    Id = "cad26122-914c-499c-af80-0e4b70fd28cc",
                    UserName = "hertzCustomerServiceAgent@kona.com",
                    FirstName = "Henry",
                    LastName = "Thoreau",
                    TenantId = "HERTZ"
                }
            };
        }
    }
}
