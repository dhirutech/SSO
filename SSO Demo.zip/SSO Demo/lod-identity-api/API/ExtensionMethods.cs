using System.Linq;

namespace API
{
	public static class StringExtnsionMethods
	{
		public static string SafeSubstring(this string value, int startIndex, int length)
		{
			return new string((value ?? string.Empty).Skip(startIndex).Take(length).ToArray());
		}
	}
}