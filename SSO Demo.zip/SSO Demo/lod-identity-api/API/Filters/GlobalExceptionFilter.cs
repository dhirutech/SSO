﻿using System;
using System.Collections.Generic;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using Repository.CustomExceptions;

namespace API.Filters
{
    public class GlobalExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            ErrorInformation _errorInformation=new ErrorInformation();
            HttpStatusCode status;
            Type exceptionType = context.Exception.GetType();
            
            if (exceptionType == typeof(UnauthorizedAccessException))
            {
                _errorInformation.HttpStatus = HttpStatusCode.Unauthorized;
                _errorInformation.DeveloperMessage = context.Exception?.Message;
                _errorInformation.UserMessage = context.Exception.InnerException?.Message;
                _errorInformation.MoreInfo = "";
                status = HttpStatusCode.Unauthorized;
            }
            else if (exceptionType == typeof(NotImplementedException))
            {
                _errorInformation.HttpStatus = HttpStatusCode.NotImplemented;
                _errorInformation.DeveloperMessage = context.Exception?.Message;
                _errorInformation.UserMessage = context.Exception.InnerException?.Message;
                _errorInformation.MoreInfo = "";
                status = HttpStatusCode.NotImplemented;
            }
            else if (exceptionType == typeof(ForbiddenException))
            {
                _errorInformation.HttpStatus = HttpStatusCode.Forbidden;
                _errorInformation.DeveloperMessage = context.Exception?.Message;
                _errorInformation.UserMessage = context.Exception.InnerException?.Message;
                _errorInformation.MoreInfo = "";
                status = HttpStatusCode.Forbidden;
            }
            else if (exceptionType == typeof(InvalidPassword))
            {
                _errorInformation.HttpStatus = HttpStatusCode.BadRequest;
                _errorInformation.DeveloperMessage = context.Exception?.Message;
                _errorInformation.UserMessage = context.Exception.InnerException?.Message;
                _errorInformation.MoreInfo = "";
                status = HttpStatusCode.BadRequest;
            }
            else if(exceptionType==typeof(PasswordAlreadyUsedException)|| exceptionType == typeof(InvalidOperationException))
            {
                _errorInformation.HttpStatus = HttpStatusCode.UnprocessableEntity;
                _errorInformation.DeveloperMessage = context.Exception?.Message;
                _errorInformation.UserMessage = context.Exception.InnerException?.Message;
                _errorInformation.MoreInfo = "";
                status = HttpStatusCode.UnprocessableEntity;
            }
            else if (exceptionType == typeof(KeyNotFoundException))
            {
                _errorInformation.HttpStatus = HttpStatusCode.NotFound;
                _errorInformation.DeveloperMessage = context.Exception?.Message;
                _errorInformation.UserMessage= context.Exception.InnerException?.Message;
                _errorInformation.MoreInfo = "";
                status = HttpStatusCode.NotFound;
            }
            else if(exceptionType==typeof(UniqueEmailException))
            {
                _errorInformation.HttpStatus = HttpStatusCode.Conflict;
                _errorInformation.DeveloperMessage = context.Exception?.Message;
                _errorInformation.UserMessage = context.Exception.InnerException?.Message;
                _errorInformation.MoreInfo = "";
                status = HttpStatusCode.Conflict;
            }
            else if (exceptionType==typeof(AccountBlockedException))
            {
                _errorInformation.HttpStatus = HttpStatusCode.Locked;
                _errorInformation.DeveloperMessage = context.Exception?.Message;
                _errorInformation.UserMessage = context.Exception.InnerException?.Message;
                _errorInformation.MoreInfo = "";
                status = HttpStatusCode.Locked;
            }
            else
            {
                _errorInformation.HttpStatus = HttpStatusCode.InternalServerError;
                _errorInformation.DeveloperMessage = context.Exception?.Message;
                _errorInformation.UserMessage = context.Exception.InnerException?.Message;
                _errorInformation.MoreInfo = "";
                status = HttpStatusCode.InternalServerError;
            }
            context.ExceptionHandled = true;
            HttpResponse response = context.HttpContext.Response;
            response.StatusCode = (int)status;
            response.ContentType = "application/json";
            string err = $"{JsonConvert.SerializeObject(_errorInformation)}";
            response.WriteAsync(err);
        }
    }
}