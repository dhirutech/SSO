
using System;
using System.Net;
using Microsoft.AspNetCore.Rewrite;
using Microsoft.Net.Http.Headers;

namespace API.Filters
{
	public class RedirectRule : Microsoft.AspNetCore.Rewrite.IRule
	{
		public int StatusCode { get; } = (int)HttpStatusCode.Found;
		public bool ExcludeLocalhost { get; set; } = true;

		public void ApplyRule(RewriteContext context)
		{
			var ui_host = Environment.GetEnvironmentVariable("UI_Host");
			var request = context.HttpContext.Request;
						
			Console.WriteLine("////");
			Console.WriteLine("////");
			Console.WriteLine("////");
			Console.WriteLine("HIT THE REWRITER, PATH VALUE : " + request.Path.Value);
			Console.WriteLine("EQUALS : " + request.Path.Value.Equals("/identity/oauth/login"));
			Console.WriteLine("STARTSWITH : " + request.Path.Value.StartsWith("/identity/oauth/login"));
			Console.WriteLine("CONTAINS : " + request.Path.Value.Contains("/identity/oauth/login"));
			
			Console.WriteLine("////");
			Console.WriteLine("////");
			if(request.Path.Value.Equals("/identity/oauth/login", StringComparison.OrdinalIgnoreCase))
			{
				string newPath = "https://" + ui_host + "/login"; 

				var response = context.HttpContext.Response;
				response.StatusCode = StatusCode;
				response.Headers[HeaderNames.Location] = newPath;
				context.Result = RuleResult.EndResponse; // Do not continue processing the request
			}

			context.Result = RuleResult.ContinueRules;
		}
	}
}