using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Repository.Models;

namespace Repository
{
	// APPLICATION USER STORE
	// Here we create a derived class from Identity's native UserStore in order to override default
	// data management. This was introduced specifically in order to allow Identity native data management 
	// to consider tenancy claims for uniqueness based on username and tenantId.
	//
	// For a more thorough understanding, visit:
	// MS Docs: Customize the User Store
	// https://docs.microsoft.com/en-us/aspnet/core/security/authentication/identity-custom-storage-providers?view=aspnetcore-3.1#customize-the-user-store
	//
	// For the source code of MS Identity's UserStoreBase, visit:
	// https://github.com/dotnet/aspnetcore/blob/master/src/Identity/Extensions.Stores/src/UserStoreBase.cs
	//
	// For the source code of MS Identity's UserStore, visit:
	// https://github.com/dotnet/aspnetcore/blob/master/src/Identity/EntityFrameworkCore/src/UserStore.cs

	// public class ApplicationUserStore<AppUser> : UserStore<AppUser>
	public class ApplicationUserStore<TUser> : UserStore<TUser, IdentityRole, ApplicationDbContext, string> where TUser : AppUser, new()
    {
		public string TenantId { get; set; }
		private readonly ApplicationDbContext _context;
		public ApplicationUserStore(ApplicationDbContext context, IdentityErrorDescriber describer = null) : base(context, describer)
		{
			_context = context;
		}


		public async override Task<IdentityResult> CreateAsync(TUser user, CancellationToken cancellationToken = default(CancellationToken) )
		{

			if (user == null)
            {
                throw new ArgumentNullException("user");
            }

			await _context.Users.AddAsync(user);

			var rows = await _context.SaveChangesAsync();

			if(rows > 0)
				return IdentityResult.Success;

			return IdentityResult.Failed(new IdentityError { Description = $"Could not insert user {user.Email}." });
		}

		public override async Task<TUser> FindByNameAsync(string normalizedUserName, CancellationToken cancellationToken)
		{
			var actualUser = await _context.Users.FirstOrDefaultAsync(u => 
				u.NormalizedUserName == normalizedUserName &&
        		u.TenantId == TenantId);

			return (TUser)actualUser;
		}

		public async Task<string> GetNormalizedUserNameAsync(TUser user, CancellationToken cancellationToken)
		{
			var actualUser = await _context.Users.FirstOrDefaultAsync(u => 
				u.Id == user.Id);

			return actualUser.NormalizedUserName;
		}
	}
}