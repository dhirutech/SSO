﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

namespace Repository.Data.Migrations.IdentityServer.ApplicationDb
{
    public partial class AddingUsersPreferences : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "UserPreferenceId",
                table: "AspNetUsers",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "UserPreferences",
                columns: table => new
                {
                    UserPreferenceId = table.Column<int>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    DefaultApplication = table.Column<string>(nullable: true),
                    DefaultLanguage = table.Column<string>(nullable: true),
                    DefaultListView = table.Column<string>(nullable: true),
                    Id = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserPreferences", x => x.UserPreferenceId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_UserPreferenceId",
                table: "AspNetUsers",
                column: "UserPreferenceId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_UserPreferences_UserPreferenceId",
                table: "AspNetUsers",
                column: "UserPreferenceId",
                principalTable: "UserPreferences",
                principalColumn: "UserPreferenceId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_UserPreferences_UserPreferenceId",
                table: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "UserPreferences");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_UserPreferenceId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "UserPreferenceId",
                table: "AspNetUsers");
        }
    }
}
