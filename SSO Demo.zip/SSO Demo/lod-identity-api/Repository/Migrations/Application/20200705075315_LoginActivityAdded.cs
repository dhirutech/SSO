﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Repository.Data.Migrations.IdentityServer.ApplicationDb
{
    public partial class LoginActivityAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "LastLoginTime",
                table: "AspNetUsers",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "PasswordSignUpToken",
                table: "AspNetUsers",
                nullable: true);

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "PasswordSignUpTokenEndTime",
                table: "AspNetUsers",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LastLoginTime",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "PasswordSignUpToken",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "PasswordSignUpTokenEndTime",
                table: "AspNetUsers");
        }
    }
}
