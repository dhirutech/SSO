﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Repository.Data.Migrations.IdentityServer.ApplicationDb
{
    public partial class userStatusTextUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "UserStatus",
                keyColumn: "UserStatusId",
                keyValue: 2,
                column: "StatusName",
                value: "Pending Signup");

            migrationBuilder.UpdateData(
                table: "UserStatus",
                keyColumn: "UserStatusId",
                keyValue: 3,
                column: "StatusName",
                value: "Expired Link");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "UserStatus",
                keyColumn: "UserStatusId",
                keyValue: 2,
                column: "StatusName",
                value: "PendingSignup");

            migrationBuilder.UpdateData(
                table: "UserStatus",
                keyColumn: "UserStatusId",
                keyValue: 3,
                column: "StatusName",
                value: "ExpiredLink");
        }
    }
}
