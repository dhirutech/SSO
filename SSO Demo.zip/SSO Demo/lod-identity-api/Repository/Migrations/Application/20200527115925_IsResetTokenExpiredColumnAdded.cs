﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Repository.Data.Migrations.IdentityServer.ApplicationDb
{
    public partial class IsResetTokenExpiredColumnAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsResetTokenExpired",
                table: "AspNetUsers",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsResetTokenExpired",
                table: "AspNetUsers");
        }
    }
}
