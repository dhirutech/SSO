﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

namespace Repository.Data.Migrations.IdentityServer.ApplicationDb
{
    public partial class addUserStatus : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "DefaultApp",
                table: "AspNetUsers",
                nullable: true,
                defaultValue: "myDefaultApp",
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "UserStatusId",
                table: "AspNetUsers",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "UserStatus",
                columns: table => new
                {
                    UserStatusId = table.Column<int>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    StatusName = table.Column<string>(nullable: true),
                    StatusDesciption = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserStatus", x => x.UserStatusId);
                });

            migrationBuilder.InsertData(
                table: "UserStatus",
                columns: new[] { "UserStatusId", "StatusDesciption", "StatusName" },
                values: new object[,]
                {
                    { 1, "User details pending, yet to complete", "Draft" },
                    { 2, "User details complete, Password creating pending", "PendingSignup" },
                    { 3, "Password creation Link Expired", "ExpiredLink" },
                    { 4, "Active User", "Active" },
                    { 5, "Inactive User", "Inactive" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_UserStatusId",
                table: "AspNetUsers",
                column: "UserStatusId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_UserStatus_UserStatusId",
                table: "AspNetUsers",
                column: "UserStatusId",
                principalTable: "UserStatus",
                principalColumn: "UserStatusId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_UserStatus_UserStatusId",
                table: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "UserStatus");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_UserStatusId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "UserStatusId",
                table: "AspNetUsers");

            migrationBuilder.AlterColumn<string>(
                name: "DefaultApp",
                table: "AspNetUsers",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true,
                oldDefaultValue: "myDefaultApp");
        }
    }
}
