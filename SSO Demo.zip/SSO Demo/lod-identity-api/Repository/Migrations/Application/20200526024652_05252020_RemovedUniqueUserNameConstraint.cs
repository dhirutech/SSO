﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Repository.Migrations.Application
{
    public partial class _05252020_RemovedUniqueUserNameConstraint : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
