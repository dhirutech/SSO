using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Repository.Interfaces;
using Repository.Models;

namespace Repository
{
	// APPLICATION USER MANAGER
	// Here we create a derived class from Identity's native UserManager in order to override default
	// methods. This was introduced specifically in order to allow Identity native methods that 
	// consider tenancy claims to allow for uniqueness not on username alone, but a combination of
	// username with tenantId.
	//
	// It's important to note that the "Manager" lives atop the "Store" (which is replaced by our derived
	// ApplicationUserStore class), so both layers must be modified so that methods (Manager) and data
	// management/access (Store) are in sync with eachother.
	//
	// For a more thorough understanding, visit:
	// MS Docs: Custom storage providers for ASP.NET Core Identity
	// https://docs.microsoft.com/en-us/aspnet/core/security/authentication/identity-custom-storage-providers?view=aspnetcore-3.1
	//
	// For the source code of MS Identity's Implementation, visit:
	// https://github.com/dotnet/aspnetcore/blob/master/src/Identity/Extensions.Core/src/UserManager.cs

	public class ApplicationUserManager<TUser> : UserManager<TUser> where TUser : AppUser
    {
		private readonly IUserRepository _userRepository;
        private readonly ITenantRequestProvider _tenantProvider;
		public string TenantId { get; set; }
		public ApplicationUserManager(IUserStore<TUser> store, 
		IOptions<IdentityOptions> optionsAccessor, 
		IPasswordHasher<TUser> passwordHasher, 
		IEnumerable<IUserValidator<TUser>> userValidators, 
		IEnumerable<IPasswordValidator<TUser>> passwordValidators, 
		ILookupNormalizer keyNormalizer, 
		IdentityErrorDescriber errors, 
		IServiceProvider services, 
		ILogger<UserManager<TUser>> logger,
		IUserRepository userRepository,
        ITenantRequestProvider tenantProvider
        ) : base(
			store, 
			optionsAccessor, 
			passwordHasher, 
			userValidators, 
			passwordValidators, 
			keyNormalizer, 
			errors, 
			services, 
			logger)
		{
			_userRepository = userRepository;
            _tenantProvider = tenantProvider;
		}

        public async Task<IdentityResult> IsPasswordValid(TUser user, string PasswordHash)
        {
            return await this.ValidatePasswordAsync(user, PasswordHash);
        }

        public override async Task<IdentityResult> CreateAsync(TUser user)
        {
            ThrowIfDisposed();
			
			var result = await ValidateUserAsync(user);
            
			if (!result.Succeeded)
            {
                return result;
            }
            await UpdateNormalizedUserNameAsync(user);
            await UpdateNormalizedEmailAsync(user);


            return await Store.CreateAsync(user, CancellationToken);
        }

		public override async Task<IdentityResult> CreateAsync(TUser user, string password)
        {
            ThrowIfDisposed();
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }
            if (password == null)
            {
                throw new ArgumentNullException(nameof(password));
            }
            var result = await UpdatePasswordHash(user, password, true);
            if (!result.Succeeded)
            {
                return result;
            }
            return await CreateAsync(user);
        }

        public override async Task<TUser> FindByNameAsync(string userName)
        {
            ThrowIfDisposed();
            if (userName == null)
            {
                throw new ArgumentNullException(nameof(userName));
            }
            userName = NormalizeName(userName);

            if(TenantId == null)
                TenantId = _tenantProvider.GetTenant();

            var user = await _userRepository.FindByNameAndTenantAsync(userName, TenantId);
 
            return await Task.FromResult<TUser>((TUser)user);
        }

		new async Task<IdentityResult> ValidateUserAsync(TUser user)
        {
            var errors = new List<IdentityError>();
            foreach (var v in UserValidators)
            {
                var result = await v.ValidateAsync(this, user);
                if (!result.Succeeded)
                {
                    errors.AddRange(result.Errors);
                }
            }
            if (errors.Count > 0)
            {
                Logger.LogWarning(13, "User {userId} validation failed: {errors}.", await GetUserIdAsync(user), string.Join(";", errors.Select(e => e.Code)));
                return IdentityResult.Failed(errors.ToArray());
            }
            return IdentityResult.Success;
        }
    }
}