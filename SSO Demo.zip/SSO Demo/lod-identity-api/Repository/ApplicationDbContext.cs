﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Repository.Models;
using System.Collections.Generic;

namespace Repository
{
    public class ApplicationDbContext : IdentityDbContext<AppUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> contextOptions) : base(contextOptions)
        {
        }
        public DbSet<UserStatus> UserStatus { get; set; }
        public DbSet<UserPreferences> UserPreferences { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);


            modelBuilder.Entity<AppUser>()
                .Property(au => au.DefaultApp)
                .HasDefaultValue("myDefaultApp");

            modelBuilder.Entity<AppUser>(builder =>
            {
                // REMOVE INDEX
                // Here we override the default indexes that Identity places on the username and email so that we
                // can create indexes based on the combination of them with tenantId.
                builder.Metadata.RemoveIndex(new[] { builder.Property(u => u.NormalizedUserName).Metadata });
                builder.Metadata.RemoveIndex(new[] { builder.Property(u => u.NormalizedEmail).Metadata });
                builder.HasIndex(u => new { u.NormalizedUserName, u.TenantId }).HasName("UserNameIndex").IsUnique();
                builder.HasIndex(u => new { u.NormalizedEmail, u.TenantId }).HasName("EmailIndex").IsUnique();
            });
            modelBuilder.Entity<UserStatus>(entity => entity.HasData(new List<UserStatus>
            {
                new UserStatus
                {
                    UserStatusId=1,
                    StatusName="Draft",
                    StatusDesciption="User details pending, yet to complete",
                },
                new UserStatus
                {
                    UserStatusId=2,
                    StatusName="Pending Signup",
                    StatusDesciption="User details complete, Password creating pending",
                },
                new UserStatus
                {
                    UserStatusId=3,
                    StatusName="Expired Link",
                    StatusDesciption="Password creation Link Expired",
                },
                new UserStatus
                {
                    UserStatusId=4,
                    StatusName="Active",
                    StatusDesciption="Active User",
                },
                new UserStatus
                {
                    UserStatusId=5,
                    StatusName="Inactive",
                    StatusDesciption="Inactive User",
                }
            }));
        }
    }
}
