using Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace Repository.Repositories
{
	public class TenantRequestProvider : ITenantRequestProvider
	{
		private string _tenant;

		public void SetTenant(string tenant)
		{
			_tenant = tenant;
		}
		public string GetTenant()
		{
			return _tenant;
		}
	}
}