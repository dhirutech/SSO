﻿using Microsoft.EntityFrameworkCore;
using Repository.CustomExceptions;
using Repository.Interfaces;
using Repository.Models;
using Repository.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repository.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly ApplicationDbContext _identityContext;
        public UserRepository(ApplicationDbContext identityContext)
        {
            _identityContext = identityContext;
        }

        public async Task<List<AppUser>> SearchUsers(SearchFilterDto searchFilter)
        {
            var searchList = !String.IsNullOrWhiteSpace(searchFilter.SearchText) ?
                searchFilter.SearchText.Replace(" ", ",").Replace("\t", ",").Split(",").ToList() : new List<string>();
            var statusList = new List<string>();
            if (!String.IsNullOrEmpty(searchFilter.Status))
                statusList = searchFilter.Status.Split(',').ToList();

            return _identityContext.Users
                    .Include(u => u.UserStatus)
                    .AsEnumerable()
                    .Where(user => user.TenantId == searchFilter.TenantId
                    && (!searchList.Any() || searchList.Any($"{user.FirstName}{user.LastName}{user.Email}{user.PhoneNumber}{user.ExternalId}".ToUpper().Contains))
                    && (!searchFilter.FromDate.HasValue || (user.LastLoginTime.HasValue && user.LastLoginTime.Value.Date >= searchFilter.FromDate.Value.Date))
                    && (!searchFilter.ToDate.HasValue || (user.LastLoginTime.HasValue && user.LastLoginTime.Value.Date <= searchFilter.ToDate.Value.Date))
                    && (statusList.Count == 0 || (user.UserStatus != null && statusList.Contains(user.UserStatus.StatusName)))
                    ).ToList();
        }

        public async Task<List<AppUser>> GetUser()
        {
            List<AppUser> _users;
            try
            {
                _users = await _identityContext.Users.ToListAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error Details: {ex.Message}");
                throw;
            }
            return _users;
        }

        public async Task<AppUser> GetUserById(string id)
        {
            var users = await _identityContext.Users.Include(u => u.UserPreferences).FirstOrDefaultAsync(x => x.Id == id);
            if (users == null)
            {
                throw new KeyNotFoundException("The Record was not found in the record ");
            }
            return users;
        }

        public async Task<AppUser> CreateUser(AppUser users)
        {
            users.UserName = users.Email;
            users.PasswordQueue = users.PasswordHash;
            var user = await _identityContext.Users.Where(x =>
                x.Email.ToLower() == users.Email.ToLower() &&
                x.TenantId.ToLower() == users.TenantId.ToLower() &&
                x.Status)
                .FirstOrDefaultAsync();
            if (user != null)
            {
                throw new UniqueEmailException(users.Email + " is exists in the db.");
            }
            await _identityContext.Users.AddAsync(users);
            await _identityContext.SaveChangesAsync();
            return users;
        }

        public async Task<AppUser> UpdateUser(AppUser user)
        {
            AppUser _user = await _identityContext.Users.Where(x => x.Id == user.Id).FirstOrDefaultAsync();
            _user.Status = user.Status;
            if (!string.IsNullOrEmpty(user.Email))
            {
                _user.Email = user.Email;
                _user.UserName = user.Email;
            }
            _user.AlternateEmail = user.AlternateEmail;
            if (user.PasswordHash != _user.PasswordHash && _user.PasswordQueue.Split(',').Any(x => x.Equals(user.PasswordHash)))
            {
                throw new PasswordAlreadyUsedException("This is one of the last 3 passwords");
            }
            _user.PhoneNumber = user.PhoneNumber;
            _user.FirstName = user.FirstName;
            _user.LastName = user.LastName;
            _user.ExternalId = user.ExternalId;
            _user.UpdatedDate = DateTime.Now;
            Queue<string> pQ = new Queue<string>(_user.PasswordQueue.Split(',').Take(3));
            if (!pQ.Contains(null) && pQ.Count >= 3)
            {
                pQ.Dequeue();
            }

            if (!string.IsNullOrEmpty(user.PasswordHash) && user.PasswordHash != _user.PasswordHash)
            {
                pQ.Enqueue(user.PasswordHash);
                _user.PasswordHash = user.PasswordHash;
                _user.PasswordQueue = string.Empty;
                for (int i = 0; i < pQ.Count; i++)
                {
                    _user.PasswordQueue =
                        i == 0 ? $"{pQ.ToArray()[i]}" : $"{_user.PasswordQueue},{pQ.ToArray()[i]}";
                }
            }
            _user.CreatedDate = DateTime.Now;
            _user.UpdatedDate = DateTime.Now;
            _identityContext.Users.Update(_user);
            await _identityContext.SaveChangesAsync();
            return user;
        }

        public async Task<bool> DeleteUser(IList<string> ids)
        {
            IList<AppUser> users = new List<AppUser>();
            try
            {
                foreach (string id in ids)
                {
                    AppUser user = await _identityContext.Users.FirstOrDefaultAsync(x => x.Id == id);
                    if (user == null)
                    {
                        throw new KeyNotFoundException("Record Not Found");
                    }

                    user.Status = false;
                    users.Add(user);
                }
                _identityContext.UpdateRange(users);
                await _identityContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error Details: {ex.Message}");
                throw;
            }
            return true;
        }

        public async Task<bool> ActivateDeActivateUser(string userId)
        {
            try
            {
                AppUser user = await _identityContext.Users.FirstOrDefaultAsync(x => x.Id == userId);
                if (user == null)
                {
                    throw new KeyNotFoundException("Record Not Found");
                }

                user.Status = !user.Status;
                if (user.Status == true)
                {
                    user.UserStatusId = UserStatuses.Active;
                }
                else
                {
                    user.UserStatusId = UserStatuses.Inactive;
                }

                _identityContext.Update(user);
                await _identityContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error Details: {ex.Message}");
                throw;
            }
            return true;
        }

        public async Task<bool> SetUserDefaultAppAsync(string userId, string defaultApp)
        {
            var user = await _identityContext.Users.Where(x => x.Id == userId)
                .FirstOrDefaultAsync();
            if (user == null)
            {
                throw new KeyNotFoundException($"{userId} not found in our records.");
            }
            user.DefaultApp = defaultApp;
            await _identityContext.Users.Update(user).Context.SaveChangesAsync();
            return true;
        }

        public async Task<AppUser> FindByNameAndTenantAsync(string normalizedUserName, string tenantId)
        {
            return await _identityContext.Users.FirstOrDefaultAsync(u =>
                u.NormalizedUserName == normalizedUserName &&
                u.TenantId == tenantId);
        }

        public async Task<AppUser> updateUserStatus(string userId)
        {
            AppUser appUser = await _identityContext.Users.FirstOrDefaultAsync(x => x.Id == userId);

            try
            {
                if (appUser == null)
                {
                    throw new KeyNotFoundException("Record Not Found");
                }

                if (appUser.UserStatusId != null && appUser.UserStatusId == UserStatuses.ExpiredLink)
                {
                    appUser.PasswordSignUpToken = Guid.NewGuid();
                    appUser.PasswordSignUpTokenEndTime = DateTimeOffset.Now.AddDays(1);
                    appUser.UserStatusId = UserStatuses.PendingSignup;
                    appUser.UpdatedDate = DateTime.Now;
                    _identityContext.Update(appUser);
                }
                else
                {
                    throw new InvalidUserException($"User is not Expired");
                }
                await _identityContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error Details: {ex.Message}");
                throw;
            }
            return appUser;
        }

        public async Task<IList<AppUser>> GetSignUpExpiredUsers()
        {
            var users = _identityContext.Users.AsEnumerable().Where(x => x.PasswordSignUpTokenEndTime.HasValue
           && x.PasswordSignUpTokenEndTime < DateTimeOffset.Now
           && x.UserStatusId == UserStatuses.PendingSignup).ToList();
            if (!(users?.Count() > 0))
            {
                return users;
            }

            users.ForEach(user =>
            {
                user.UserStatusId = UserStatuses.ExpiredLink;
            });
            _identityContext.Users.UpdateRange(users);
            await _identityContext.SaveChangesAsync();
            return users;
        }

        public async Task<bool> SetUserDefaultListView(string userId)
        {
            AppUser user = await _identityContext.Users.Where(x => x.Id == userId).FirstOrDefaultAsync();
            if (user != null)
            {
                try
                {
                    UserPreferences userPreference = new UserPreferences();
                    userPreference.DefaultListView = UserPreferenceConstant.DefaultView;
                    userPreference.Id = user.Id;
                    _identityContext.UserPreferences.Add(userPreference);
                    _identityContext.SaveChanges();
                    user.UserPreferenceId = userPreference.UserPreferenceId;
                    _identityContext.Users.UpdateRange(user);
                    _identityContext.SaveChanges();
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error Details: {ex.Message}");
                    throw;
                }
            }
            return false;
        }

        public async Task<bool> SetUserDefaultPreferences(string userId, string defaultLanguage, string defaultApp, string defaultListView)
        {

            AppUser user = await _identityContext.Users.Where(x => x.Id == userId).FirstOrDefaultAsync();
            UserPreferences userPreference = await _identityContext.UserPreferences.Where(x => x.Id == userId).FirstOrDefaultAsync();

            if (user != null)
            {
                if (userPreference == null)
                {
                    try
                    {
                        UserPreferences userPref = new UserPreferences();
                        userPref.Id = user.Id;
                        if (!string.IsNullOrEmpty(defaultApp)) { userPref.DefaultApplication = defaultApp; }
                        if (!string.IsNullOrEmpty(defaultLanguage)) { userPref.DefaultLanguage = defaultLanguage; }
                        if (!string.IsNullOrEmpty(defaultListView)) { userPref.DefaultListView = defaultListView; }
                        _identityContext.UserPreferences.Add(userPref);
                        await _identityContext.SaveChangesAsync();
                        user.UserPreferenceId = userPref.UserPreferenceId;
                        _identityContext.Users.UpdateRange(user);
                        await _identityContext.SaveChangesAsync();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error Details: {ex.Message}");
                        throw ex;
                    }
                }
                else
                {
                    try
                    {
                        if (!string.IsNullOrEmpty(defaultApp)) { userPreference.DefaultApplication = defaultApp; }
                        if (!string.IsNullOrEmpty(defaultLanguage)) { userPreference.DefaultLanguage = defaultLanguage; }
                        if (!string.IsNullOrEmpty(defaultListView)) { userPreference.DefaultListView = defaultListView; }
                        _identityContext.UserPreferences.Update(userPreference);
                        await _identityContext.SaveChangesAsync();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error Details: {ex.Message}");
                        throw ex;
                    }

                }
                return true;
            }

            return false;
        }

        public async Task<List<AppUser>> GetUserDetailsByUserIds(List<string> userIds)
        {
            return await _identityContext.Users.Where(x => userIds.Contains(x.Id)).ToListAsync();

        }

        public void Dispose()
        {
        }
    }
}
