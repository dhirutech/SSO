using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.DataProtection.EntityFrameworkCore;

namespace Repository
{
    public class PersistedKeyDbContext : DbContext, IDataProtectionKeyContext
    {
        public PersistedKeyDbContext(DbContextOptions<PersistedKeyDbContext> options) : base(options)
		{ 

		}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
        public DbSet<DataProtectionKey> DataProtectionKeys { get; set; }
	}
}