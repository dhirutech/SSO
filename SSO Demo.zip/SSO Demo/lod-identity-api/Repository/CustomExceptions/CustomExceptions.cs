﻿using System;

namespace Repository.CustomExceptions
{
    public class CustomExceptions
    {
    }
    public class InvalidUserException : Exception
    {
        public InvalidUserException(string message) : base(message)
        {

        }
    }
    [Serializable]
    public class UniqueEmailException : Exception
    {
        public UniqueEmailException(string messageString)
        : base(string.Format(messageString))
        {
        }
    }
    [Serializable]
    public class PasswordAlreadyUsedException : Exception
    {
        public PasswordAlreadyUsedException(string message) : base(message)
        {

        }
    }

    [Serializable]
    public class InvalidPassword : Exception
    {
        public InvalidPassword(string message) : base(message)
        {

        }
    }

    [Serializable]
    public class ForbiddenException : Exception
    {
        public ForbiddenException(string message) : base(message)
        {

        }
    }

    [Serializable]
    public class DuplicateUserRoleException : Exception
    {
        public DuplicateUserRoleException(string message) : base(message)
        {

        }
    }
    [Serializable]
    public class AccountBlockedException : Exception
    {
        public AccountBlockedException(string message) : base(message)
        {

        }
    }
}
