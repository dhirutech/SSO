﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Repository.Models
{
    public class UserPreferences
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int UserPreferenceId { get; set; }
        public string DefaultApplication { get; set; }
        public string DefaultLanguage { get; set; }
        public string DefaultListView { get; set; }
        public string Id { get; set; }
    }
    
}