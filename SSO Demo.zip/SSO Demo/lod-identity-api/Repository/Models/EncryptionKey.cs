using Microsoft.AspNetCore.DataProtection.EntityFrameworkCore;

namespace Repository
{
	public class EncryptionKey : DataProtectionKey
	{
		public EncryptionKey()
		{
			
		}

	}
}