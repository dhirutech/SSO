﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Repository.Models
{
    public class UserStatus
    {
        [Key]
        public int UserStatusId { get; set; }
        public string StatusName { get; set; }
        public string StatusDesciption { get; set; }
        [ForeignKey("UserStatusId")]
        public virtual ICollection<AppUser> AppUsers { get; set; }

    }
}
