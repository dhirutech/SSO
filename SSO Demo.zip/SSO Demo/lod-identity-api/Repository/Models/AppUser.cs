﻿using Microsoft.AspNetCore.Identity;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Repository.Models
{
    public class AppUser : IdentityUser
    {
        public AppUser()
        {

        }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string TenantId { get; set; }
        public string AlternateEmail { get; set; }
        public string Roles { get; set; }
        public string DefaultApp { get; set; }
        public string ExternalId { get; set; }
        public string PasswordQueue { get; set; }
        public Guid PasswordResetToken { get; set; }
        public DateTime PasswordResetTokenExpiration { get; set; }
        [Key]
        public override string Id { get; set; } = Guid.NewGuid().ToString();
        public bool Status { get; set; }
        public bool ResetPasswordLinkExpired { get; set; }
        public Guid? PasswordSignUpToken { get; set; }
        public DateTimeOffset? PasswordSignUpTokenEndTime { get; set; }
        public DateTimeOffset? LastLoginTime { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public virtual UserStatus UserStatus { get; set; }
        public int? UserStatusId { get; set; }
        public int? UserPreferenceId { get; set; }
        [ForeignKey("UserPreferenceId")]
        public virtual UserPreferences UserPreferences { get; set; }
        
    }
}
