﻿using System;
using System.Collections.Generic;

namespace Repository.ViewModels
{
    public class SearchFilterDto
    {
        public string SearchText { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
        public string SortField { get; set; }
        public string SortType { get; set; }
        public string TenantId { get; set; }
        //filter params
        public DateTimeOffset? FromDate { get; set; }
        public DateTimeOffset? ToDate { get; set; }
        public int ProgramId { get; set; }
        public int RoleId { get; set; }
        public string Status { get; set; }
    }
}