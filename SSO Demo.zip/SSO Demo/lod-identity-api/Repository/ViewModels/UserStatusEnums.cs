﻿namespace Repository.ViewModels
{
    public static class UserStatuses
    {
        public const int Draft = 1;
        public const int PendingSignup = 2;
        public const int ExpiredLink = 3;
        public const int Active = 4;
        public const int Inactive = 5;
    }
    public class UserPreferenceConstant
    {
        public const string DefaultView = "GridView";
        public const string DefaultLanguage = "English";
    }
}
