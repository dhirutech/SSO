﻿using Repository.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Repository.ViewModels;
using System;

namespace Repository.Interfaces
{
    public interface IUserRepository:IDisposable
    {
        Task<List<AppUser>> SearchUsers(SearchFilterDto searchFilter);
        Task<AppUser> GetUserById(string id);
        Task<bool> ActivateDeActivateUser(string userId);
        Task<bool> SetUserDefaultAppAsync(string userId, string defaultApp);
        Task<AppUser> FindByNameAndTenantAsync(string normalizedUserName, string tenantId);
        Task<AppUser> updateUserStatus(string emailId);
        Task<IList<AppUser>> GetSignUpExpiredUsers();
        Task<bool> SetUserDefaultListView(string userId);
        Task<bool> SetUserDefaultPreferences(string userId, string defaultLanguage, string defaultApp, string defaultListView);
        Task<List<AppUser>> GetUserDetailsByUserIds(List<string> userIds);
    }
}
