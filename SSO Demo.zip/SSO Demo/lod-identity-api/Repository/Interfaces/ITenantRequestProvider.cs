using System.Threading.Tasks;

namespace Repository.Interfaces
{
  public interface ITenantRequestProvider
  {
    void SetTenant(string tenant);
	  string GetTenant();
  }
}