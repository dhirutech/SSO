﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;
using Repository;
using Repository.Models;
using Repository.Repositories;
using Repository.ViewModels;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace UnitTests.RepositoryTest
{
    [TestFixture]
    public class UserRepositoryTest
    {
        private DbContextOptions<ApplicationDbContext> options { get; set; }
        private ApplicationDbContext context { get; set; }
        private UserRepository userRepository { get; set; }

        private List<SearchFilterDto> SearchFilterDto;

        private List<AppUser> users;

        public class mockUserManager : UserManager<AppUser>
        {
            public mockUserManager() : base(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object)
            {

            }
            public override Task<AppUser> FindByEmailAsync(string email)
            {
                return Task.FromResult(new AppUser { Email = email });
            }

            public override Task<IList<string>> GetRolesAsync(AppUser user)
            {

                IList<string> roles = new List<string>();
                roles.Add("Admin");
                roles.Add("Super Admin");
                return Task.FromResult(roles);
            }

            public override Task<bool> IsEmailConfirmedAsync(AppUser user)
            {
                return Task.FromResult(user.Email == "test@test.com");
            }

            public override Task<string> GeneratePasswordResetTokenAsync(AppUser user)
            {
                return Task.FromResult("---------------");
            }
            public override Task<bool> CheckPasswordAsync(AppUser user, string password)
            {
                return Task.FromResult(true);
            }

            public override Task<IdentityResult> UpdateAsync(AppUser user)
            {
                return Task.FromResult(IdentityResult.Success);
            }

            public override Task<IdentityResult> ChangePasswordAsync(AppUser user, string currentPassword, string oldPassword)
            {
                return Task.FromResult(IdentityResult.Success);
            }
        }
        mockUserManager mockUser = new mockUserManager();


        [SetUp]
        public void SetUp()
        {
            options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(databaseName: "DBConnection").Options;
            context = new ApplicationDbContext(options);
            Seed(context);
            userRepository = new UserRepository(context);
        }

        #region SearchUsers
        [Test]
        public void SearchUsers_Test()
        {
            SearchFilterDto searchFilter = new SearchFilterDto()
            {
                SearchText = "TestSearchText",
                PageSize = 1,
                PageNumber = 2,
                SortField = "CreatedDate",
                SortType = "desc"
            };
            var actual = userRepository.SearchUsers(searchFilter);
            Assert.IsNotNull(actual);
        }
        [Test]
        public void SearchUsers_Test_Empty()
        {
            SearchFilterDto searchFilter = new SearchFilterDto()
            {
                SearchText = string.Empty,
                PageSize = 1,
                PageNumber = 2,
                SortField = "CreatedDate",
                SortType = "desc"
            };
            var actual = userRepository.SearchUsers(searchFilter);
            Assert.IsNotNull(actual);
        }
        #endregion

        #region GetUser
        [Test]
        public void GetUser_Test()
        {
            var actual = userRepository.GetUser();
            Assert.IsNotNull(actual);
        }
        #endregion


        #region GetUserById
        [Test]
        public void GetUserById_Test()
        {
            string id = "Testdata";
            var actual = userRepository.GetUserById(id);
            Assert.IsNotNull(actual);
        }
        [Test]
        public void GetUserById_Test_Exception()
        {
            try
            {
                string id = "Testdatadata";
                var actual = userRepository.GetUserById(id);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
            //Assert.IsNotNull(actual);
        }
        #endregion

        #region CreateUser
        [Test]
        public void CreateUser_Test_Exception()
        {
            AppUser user = new AppUser()
            {
                Id = "testdata",
                UserName = "TestUserName",
                Email = "test@gmail.com",
                PasswordHash = "testpassword",
                Roles = "testroles",
                FirstName = "TestName",
                LastName = "TestLastName",
                ExternalId = "Testdata",
                AlternateEmail = "TestData@gmail.com",
                DefaultApp = "TestDefaultapp",
                PhoneNumber = "1234567890",
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                CreatedBy = "Testcreated",
                UpdatedBy = "TestUpdated",
                Status = true
            };
            var actual = userRepository.CreateUser(user);
            Assert.IsNotNull(actual);
        }
        [Test]
        public void CreateUser_Test()
        {
            AppUser user = new AppUser()
            {
                Id = "testdata",
                UserName = "TestUserName",
                Email = "testdata@gmail.com",
                PasswordHash = "testpassword",
                Roles = "testroles",
                FirstName = "TestName",
                LastName = "TestLastName",
                ExternalId = "Testdata",
                AlternateEmail = "TestData@gmail.com",
                DefaultApp = "TestDefaultapp",
                PhoneNumber = "1234567890",
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                CreatedBy = "Testcreated",
                UpdatedBy = "TestUpdated",
                Status = true
            };
            var actual = userRepository.CreateUser(user);
            Assert.IsNotNull(actual);
        }
        #endregion

        #region UpdateUser
        [Test]
        public void UpdateUSer_Test()
        {
            AppUser user = new AppUser()
            {
                Id = "Testdata",
                UserName = "TestUserName",
                Email = "test@gmail.com",
                PasswordHash = "testpassword@123",
                Roles = "testroles",
                FirstName = "TestName",
                LastName = "TestLastName",
                ExternalId = "Testdata",
                AlternateEmail = "TestData@gmail.com",
                DefaultApp = "TestDefaultapp",
                PhoneNumber = "1234567890",
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                CreatedBy = "Testcreated",
                UpdatedBy = "TestUpdated",
                Status = true
            };
            var actual = userRepository.UpdateUser(user);
            Assert.IsNotNull(actual);
        }
        [Test]
        public void UpdateUSer_Test_Exception()
        {
            try
            {
                AppUser user = new AppUser()
                {
                    Id = "Testdata",
                    UserName = "TestUserName",
                    Email = "test@gmail.com",
                    PasswordHash = "testpasswordchanged@123",
                    Roles = "testroles",
                    FirstName = "TestName",
                    LastName = "TestLastName",
                    ExternalId = "Testdata",
                    AlternateEmail = "TestData@gmail.com",
                    DefaultApp = "TestDefaultapp",
                    PhoneNumber = "1234567890",
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    CreatedBy = "Testcreated",
                    UpdatedBy = "TestUpdated",
                    Status = true
                };
                var actual = userRepository.UpdateUser(user);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }

        }
        #endregion

        #region DeleteUser
        [Test]
        public void DeleteUser_Test()
        {
            IList<string> ids = new List<string>();
            ids.Add("Testdata");
            var actual = userRepository.DeleteUser(ids);
            Assert.IsNotNull(actual);
        }
        [Test]
        public void DeleteUser_Exception()
        {
            try
            {
                IList<string> ids = new List<string>();
                ids.Add("Testdatachanged");
                var actual = userRepository.DeleteUser(ids);
            }
            catch (Exception ex)
            {

                Assert.IsTrue(ex.Message != null);
            }


        }
        #endregion

        #region ActivateDeactivateUser
        [Test]
        public void ActivateDeactivateUser_Test()
        {
            string userId = "Testdata";
            var actual = userRepository.ActivateDeActivateUser(userId);
            Assert.IsNotNull(actual);
        }
        [Test]
        public void ActivateDeactivateUser_Exception()
        {
            try
            {
                string userId = "Testdatachanged";
                var actual = userRepository.ActivateDeActivateUser(userId);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex.Message != null);
            }

        }
        #endregion

        #region SearchUserDefaultAppAsync
        [Test]
        public void SearchUserDefaultAppAsync_Test()
        {
            string UserId = "Testdata";
            string DefaultApp = "testdefault";
            var actual = userRepository.SetUserDefaultAppAsync(UserId, DefaultApp);
            Assert.IsNotNull(actual);
        }
        [Test]
        public void SearchUserDefaultAppAsync_Test_Exception()
        {
            try
            {
                string UserId = "Testdatachanged";
                string DefaultApp = "testdefault";
                var actual = userRepository.SetUserDefaultAppAsync(UserId, DefaultApp);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
        }
        #endregion


        #region FindByNameAndTenantAsyncTest
        [Test]
        public async Task findByNameAndTenantAsync_Test_returnsSuccessfully()
        {
            string normalizedName = "testnormalizedusername";
            string tenantId = "testTenantId";
            AppUser appUser = await userRepository.FindByNameAndTenantAsync(normalizedName, tenantId);
            Assert.IsNotNull(appUser);
        }
        #endregion

        #region updateUserStatus
        [Test]
        public async Task updateUserStatus_Test_ReturnSuccess()
        {
            AppUser user = new AppUser();
            user.UserStatusId = 3;
            string Id = "Testdata1";
            AppUser appUser = await userRepository.updateUserStatus(Id);
            Assert.IsNotNull(appUser);
        }
        
        #endregion

        #region GetSignUpExpiredUsers
        [Test]
        public async Task GetSignUpExpiredUsers_Test_ReturnSuccess()
        {
            
            IList<AppUser> appUser = await userRepository.GetSignUpExpiredUsers( );
            Assert.IsNotNull(appUser);
        }
        #endregion

        #region SetUserDefaultListView
        [Test]
        public async Task SetUserDefaultListView_Test_ReturnSuccess()
        {
             string id= "Testdata";
            bool result = await userRepository.SetUserDefaultListView(id);
            Assert.IsTrue(result);
        }
        [Test]
        public async Task SetUserDefaultListView_Invalid_Test()
        {
            string id = "Test";
            bool result = await userRepository.SetUserDefaultListView(id);
            Assert.IsFalse(result);
        }
        #endregion

        #region SetUserDefaultPreferences
        [Test]
        public async Task SetUserDefaultPreferences_Test_ReturnSuccess()
        {
            string id= "Testdata";
            string defaultLang = "en";
            string defaultApp = "Test";
            string defaultView = "Grid";

            bool result = await userRepository.SetUserDefaultPreferences(id,defaultLang,defaultApp, defaultView);
            Assert.IsTrue(result);
        }       
       
        [Test]
        public async Task SetUserDefaultPreferences_Invalid_Test()
        {
            string id = "Test";
            string defaultLang = "en";
            string defaultApp = "Test";
            string defaultView = "Grid";
            bool result = await userRepository.SetUserDefaultPreferences(id, defaultLang, defaultApp, defaultView);
            Assert.IsFalse(result);
        }
        #endregion
        private void Seed(ApplicationDbContext identityContext)
        {
            users = new List<AppUser>();
            users.Add(new AppUser
            {
                Id = "Testdata",
                UserName = "TestUserName",
                Email = "test@gmail.com",
                PasswordHash = "testpassword",
                Roles = "testroles",
                FirstName = "TestName",
                LastName = "TestLastName",
                ExternalId = "Testdata",
                AlternateEmail = "TestData@gmail.com",
                DefaultApp = "TestDefaultapp",  
                PhoneNumber = "1234567890",
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                CreatedBy = "Testcreated",
                UpdatedBy = "TestUpdated",
                Status = true,
                PasswordQueue = "testpasswordchanged@123",
                NormalizedUserName = "testnormalizedusername",
                TenantId = "testTenantId",
            });
            users.Add(new AppUser
            {
                Id = "Testdata1",
                UserName = "TestUserName1",
                Email = "test1@gmail.com",
                PasswordHash = "testpassword1",
                Roles = "testroles1",
                FirstName = "TestName1",
                LastName = "TestLastName",
                ExternalId = "Testdata1",
                AlternateEmail = "TestData1@gmail.com",
                DefaultApp = "TestDefaultapp",
                PhoneNumber = "1234567890",
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                CreatedBy = "Testcreated",
                UpdatedBy = "TestUpdated",
                Status = true,
                PasswordQueue = "testpasswordchanged@123",
                NormalizedUserName = "testnormalizedusername",
                TenantId = "testTenantId",
                UserStatusId = 3
        });
            users.Add(new AppUser
            {
                Id = "Testdata2",
                UserName = "TestUserName2",
                Email = "test2@gmail.com",
                PasswordHash = "testpassword1",
                Roles = "testroles2",
                FirstName = "TestName2",
                LastName = "TestLastName",
                ExternalId = "Testdata2",
                AlternateEmail = "TestData2@gmail.com",
                DefaultApp = "TestDefaultapp",
                PhoneNumber = "1234567890",
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                CreatedBy = "Testcreated",
                UpdatedBy = "TestUpdated",
                Status = true,
                PasswordQueue = "testpasswordchanged@123",
                NormalizedUserName = "testnormalizedusername",
                TenantId = "testTenantId",
                UserStatusId = 2,
                PasswordSignUpTokenEndTime = DateTime.Now.AddMonths(-2)
            });
            SearchFilterDto = new List<SearchFilterDto>();
            SearchFilterDto.Add(new SearchFilterDto
            {
                SearchText = "test",
                PageSize = 10,
                PageNumber = 1,
                SortField = "CreatedDate",
                SortType = "desc"
            });
            identityContext.Users.AddRange(users);
            identityContext.SaveChanges();
        }
        [TearDown]
        public void TearDown()
        {
            try
            {
                var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(databaseName: "DBConnection").Options;
                var context = new ApplicationDbContext(options);
                context.Database.EnsureDeleted();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
