﻿using API.Controllers;
using API.Controllers.V1;
using Logic.Interfaces;
using Logic.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MockQueryable.Moq;
using Moq;
using NUnit.Framework;
using NUnit.Framework.Internal;
using Repository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SignInResult = Microsoft.AspNetCore.Identity.SignInResult;

namespace UnitTests.ControllerTest
{
    [TestFixture]
    public class LoginControllerTest
    {
        private LoginController _loginController;
        private Mock<ILoginService> _loginService;
        private Mock<IUserService> _userService;
        private Mock<IConfiguration> _config;
        private Mock<ITokenService> _token;
        private Mock<IEmailService> _emailService;
        private Mock<UserManager<AppUser>> _usermanager;


        public class mockUserManager : UserManager<AppUser>
        {
            public mockUserManager() : base(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object)
            {

            }
            public override Task<AppUser> FindByEmailAsync(string email)
            {
                return Task.FromResult(new AppUser { Email = email });
            }

            public override Task<IList<string>> GetRolesAsync(AppUser user)
            {

                IList<string> roles = new List<string>();
                roles.Add("Admin");
                roles.Add("Super Admin");
                return Task.FromResult(roles);
            }

            public override Task<bool> IsEmailConfirmedAsync(AppUser user)
            {
                return Task.FromResult(user.Email == "test@test.com");
            }

            public override Task<string> GeneratePasswordResetTokenAsync(AppUser user)
            {
                return Task.FromResult("---------------");
            }
        }
        mockUserManager mockUser = new mockUserManager();

        public class FakeSignInManager : SignInManager<AppUser>
        {
            public FakeSignInManager()
                : base(new mockUserManager(),
                      new Mock<IHttpContextAccessor>().Object,
                      new Mock<IUserClaimsPrincipalFactory<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<ILogger<SignInManager<AppUser>>>().Object,
                      new Mock<IAuthenticationSchemeProvider>().Object,
                      new Mock<IUserConfirmation<AppUser>>().Object)
            {

            }

            public override Task SignOutAsync()
            {
                return Task.FromResult("-----------");
            }

            public override Task<SignInResult> PasswordSignInAsync(AppUser userName, string password, bool isPersistent, bool lockoutOnFailure)
            {
                return Task.FromResult(SignInResult.Success);
            }


        }
        FakeSignInManager fakeSignInManager = new FakeSignInManager();


        public class MockSignInManager : SignInManager<AppUser>
        {
            public MockSignInManager()
                : base(new mockUserManager(),
                      new Mock<IHttpContextAccessor>().Object,
                      new Mock<IUserClaimsPrincipalFactory<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<ILogger<SignInManager<AppUser>>>().Object,
                      new Mock<IAuthenticationSchemeProvider>().Object,
                      new Mock<IUserConfirmation<AppUser>>().Object)
            {

            }

            public override Task SignOutAsync()
            {
                return Task.FromResult("-----------");
            }

            public override Task<SignInResult> PasswordSignInAsync(AppUser userName, string password, bool isPersistent, bool lockoutOnFailure)
            {
                return Task.FromResult(SignInResult.LockedOut);
            }


        }
        MockSignInManager mockSignInManager = new MockSignInManager();


        public class MockSignInManager1 : SignInManager<AppUser>
        {
            public MockSignInManager1()
                : base(new mockUserManager(),
                      new Mock<IHttpContextAccessor>().Object,
                      new Mock<IUserClaimsPrincipalFactory<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<ILogger<SignInManager<AppUser>>>().Object,
                      new Mock<IAuthenticationSchemeProvider>().Object,
                      new Mock<IUserConfirmation<AppUser>>().Object)
            {

            }

            public override Task SignOutAsync()
            {
                return Task.FromResult("-----------");
            }

            public override Task<SignInResult> PasswordSignInAsync(AppUser userName, string password, bool isPersistent, bool lockoutOnFailure)
            {
                return Task.FromResult(SignInResult.Failed);
            }


        }
        MockSignInManager1 mockSignInManager1 = new MockSignInManager1();




        [SetUp]
        public void SetUp()
        {
            _loginService = new Mock<ILoginService>();
            _userService = new Mock<IUserService>();
            _config = new Mock<IConfiguration>();
            _token = new Mock<ITokenService>();
            _emailService = new Mock<IEmailService>();
            _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, mockUser, fakeSignInManager);
        }

        #region Update
        [Test]
        public async Task Update_Test()
        {
            UserViewModels userView = new UserViewModels()
            {
                UserId = "tesdata",
                OldPassword = "TestPassWord",
                NewPassword = "TestNewPassword",
            };
            _loginService
                .Setup(m => m.UpdatePasswordAsync(userView))
                .Returns(Task.FromResult(true));
            IActionResult controllerResult = await _loginController.Update(userView);
            Assert.IsTrue(controllerResult is OkObjectResult);
        }

        #endregion


        #region ValidateResetToken
        [Test]
        public async Task ValidateResetToken_Returns_Sucessfully()
        {
            var dueDate = new DateTime(2011, 3, 3);
            AppUser appUser = new AppUser()
            {
                AlternateEmail = "testdata@gmail.com",
                CreatedBy = "tester",
                CreatedDate = DateTime.Now,
                DefaultApp = "tesdefaultapp",
                Email = "testdata@gmail.com",
                ExternalId = "123",
                FirstName = "tester",
                LastName = "user",
                PasswordHash = "12345678",
                PhoneNumber = "2134567890",
                Roles = "admin",
                Status = true,
                Id = "testdata",
                PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                PasswordResetTokenExpiration = dueDate.AddYears(100)
            };
            var dd = new List<AppUser>();
            dd.Add(appUser);
            IQueryable<AppUser> queryableUsers = dd.AsQueryable();

            var mock1 = dd.AsQueryable().BuildMock();
            _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                  new Mock<IOptions<IdentityOptions>>().Object,
                  new Mock<IPasswordHasher<AppUser>>().Object,
                  new IUserValidator<AppUser>[0],
                  new IPasswordValidator<AppUser>[0],
                  new Mock<ILookupNormalizer>().Object,
                  new Mock<IdentityErrorDescriber>().Object,
                  new Mock<IServiceProvider>().Object,
                  new Mock<ILogger<UserManager<AppUser>>>().Object);
            _usermanager.Setup(x => x.Users).Returns(mock1.Object);



            _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);
            Guid resetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf");
            IActionResult controllerResult = await _loginController.ValidateResetToken(resetToken);
        }
        [Test]
        public async Task ValidateResetToken_Returns_Exception()
        {
            try
            {
                AppUser appUser = new AppUser()
                {
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    PasswordResetTokenExpiration = DateTime.Now
                };
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);



                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);
                Guid resetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf");
                IActionResult controllerResult = await _loginController.ValidateResetToken(resetToken);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == "Reset password link Expired."); }
        }
        [Test]
        public async Task ValidateResetToken_Returns_KeyNotFoundException()
        {
            try
            {
                AppUser appUser = new AppUser()
                {

                };
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);



                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);
                Guid resetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf");
                IActionResult controllerResult = await _loginController.ValidateResetToken(resetToken);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == "User Not Found"); }
        }
        #endregion


        #region GenerateToken
        [Test]
        public async Task GenerateToken_Tests_StatusCode423()
        {
            try
            {
                AppUser appUser = new AppUser
                {
                    UserName = "TestUserName",
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                };

                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                    new Mock<IOptions<IdentityOptions>>().Object,
                    new Mock<IPasswordHasher<AppUser>>().Object,
                    new IUserValidator<AppUser>[0],
                    new IPasswordValidator<AppUser>[0],
                    new Mock<ILookupNormalizer>().Object,
                    new Mock<IdentityErrorDescriber>().Object,
                    new Mock<IServiceProvider>().Object,
                    new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);



                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);

                TokenResponse tokenResponse = new TokenResponse()
                {
                    InvalidAttempts = 1,
                    AccessToken = "emlkanld",
                    DefaultApp = "testdefault",
                    Error = "TestError",
                    ErrorDescription = "testErrorDescription",
                    RefreshToken = "testrefreshtoken",
                    TokenType = "testtokentype"
                };

                TokenRequest tokenRequest = new TokenRequest()
                {
                    ClientId = "2",
                    ClientSecret = "testclientsecret",
                    GrantType = "password",
                    Password = "testpassword",
                    RefreshToken = "testrefreshtoken",
                    Scope = "testscope",
                    Username = "TestUserName"
                };
                _token
                    .Setup(m => m.GetToken(tokenRequest))
                    .Returns(Task.FromResult(tokenResponse));

                var result = _loginController.GenerateToken(tokenRequest);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
        }
        [Test]
        public async Task GenerateToken_Tests_BadRequestObject()
        {
            try
            {
                AppUser appUser = new AppUser()
                {
                    UserName = "TestUserName",
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    AccessFailedCount = 3
                };

                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);



                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);

                TokenResponse tokenResponse = new TokenResponse()
                {
                    InvalidAttempts = 1,
                    AccessToken = "emlkanld",
                    DefaultApp = "testdefault",
                    Error = "TestError",
                    ErrorDescription = "testErrorDescription",
                    RefreshToken = "testrefreshtoken",
                    TokenType = "testtokentype"
                };

                TokenRequest tokenRequest = new TokenRequest()
                {
                    ClientId = "2",
                    ClientSecret = "testclientsecret",
                    GrantType = "password",
                    Password = "testpassword",
                    RefreshToken = "testrefreshtoken",
                    Scope = "testscope",
                    Username = "TestUserName"
                };
                _token
                    .Setup(m => m.GetToken(tokenRequest))
                    .Returns(Task.FromResult(tokenResponse));

                var result = _loginController.GenerateToken(tokenRequest);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
        }

        [Test]
        public async Task GenerateToken_Tests_BadRequestObject_ResponseError()
        {
            try
            {
                AppUser appUser = new AppUser()
                {
                    UserName = "TestUserName",
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    AccessFailedCount = 3
                };

                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);



                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);

                TokenResponse tokenResponse = new TokenResponse()
                {
                    InvalidAttempts = 1,
                    AccessToken = "emlkanld",
                    DefaultApp = "testdefault",
                    ErrorDescription = "testErrorDescription",
                    RefreshToken = "testrefreshtoken",
                    TokenType = "testtokentype"
                };

                TokenRequest tokenRequest = new TokenRequest()
                {
                    ClientId = "2",
                    ClientSecret = "testclientsecret",
                    GrantType = "password",
                    Password = "testpassword",
                    RefreshToken = "testrefreshtoken",
                    Scope = "testscope",
                    Username = "TestUserName"
                };
                _token
                    .Setup(m => m.GetToken(tokenRequest))
                    .Returns(Task.FromResult(tokenResponse));

                var result = _loginController.GenerateToken(tokenRequest);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
        }

        [Test]
        public async Task GenerateToken_Tests_Status403Forbidden()
        {
            try
            {
                AppUser appUser = new AppUser()
                {
                    UserName = "TestUserName",
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = false,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    AccessFailedCount = 3
                };

                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);



                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);

                TokenResponse tokenResponse = new TokenResponse()
                {
                    InvalidAttempts = 1,
                    AccessToken = "emlkanld",
                    DefaultApp = "testdefault",
                    ErrorDescription = "testErrorDescription",
                    RefreshToken = "testrefreshtoken",
                    TokenType = "testtokentype"
                };

                TokenRequest tokenRequest = new TokenRequest()
                {
                    ClientId = "2",
                    ClientSecret = "testclientsecret",
                    GrantType = "password",
                    Password = "testpassword",
                    RefreshToken = "testrefreshtoken",
                    Scope = "testscope",
                    Username = "TestUserName"
                };
                _token
                    .Setup(m => m.GetToken(tokenRequest))
                    .Returns(Task.FromResult(tokenResponse));

                var result = _loginController.GenerateToken(tokenRequest);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
        }


        [Test]
        public async Task GenerateToken_Tests_BadRequestObjectResult_ResponseError()
        {
            try
            {
                AppUser appUser = new AppUser()
                {
                    UserName = "TestUserName",
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = false,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    AccessFailedCount = 3
                };

                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);



                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);

                TokenResponse tokenResponse = new TokenResponse()
                {
                    InvalidAttempts = 1,
                    AccessToken = "emlkanld",
                    DefaultApp = "testdefault",
                    ErrorDescription = "testErrorDescription",
                    RefreshToken = "testrefreshtoken",
                    TokenType = "testtokentype",
                    Error = "teserror"
                };

                TokenRequest tokenRequest = new TokenRequest()
                {
                    ClientId = "2",
                    ClientSecret = "testclientsecret",
                    Password = "testpassword",
                    RefreshToken = "testrefreshtoken",
                    Scope = "testscope",
                    Username = "TestUserName"
                };
                _token
                    .Setup(m => m.GetToken(tokenRequest))
                    .Returns(Task.FromResult(tokenResponse));

                var result = _loginController.GenerateToken(tokenRequest);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
        }


        [Test]
        public async Task GenerateToken_Tests_NoContent()
        {
            try
            {
                AppUser appUser = new AppUser()
                {
                    UserName = "tesdtadat",
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = false,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    AccessFailedCount = 3
                };

                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);



                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);

                TokenResponse tokenResponse = new TokenResponse()
                {
                    InvalidAttempts = 1,
                    AccessToken = "emlkanld",
                    DefaultApp = "testdefault",
                    ErrorDescription = "testErrorDescription",
                    RefreshToken = "testrefreshtoken",
                    TokenType = "testtokentype",
                    Error = "teserror"
                };

                TokenRequest tokenRequest = new TokenRequest()
                {
                    ClientId = "2",
                    ClientSecret = "testclientsecret",
                    Password = "testpassword",
                    RefreshToken = "testrefreshtoken",
                    Scope = "testscope",
                    Username = "TestUserName",
                    GrantType = "password"
                };
                _token
                    .Setup(m => m.GetToken(tokenRequest))
                    .Returns(Task.FromResult(tokenResponse));

                var result = _loginController.GenerateToken(tokenRequest);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
        }
        #endregion



        #region GenerateResetPasswordLink
        [Test]
        public async Task GenerateResetPasswordLink_Test()
        {
            try
            {

                AppUser appUser = new AppUser()
                {
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    PasswordResetTokenExpiration = DateTime.Now,
                    UserName = "testdata@gmail.com"
                };
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);
                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);

                string email = "testdata@gmail.com";
                IActionResult controllerResult = await _loginController.GenerateResetPasswordLink(email,"Brierley");
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message.Contains("Value cannot be null. (Parameter 's')")); }
        }

        [Test]
        public async Task GenerateResetPasswordLink_Test_KeyNotFoundException()
        {
            try
            {

                AppUser appUser = new AppUser()
                {
                    UserName = "mockdata@gmail.com"
                };
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);
                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);

                string email = "tester@gmail.com";
                IActionResult controllerResult = await _loginController.GenerateResetPasswordLink(email,"Brierley");
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message.Contains("User Not found")); }
        }
        #endregion
        

        #region LogOut
        [Test]
        public async Task LogOut_Test_ReturnsSucessfully()
        {
            try
            {

                AppUser appUser = new AppUser()
                {
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    PasswordResetTokenExpiration = DateTime.Now,
                    UserName = "testdata@gmail.com"
                };
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);
                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);

                string email = "testdata@gmail.com";
                IActionResult controllerResult = await _loginController.Logout(email);
                Assert.IsTrue(controllerResult is OkResult);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message.Contains("Value cannot be null. (Parameter 's')")); }
        }
        #endregion



        #region LogIn
        [Test]
        public async Task LogIn_Returns_Sucessfully_resultSucceeded()
        {
            try
            {
                LoginViewModel loginViewModel = new LoginViewModel()
                {
                    Username = "testdata@gmail.com",
                    Password = "testuserpassword",
                    ReturnUrl = "ldlkcllclwlww"
                };
                AppUser appUser = new AppUser()
                {
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    PasswordResetTokenExpiration = DateTime.Now,
                    UserName = "testdata@gmail.com"
                };
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                    new Mock<IOptions<IdentityOptions>>().Object,
                    new Mock<IPasswordHasher<AppUser>>().Object,
                    new IUserValidator<AppUser>[0],
                    new IPasswordValidator<AppUser>[0],
                    new Mock<ILookupNormalizer>().Object,
                    new Mock<IdentityErrorDescriber>().Object,
                    new Mock<IServiceProvider>().Object,
                    new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);
                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);


                IActionResult controllerResult = await _loginController.Login(loginViewModel);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(!string.IsNullOrEmpty(ex.Message));
            }

        }

        [Test]
        public async Task LogIn_Returns_Sucessfully_resultIsLockedOut()
        {
            try
            {
                LoginViewModel loginViewModel = new LoginViewModel()
                {
                    Username = "testdata@gmail.com",
                    Password = "testuserpassword",
                    ReturnUrl = "ldlkcllclwlww"
                };
                AppUser appUser = new AppUser()
                {
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    PasswordResetTokenExpiration = DateTime.Now,
                    UserName = "testdata@gmail.com"
                };
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);
                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, mockSignInManager);


                IActionResult controllerResult = await _loginController.Login(loginViewModel);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(!string.IsNullOrEmpty(ex.Message));
            }

        }

        [Test]
        public async Task LogIn_Returns_Sucessfully_BadRequestObjectResult_Test()
        {
            try
            {
                LoginViewModel loginViewModel = new LoginViewModel()
                {
                    Username = "testdata@gmail.com",
                    Password = "testuserpassword",
                    ReturnUrl = "ldlkcllclwlww"
                };
                AppUser appUser = new AppUser()
                {
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    PasswordResetTokenExpiration = DateTime.Now,
                    UserName = "testdata@gmail.com"
                };
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);
                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, mockSignInManager1);


                IActionResult controllerResult = await _loginController.Login(loginViewModel);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(!string.IsNullOrEmpty(ex.Message));
            }

        }

        [Test]
        public async Task LogIn_Returns_Sucessfully_loggedUserNull()
        {
            try
            {
                LoginViewModel loginViewModel = new LoginViewModel()
                {
                    Username = "testdata@gmail.com",
                    Password = "testuserpassword",
                    ReturnUrl = "ldlkcllclwlww"
                };
                AppUser appUser = new AppUser()
                {
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdatachanged@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    PasswordResetTokenExpiration = DateTime.Now,
                    UserName = "testdatachanged@gmail.com"
                };
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);
                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);


                IActionResult controllerResult = await _loginController.Login(loginViewModel);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex.Message == "");
            }

        }

        [Test]
        public async Task LogIn_Returns_Sucessfully_loggedUserStatus()
        {
            try
            {
                LoginViewModel loginViewModel = new LoginViewModel()
                {
                    Username = "testdata@gmail.com",
                    Password = "testuserpassword",
                    ReturnUrl = "ldlkcllclwlww"
                };
                AppUser appUser = new AppUser()
                {
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = false,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    PasswordResetTokenExpiration = DateTime.Now,
                    UserName = "testdata@gmail.com"
                };
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);
                _loginController = new LoginController(_config.Object, _loginService.Object, _token.Object, _emailService.Object, _usermanager.Object, fakeSignInManager);


                IActionResult controllerResult = await _loginController.Login(loginViewModel);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(!string.IsNullOrEmpty(ex.Message));
            }

        }
        #endregion


    }
}
