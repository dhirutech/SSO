﻿using API.Controllers.V1;
using AutoMapper;
using Logic.Interfaces;
using Logic.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;
using Repository.Models;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace UnitTests.ControllerTest
{
    [TestFixture]
    public class UserControllerTest
    {
        private UserController _userController;
        private Mock<IUserService> _userService;
        private IList<UserViewModel> userViewModels;
        private Mock<UserManager<AppUser>> _usermanager;
        private Mock<IMapper> _mapper;
        private ClaimsPrincipal _user;

        public class mockUserManager : UserManager<AppUser>
        {
            public mockUserManager() : base(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object)
            {

            }
            public override Task<AppUser> FindByEmailAsync(string email)
            {
                return Task.FromResult(new AppUser { Email = email });
            }

            public override Task<IList<string>> GetRolesAsync(AppUser user)
            {

                IList<string> roles = new List<string>();
                roles.Add("Admin");
                roles.Add("Super Admin");
                return Task.FromResult(roles);
            }

            public override Task<bool> IsEmailConfirmedAsync(AppUser user)
            {
                return Task.FromResult(user.Email == "test@test.com");
            }

            public override Task<string> GeneratePasswordResetTokenAsync(AppUser user)
            {
                return Task.FromResult("---------------");
            }
            public override Task<IdentityResult> CreateAsync(AppUser user, string password)
            {
                return Task.FromResult(IdentityResult.Success);
            }
            public override Task<IdentityResult> AddClaimsAsync(AppUser user, IEnumerable<Claim> claims)
            {
                return Task.FromResult(IdentityResult.Success);
            }
        }
        mockUserManager mockUser = new mockUserManager();

        [SetUp]
        public void SetUp()
        {
            _userService = new Mock<IUserService>();
            _usermanager = new Mock<UserManager<AppUser>>();
            _mapper = new Mock<IMapper>();
            _userController = new UserController(_userService.Object);
            _user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim("tenant", "MOCKTENANT")
            }, "mock"));
            _userController.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = _user }
            };
            userViewModels = GetUserViewModelMockData();

        }

        #region GetAll
        [Test]
        public async Task GetAll_Test_OK()
        {
            SearchFilterViewModel searchFilterView = new SearchFilterViewModel()
            {
                SearchText = "testsearch",
                PageSize = 1,
                PageNumber = 5,
                NameSortType = "testname",
                EmailSortType = "Testemail"
            };
            List<UserResultViewModel> userResultViewModels = new List<UserResultViewModel>();
            userResultViewModels.Add(new UserResultViewModel
            {
                Name = "Testadata",
                Active = true,
                Email = "Testdata@gmail.com",
                ExternalId = "123",
                Id = "1",
                PhoneNumber = "12345678",
                Roles = "Admin"
            });
            SearchResultViewModel searchResultView = new SearchResultViewModel()
            {
                UserCount = 1,
                UsersSearchResult = userResultViewModels
            };
            string searchText = "Test";
            int pageSize = 1;
            int PageNumber = 5;
            string NameSortType = "testname";
            string EmailSortType = "Testemail";
            string externalIdSortType = "testExternal";
            string statussorttype = "testsort";

            _userService.Setup(m => m.SearchUsers(It.IsAny<SearchFilterViewModel>())).ReturnsAsync(searchResultView);
            IActionResult controllerResult = await _userController.GetAll(searchText, pageSize, PageNumber, NameSortType, EmailSortType, externalIdSortType, statussorttype);
            
            Assert.IsTrue(controllerResult is OkObjectResult);
        }

        [Test]
        public async Task GetAll_Test_NoContent()
        {
            SearchResultViewModel searchResultView = new SearchResultViewModel();
            searchResultView = null;
            string searchText = "Test";
            int pageSize = 1;
            int PageNumber = 5;
            string NameSortType = "testname";
            string EmailSortType = "Testemail";
            string externalIdSortType = "testExternal";
            string statussorttype = "testsort";

            _userService.Setup(m => m.SearchUsers(It.IsAny<SearchFilterViewModel>())).ReturnsAsync(searchResultView);
            IActionResult controllerResult = await _userController.GetAll(searchText, pageSize, PageNumber, NameSortType, EmailSortType, externalIdSortType, statussorttype);

            Assert.IsTrue(controllerResult is NoContentResult);
        }
        #endregion

        #region Get
        [Test]
        public async Task Get_Test()
        {
            UserViewModel userView = new UserViewModel()
            {
                UserId = "Testadata",
                UserName = "TestUserName",
                Email = "test@gmail.com",
                Roles = "testroles",
                FirstName = "TestName",
                LastName = "TestLastName",
                PhoneNumber = "1234567890"
            };
            string id = "Testadata";
            _userService
                .Setup(m => m.GetUserById(id))
                .Returns(Task.FromResult(userView));
            IActionResult controllerResult = await _userController.Get(id);
            Assert.IsTrue(controllerResult is OkObjectResult);
        }
        [Test]
        public async Task Get_Exception()
        {
            try
            {
                UserViewModel userView = new UserViewModel()
                {
                    UserId = "testdata",
                    UserName = "TestUserName",
                    Email = "test@gmail.com",
                    Roles = "testroles",
                    FirstName = "TestName",
                    LastName = "TestLastName",
                    PhoneNumber = "1234567890"
                };
                string id = "testadata";
                _userService
                    .Setup(m => m.GetUserById(id))
                    .Throws(new Exception(""));
                IActionResult controllerResult = await _userController.Get(id);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }

        }
        [Test]
        public async Task Get_IdNotException()
        {
            try
            {
                UserViewModel userView = new UserViewModel()
                {
                    UserId = "TestData",
                    UserName = "TestUserName",
                    Email = "test@gmail.com",
                    Roles = "testroles",
                    FirstName = "TestName",
                    LastName = "TestLastName",
                    PhoneNumber = "1234567890"
                };
                string id = "testdata";
                _userService
                    .Setup(m => m.GetUserById(id))
                    .Throws(new KeyNotFoundException(""));
                IActionResult controllerResult = await _userController.Get(id);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
        }
        #endregion

        #region CreateUser

        [Test]
        public async Task create_ModelStateisvalidornot_Test()
        {
            try
            {
                CreateUserViewModel createUserView = new CreateUserViewModel
                {
                    AlternateEmail = "test@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "test@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true
                };
                UserViewModel userView = new UserViewModel()
                {
                    UserId = "TestData",
                    UserName = "TestUserName",
                    Email = "test@gmail.com",
                    Roles = "testroles",
                    FirstName = "TestName",
                    LastName = "TestLastName",
                    PhoneNumber = "1234567890"
                };
                _userService
                    .Setup(m => m.CreateUser(createUserView))
                    .Returns(Task.FromResult(userView));
                //var result = new List<ValidationResult>();
                //var isValid = Validator.TryValidateProperty("this is test user name", new ValidationContext(new CreateUserViewModel()) {MemberName= "FirstName" }, result);
                var controller = new UserController(_userService.Object);
                controller.ModelState.AddModelError("sessionName", "required");
                //var createUserModel = 
                var result = await controller.Create(createUserView);

                IActionResult controllerResult = await _userController.Create(createUserView);

            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
        }
        #endregion

        #region Update
        [Test]
        public async Task Update_Test()
        {
            UserViewModel userView = new UserViewModel()
            {
                UserId = "asdfg",
                UserName = "TestUserName",
                Email = "test@gmail.com",
                Roles = "testroles",
                FirstName = "TestName",
                LastName = "TestLastName",
                PhoneNumber = "1234567890"
            };
            EditUserViewModel editUserView = new EditUserViewModel()
            {
                UserId = "testdata",
                Email = "test@gmail.com",
                Roles = "testroles",
                FirstName = "TestName",
                LastName = "TestLastName",
                PhoneNumber = "1234567890"
            };
            _userService
                .Setup(m => m.UpdateUser(editUserView))
                .Returns(Task.FromResult(userView));
            IActionResult controllerResult = await _userController.Update(editUserView);
            Assert.IsTrue(controllerResult is OkObjectResult);
        }


        #endregion

        #region ActivateorDeactivateUser
        [Test]
        public async Task ActivateDeActivate_Test()
        {
            string id = "testdata";
            _userService
                .Setup(m => m.ActivateDeActivateUser(id))
                .Returns(Task.FromResult(true));
            IActionResult controllerResult = await _userController.ActivateDeActivate(id);
            Assert.IsTrue(controllerResult is OkObjectResult);
        }
        #endregion

        #region SetUserDefaultApp
        [Test]
        public async Task SetUserDefaultApp_Test()
        {
            string UserId = "tesdata";
            string DefaultApp = "Test";
            _userService
                .Setup(m => m.SetUserDefaultApp(UserId, DefaultApp))
                .Returns(Task.FromResult(true));
            IActionResult controllerResult = await _userController.SetUserDefaultApp(UserId, DefaultApp);
            Assert.IsTrue(controllerResult is OkObjectResult);
        }
        #endregion

        private IList<UserViewModel> GetUserViewModelMockData()
        {
            userViewModels = new List<UserViewModel>();
            userViewModels.Add(new UserViewModel
            {
                UserId = "TestData",
                UserName = "TestUserName",
                Email = "test@gmail.com",
                Roles = "testroles",
                FirstName = "TestName",
                LastName = "TestLastName",
                PhoneNumber = "1234567890"
            });
            return userViewModels;
        }
    }
}
