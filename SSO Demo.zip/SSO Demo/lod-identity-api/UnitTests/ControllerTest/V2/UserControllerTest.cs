﻿using API.Controllers;
using API.Controllers.V2;
using AutoMapper;
using Brierley.Common.Web.Controllers.Response;
using Logic.Interfaces;
using Logic.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using Repository.Models;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using FizzWare.NBuilder;
using System;
using System.Linq;

namespace UnitTests.ControllerTest.V2
{
    [TestFixture]
    internal class UserControllerTest
    {     
        private UserController _userController;
        private Mock<IUserService> _userService;
        private Mock<IEmailService> _emailService;
        private IList<UserViewModel> userViewModels;
        private UserManager<AppUser> _usermanager;
        private Mock<UserManager<AppUser>> _usermanagerMock;
        private Mock<IMapper> _mapper;
        private ClaimsPrincipal _user;
        private CommonResponse _commonResponse;
        private UserViewModel _userViewModel;
        private CreateUserViewModel _createUserViewModel;
        private PasswordSignUpViewModel _passwordSignUpViewModel;
        private CreateUser _createUser;
        private IList<AppUser> _appUser;
        private EditUser _editUser;
        private SearchFilterViewModel _searchFilterViewModel;
        private SearchResultViewModel _searchResultViewModel;
        private UserPreferencesViewModel _userPreferencesViewModel;

        [SetUp]
        public void SetUp()
        {
            _userService = new Mock<IUserService>();
            _mapper = new Mock<IMapper>();
            _emailService=new Mock<IEmailService>();
            _userViewModel = Builder<UserViewModel>.CreateNew().Build();
            _createUserViewModel = Builder<CreateUserViewModel>.CreateNew().Build();
            _createUser = Builder<CreateUser>.CreateNew().Build();
            _appUser = Builder<AppUser>.CreateListOfSize(2).Build().ToList();
            _editUser = Builder<EditUser>.CreateNew().Build();
            _passwordSignUpViewModel = Builder<PasswordSignUpViewModel>.CreateNew().Build();
            _usermanagerMock = Builder<Mock<UserManager<AppUser>>>.CreateNew().Build();
            _commonResponse = Builder<CommonResponse>.CreateNew().Build();
            _searchFilterViewModel = Builder<SearchFilterViewModel>.CreateNew().Build();
            _searchResultViewModel = Builder<SearchResultViewModel>.CreateNew().Build();
            _user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
           {
                new Claim("TenantId", "TenantId1")
           }, "mock"));
            //_usermanager = Builder<UserManager<AppUser>>.CreateNew().Build(); 
            _userController = new UserController(_userService.Object, _usermanager,_mapper.Object, _emailService.Object);
        }

        #region Create
        [Test]
        public async Task Create_Success_Test()
        {            
            _userService.Setup(m => m.CreateUser(_createUserViewModel))
                .Returns(Task.FromResult(_userViewModel));
            IActionResult controllerResult = await _userController.Create(_createUser);
            Assert.IsNotNull(controllerResult);
        }
        #endregion
        #region SignUpComplete
        [Test]
        public async Task SignUpComplete_Success_Test()
        {
            _commonResponse.Data = _passwordSignUpViewModel;
            _userService.Setup(m => m.SignUpComplete(_passwordSignUpViewModel))
                        .Returns(Task.FromResult(_commonResponse));
            IActionResult controllerResult = await _userController.SignUpComplete(_passwordSignUpViewModel);
            Assert.IsNotNull(controllerResult);

        }
        #endregion

        #region UpdateUserExpiredStatus
        [Test]
        public async Task UpdateUserExpiredStatus_Success_Test()
        {
            _userService.Setup(m => m.updateUserStatus("Test"))
                        .Returns(Task.FromResult(true));
            IActionResult controllerResult = await _userController.UpdateUserExpiredStatus("Test");
            Assert.IsNotNull(controllerResult);
        }
        #endregion
        #region SignupExpiryUsers
        [Test]
        public async Task SignupExpiryUsers_Success_Test()
        {
            _commonResponse.Data = _appUser;
            _userService.Setup(m => m.GetSignUpExpiredUsers())
                        .Returns(Task.FromResult(_commonResponse));
            IActionResult controllerResult = await _userController.SignupExpiryUsers( );
            Assert.IsNotNull(controllerResult);
        }
        #endregion
      

        #region SetUserDefaultPreferences
        [Test]
        public async Task SetUserDefaultPreferences_Returns_CommonResponse()
        {
            _commonResponse.Data = true;            
            _userService.Setup(m => m.SetUserDefaultPreferences(_userPreferencesViewModel))
                .Returns(Task.FromResult(_commonResponse));
            IActionResult controllerResult = await _userController.SetUserDefaultPreferences(_userPreferencesViewModel);
            Assert.IsNotNull(controllerResult);
        }
        #endregion
    }
}
