﻿using AutoMapper;
using Brierley.Common.Web.Controllers.Response;
using FizzWare.NBuilder;
using IdentityServer4;
using IdentityServer4.Services;
using Logic.Interfaces;
using Logic.Mappers;
using Logic.Services;
using Logic.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MockQueryable.Moq;
using Moq;
using NUnit.Framework;
using Repository;
using Repository.Interfaces;
using Repository.Models;
using Repository.ViewModels;
using RichardSzalay.MockHttp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace UnitTests.LogicTest
{
    [TestFixture]
    public class UserServiceTest
    {
        private UserService _userService;
        private Mock<IUserRepository> _userRepository;
        private Mock<IMapper> _mapper;
        private Mock<IConfiguration> _configuration;
        private IList<UserViewModel> userViewModels;
        private Mock<ApplicationUserManager<AppUser>> _usermanager;
        private ApplicationUserManager<AppUser> _usermanager1;
        private IList<AppUser> users;
        private HttpClient _httpClient;
        private Mock<IHttpContextAccessor> _httpContextAccessor;
        private IdentityServerTools identityServer;
        private Mock<ITokenCreationService> tokenCreationService;
        private Mock<ISystemClock> clock;
        private Mock<IHttpClientAccessor> _httpClientAccessor;
        private Mock<IEmailService> _emailService;
        private AppUser _appUser;
        private UserPreferencesViewModel _userPreferencesViewModel;
        private CreateUserViewModel _createUserViewModel;
        private UserViewModel _userViewModel;
        private List<UserRole> _userRole;
        private List<UserProgram> _userProgram;

        public class mockUserManager : ApplicationUserManager<AppUser>
        {
            public mockUserManager() : base(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object,
                      new Mock<IUserRepository>().Object,
                      new Mock<ITenantRequestProvider>().Object)
            {

            }

            public override Task<AppUser> FindByEmailAsync(string email)
            {
                return Task.FromResult(new AppUser { Email = email });
            }

            public override Task<IList<string>> GetRolesAsync(AppUser user)
            {

                IList<string> roles = new List<string>();
                roles.Add("Admin");
                roles.Add("Super Admin");
                return Task.FromResult(roles);
            }

            public override Task<bool> IsEmailConfirmedAsync(AppUser user)
            {
                return Task.FromResult(user.Email == "test@test.com");
            }

            public override Task<string> GeneratePasswordResetTokenAsync(AppUser user)
            {
                return Task.FromResult("---------------");
            }
            public override Task<bool> CheckPasswordAsync(AppUser user, string password)
            {
                return Task.FromResult(true);
            }

            public override Task<IdentityResult> UpdateAsync(AppUser user)
            {
                return Task.FromResult(IdentityResult.Success);
            }

            public override Task<IdentityResult> CreateAsync(AppUser user, string password)
            {
                return Task.FromResult(IdentityResult.Success);
            }

            public override Task<IdentityResult> ChangePasswordAsync(AppUser user, string currentPassword, string oldPassword)
            {
                return Task.FromResult(IdentityResult.Success);
            }
        }

        readonly mockUserManager mockUser = new mockUserManager();
        public async Task GetHttpClientObject()
        {
            var mockHttp = new MockHttpMessageHandler();
            mockHttp.When("http://3.135.186.102:31380/communication/")
                    .Respond("application/json", "[{'AttributeSet' : 'ResetPassword_FirstNameLastName,ResetPassword_ResetLink' ,'EmailTemplateId' : 1,'Name' : 'sampleData' }]"); // Respond with JSON
                                                                                                                                                                                  // Inject the handler or client into your application code
            _httpClient = new HttpClient(mockHttp);
            var response = await _httpClient.GetAsync("http://3.135.186.102:31380/communication/communication");
            //var json = await response.Content.ReadAsStringAsync();

        }
        [SetUp]
        public void SetUp()
        {
            _httpContextAccessor = new Mock<IHttpContextAccessor>();
            tokenCreationService = new Mock<ITokenCreationService>();
            _httpClientAccessor = new Mock<IHttpClientAccessor>();
            GetHttpClientObject();
            _userRepository = new Mock<IUserRepository>();
            _mapper = new Mock<IMapper>();
            _usermanager = new Mock<ApplicationUserManager<AppUser>>();
            _configuration = new Mock<IConfiguration>();
            clock = new Mock<ISystemClock>();
            _appUser= Builder<AppUser>.CreateNew().Build();
            _createUserViewModel = Builder<CreateUserViewModel>.CreateNew().Build();
            _userViewModel = Builder<UserViewModel>.CreateNew().Build();
            _userRole = Builder<UserRole>.CreateListOfSize(2).Build().ToList();
            _userProgram = Builder<UserProgram>.CreateListOfSize(2).Build().ToList();
            _userPreferencesViewModel = Builder<UserPreferencesViewModel>.CreateNew().Build();
            _emailService = new Mock<IEmailService>();
            identityServer = new IdentityServerTools(_httpContextAccessor.Object,
                tokenCreationService.Object, clock.Object);
            _userService = new UserService(
                _userRepository.Object,
                _mapper.Object,
                _usermanager1,
                _httpClientAccessor.Object,
                //_configuration.Object,
                //_httpContextAccessor.Object,
                //identityServer,
                _emailService.Object
                );
            userViewModels = GetUserViewModelMockData();
            users = GetUsersMockData();
            var mockMapper = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new LoginProfile());
            });
        }      


        #region ActivateDeactivate
        [Test]
        public async Task ActivateDeactivate_Test()
        {
            string id = "data";
            _userRepository
                .Setup(m => m.ActivateDeActivateUser(id))
                .Returns(Task.FromResult(true));
            bool result = await _userService.ActivateDeActivateUser(id);
            Assert.IsTrue(result);
        }
        #endregion
        #region SetUserDefaultApp
        [Test]
        public async Task SetUserDefaultApp_Test()
        {
            string userId = "tsestadat";
            string DefaultApp = "TestData";
            _userRepository
                .Setup(m => m.SetUserDefaultAppAsync(userId, DefaultApp))
                .Returns(Task.FromResult(true));
            bool userDetails = await _userService.SetUserDefaultApp(userId, DefaultApp);
            Assert.IsTrue(userDetails);
        }
        #endregion
        #region updateUserStatus
        [Test]
        public async Task updateUserStatus_Success_Test()
        {
            string id = "data";
            _userRepository
                .Setup(m => m.updateUserStatus(id))
                .Returns(Task.FromResult(_appUser));
            bool result = await _userService.updateUserStatus(id);
            Assert.IsTrue(result);
        }
        #endregion
        #region GetSignUpExpiredUsers
        [Test]
        public async Task GetSignUpExpiredUsers_Success_Test()
        {            
            string id = "data";
            _userRepository
                .Setup(m => m.GetSignUpExpiredUsers())
                .Returns(Task.FromResult(users));
            CommonResponse result = await _userService.GetSignUpExpiredUsers();
            Assert.IsNotNull(result);
        }
        #endregion

        #region SetUserDefaultPreferences
        [Test]
        public async Task SetUserDefaultPreferences_Success_Test()
        {
            string id = "Test";
            string defaultLang = "en";
            string defaultApp = "Test";
            string defaultView = "Grid";
            _userPreferencesViewModel.UserId = "Test";
            _userPreferencesViewModel.DefaultLanguage = "en";
            _userPreferencesViewModel.DefaultApplication = "Test";
            _userPreferencesViewModel.DefaultListView = "Grid";
            _userRepository
                .Setup(m => m.SetUserDefaultPreferences(id,defaultLang, defaultApp, defaultView))
                .Returns(Task.FromResult(true));
            CommonResponse userDetails = await _userService.SetUserDefaultPreferences(_userPreferencesViewModel);
            Assert.IsNotNull(userDetails);
            Assert.AreEqual(userDetails.Data,true);
            
        }
        #endregion        

        #region CreateUser

        public class IdntResult : IdentityResult
        {
            public IdntResult()
            {
                base.Succeeded = true;
            }
        }

        [Test]
        public async Task CreateUser_Test_Error()
        {
            try
            {
                IdntResult identityResult = new IdntResult();
                List<UserRole> userRoles = new List<UserRole>();
                userRoles.Add(new UserRole()
                {
                    RoleId = 1,
                    RoleName = "testRole"
                });
                List<UserProgram> programs = new List<UserProgram>();
                programs.Add(new UserProgram()
                {
                    ProgramId = 1,
                    ProgramName = "testProgram",
                    UserRoleDetails = userRoles
                });
                CreateUserViewModel createUserViewModel = new CreateUserViewModel()
                {
                    TenantId = "testtenantid",
                    AlternateEmail = "test@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "test@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    UserPrograms = programs
                };
                var dueDate = new DateTime(2011, 3, 3);
                AppUser appUser = new AppUser()
                {
                    TenantId = "testtenantid",
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    PasswordResetTokenExpiration = dueDate.AddYears(100)
                };
                var dueDate1 = new DateTime(2011, 3, 3);
                AppUser appUser1 = new AppUser()
                {
                    TenantId = "testtenantid",
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdatachanged@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf"),
                    PasswordResetTokenExpiration = dueDate1.AddYears(100)
                };
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<ApplicationUserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                                  new Mock<IOptions<IdentityOptions>>().Object,
                                  new Mock<IPasswordHasher<AppUser>>().Object,
                                  new IUserValidator<AppUser>[0],
                                  new IPasswordValidator<AppUser>[0],
                                  new Mock<ILookupNormalizer>().Object,
                                  new Mock<IdentityErrorDescriber>().Object,
                                  new Mock<IServiceProvider>().Object,
                                  new Mock<ILogger<UserManager<AppUser>>>().Object,
                                  new Mock<IUserRepository>().Object,
                                  new Mock<ITenantRequestProvider>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);

                _mapper
              .Setup(m => m.Map<AppUser>(createUserViewModel))
                      .Returns(appUser1);


                _userService = new UserService(
                 _userRepository.Object,
                 _mapper.Object,
                 _usermanager.Object,
                 _httpClientAccessor.Object,
                 //_configuration.Object,
                 //_httpContextAccessor.Object,
                 //identityServer,
                 _emailService.Object
                 );

                UserViewModel userViewModel = await _userService.CreateUser(createUserViewModel);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == "Object reference not set to an instance of an object."); }
        }        
        #endregion

        #region Data
        private AppUser UpdateUser(AppUser _users)
        {
            try
            {
                AppUser users1 = new AppUser();
                users1 = users.Where(x => x.Id == _users.Id).FirstOrDefault();
                if (users1 != null)
                {
                    users1.UserName = _users.UserName;
                    users1.Email = _users.Email;
                }
                return _users;
            }
            catch (Exception ex) { throw ex; }
        }
        private IList<UserViewModel> GetUserViewModelMockData()
        {
            userViewModels = new List<UserViewModel>();
            userViewModels.Add(new UserViewModel
            {
                UserId = "Testdata",
                UserName = "TestUserName",
                Email = "test@gmail.com",
                Roles = "testroles",
                FirstName = "TestName",
                LastName = "TestLastName",
                PhoneNumber = "1234567890"
            });
            return userViewModels;
        }
        private IList<AppUser> GetUsersMockData()
        {
            users = new List<AppUser>();
            users.Add(new AppUser
            {
                Id = "data1",
                UserName = "TestUserName",
                Email = "test@gmail.com",
                PasswordHash = "testpassword",
                Roles = "testroles",
                FirstName = "TestName",
                LastName = "TestLastName",
                PhoneNumber = "1234567890"
            });
            return users;
        }
        #endregion
    }
}