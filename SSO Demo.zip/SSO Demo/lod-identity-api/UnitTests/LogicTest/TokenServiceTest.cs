﻿using IdentityServer4.Models;
using IdentityServer4.ResponseHandling;
using IdentityServer4.Validation;
using Logic.Services;
using Logic.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Moq;
using NUnit.Framework;
using Repository;
using Repository.Interfaces;
using Repository.Models;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace UnitTests.LogicTest
{
    [TestFixture]
    public class TokenServiceTest
    {
        private Mock<ITokenRequestValidator> _requestValidator;
        private Mock<IClientSecretValidator> _clientValidator;
        private Mock<ITokenResponseGenerator> _responseGenerator;
        private Mock<IHttpContextAccessor> _httpContextAccessor;
        private Mock<ApplicationUserManager<AppUser>> _userManager;
        private Mock<ITenantRequestProvider> _tenantRequestProvider;
        private TokenService tokenService;



        public class mockUserManager : ApplicationUserManager<AppUser>
        {
            public mockUserManager() : base(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object,
                      new Mock<IUserRepository>().Object,
                      new Mock<ITenantRequestProvider>().Object)
            {

            }
            public override Task<AppUser> FindByEmailAsync(string email)
            {
                return Task.FromResult(new AppUser { Email = email });
            }
            public override Task<IList<string>> GetRolesAsync(AppUser user)
            {

                IList<string> roles = new List<string>();
                roles.Add("Admin");
                roles.Add("Super Admin");
                return Task.FromResult(roles);
            }


            public override Task<bool> IsEmailConfirmedAsync(AppUser user)
            {
                return Task.FromResult(user.Email == "test@test.com");
            }

            public override Task<string> GeneratePasswordResetTokenAsync(AppUser user)
            {
                return Task.FromResult("---------------");
            }
            public override Task<bool> CheckPasswordAsync(AppUser user, string password)
            {
                return Task.FromResult(true);
            }

            public override Task<IdentityResult> UpdateAsync(AppUser user)
            {
                return Task.FromResult(IdentityResult.Success);
            }

            public override Task<IdentityResult> CreateAsync(AppUser appUser)
            {
                return Task.FromResult(IdentityResult.Success);
            }

            public override IQueryable<AppUser> Users => new List<AppUser>() { new AppUser() {
                Id="testdata",
                Email="testdata@qentelli.com",
                PasswordQueue="TestNewPassword,T"
            } }.AsQueryable();

            public override Task<IdentityResult> ChangePasswordAsync(AppUser user, string currentPassword, string oldPassword)
            {
                return Task.FromResult(IdentityResult.Success);
            }



        }
        mockUserManager mockUser = new mockUserManager();

        #region MockData


        public class FakeClientValidator : IClientSecretValidator
        {
            private readonly IHttpContextAccessor _httpAccessor;

            public FakeClientValidator(IHttpContextAccessor httpAccessor)
            {
                this._httpAccessor = httpAccessor;
            }

            public Task<ClientSecretValidationResult> ValidateAsync(HttpContext context)
            {
                return Task.FromResult(new ClientSecretValidationResult
                {
                    IsError = true,
                    Error = "invalid_client",
                    ErrorDescription = "Invalid client/secret combination"
                });
            }
        }

        public class FakeTokenRequestValidator : ITokenRequestValidator
        {
            private readonly IHttpContextAccessor _httpAccessor;

            public FakeTokenRequestValidator()
            {

            }

            public Task<TokenRequestValidationResult> ValidateRequestAsync(NameValueCollection parameters, ClientSecretValidationResult clientValidationResult)
            {
                Dictionary<string, object> dict = new Dictionary<string, object>();
                return Task.FromResult(new TokenRequestValidationResult(new ValidatedTokenRequest() { })
                {
                    IsError = true,
                    Error = "testerror",
                    ErrorDescription = "testerrordescription",
                    CustomResponse = dict
                });
            }
        }

        public class FakeTokenResponseGenerator : ITokenResponseGenerator
        {
            public Task<IdentityServer4.ResponseHandling.TokenResponse> ProcessAsync(TokenRequestValidationResult validationResult)
            {
                return Task.FromResult(new IdentityServer4.ResponseHandling.TokenResponse
                {
                    AccessToken = "testaccsesstoken",
                    RefreshToken = "testrefreshtoken",
                    AccessTokenLifetime = 100,

                });
            }
        }

        public class FakeTenantRequestProvider : ITenantRequestProvider
        {
            public string GetTenant()
            {
                throw new NotImplementedException();
            }

            public void SetTenant(string tenant)
            {
                tenant = "TenatId"; 
            }
        }

        public class FakeIHttpContextAcessor : IHttpContextAccessor
        {
            public HttpContext HttpContext { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        }

        #endregion


        #region MockData1


        public class FakeClientValidator1 : IClientSecretValidator
        {
            private readonly IHttpContextAccessor _httpAccessor;

            public FakeClientValidator1(IHttpContextAccessor httpAccessor)
            {
                this._httpAccessor = httpAccessor;
            }

            public Task<ClientSecretValidationResult> ValidateAsync(HttpContext context)
            {
                return Task.FromResult(new ClientSecretValidationResult
                {
                    IsError = false,
                    Error = "invalid_client",
                    ErrorDescription = "Invalid client/secret combination"
                });
            }
        }

        public class FakeTokenRequestValidator1 : ITokenRequestValidator
        {
            private readonly IHttpContextAccessor _httpAccessor;

            public FakeTokenRequestValidator1()
            {

            }

            public Task<TokenRequestValidationResult> ValidateRequestAsync(NameValueCollection parameters, ClientSecretValidationResult clientValidationResult)
            {
                Dictionary<string, object> dict = new Dictionary<string, object>();
                return Task.FromResult(new TokenRequestValidationResult(new ValidatedTokenRequest() { })
                {
                    IsError = true,
                    Error = "testerror",
                    ErrorDescription = "testerrordescription",
                    CustomResponse = dict
                });
            }
        }

        public class FakeTokenResponseGenerator1 : ITokenResponseGenerator
        {
            public Task<IdentityServer4.ResponseHandling.TokenResponse> ProcessAsync(TokenRequestValidationResult validationResult)
            {
                return Task.FromResult(new IdentityServer4.ResponseHandling.TokenResponse
                {
                    AccessToken = "testaccsesstoken",
                    RefreshToken = "testrefreshtoken",
                    AccessTokenLifetime = 100,

                });
            }
        }

        public class FakeTenantRequestProvider1 : ITenantRequestProvider
        {
            public string GetTenant()
            {
                throw new NotImplementedException();
            }

            public void SetTenant(string tenant)
            {
                tenant = "mocktenantId";
            }
        }

        public class FakeIHttpContextAcessor1 : IHttpContextAccessor
        {
            public HttpContext HttpContext { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        }

        #endregion


        #region MockData2


        public class FakeClientValidator2 : IClientSecretValidator
        {
            private readonly IHttpContextAccessor _httpAccessor;

            public FakeClientValidator2(IHttpContextAccessor httpAccessor)
            {
                this._httpAccessor = httpAccessor;
            }

            public Task<ClientSecretValidationResult> ValidateAsync(HttpContext context)
            {
                return Task.FromResult(new ClientSecretValidationResult
                {
                    IsError = false,
                    Error = "invalid_client",
                    ErrorDescription = "Invalid client/secret combination"
                });
            }
        }

        public class FakeTokenRequestValidator2 : ITokenRequestValidator
        {
            private readonly IHttpContextAccessor _httpAccessor;

            public FakeTokenRequestValidator2()
            {

            }

            public Task<TokenRequestValidationResult> ValidateRequestAsync(NameValueCollection parameters, ClientSecretValidationResult clientValidationResult)
            {
                Dictionary<string, object> dict = new Dictionary<string, object>();
                return Task.FromResult(new TokenRequestValidationResult(new ValidatedTokenRequest() { })
                {
                    IsError = false,
                    Error = "testerror",
                    ErrorDescription = "testerrordescription",
                    CustomResponse = dict
                });
            }
        }

        public class FakeTokenResponseGenerator2 : ITokenResponseGenerator
        {
            public Task<IdentityServer4.ResponseHandling.TokenResponse> ProcessAsync(TokenRequestValidationResult validationResult)
            {
                return Task.FromResult(new IdentityServer4.ResponseHandling.TokenResponse
                {
                    AccessToken = "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJJU1MiLCJzY29wZSI6Imh0dHBzOi8vbGFyaW0uZG5zY2UuZG91YW5lL2NpZWxzZXJ2aWNlL3dzIiwiYXVkIjoiaHR0cHM6Ly9kb3VhbmUuZmluYW5jZXMuZ291di5mci9vYXV0aDIvdjEiLCJpYXQiOiJcL0RhdGUoMTQ2ODM2MjU5Mzc4NClcLyJ9",
                    RefreshToken = "testrefreshtoken",
                    AccessTokenLifetime = 100,

                });
            }
        }

        public class FakeTenantRequestProvider2 : ITenantRequestProvider
        {
            public string GetTenant()
            {
                throw new NotImplementedException();
            }

            public void SetTenant(string tenant)
            {
                tenant = "mocktenantId";
            }
        }

        public class FakeIHttpContextAcessor2 : IHttpContextAccessor
        {
            public HttpContext HttpContext { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        }

        public virtual SecurityToken ReadToken(string token)
        {
            var stream =
            "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJJU1MiLCJzY29wZSI6Imh0dHBzOi8vbGFyaW0uZG5zY2UuZG91YW5lL2NpZWxzZXJ2aWNlL3dzIiwiYXVkIjoiaHR0cHM6Ly9kb3VhbmUuZmluYW5jZXMuZ291di5mci9vYXV0aDIvdjEiLCJpYXQiOiJcL0RhdGUoMTQ2ODM2MjU5Mzc4NClcLyJ9";
            var handler = new JwtSecurityTokenHandler();

            var jsonToken = handler.ReadToken(stream);
            return jsonToken;
        }

        #endregion



        //public class FakeHttpContextAccessor : IHttpContextAccessor

        [SetUp]
        public void SetUp()
        {
            _clientValidator = new Mock<IClientSecretValidator>();
            _responseGenerator = new Mock<ITokenResponseGenerator>();
            _httpContextAccessor = new Mock<IHttpContextAccessor>();
            _requestValidator = new Mock<ITokenRequestValidator>();
            _tenantRequestProvider = new Mock<ITenantRequestProvider>();
            tokenService = new TokenService(new FakeTokenRequestValidator(), new FakeClientValidator(new FakeIHttpContextAcessor()), new FakeTokenResponseGenerator(), _httpContextAccessor.Object, mockUser ,new FakeTenantRequestProvider());
        }



        [Test]
        public async Task GetToken_Test_ReturnsSucessfully1()
        {
            try
            {
                TokenRequest tokenRequest = new TokenRequest()
                {
                    ClientId = "2",
                    ClientSecret = "testclientsecret",
                    GrantType = "testgranttype",
                    Password = "testpassword",
                    RefreshToken = "testrefreshtoken",
                    Scope = "testscope",
                    Username = "TestUserName",
                    TenantId="asdfghjk"
                  
                };


                var token = await tokenService.GetToken(tokenRequest);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
        }

        [Test]
        public async Task GetToken_AnotherTest_ReturnsSucessfully2()
        {
            try
            {
                TokenRequest tokenRequest = new TokenRequest()
                {
                    ClientId = "2",
                    ClientSecret = "testclientsecret",
                    GrantType = "testgranttype",
                    Password = "testpassword",
                    RefreshToken = "testrefreshtoken",
                    Scope = "testscope",
                    Username = "TestUserName"
                };
                tokenService = new TokenService(new FakeTokenRequestValidator1(), new FakeClientValidator1(new FakeIHttpContextAcessor()), new FakeTokenResponseGenerator1(), _httpContextAccessor.Object, mockUser,new FakeTenantRequestProvider1());

                var token = await tokenService.GetToken(tokenRequest);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == ""); }
        }


        [Test]
        public async Task GetToken_AnotherTest_ReturnsSucessfully3()
        {
            try
            {
                TokenRequest tokenRequest = new TokenRequest()
                {
                    ClientId = "2",
                    ClientSecret = "testclientsecret",
                    GrantType = "testgranttype",
                    Password = "testpassword",
                    RefreshToken = "testrefreshtoken",
                    Scope = "testscope",
                    Username = "TestUserName"
                };
                tokenService = new TokenService(new FakeTokenRequestValidator2(), new FakeClientValidator2(new FakeIHttpContextAcessor()), new FakeTokenResponseGenerator2(), _httpContextAccessor.Object, mockUser,new FakeTenantRequestProvider2());

                var token = await tokenService.GetToken(tokenRequest);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message.Contains("IDX12709: CanReadToken() returned false. JWT is not well formed:")); }
        }

        #region NotImplementedMethods
        [Test]
        public async Task CreateIdentityTokenAsync_Test()
        {
            try
            {
                TokenCreationRequest tokenCreationRequest = new TokenCreationRequest();
                var result = tokenService.CreateAccessTokenAsync(tokenCreationRequest);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex.Message == "The method or operation is not implemented.");
            }
        }

        [Test]
        public async Task CreateAccessTokenAsync_Test()
        {
            try
            {
                TokenCreationRequest tokenCreationRequest = new TokenCreationRequest();
                var result = tokenService.CreateAccessTokenAsync(tokenCreationRequest);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex.Message == "The method or operation is not implemented.");
            }
        }

        [Test]
        public async Task CreateSecurityTokenAsync_Test()
        {
            try
            {
                Token token = new Token();
                var result = tokenService.CreateSecurityTokenAsync(token);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex.Message == "The method or operation is not implemented.");
            }
        }
        #endregion
    }


}