﻿using Logic.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;
using Repository.Models;
using RichardSzalay.MockHttp;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace UnitTests.LogicTest
{
    [TestFixture]
    public class EmailServiceTest
    {
        private EmailService _emailService;
        private HttpClient _httpClient;
        public Mock<IConfiguration> configuration;
        public Mock<IHttpContextAccessor> _httpContextAccessor;

        [SetUp]
        public void SetUp()
        {

            configuration = new Mock<IConfiguration>();
            _httpContextAccessor = new Mock<IHttpContextAccessor>();
            GetHttpClientObject();
            _emailService = new EmailService(configuration.Object, _httpClient, _httpContextAccessor.Object);
            //_emailConfiguration = new EmailConfiguration();

        }

        public async Task GetHttpClientObject()
        {

            var mockHttp = new MockHttpMessageHandler();
            mockHttp.When("http://3.135.186.102:31380/communication/")
                    .Respond("application/json", "[{'AttributeSet' : 'ResetPassword_FirstNameLastName,ResetPassword_ResetLink' ,'EmailTemplateId' : 1,'Name' : 'sampleData' }]"); // Respond with JSON
                                                                                                                                                                                  // Inject the handler or client into your application code
            _httpClient = new HttpClient(mockHttp);
            var response = await _httpClient.GetAsync("http://3.135.186.102:31380/communication/communication");
            //var json = await response.Content.ReadAsStringAsync();

        }

        #region SendEmail
        [Test]
        public async Task SendEmail_SucessfulTest()
        {
            bool result = true;
            try
            {
                AppUser user = new AppUser();
                user.FirstName = "TestFirst";
                user.Email = "test@abc.com";
                user.PasswordResetToken = Guid.Parse("f52d452e-a760-44fa-ac20-7e4950a75fdf");
                //configuration
                Environment.SetEnvironmentVariable("CommunicationAPI_BaseURL", "http://3.135.186.102:31380/communication/");
                await _emailService.SendEmail(user,"BRIERLEY");
            }
            catch (Exception ex)
            {
                result = false;
            }
            Assert.IsTrue(result);

        }
        #endregion
    }
}