﻿using AutoMapper;
using Logic.Services;
using Logic.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MockQueryable.Moq;
using Moq;
using NUnit.Framework;
using Repository.Models;
using Repository.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UnitTests.LogicTest
{
    [TestFixture]
    public class LoginServiceTest
    {
        private LoginService _loginService;
        private Mock<IMapper> _mapper;
        private Mock<UserManager<AppUser>> _usermanager;
        private Mock<IQueryableUserStore<AppUser>> _queryableUserStore;

        public class mockUserManager : UserManager<AppUser>
        {
            public mockUserManager() : base(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object)
            {

            }
            public override Task<AppUser> FindByEmailAsync(string email)
            {
                return Task.FromResult(new AppUser { Email = email });
            }
            public override Task<IList<string>> GetRolesAsync(AppUser user)
            {

                IList<string> roles = new List<string>();
                roles.Add("Admin");
                roles.Add("Super Admin");
                return Task.FromResult(roles);
            }


            public override Task<bool> IsEmailConfirmedAsync(AppUser user)
            {
                return Task.FromResult(user.Email == "test@test.com");
            }

            public override Task<string> GeneratePasswordResetTokenAsync(AppUser user)
            {
                return Task.FromResult("---------------");
            }
            public override Task<bool> CheckPasswordAsync(AppUser user, string password)
            {
                return Task.FromResult(true);
            }

            public override Task<IdentityResult> UpdateAsync(AppUser user)
            {
                return Task.FromResult(IdentityResult.Success);
            }

            public override Task<IdentityResult> CreateAsync(AppUser appUser)
            {
                return Task.FromResult(IdentityResult.Success);
            }

            public override IQueryable<AppUser> Users => new List<AppUser>() { new AppUser() {
                 Id="testdata",
                 Email="testdata@qentelli.com",
                 PasswordQueue="TestNewPassword,T"
             } }.AsQueryable();

            public override Task<IdentityResult> ChangePasswordAsync(AppUser user, string currentPassword, string oldPassword)
            {
                return Task.FromResult(IdentityResult.Success);
            }



        }

        readonly mockUserManager mockUser = new mockUserManager();

        [SetUp]
        public void SetUp()
        {
            _mapper = new Mock<IMapper>();
            _usermanager = new Mock<UserManager<AppUser>>();
            _loginService = new LoginService(mockUser, _mapper.Object);
            _queryableUserStore = new Mock<IQueryableUserStore<AppUser>>();
        }

        #region UpdatePassword
        [Test]
        public async Task UpdatePasswordAsnyc_Test()
        {
            try
            {
                UserViewModels userView = new UserViewModels()
                {
                    UserId = "testdata",
                    OldPassword = "TestPassWord",
                    NewPassword = "TestNewPasswordChanged"
                };
                UserDto UserDto = new UserDto()
                {
                    UserId = "testdata1",
                    UserName = "TestName",
                    OldPassword = "TestPassWord",
                    NewPassword = "TestNewPassword"
                };
                AppUser appUser = new AppUser()
                {
                    AlternateEmail = "testdata@gmail.com",
                    CreatedBy = "tester",
                    CreatedDate = DateTime.Now,
                    DefaultApp = "tesdefaultapp",
                    Email = "testdata@gmail.com",
                    ExternalId = "123",
                    FirstName = "tester",
                    LastName = "user",
                    PasswordHash = "12345678",
                    PhoneNumber = "2134567890",
                    Roles = "admin",
                    Status = true,
                    Id = "testdata",
                    PasswordQueue = "SGhhTnZ6VHNWWXdTL5gvemJRWGxNH0UzRVRNWFFnbGxxckRhSlk5IEQvVT3Cig==,VGVzdE5ld1Arc3M3b2Jk"
                };

                _mapper
               .Setup(m => m.Map<UserDto>(userView))
               .Returns(UserDto);
                var dd = new List<AppUser>();
                dd.Add(appUser);
                IQueryable<AppUser> queryableUsers = dd.AsQueryable();

                var mock1 = dd.AsQueryable().BuildMock();
                _usermanager = new Mock<UserManager<AppUser>>(new Mock<IUserStore<AppUser>>().Object,
                      new Mock<IOptions<IdentityOptions>>().Object,
                      new Mock<IPasswordHasher<AppUser>>().Object,
                      new IUserValidator<AppUser>[0],
                      new IPasswordValidator<AppUser>[0],
                      new Mock<ILookupNormalizer>().Object,
                      new Mock<IdentityErrorDescriber>().Object,
                      new Mock<IServiceProvider>().Object,
                      new Mock<ILogger<UserManager<AppUser>>>().Object);
                _usermanager.Setup(x => x.Users).Returns(mock1.Object);

                _usermanager.Setup(x => x.UpdateAsync(appUser)).Returns(Task.FromResult(IdentityResult.Success));

                _loginService = new LoginService(_usermanager.Object, _mapper.Object);





                var result = await _loginService.UpdatePasswordAsync(userView);
                Assert.IsTrue(result is true);
            }
            catch (Exception ex) { Assert.IsTrue(ex.Message == "Object reference not set to an instance of an object."); }

        }

        #endregion

    }
}