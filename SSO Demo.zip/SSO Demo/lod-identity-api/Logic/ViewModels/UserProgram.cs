﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.ViewModels
{
    public class UserProgram
    {
        public int? ProgramId { get; set; }
        public string ProgramName { get; set; }
        public IList<UserRole> UserRoleDetails { get; set; }
    }

    public class UserRole
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
