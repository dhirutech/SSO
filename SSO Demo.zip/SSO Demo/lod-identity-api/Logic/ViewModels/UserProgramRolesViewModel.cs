﻿namespace Logic.ViewModels
{
    public class UserProgramRolesViewModel
    {
        public int? ProgramId { get; set; }
        public string ProgramName { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
