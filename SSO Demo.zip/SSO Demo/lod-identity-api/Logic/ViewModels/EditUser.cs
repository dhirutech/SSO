﻿using DataAnnotationsExtensions;
using System.Collections.Generic;

namespace Logic.ViewModels
{
    public class EditUser
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public string TenantId { get; set; }
        [Email]
        public string Email { get; set; }
        public string Roles { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AlternateEmail { get; set; }
        public string PhoneNumber { get; set; }
        public string ExternalId { get; set; }
        public bool Status { get; set; }
        public string DefaultApp { get; set; }
        public bool IsProfileComplete { get; set; }
        public List<UserProgram> UserPrograms { get; set; }
    }
}
