﻿namespace Logic.ViewModels
{
    public class UserStatusViewModel
    {
        public int UserStatusId { get; set; }
        public string StatusName { get; set; }
        public string StatusDesciption { get; set; }
    }
}
