﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Logic.ViewModels
{
    public class UserViewModel
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string TenantId { get; set; }
        public string Email { get; set; }
        public string Roles { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AlternateEmail { get; set; }
        public string PhoneNumber { get; set; }
        public string ExternalId { get; set; }
        public string DefaultApp { get; set; }
        public bool Status { get; set; }
        public DateTimeOffset? LastLoginTime { get; set; }
        public List<UserProgram> UserPrograms { get; set; }

        [JsonIgnore]
        public DateTime CreatedDate { get; set; }
        [JsonIgnore]
        public string CreatedBy { get; set; }
        [JsonIgnore]
        public DateTime UpdatedDate { get; set; }
        [JsonIgnore]
        public string UpdatedBy { get; set; }
        public UserAccountPreference UserAccountPreference { get; set; }
    }
}
