﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.ViewModels
{
    public class UserRoleMapRequest
    {
        public Guid UserGuidId { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public bool UserStatus { get; set; }
        public List<UserProgram> UserPrograms { get; set; }
    }

    public class RbacUser
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
    }

    public class RbacUserRoleProgram
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public int? RoleId { get; set; }
        public string RoleName { get; set; }
        public int? ProgramId { get; set; }
    }
}
