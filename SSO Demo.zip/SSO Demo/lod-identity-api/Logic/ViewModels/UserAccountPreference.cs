﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.ViewModels
{
  public  class UserAccountPreference
    {
        public string DefaultApplication { get; set; }
        public string DefaultLanguage { get; set; }
        public string DefaultListView { get; set; }
    }
}
