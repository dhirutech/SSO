﻿using DataAnnotationsExtensions;
using System;
using System.Text.Json.Serialization;

namespace Logic.ViewModels
{
    public class EditUserViewModel
    {
        public string UserId { get; set; }
        public string TenantId { get; set; }
        [Email]
        public string Email { get; set; }
        public virtual string CurrentPassword { get; set; }
        public virtual string PasswordHash { get; set; }
        public string Roles { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AlternateEmail { get; set; }
        public DateTimeOffset? LastLoginTime { get; set; }
        public string PhoneNumber { get; set; }
        public string ExternalId { get; set; }
        public bool Status { get; set; }
        [JsonIgnore]
        public DateTime CreatedDate { get; set; }
        [JsonIgnore]
        public string CreatedBy { get; set; }
        [JsonIgnore]
        public DateTime UpdatedDate { get; set; }
        [JsonIgnore]
        public string UpdatedBy { get; set; }
        public UserStatusViewModel UserStatus { get; set; }
    }

    public class UserDetailsByIds
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string TenantId { get; set; }
        public string AlternateEmail { get; set; }
        public string Roles { get; set; }
        public string ExternalId { get; set; }       
    }
}
