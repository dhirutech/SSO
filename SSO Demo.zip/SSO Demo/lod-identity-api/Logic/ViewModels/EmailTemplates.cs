﻿using System.Collections.Generic;

namespace Logic.ViewModels
{
    public class EmailTemplates
    {
        public int? EmailTemplateId { get; set; }
        public IList<string> ToList { get; set; }
        public IDictionary<string, string> EmailParameters { get; set; }
    }
    public class EmailAttributeSet
    {
        public int? EmailTemplateId { get; set; }
        public string AttributeSet { get; set; }
        public string Name { get; set; }
    }
}
