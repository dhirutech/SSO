﻿

// namespace Logic.ViewModels
// {
//     public class AuthorizationRequest
//     {
//         [FromForm(Name = "code_challenge")]
// 		public string CodeChallenge {get; set;}

// 		[FromForm(Name = "code_challenge_method")]


// 		[FromForm(Name = "scope")]


// 		[FromForm(Name = "response_type")]


// 		[FromForm(Name = "client_id")]


// 		[FromForm(Name = "aud")]

//     }
// }
