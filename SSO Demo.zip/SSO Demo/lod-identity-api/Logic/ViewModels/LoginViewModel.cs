﻿using Microsoft.AspNetCore.Authentication;
using System.Collections.Generic;

namespace Logic.ViewModels
{
    public class LoginViewModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Tenant { get; set;}
        public string ReturnUrl { get; set; }
    }
}