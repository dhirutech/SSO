﻿using DataAnnotationsExtensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Logic.ViewModels
{
    public class CreateUserViewModel
    {
        public string UserId { get; set; } = Guid.NewGuid().ToString();
        public string UserName { get; set; } = String.Empty;
        public string TenantId {get; set;}
        [Email]
        public string Email { get; set; }
        public virtual string PasswordHash { get; set; }
        public string Roles { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AlternateEmail { get; set; }
        public string PhoneNumber { get; set; }
        public string ExternalId { get; set; }
        public string DefaultApp { get; set; }
        public bool Status { get; set; }
        [JsonIgnore]
        public DateTime CreatedDate { get; set; }
        [JsonIgnore]
        public string CreatedBy { get; set; }
        [JsonIgnore]
        public DateTime UpdatedDate { get; set; }
        [JsonIgnore]
        public string UpdatedBy { get; set; }
        public bool IsProfileComplete { get; set; } = false;
        public List<UserProgram> UserPrograms { get; set; }
    }
}
