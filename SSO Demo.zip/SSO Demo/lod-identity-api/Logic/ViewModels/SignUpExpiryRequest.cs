﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Logic.ViewModels
{
    public class SignUpExpiryRequest
    {
        [Required]
        public IList<string> ExpiredUsers { get; set; }
        [Required]
        public IList<string> Administrators { get; set; }
        [Required]
        public string TenantId { get; set; }
    }
}
