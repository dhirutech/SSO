﻿using Microsoft.AspNetCore.Mvc;

namespace Logic.ViewModels
{
    public class TokenRequest
    {
        [FromForm(Name = "uname")]
        public string Username { get; set; }
        [FromForm(Name = "pwd")]
        public string Password { get; set; }
        [FromForm(Name = "grant_type")]
        public string GrantType { get; set; }
        [FromForm(Name = "scope")]
        public string Scope { get; set; }
        [FromForm(Name = "refresh_token")]
        public string RefreshToken { get; set; }
        [FromForm(Name = "client_id")]
        public string ClientId { get; set; }

        [FromForm(Name = "client_secret")]
        public string ClientSecret { get; set; }

        [FromForm(Name = "tenant")]
        public string TenantId { get; set; }
    }
}
