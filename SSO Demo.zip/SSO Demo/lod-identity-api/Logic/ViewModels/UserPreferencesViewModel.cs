﻿namespace Logic.ViewModels
{
    public class UserPreferencesViewModel
    {
        public string DefaultApplication { get; set; }
        public string DefaultLanguage { get; set; }
        public string DefaultListView { get; set; }
        public string UserId { get; set; }

    }
    public class UserId
    {
        public string UserIds { get; set; }
    }
}
