﻿using System;

namespace Logic.ViewModels
{
    public class SearchFilterViewModel
    {
        public string SearchText { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
        public string NameSortType { get; set; }
        public string EmailSortType { get; set; }
        public string ExternalIdSortType { get; set; }
        public string StatusSortType { get; set; }
        public string TenantId { get; set; }
        public DateTimeOffset? FromDate { get; set; } = null;
        public DateTimeOffset? ToDate { get; set; } = null;
        public int ProgramId { get; set; } = 0;
        public int RoleId { get; set; } = 0;
        public string Status { get; set; } = null;
    }
    public class SearchTypeHeadViewModel
    {
        public string SearchText { get; set; }
    }
}
