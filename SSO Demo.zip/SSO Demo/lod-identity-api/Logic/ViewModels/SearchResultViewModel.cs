﻿using System;
using System.Collections.Generic;

namespace Logic.ViewModels
{
    public class SearchResultViewModel
    {
        public List<UserResultViewModel> UsersSearchResult { get; set; }
        public int UserCount { get; set; }
    }

    public class UserResultViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Roles { get; set; }
        public string PhoneNumber { get; set; }
        public string ExternalId { get; set; }
        public string TenantId { get; set; }
        public DateTimeOffset? LastLoginTime { get; set; }
        public DateTime CreatedDate { get; set; }
        public UserStatusViewModel UserStatus { get; set; }
        public bool Active { get; set; }
        //public IList<UserProgramRolesViewModel> UserRoles { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AlternateEmail { get; set; }
        public string UserName { get; set; }
        public string DefaultApp { get; set; }
        public bool Status { get; set; }
        public List<UserProgram> UserPrograms { get; set; }
        public string CreatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
    }
}