﻿using System.Collections.Generic;

namespace Logic.ViewModels
{
    public class ForgotPasswordRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ResetPasswordLink { get; set; }
        public string TenantId { get; set; }
        public IList<string> ToList { get; set; }
    }
}