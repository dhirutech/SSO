﻿using System.ComponentModel.DataAnnotations;

namespace Logic.ViewModels
{
    public class UserViewModels
    {
        public string UserId { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
    }

    public class UserDetails
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
    }
    public class PasswordSignUpViewModel
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ExternalId { get; set; }
        public string PhoneNumber { get; set; }
        public string Password { get; set; }
    }
    public class SignUpInviteRequest
    {
        [Url]
        [Required]
        public string SignUpLink { get; set; }
        [EmailAddress]
        [Required]
        public string UserEmail { get; set; }
    }
}