﻿using DataAnnotationsExtensions;
using Newtonsoft.Json;
using Repository.ExtensionMethods;
using System;

namespace Logic.ViewModels
{
    public class CreateUser:CreateUserViewModel
    {
        [JsonIgnore]
        public override string PasswordHash => string.Format("Q2lwaGVyQDI1Ng==").ToDecrypt();
    }
}
