﻿using IdentityServer4.Models;
using System.Threading.Tasks;

namespace Logic.Interfaces
{
    public interface ITokenService
    {
        Task<ViewModels.TokenResponse> GetToken(ViewModels.TokenRequest request);
        Task<ViewModels.TokenResponse> GetTokenEx(TokenCreationRequest request);
    }
}
