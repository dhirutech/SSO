using Logic.ViewModels;
using Repository.Models;
using System.Threading.Tasks;

namespace Logic.Interfaces
{
    public interface IEmailService
    {
        Task SendEmail(AppUser user,string tenantId);
        Task UserSignUpEmail(AppUser user);
    }
}
