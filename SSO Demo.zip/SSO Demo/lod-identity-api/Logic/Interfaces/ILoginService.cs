﻿using Brierley.Common.Web.Controllers.Response;
using Logic.ViewModels;
using System;
using System.Threading.Tasks;

namespace Logic.Interfaces
{
    public interface ILoginService
    {
        Task<bool> UpdatePasswordAsync(UserViewModels credentials);
        Task<CommonResponse> ValidateSignUpToken(string userName, Guid signUpToken);
    }
}
