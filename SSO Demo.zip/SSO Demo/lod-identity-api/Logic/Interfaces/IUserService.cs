﻿using Brierley.Common.Web.Controllers.Response;
using Logic.ViewModels;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Logic.Interfaces
{
    public interface IUserService:IDisposable
    {
        Task<SearchResultViewModel> SearchUsers(SearchFilterViewModel searchFilter);
        Task<UserViewModel> GetUserById(string id);
        Task<UserViewModel> UpdateUser(EditUserViewModel users);
        Task<bool> ActivateDeActivateUser(string userId);
        Task<bool> SetUserDefaultApp(string userId, string defaultApp);
        Task<UserViewModel> CreateUser(CreateUserViewModel user);
        Task<CommonResponse> SignUpComplete(PasswordSignUpViewModel passwordSignUpViewModel);
        Task<bool> updateUserStatus(string userId);
        Task<CommonResponse> GetSignUpExpiredUsers();
        Task<bool> UserRoleMap(UserRoleMapRequest reqObj);
        Task<CommonResponse> SetUserDefaultPreferences(UserPreferencesViewModel userPreference);
        Task<CommonResponse> GetUserDetailsByUserIds(List<string> userIds);

    }
}
