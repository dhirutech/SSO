﻿using System.Threading.Tasks;

namespace Logic.Interfaces
{
    public interface IHttpClientAccessor
    {
        Task<Tr> GetAsync<Tr>(string url);
        Task<Tr> PostAsync<Tq, Tr>(string url, Tq req);
        Task<Tr> PutAsync<Tq, Tr>(string url, Tq req);
        Task<Tr> DeleteAsync<Tr>(string url);
    }
}