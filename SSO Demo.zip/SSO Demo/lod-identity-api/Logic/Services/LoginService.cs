﻿using AutoMapper;
using Brierley.Common.Web.Controllers.Response;
using Logic.Interfaces;
using Logic.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Repository.CustomExceptions;
using Repository.ExtensionMethods;
using Repository.Models;
using Repository.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Logic.Services
{
    public class LoginService : ILoginService
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly IMapper mapper;
        public LoginService(UserManager<AppUser> userManager, IMapper mapper)
        {
            _userManager = userManager;
            this.mapper = mapper;
        }

        public async Task<bool> UpdatePasswordAsync(UserViewModels credentials)
        {
            var getUser = await _userManager.Users.FirstOrDefaultAsync(x => x.Id == credentials.UserId);

            if (!string.IsNullOrEmpty(credentials.NewPassword) &&
                getUser.PasswordQueue.Split(',')
                    .Any(x => x.ToDecrypt()
                        .Equals(credentials.NewPassword)))
            {
                throw new PasswordAlreadyUsedException("This is one of the last 3 passwords");
            }

            getUser.PasswordHash = _userManager.PasswordHasher.HashPassword(getUser, credentials.NewPassword);

            Queue<string> pQ = new Queue<string>(getUser.PasswordQueue.Split(',').Take(3));
            if (!string.IsNullOrEmpty(credentials.NewPassword) && !pQ.Contains(null) && pQ.Count >= 3)
            {
                pQ.Dequeue();
            }

            if (!string.IsNullOrEmpty(credentials.NewPassword))
            {
                pQ.Enqueue(credentials.NewPassword.ToEncrypt());
                getUser.PasswordQueue = string.Empty;
                for (int i = 0; i < pQ.Count; i++)
                {
                    getUser.PasswordQueue =
                        i == 0 ? $"{pQ.ToArray()[i]}" : $"{getUser.PasswordQueue},{pQ.ToArray()[i]}";
                }
            }

            getUser.LockoutEnd = null;
            getUser.AccessFailedCount = 0;
            var result = await _userManager.UpdateAsync(getUser);
            await _userManager.ResetAccessFailedCountAsync(getUser);
            return result.Succeeded;
        }

        public async Task<CommonResponse> ValidateSignUpToken(string userName, Guid signUpToken)
        {
            var user = await _userManager.Users.Where(x => x.UserName.ToLower() == userName.ToLower()
            && x.PasswordSignUpToken.Equals(signUpToken)).FirstOrDefaultAsync();
            if (user == null)
            {
                return new CommonResponse
                {
                    IsError = true,
                    DeveloperMessage = "User Not Found",
                    HttpStatusCode = StatusCodes.Status204NoContent,
                    UserMessage = $"{ userName } does not exist"
                };
            }
            if (user.UserStatusId != UserStatuses.PendingSignup || user.PasswordSignUpTokenEndTime.HasValue
                && DateTimeOffset.Now > user.PasswordSignUpTokenEndTime)
            {
                return new CommonResponse
                {
                    IsError = true,
                    HttpStatusCode = StatusCodes.Status412PreconditionFailed,
                    DeveloperMessage = "Reset time expired",
                    UserMessage = "Invalid token, expired"
                };
            }
            var userDetails = mapper.Map<UserViewModel>(user);
            var response = new CommonResponse
            {
                Data = userDetails,
                HttpStatusCode = StatusCodes.Status200OK
            };
            return response;
        }
    }
}