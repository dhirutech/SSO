﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Threading.Tasks;
using IdentityModel;
using IdentityServer4;
using IdentityServer4.Configuration;
using IdentityServer4.Models;
using IdentityServer4.ResponseHandling;
using IdentityServer4.Stores;
//using IdentityServer4.Services;
using IdentityServer4.Validation;
using Logic.Interfaces;
using Logic.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Repository;
using Repository.Interfaces;
using Repository.Models;
using IdpTokenResponse = IdentityServer4.ResponseHandling.TokenResponse;
using TokenResponse = Logic.ViewModels.TokenResponse;

namespace Logic.Services
{
    public class TokenService : ITokenService
    {
        private readonly ITokenRequestValidator _requestValidator;
        private readonly IClientSecretValidator _clientValidator;
        private readonly ITokenResponseGenerator _responseGenerator;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationUserManager<AppUser> _userManager;
        private readonly ITenantRequestProvider _tenantProvider;
        IdentityServer4.Services.ITokenService _defaultTokenService;
        IdentityServer4.Services.IRefreshTokenService _refreshTokenService;
        // protected readonly IdentityServer4.Services.IClaimsService _claimsProvider;
        //protected readonly ISystemClock _clock;
        //IdentityServerOptions _options;
        //protected readonly IReferenceTokenStore _referenceTokenStore;
        //protected readonly IdentityServer4.Services.ITokenCreationService _creationService;

        public TokenService(
          ITokenRequestValidator requestValidator,
          IClientSecretValidator clientValidator,
          ITokenResponseGenerator responseGenerator,
          IHttpContextAccessor httpContextAccessor, 
          ApplicationUserManager<AppUser> userManager,
          ITenantRequestProvider tenantProvider,
          IdentityServer4.Services.ITokenService defaultTokenService, 
          IdentityServer4.Services.IRefreshTokenService refreshTokenService
          //IdentityServer4.Services.IClaimsService claimsProvider,
          //ISystemClock clock,
          //IdentityServerOptions options,
          //IReferenceTokenStore referenceTokenStore,
          //IdentityServer4.Services.ITokenCreationService creationService
          )
        {
            _requestValidator = requestValidator;
            _clientValidator = clientValidator;
            _responseGenerator = responseGenerator;
            _httpContextAccessor = httpContextAccessor;
            _userManager = userManager;
            _tenantProvider = tenantProvider;
            _defaultTokenService = defaultTokenService;
            _refreshTokenService = refreshTokenService;
            // _claimsProvider = claimsProvider;
            //_clock = clock;
            //_options = options;
            //_referenceTokenStore = referenceTokenStore;
            //_creationService = creationService;
        }

        public async Task<TokenResponse> GetToken(TokenRequest request)
        {
            var parameters = new NameValueCollection
              {
                { "username", request.Username },
                { "password", request.Password },
                { "grant_type", request.GrantType },
                { "scope", request.Scope },
                { "refresh_token", request.RefreshToken },
                { "tenant", request.TenantId },
                { "client_id", request.ClientId },
                { "client_secret", request.ClientSecret },
                { "response_type", OidcConstants.ResponseTypes.Token }
              };

            _tenantProvider.SetTenant(request.TenantId);

            var response = await GetIdpToken(parameters);

            var tokenResponse= GetTokenResponse(response);
            
            if(!string.IsNullOrEmpty(response.AccessToken))
                tokenResponse.DefaultApp = GetDefaultApp(tokenResponse.AccessToken);
            
            return tokenResponse;
        }

        private async Task<IdpTokenResponse> GetIdpToken(NameValueCollection parameters)
        {
            var clientResult = await _clientValidator.ValidateAsync(_httpContextAccessor.HttpContext);

            

            if (clientResult.IsError)
            {
                return new IdpTokenResponse
                {
                    Custom = new Dictionary<string, object>
					{
						{ "Error", "invalid_client" },
						{ "ErrorDescription", "Invalid client/secret combination" }
					}
                };
            }

            var validationResult = await _requestValidator.ValidateRequestAsync(parameters, clientResult);

            if (validationResult.IsError)
            {
                return new IdpTokenResponse
                {
                    Custom = new Dictionary<string, object>
                    {
                      { "Error", validationResult.Error },
                      { "ErrorDescription", validationResult.ErrorDescription }
                    }
                };
            }

            return await _responseGenerator.ProcessAsync(validationResult);
        }

        private static TokenResponse GetTokenResponse(IdpTokenResponse response)
        {
            if (response.Custom != null && response.Custom.ContainsKey("Error"))
            {
                return new TokenResponse
                {
                    Error = response.Custom["Error"].ToString(),
                    ErrorDescription = response.Custom["ErrorDescription"]?.ToString()
                };
            }

            var token= new TokenResponse
            {
                AccessToken = response.AccessToken,
                RefreshToken = response.RefreshToken,
                ExpiresIn = response.AccessTokenLifetime,
                TokenType = "Bearer",
            };
            return token;
        }

        private string GetDefaultApp(string token)
        {
            string defaultApp=string.Empty;
            var stream = token;
            var handler = new JwtSecurityTokenHandler();
            handler.ReadToken(stream);
            if (handler.ReadToken(stream) is JwtSecurityToken tokenS)
            {
                var userId = tokenS.Claims.FirstOrDefault(x => x.Type == "sub")?.Value;
                defaultApp = _userManager.Users.FirstOrDefaultAsync(y => userId != null && y.Id.Equals(userId))
                    .Result?.DefaultApp;
            }
            return defaultApp;
        }
        public Task<Token> CreateIdentityTokenAsync(TokenCreationRequest request)
        {
            throw new NotImplementedException();
        }

        public async Task<TokenResponse> GetTokenEx(TokenCreationRequest request)
        {
            var token = await _defaultTokenService.CreateAccessTokenAsync(request);
            var accessToken = await _defaultTokenService.CreateSecurityTokenAsync(token);
            var refreshToken = await _refreshTokenService.CreateRefreshTokenAsync(request.Subject, token, request.ValidatedRequest.Client);

            var tokenResponse = new TokenResponse
            {
                AccessToken = accessToken,
                RefreshToken = refreshToken,
                ExpiresIn = 3200,
                TokenType = "Bearer",
            };

            if (!string.IsNullOrEmpty(accessToken))
                tokenResponse.DefaultApp = GetDefaultApp(tokenResponse.AccessToken);

            return tokenResponse;
        }

        public Task<Token> CreateAccessTokenAsync(TokenCreationRequest request)
        {
            throw new NotImplementedException();
        }

        public Task<string> CreateSecurityTokenAsync(Token token)
        {
            throw new NotImplementedException();
        }
    }
}
