﻿using AutoMapper;
using Brierley.Common.Web.Controllers.Response;
using IdentityModel;
using Logic.Interfaces;
using Logic.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Repository;
using Repository.CustomExceptions;
using Repository.ExtensionMethods;
using Repository.Interfaces;
using Repository.Models;
using Repository.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Logic.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepo;
        private readonly IMapper _mapper;
        private readonly ApplicationUserManager<AppUser> _userManager;
        private readonly IHttpClientAccessor _apiClient;
        private readonly IEmailService _emailService;

        public UserService(IUserRepository userRepo, IMapper mapper, ApplicationUserManager<AppUser> userManager, IHttpClientAccessor apiClient, IEmailService emailService)
        {
            _userManager = userManager;
            _apiClient = apiClient;
            _userRepo = userRepo;
            _mapper = mapper;
            _emailService = emailService;
        }

        public async Task<SearchResultViewModel> SearchUsers(SearchFilterViewModel searchFilterViewModel)
        {
            SearchResultViewModel memberEfs = new SearchResultViewModel()
            {
                UsersSearchResult = new List<UserResultViewModel>()
            };
            if (searchFilterViewModel != null)
            {
                SearchFilterDto searchFilter = _mapper.Map<SearchFilterDto>(searchFilterViewModel);
                var searchedUsers = await _userRepo.SearchUsers(searchFilter);
                var users = _mapper.Map<List<EditUserViewModel>>(searchedUsers);

                if (users.Count > 0)
                {
                    #region rback API call by role and program
                    var rbacUsers = new List<RbacUser>();
                    if (searchFilter.RoleId != 0 || searchFilter.ProgramId != 0)
                    {
                        try
                        {
                            rbacUsers = await _apiClient.GetAsync<List<RbacUser>>(Environment.GetEnvironmentVariable("PermissionsAPI_BaseUrl") + "api/v1/users/" + searchFilter.RoleId + "/" + searchFilter.ProgramId);
                            if (rbacUsers.Any())
                            {
                                var emails = rbacUsers.Select(u => u.EmailAddress);
                                users = users.Where(u => emails.Contains(u.Email)).ToList();
                            }
                            else
                                users = new List<EditUserViewModel>();
                        }
                        catch (Exception) { }
                    }
                    #endregion

                    if (users.Count > 0)
                    {
                        var propertyInfo = typeof(EditUserViewModel).GetProperty(searchFilter.SortField);
                        var sortedUser = searchFilter.SortType == "asc" ? users.OrderBy(x => propertyInfo.GetValue(x, null)?.ToString().ToLower())
                                                                        : users.OrderByDescending(x => propertyInfo.GetValue(x, null)?.ToString().ToLower());

                        memberEfs.UsersSearchResult = _mapper.Map<List<UserResultViewModel>>(sortedUser);
                        memberEfs.UsersSearchResult = memberEfs.UsersSearchResult.Skip((searchFilter.PageNumber - 1) * searchFilter.PageSize).Take(searchFilter.PageSize).ToList();

                        #region rback API call for role and pprogram mappings
                        var emailIds = String.Join(",", memberEfs.UsersSearchResult.Select(u => u.Email));
                        var userRolePrograms = await GetRbacUserRoleProgramsByEmail(emailIds);
                        #endregion

                        memberEfs.UsersSearchResult.ForEach(user =>
                        {
                            if (userRolePrograms.Count > 0)
                            {
                                var userPrograms = new List<UserProgram>();
                                var userRoleDetails = new List<UserRole>();
                                var rolePrograms = userRolePrograms.Where(up => up.EmailAddress == user.Email);
                                foreach (var ur in rolePrograms)
                                {
                                    if (!userPrograms.Any(up => up.ProgramId == ur.ProgramId))
                                    {
                                        userPrograms.Add(new UserProgram()
                                        {
                                            ProgramId = ur.ProgramId,
                                            ProgramName = String.Empty,
                                            UserRoleDetails = _mapper.Map<List<UserRole>>(userRolePrograms.Where(rp => rp.ProgramId == ur.ProgramId && rp.EmailAddress == user.Email).ToList())
                                        });
                                    }
                                }
                                user.UserPrograms = userPrograms;
                            }
                        });
                    }
                }
                memberEfs.UserCount = users.Count;
            }
            return memberEfs;
        }

        public async Task<UserViewModel> UpdateUser(EditUserViewModel user)
        {
            var originalUser = await _userRepo.GetUserById(user.UserId);

            if (!string.IsNullOrEmpty(user.PasswordHash))
            {
                var res = await _userManager.IsPasswordValid(originalUser, user.PasswordHash);

                if (!res.Succeeded)
                {
                    throw new InvalidPassword("Password Not Valid");
                }
            }

            // DOUBLE CHECK PASSWORD
            // If the user is updating their password, final check that they know the current password
            if (!string.IsNullOrEmpty(user.PasswordHash) &&
                !_userManager.CheckPasswordAsync(originalUser, user.CurrentPassword).Result)
            {
                throw new ForbiddenException("Not authenticated");
            }


            // CHECK PASSWORD HISTORY
            // Check if the password the user sent was previously used and can't be reused
            if (!string.IsNullOrEmpty(user.PasswordHash) &&
                originalUser.PasswordQueue.Split(',')
                    .Any(x => x.ToDecrypt()
                        .Equals(user.PasswordHash)))
            {
                throw new PasswordAlreadyUsedException("This is one of the last 3 passwords");
            }


            // UPDATE PASSWORD QUEUE
            // If the user is updating their password, push it into their queue so that it only includes
            // the last 3 passwords
            Queue<string> passwordQueue = new Queue<string>(originalUser.PasswordQueue?.Split(',')?.Take(3));
            if (!string.IsNullOrEmpty(user.PasswordHash) &&
                !passwordQueue.Contains(null) &&
                passwordQueue.Count >= 3)
            {
                passwordQueue.Dequeue();
            }


            // UPDATE PASSWORD
            // If the user is updating their password, encrypt it and reassign it to the user object.
            if (!string.IsNullOrEmpty(user.PasswordHash))
            {
                passwordQueue.Enqueue(user.PasswordHash.ToEncrypt());
                originalUser.PasswordQueue = string.Empty;
                for (int i = 0; i < passwordQueue.Count; i++)
                {
                    originalUser.PasswordQueue =
                        i == 0 ? $"{passwordQueue.ToArray()[i]}" : $"{originalUser.PasswordQueue},{passwordQueue.ToArray()[i]}";
                }
            }
            originalUser.Email = user.Email ?? originalUser.Email;
            originalUser.FirstName = user.FirstName ?? originalUser.FirstName;
            originalUser.LastName = user.LastName ?? originalUser.LastName;
            originalUser.AlternateEmail = user.AlternateEmail ?? originalUser.AlternateEmail;
            originalUser.PhoneNumber = user.PhoneNumber ?? originalUser.PhoneNumber;
            originalUser.ExternalId = user.ExternalId ?? originalUser.ExternalId;
            //originalUser.Status = user.Status;  //Commented this because the status is resetting to false, when user edits
            var result = await _userManager.UpdateAsync(originalUser);

            if (!string.IsNullOrEmpty(user.PasswordHash) && result.Succeeded)
            {
                await _userManager.ChangePasswordAsync(originalUser, user.CurrentPassword, user.PasswordHash);
            }

            var updatedUser = _mapper.Map<UserViewModel>(user);

            updatedUser.UserName = originalUser.UserName;
            updatedUser.DefaultApp = originalUser.DefaultApp;
            return updatedUser;
        }

        public async Task<UserViewModel> GetUserById(string id)
        {
            var user = await _userRepo.GetUserById(id);
            var userViewModel = _mapper.Map<UserViewModel>(user);
            var userAccountPreference = new UserAccountPreference();
            if (user.UserPreferences != null)
            {
                userAccountPreference.DefaultApplication = user.UserPreferences.DefaultApplication;
                userAccountPreference.DefaultLanguage = String.IsNullOrEmpty(user.UserPreferences.DefaultLanguage) ? UserPreferenceConstant.DefaultLanguage : user.UserPreferences.DefaultLanguage;
                userAccountPreference.DefaultListView = String.IsNullOrEmpty(user.UserPreferences.DefaultListView) ? UserPreferenceConstant.DefaultView : user.UserPreferences.DefaultListView;
            }
            else
            {
                userAccountPreference.DefaultApplication = "";
                userAccountPreference.DefaultLanguage = UserPreferenceConstant.DefaultLanguage;
                userAccountPreference.DefaultListView = UserPreferenceConstant.DefaultView;
            }

            userViewModel.UserAccountPreference = userAccountPreference;
            #region rback API call for role and pprogram mappings
            var userRolePrograms = await GetRbacUserRoleProgramsByEmail(userViewModel.Email);
            #endregion
            if (userRolePrograms.Count > 0)
            {
                var userPrograms = new List<UserProgram>();
                var userRoleDetails = new List<UserRole>();
                foreach (var ur in userRolePrograms)
                {
                    if (!userPrograms.Any(up => up.ProgramId == ur.ProgramId))
                    {
                        userPrograms.Add(new UserProgram()
                        {
                            ProgramId = ur.ProgramId,
                            UserRoleDetails = _mapper.Map<List<UserRole>>(userRolePrograms.Where(rp => rp.ProgramId == ur.ProgramId).ToList())
                        });
                    }
                }
                userViewModel.UserPrograms = userPrograms;
            }
            return userViewModel;
        }

        public async Task<bool> ActivateDeActivateUser(string userId)
        {
            var isDeleted = await _userRepo.ActivateDeActivateUser(userId);
            return isDeleted;
        }

        public async Task<bool> SetUserDefaultApp(string userId, string defaultApp)
        {
            return await _userRepo.SetUserDefaultAppAsync(userId, defaultApp);
        }

        public async Task<UserViewModel> CreateUser(CreateUserViewModel user)
        {
            var appUser = _mapper.Map<AppUser>(user);
            appUser.LockoutEnabled = true;
            appUser.PasswordSignUpToken = Guid.NewGuid();
            appUser.PasswordSignUpTokenEndTime = DateTimeOffset.Now.AddDays(1);
            appUser.UserStatusId = user.IsProfileComplete ?
                UserStatuses.PendingSignup : UserStatuses.Draft;
            var userAlreadyExists = await _userManager.Users
                .AnyAsync(x => (x.Email.ToLower() == appUser.Email.ToLower()) &&
                x.TenantId == appUser.TenantId);

            if (userAlreadyExists)
            {
                throw new UniqueEmailException($"The email address {appUser.Email} is already taken.");
            }

            var result = await _userManager.CreateAsync(appUser, user.PasswordHash);
            await _userRepo.SetUserDefaultListView(appUser.Id);
            IList<Claim> claims = new List<Claim>
            {
                new Claim(JwtClaimTypes.Email, appUser.Email),
                new Claim(JwtClaimTypes.Role, user.Roles),
                new Claim("tenant", appUser.TenantId),
                new Claim("defaultApp", string.Empty)
            };
            if (!result.Succeeded)
            {
                throw new InvalidOperationException(JsonConvert.SerializeObject(result.Errors.Select(x => x.Description)));
            }

            if (result.Succeeded)
            {
                var reqObj = _mapper.Map<UserRoleMapRequest>(user);
                await UserRoleMap(reqObj);
                await _userManager.AddClaimsAsync(appUser, claims);
            }

            var createdUser = _mapper.Map<UserViewModel>(appUser);
            try
            {
                if (appUser.UserStatusId != UserStatuses.Draft)
                    Task.Run(() => _emailService.UserSignUpEmail(appUser));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            return createdUser;
        }

        public async Task<CommonResponse> SignUpComplete(PasswordSignUpViewModel passwordSignUpViewModel)
        {
            var appUser = await _userManager.Users.Where(x => x.Id.Equals(passwordSignUpViewModel.Id))
                .FirstOrDefaultAsync();
            if (appUser == null)
            {
                return new CommonResponse
                {
                    IsError = true,
                    DeveloperMessage = "User Not Found",
                    HttpStatusCode = StatusCodes.Status204NoContent,
                    UserMessage = "User does not exist"
                };
            }
            appUser.FirstName = passwordSignUpViewModel.FirstName;
            appUser.LastName = passwordSignUpViewModel.LastName;
            appUser.PhoneNumber = passwordSignUpViewModel.PhoneNumber;
            appUser.ExternalId = passwordSignUpViewModel.ExternalId;
            var result = await _userManager.ChangePasswordAsync(appUser, new CreateUser().PasswordHash, passwordSignUpViewModel.Password);
            if (result.Succeeded)
            {
                appUser.UserStatusId = UserStatuses.Active;
                result = await _userManager.UpdateAsync(appUser);
            }
            var response = result.Succeeded ? new CommonResponse
            {
                HttpStatusCode = StatusCodes.Status201Created,
                UserMessage = "Successfuly Updated"
            } : new CommonResponse
            {
                HttpStatusCode = StatusCodes.Status400BadRequest,
                UserMessage = "Sign Up Failed",
                DeveloperMessage = JsonConvert.SerializeObject(result.Errors)
            };
            return response;
        }

        public async Task<bool> updateUserStatus(string userId)
        {
            var result = await _userRepo.updateUserStatus(userId);
            try
            {
                Task.Run(() => _emailService.UserSignUpEmail(result));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            return true;
        }

        public async Task<CommonResponse> GetSignUpExpiredUsers()
        {
            IList<AppUser> users = await _userRepo.GetSignUpExpiredUsers();
            CommonResponse response = new CommonResponse
            {
                Data = users == null ? new List<UserViewModel>() : _mapper.Map<IList<UserViewModel>>(users),
                HttpStatusCode = StatusCodes.Status200OK
            };
            return response;
        }

        public async Task<bool> UserRoleMap(UserRoleMapRequest reqObj)
        {
            bool status = false;
            try
            {
                status = await _apiClient.PostAsync<UserRoleMapRequest, bool>(Environment.GetEnvironmentVariable("PermissionsAPI_BaseUrl") + "api/v1/permissions/user/roles", reqObj);
            }
            catch (Exception)
            {
            }
            return status;
        }

        private async Task<List<RbacUserRoleProgram>> GetRbacUserRoleProgramsByEmail(string emailIds)
        {
            var userRolePrograms = new List<RbacUserRoleProgram>();
            try
            {
                userRolePrograms = await _apiClient.GetAsync<List<RbacUserRoleProgram>>(Environment.GetEnvironmentVariable("PermissionsAPI_BaseUrl") + "api/v1/users/roleprogram/" + emailIds);
            }
            catch (Exception) { }

            return userRolePrograms;
        }

        public async Task<CommonResponse> SetUserDefaultPreferences(UserPreferencesViewModel userPreference)
        {
            CommonResponse commonResponse = new CommonResponse();
            var result = await _userRepo.SetUserDefaultPreferences(userPreference.UserId, userPreference.DefaultLanguage, userPreference.DefaultApplication, userPreference.DefaultListView);

            return new CommonResponse
            {
                Data = result,
                HttpStatusCode = result ? StatusCodes.Status200OK : StatusCodes.Status400BadRequest,
                DeveloperMessage = result ? "Updated Successfully" : "Record Not Updated or Not Found"
            };
        }

        public async Task<CommonResponse> GetUserDetailsByUserIds(List<string> userIds)
        {
            var result = await _userRepo.GetUserDetailsByUserIds(userIds);
            var usersDetails = _mapper.Map<List<UserDetailsByIds>>(result);
            return new CommonResponse
            {
                Data = usersDetails,
                HttpStatusCode = result.Any() ? StatusCodes.Status200OK : StatusCodes.Status404NotFound,
                DeveloperMessage = result.Any() ? "returned Successfully" : "Records Not Found"
            };
        }

        public void Dispose()
        {

        }
    }
}