using Logic.Interfaces;
using Logic.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Repository.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Logic.Services
{
    public class EmailService : IEmailService
    {
        private readonly IConfiguration _configuration;
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public EmailService(IConfiguration configuration, HttpClient httpClient, IHttpContextAccessor httpContextAccessor)
        {
            _configuration = configuration;
            _httpContextAccessor = httpContextAccessor;
            _httpClient = httpClient;
        }

        public async Task SendEmail(AppUser user, string tenantId)
        {
            try
            {
                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var emailReq = new ForgotPasswordRequest
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    ResetPasswordLink = Environment.GetEnvironmentVariable("Emailhost_BaseURL") +
                                          "reset/resetpassword/" + user.PasswordResetToken,
                    TenantId = tenantId,
                    ToList = new List<string> { user.Email }
                };
                string json = JsonConvert.SerializeObject(emailReq);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync(
                    Environment.GetEnvironmentVariable("CommunicationAPI_BaseURL") + _configuration["SendEmailApi"],
                    data);
                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    await _httpClient.PostAsync(
                        Environment.GetEnvironmentVariable("CommunicationAPI_BaseURL") + "communication" +
                        _configuration["SendEmailApi"], data);
                }



            }
            catch (Exception e)
            {
                Console.WriteLine(e.InnerException);
                if (e.InnerException != null)
                {
                    Console.WriteLine(e.InnerException.Message);
                }

                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.WriteLine(e.Source);
                throw;
            }
        }

        public async Task UserSignUpEmail(AppUser user)
        {
            try
            {
                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var headers = _httpContextAccessor?.HttpContext?.Request?.Headers;
                if (headers != null && headers.ContainsKey("Authorization"))
                {
                    var authString = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];
                    var token = authString.ToString().Split(" ")[1];
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                }
                var emailReq = new SignUpInviteRequest
                {
                    SignUpLink = Environment.GetEnvironmentVariable("Web_BaseUrl") +
                                          "loyaltyadmin/signup/" + user.Email+"/"+user.PasswordSignUpToken,
                    UserEmail=user.Email
                };
                string json = JsonConvert.SerializeObject(emailReq);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync(
                    Environment.GetEnvironmentVariable("CommunicationAPI_BaseURL") + _configuration["signupinvite"],
                    data);
                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    await _httpClient.PostAsync(
                        Environment.GetEnvironmentVariable("CommunicationAPI_BaseURL") + "communication" +
                        _configuration["SignUpEmailApi"], data);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.InnerException);
                if (e.InnerException != null)
                {
                    Console.WriteLine(e.InnerException.Message);
                }

                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.WriteLine(e.Source);
                throw;
            }
        }



    }
}