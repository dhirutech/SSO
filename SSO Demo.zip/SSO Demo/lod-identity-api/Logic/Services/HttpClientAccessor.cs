﻿using Logic.Interfaces;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Logic.Services
{
    public class HttpClientAccessor : IHttpClientAccessor
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string _authToken;
        public HttpClientAccessor(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = new HttpClient();
            _client.DefaultRequestHeaders.Add("Accept", "application/json");

            _client.DefaultRequestHeaders.Accept.Clear();
            var headers = _httpContextAccessor?.HttpContext?.Request?.Headers;
            if (headers != null && headers.ContainsKey("Authorization"))
            {
                var authString = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];
                _authToken = authString.ToString().Split(" ")[1];
            }
        }

        public async Task<Tr> PostAsync<Tq, Tr>(string url, Tq req)
        {
            return await CreateRequest<Tr>(url, HttpMethod.Post, req, _authToken);
        }

        public async Task<Tr> PutAsync<Tq, Tr>(string url, Tq req)
        {
            return await CreateRequest<Tr>(url, HttpMethod.Put, req, _authToken);
        }

        public async Task<Tr> GetAsync<Tr>(string url)
        {
            return await CreateRequest<Tr>(url, HttpMethod.Get, _authToken);
        }

        public async Task<Tr> DeleteAsync<Tr>(string url)
        {
            return await CreateRequest<Tr>(url, HttpMethod.Delete, _authToken);
        }

        #region private methods

        async Task<Tr> CreateRequest<Tr>(string url, HttpMethod method, string authToken)
        {
            return await CreateRequestMessage(url, method, authToken, async (msg) =>
            {
                return await GetResult<Tr>(msg);
            });
        }

        async Task<Tr> CreateRequest<Tr>(string url, HttpMethod method, object reqObj, string authToken)
        {
            return await CreateRequestMessage(url, method, authToken, async (msg) =>
            {
                using (var content = new StringContent(JObject.FromObject(reqObj).ToString()))
                {
                    content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    msg.Content = content;
                    return await GetResult<Tr>(msg);
                }
            });
        }

        async Task<Tr> CreateRequestMessage<Tr>(string url, HttpMethod method, string authToken, Func<HttpRequestMessage, Task<Tr>> functor)
        {
            using (var msg = new HttpRequestMessage())
            {
                msg.RequestUri = new Uri(url);
                msg.Method = method;
                if (authToken != null)
                    msg.Headers.Authorization = new AuthenticationHeaderValue("Bearer", authToken);
                return await functor(msg);
            }
        }

        async Task<Tr> GetResult<Tr>(HttpRequestMessage msg)
        {
            using (var response = await _client.SendAsync(msg))
            {
                using (var content = response.Content)
                {
                    var responseContent = await content.ReadAsStringAsync();
                    if (!response.IsSuccessStatusCode)
                        throw new Exception(responseContent);
                    if (typeof(IConvertible).IsAssignableFrom(typeof(Tr)))
                        return (Tr)Convert.ChangeType(responseContent, typeof(Tr));
                    return JToken.Parse(responseContent).ToObject<Tr>();
                }
            }
        }

        #endregion
    }
}
