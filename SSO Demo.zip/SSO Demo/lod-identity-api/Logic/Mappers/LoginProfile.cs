﻿using AutoMapper;
using Logic.Constants;
using Logic.ViewModels;
using Repository.ExtensionMethods;
using Repository.Models;
using Repository.ViewModels;
using System;
using System.Linq;

namespace Logic.Mappers
{
    public class LoginProfile : Profile
    {
        public LoginProfile()
        {
            CreateMap<CreateUserViewModel, AppUser>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.UserId))
                .ForMember(dest => dest.TenantId, opt => opt.MapFrom(src => src.TenantId.ToUpper()))
                .ForMember(dest => dest.PasswordQueue, opt => opt.MapFrom(src => src.PasswordHash.ToEncrypt()))
                .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => String.IsNullOrWhiteSpace(src.UserName) ? src.Email : src.UserName))
                .ForMember(dest => dest.CreatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ForMember(dest => dest.UpdatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ReverseMap()
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => src.Id));

            CreateMap<EditUser, AppUser>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.TenantId, opt => opt.MapFrom(src => src.TenantId.ToUpper()))
                .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => src.Email))
                .ForMember(dest => dest.CreatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ForMember(dest => dest.UpdatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ReverseMap()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id));

            CreateMap<EditUserViewModel, AppUser>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.UserId))
                .ForMember(dest => dest.TenantId, opt => opt.MapFrom(src => src.TenantId.ToUpper()))
                .ForMember(dest => dest.CreatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ForMember(dest => dest.UpdatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ReverseMap()
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => src.Id));

            CreateMap<UserViewModel, AppUser>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.UserId))
                .ForMember(dest => dest.TenantId, opt => opt.MapFrom(src => src.TenantId.ToUpper()))
                .ForMember(dest => dest.CreatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ForMember(dest => dest.UpdatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ReverseMap()
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => src.Id));

            CreateMap<UserViewModel, CreateUserViewModel>()
                .ForMember(dest => dest.CreatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ForMember(dest => dest.UpdatedDate, opt => opt.MapFrom(src => DateTime.Now));

            CreateMap<UserViewModel, EditUserViewModel>()
                .ForMember(dest => dest.CreatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ForMember(dest => dest.UpdatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ReverseMap();

            CreateMap<UserViewModels, UserDto>()
                .ReverseMap()
                .ForMember(dest => dest.NewPassword, opt => opt.MapFrom(src => src.NewPassword.ToDecrypt()))
                .ForMember(dest => dest.OldPassword, opt => opt.MapFrom(src => src.OldPassword.ToDecrypt()));

            CreateMap<SearchFilterViewModel, SearchFilterDto>()
                .ForMember(dest => dest.SearchText, opt => opt.MapFrom(src => (String.IsNullOrWhiteSpace(src.SearchText) || src.SearchText == "null") ? String.Empty : src.SearchText.Trim().ToUpper()))
                .ForMember(dest => dest.SortField, opt => opt.MapFrom(src => GetSortFieldName(src, false)))
                .ForMember(dest => dest.SortType, opt => opt.MapFrom(src => GetSortFieldName(src, true)))
                .ForMember(dest => dest.PageNumber, opt => opt.MapFrom(src => src.PageNumber == 0 ? 1 : src.PageNumber))
                .ForMember(dest => dest.PageSize, opt => opt.MapFrom(src => src.PageSize == 0 ? 10 : src.PageSize));

            CreateMap<CreateUserViewModel, EditUserViewModel>()
                .ForMember(dest => dest.CreatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ForMember(dest => dest.UpdatedDate, opt => opt.MapFrom(src => DateTime.Now))
                .ReverseMap();

            CreateMap<EditUserViewModel, UserResultViewModel>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.UserId))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.FirstName + " " + src.LastName))
                .ForMember(dest => dest.Active, opt => opt.MapFrom(src => src.Status));

            CreateMap<PasswordSignUpViewModel, AppUser>().ReverseMap();
            CreateMap<UserStatusViewModel, Repository.Models.UserStatus>().ReverseMap();
            CreateMap<UserStatusViewModel, UserStatusViewModel>().ReverseMap();
            CreateMap<UserProgramRolesViewModel, UserProgramRolesViewModel>().ReverseMap();

            CreateMap<CreateUserViewModel, UserRoleMapRequest>()
                .ForMember(dest => dest.UserGuidId, opt => opt.MapFrom(src => Guid.Parse(src.UserId)))
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => 0))
                .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => src.UserName))
                .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.FirstName))
                .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LastName))
                .ForMember(dest => dest.PhoneNumber, opt => opt.MapFrom(src => src.PhoneNumber))
                .ForMember(dest => dest.EmailAddress, opt => opt.MapFrom(src => src.Email))
                .ForMember(dest => dest.UserStatus, opt => opt.MapFrom(src => src.Status))
                .ReverseMap()
                .ForMember(dest => dest.UserPrograms, opt => opt.MapFrom(src => src.UserPrograms));

            CreateMap<EditUser, UserRoleMapRequest>()
                .ForMember(dest => dest.UserGuidId, opt => opt.MapFrom(src => Guid.Parse(src.Id)))
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => 0))
                .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => src.UserName))
                .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.FirstName))
                .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LastName))
                .ForMember(dest => dest.PhoneNumber, opt => opt.MapFrom(src => src.PhoneNumber))
                .ForMember(dest => dest.EmailAddress, opt => opt.MapFrom(src => src.Email))
                .ForMember(dest => dest.UserStatus, opt => opt.MapFrom(src => src.Status))
                .ReverseMap()
                .ForMember(dest => dest.UserPrograms, opt => opt.MapFrom(src => src.UserPrograms));

            CreateMap<RbacUserRoleProgram, UserProgram>()
                .ForMember(dest => dest.ProgramId, opt => opt.MapFrom(src => src.ProgramId))
                .ForMember(dest => dest.ProgramName, opt => opt.MapFrom(src => String.Empty));

            CreateMap<RbacUserRoleProgram, UserRole>()
                .ForMember(dest => dest.RoleId, opt => opt.MapFrom(src => src.RoleId))
                .ForMember(dest => dest.RoleName, opt => opt.MapFrom(src => src.RoleName));

            CreateMap<AppUser, UserDetailsByIds > ()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id != null ? src.Id : String.Empty))
                .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.FirstName != null ? src.FirstName : String.Empty))
                .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LastName != null ? src.LastName : String.Empty))
                .ForMember(dest => dest.TenantId, opt => opt.MapFrom(src => src.TenantId != null ? src.TenantId : String.Empty))
                .ForMember(dest => dest.AlternateEmail, opt => opt.MapFrom(src => src.AlternateEmail != null ? src.AlternateEmail : String.Empty))
                .ForMember(dest => dest.Roles, opt => opt.MapFrom(src => src.Roles != null ? src.Roles : String.Empty))
                .ForMember(dest => dest.ExternalId, opt => opt.MapFrom(src => src.ExternalId != null ? src.ExternalId : String.Empty));
                }

        private string GetSortFieldName(SearchFilterViewModel searchParams, bool type)
        {
            var sortType = UserSearchConstants.SORTTYPE;
            var sortField = UserSearchConstants.SORTFIELD_CREATEDDATE;
            if (!(String.IsNullOrWhiteSpace(searchParams.NameSortType) || searchParams.NameSortType == "null"))
            {
                sortField = UserSearchConstants.SORTFIELD_FIRSTNAME;
                sortType = searchParams.NameSortType.ToLower();
            }
            else if (!(String.IsNullOrWhiteSpace(searchParams.ExternalIdSortType) || searchParams.ExternalIdSortType == "null"))
            {
                sortField = UserSearchConstants.SORTFIELD_EXTERNALID;
                sortType = searchParams.ExternalIdSortType.ToLower();
            }
            else if (!(String.IsNullOrWhiteSpace(searchParams.EmailSortType) || searchParams.EmailSortType == "null"))
            {
                sortField = UserSearchConstants.SORTFIELD_EMAIL;
                sortType = searchParams.EmailSortType.ToLower();
            }
            else if (!(String.IsNullOrWhiteSpace(searchParams.StatusSortType) || searchParams.StatusSortType == "null"))
            {
                sortField = UserSearchConstants.SORTFIELD_STATUS;
                sortType = searchParams.StatusSortType.ToLower();
            }

            if (type)
                return sortType;
            else
                return sortField;
        }
    }
}
