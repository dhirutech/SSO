﻿namespace Logic.Constants
{
    public static class UserSearchConstants
    {
        public static string SORTTYPE = "desc";
        public static string SORTFIELD_CREATEDDATE = "CreatedDate";
        public static string SORTFIELD_FIRSTNAME = "FirstName";
        public static string SORTFIELD_EXTERNALID = "ExternalId";
        public static string SORTFIELD_EMAIL = "Email";
        public static string SORTFIELD_STATUS = "Status";
    }
}
